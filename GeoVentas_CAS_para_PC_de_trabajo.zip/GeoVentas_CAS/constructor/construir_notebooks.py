# -*- coding: utf-8 -*-
"""Arma los notebooks (.ipynb) a partir de los archivos fuente nb_XX.py de esta carpeta.

Formato de los fuentes: celdas separadas por '# %%' (código) y '# %% [markdown]' (texto; cada línea empieza con '# ').
Uso:
    python constructor/construir_notebooks.py                 # solo arma los .ipynb en la carpeta del proyecto
    python constructor/construir_notebooks.py --ejecutar      # además los ejecuta en modo simulación y guarda copias
                                                              # ejecutadas en ejecutados_simulacion/
"""
import argparse
import glob
import os
import re
import sys
import time

import nbformat
from nbformat.v4 import new_notebook, new_code_cell, new_markdown_cell

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)


def leer_fuente(ruta):
    txt = open(ruta, encoding="utf-8").read()
    bloques = re.split(r"^# %%(.*)$", txt, flags=re.M)
    celdas = []
    for i in range(1, len(bloques), 2):
        marca, cuerpo = bloques[i], bloques[i + 1].strip("\n")
        if "[markdown]" in marca:
            lineas = [re.sub(r"^# ?", "", l) for l in cuerpo.split("\n")]
            celdas.append(new_markdown_cell("\n".join(lineas).strip()))
        elif cuerpo.strip():
            celdas.append(new_code_cell(cuerpo.rstrip()))
    return celdas


def armar(nombre_fuente):
    celdas = leer_fuente(nombre_fuente)
    nb = new_notebook(cells=celdas)
    nb.metadata["kernelspec"] = {"name": "python3", "display_name": "Python 3", "language": "python"}
    nb.metadata["language_info"] = {"name": "python"}
    titulo = os.path.basename(nombre_fuente).replace("nb_", "").replace(".py", "")
    destino = os.path.join(RAIZ, f"{titulo}.ipynb")
    nbformat.write(nb, destino)
    return destino


def ejecutar(ruta, salida_dir, kernel="python3", timeout=7200):
    from nbclient import NotebookClient
    nb = nbformat.read(ruta, as_version=4)
    t0 = time.time()
    NotebookClient(nb, timeout=timeout, kernel_name=kernel, resources={"metadata": {"path": RAIZ}}).execute()
    os.makedirs(salida_dir, exist_ok=True)
    destino = os.path.join(salida_dir, os.path.basename(ruta))
    nbformat.write(nb, destino)
    print(f"  ejecutado en {time.time() - t0:,.0f} s -> {destino}", flush=True)
    return destino


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--ejecutar", action="store_true")
    ap.add_argument("--solo", default=None, help="prefijo de los notebooks a ejecutar, p. ej. 03")
    ap.add_argument("--kernel", default="python3")
    a = ap.parse_args()
    fuentes = sorted(glob.glob(os.path.join(AQUI, "nb_*.py")))
    rutas = [armar(f) for f in fuentes]
    print("notebooks armados:", [os.path.basename(r) for r in rutas])
    if a.ejecutar:
        for r in rutas:
            if a.solo and not os.path.basename(r).startswith(tuple(a.solo.split(","))):
                continue
            print("ejecutando", os.path.basename(r), flush=True)
            ejecutar(r, os.path.join(RAIZ, "ejecutados_simulacion"), a.kernel)
