# %% [markdown]
# # 01 · Ingesta y calidad de las bases Equifax
# **Hito 1 del FRF · "Ingesta de fuentes Equifax y públicas"**
#
# **Qué hace:** lee las 6 bases de Equifax desde el bucket (o las simuladas), se queda **solo con el área de estudio**
# (Región Metropolitana) y **solo con las columnas necesarias**, revisa su calidad y deja todo listo en `trabajo/`.
#
# | Entra | Sale (carpeta `trabajo/`) |
# |---|---|
# | censo SD06, personas, empresas, BBRR, POIs PI01, calles BC08 | `censo.parquet`, `area_estudio.gpkg`, `per.parquet`, `emp.parquet`, `bbrr.parquet`, `pois.parquet`, `calles.parquet`, `calidad_bases.csv` |
#
# **Ideas clave**
# * Las bases son enormes (personas: 17 millones de filas). Se leen **por bloques** y se filtran al vuelo: nunca se carga Chile entero.
# * **Datos sensibles:** de personas y BBRR NO se leen nombres ni direcciones. El RUT solo se usa para un *hash* (si la clínica
#   manda RUT seudonimizados) y luego se descarta.
# * Los archivos de `gs://` se descargan **una vez** a `cache_gcs/`; la segunda vez la lectura es inmediata.
#
# Tiempo aproximado: simulación 1–2 min · real 10–25 min la primera vez (descarga desde GCS).

# %%
import os, re, sys
sys.path.insert(0, os.path.abspath("."))
import pandas as pd
from IPython.display import display
import config_estudio
from geoventas import insumos, lectura, mapas, verificacion, coordenadas
from geoventas.utilidades import Cronometro, guardar, miles, carpeta_salida, norm_txt

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "01")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("01_ingesta")
print("Modo:", cfg["modo"], "· carpeta de trabajo:", cfg["carpetas"]["trabajo"])

# %% [markdown]
# ## 1. ¿Qué columnas usamos de cada base?
# El código trabaja con **nombres cortos** (izquierda) que apuntan a las **columnas originales** de cada base (derecha).
# Si alguna columna cambia de nombre en el futuro, solo se corrige en `config_estudio.py` → `COLUMNAS`.

# %%
mapeo = lectura.tabla_mapeo(cfg)
mapeo.pivot_table(index="nombre_en_el_codigo", columns="base", values="columna_original", aggfunc="first").fillna("")

# %% [markdown]
# ## 2. Censo (manzanas) y área de estudio
# Leemos las manzanas de la región (filtro `ID_REG = 13` al leer). Con ellas armamos el **área de estudio**:
# el contorno de las zonas pobladas más 1,5 km. Todas las demás bases se recortan a esta área.

# %%
censo = lectura.leer_censo(cfg, log)
area = lectura.construir_area_estudio(censo, cfg)
print(f"Área de estudio: {area.to_crs(cfg['estudio']['crs_metrico']).area.iloc[0] / 1e6:,.0f} km²")
censo.head(3)

# %% [markdown]
# ### ¿En qué unidad viene el gasto en salud del censo?
# Es clave para el modelo. Dividimos el gasto en salud de cada GSE por sus hogares: si da del orden de 100.000 a
# 600.000 pesos por hogar, el gasto es **mensual**; si da 12 veces más, es **anual** (hay que cambiar
# `PARAMETROS["censo"]["unidad_gasto"]` en la configuración).

# %%
dg = lectura.diagnostico_gasto_censo(censo, cfg)
dg_vista = dg.copy()
for c in ("población", "hogares", "gasto salud total", "gasto salud por hogar", "gasto salud por persona"):
    dg_vista[c] = dg_vista[c].map(miles)
print("Unidad configurada:", cfg["censo"]["unidad_gasto"])
dg_vista

# %%
# Si los datos contradicen la unidad configurada (p. ej. el gasto parece anual), el notebook se detiene y lo pide.
unidad = insumos.verificar_unidad_gasto(dg, cfg)
insumos.detener_si_falta([unidad], "Unidad del gasto del censo")
chk("Gasto en salud del censo coherente con la unidad configurada", unidad.estado == insumos.OK, unidad.detalle)

# %% [markdown]
# ### Mapa: comunas del área de estudio
# Cada comuna pintada según el **% de población AB, C1a y C1b** (el segmento objetivo del FRF). Haz clic en una comuna.

# %%
C = cfg["columnas"]["censo"]
cols_obj = [C["pob_gse"].format(gse=g) for g in cfg["gse_objetivo"]]
com = censo[[C["comuna"], C["pob"], "geometry"] + cols_obj].copy()
com["pob_objetivo"] = com[cols_obj].sum(axis=1)
com = com.dissolve(C["comuna"], aggfunc="sum").reset_index()
com["pct_objetivo"] = 100 * com["pob_objetivo"] / com[C["pob"]]
com["comuna_txt"] = com[C["comuna"]].astype(str).str.title()
mapas.mapa([
    mapas.capa(area, "Área de estudio", color="#ffffff", opacidad=0.0, borde="#0e2a47", peso=2),
    mapas.capa(com, "% de vecinos de nivel socioeconómico alto (AB, C1a y C1b)", campo_color="pct_objetivo", paleta="morado",
               popup=["comuna_txt", C["pob"], "pob_objetivo", "pct_objetivo"], titulo_popup="comuna_txt",
               etiquetas_popup={C["pob"]: "Habitantes", "pob_objetivo": "Personas de nivel alto (AB, C1a, C1b)", "pct_objetivo": "% de nivel alto"},
               formato_popup={C["pob"]: "entero", "pob_objetivo": "entero", "pct_objetivo": "pct100"},
               etiqueta="comuna_txt", simplificar_m=40, opacidad=0.7, peso=0.6, borde="#ffffff"),
], titulo="Comunas del área de estudio y su público objetivo", subtitulo="Más oscuro = mayor proporción de vecinos AB, C1a y C1b (censo)",
   ayuda=["Este mapa muestra comunas completas. Desde el notebook 03 todo se ve manzana por manzana."],
   archivo=os.path.join(carpeta_salida(cfg, "mapas"), "01_comunas_objetivo.html"))

# %% [markdown]
# ## 3. Personas (base `per`)
# Leemos solo edad, sexo, GSE, coordenadas del domicilio, tamaño del hogar, autos, BBRR, hijos, Dicom y renta del hogar.
# Se excluyen los fallecidos (`FECHA_DEFUNCION` con una fecha real o `DEFUNCION` marcada; si más del 30% apareciera
# fallecido, la columna no significa lo esperado y no se excluye a nadie). **No** se leen nombres ni direcciones.

# %%
per = lectura.leer_personas(cfg, area, log)
print("Columnas que quedaron:", list(per.columns))
per.drop(columns=["rut_hash"], errors="ignore").head(3)

# %% [markdown]
# ### Control de consistencia: ¿la base de personas se parece al censo?
# Si la distribución por GSE de `per` es muy distinta a la del censo, conviene saberlo antes de usarla.

# %%
dist_per = per["gse"].value_counts(normalize=True).reindex(cfg["gse"]).fillna(0)
dist_censo = pd.Series({g: pd.to_numeric(censo[C["pob_gse"].format(gse=g)], errors="coerce").sum() for g in cfg["gse"]})
dist_censo = dist_censo / dist_censo.sum()
comp_gse = pd.DataFrame({"% en censo": (100 * dist_censo).round(1), "% en base personas": (100 * dist_per).round(1)})
comp_gse["diferencia (pp)"] = comp_gse["% en base personas"] - comp_gse["% en censo"]
chk("Distribución GSE de personas parecida a la del censo (diferencia máx ≤ 8 pp)", comp_gse["diferencia (pp)"].abs().max() <= 8,
    f"máx {comp_gse['diferencia (pp)'].abs().max():.1f} pp")
comp_gse

# %% [markdown]
# ## 4. Empresas, bienes raíces, POIs y calles
# * **Empresas:** solo activas. Trabajadores = `CANTIDAD_TRAB`; si viene vacío, el **promedio de las empresas del mismo tamaño
#   que sí traen el dato** en la misma base. Un valor fijo (p. ej. "grande" = 600) puede errar por mucho, porque el tamaño
#   SII se define por ventas, no por empleo; y la demanda flotante depende de la **suma** de trabajadores. La tabla de
#   abajo muestra qué valor se usó para cada tamaño y de dónde salió.
# * **BBRR:** solo destino (`CODIGO_DESTINO`), avalúo, superficie y coordenadas (sin propietarios).
# * **POIs:** se descartan los cerrados; se arma un texto con CAT1, CAT2 y CAT3 para clasificarlos.
# * **Calles:** Maestro de Calles, que usaremos para geocodificar direcciones y medir vías principales.

# %%
emp = lectura.leer_empresas(cfg, area, log)
print("Origen del dato de trabajadores:", emp["fuente_trabajadores"].value_counts().to_dict())
trab_tam = pd.DataFrame(emp.attrs.get("trabajadores_por_tamano", {}))
display(trab_tam)
bbrr = lectura.leer_bbrr(cfg, area, log)
print("Destinos BBRR:", bbrr["grupo_destino"].value_counts().head(8).to_dict())
pois = lectura.leer_pois(cfg, area, log)
calles = lectura.leer_calles(cfg, area, log)
# %% [markdown]
# ### ¿Cómo viene el RUT en personas y empresas?
# Para cruzar con los pacientes, cada RUT se lleva a una **forma canónica** (cuerpo + dígito verificador, sin puntos,
# guion ni ceros a la izquierda): el `RUTID` de personas (`0216897560`) y el de empresas (`784372936`) quedan escritos
# igual que `21.689.756-0`, `21689756-0` o `216897560` en el archivo de la clínica. Si una base trajera el RUT sin
# dígito verificador, se detecta y se calcula. La tabla muestra los formatos encontrados, **sin mostrar ningún RUT**.

# %%
info_rut = {b: df.attrs.get("rut") for b, df in (("personas", per), ("empresas", emp))}
if any(info_rut.values()):
    display(pd.DataFrame([{"base": b, "RUT revisados": i["n"], "% con dígito verificador válido": i["pct_valido"],
                           "trae dígito verificador": "sí" if i["con_dv"] else "no (se calcula)", "% vacíos": i["pct_vacios"],
                           "formatos": " · ".join(f"{f} {p:.1f}%" for f, p in zip(i["formatos"]["formato"], i["formatos"]["%"]))}
                          for b, i in info_rut.items() if i]))
    for b, i in info_rut.items():
        if i:
            chk(f"RUT de {b}: dígito verificador válido ≥ 95% (forma canónica correcta)", i["pct_valido"] >= 95, f"{i['pct_valido']:.2f}%")
else:
    print('RUT_PACIENTES = "sin_rut": no se leyó ni seudonimizó ningún RUT.')

# %% [markdown]
# ### Categorías de POIs y cómo se clasifican
# Tabla de las categorías reales (CAT1 › CAT2) con cuántos POIs hay y a qué variable del estudio quedan asignadas según las
# palabras clave de `PARAMETROS["pois"]` en la configuración. **Si una categoría importante queda "sin variable"** (por
# ejemplo, si las estaciones de metro vienen con otro nombre), agrega su palabra clave en la configuración y vuelve a correr.

# %%
cats = pois.groupby(["cat1", "cat2"], dropna=False).size().rename("POIs").reset_index().sort_values("POIs", ascending=False)
txt_cat = (cats["cat1"].fillna("").astype(str) + " | " + cats["cat2"].fillna("").astype(str)).map(norm_txt)
cats["variable del estudio"] = txt_cat.map(lambda t: ", ".join(v for v, rx in cfg["pois"].items() if re.search(rx, t)) or "sin variable")
cats.head(40)

# %% [markdown]
# ### Mapa: actividad económica y equipamiento
# Empresas grandes (≥ 200 trabajadores), estaciones de metro y POIs de salud de Equifax. Sirve para ver los **polos
# laborales** (población flotante) que importan para centros médicos y tomas de muestras.

# %%
grandes = emp[emp["trabajadores_est"] >= 200]
metro = pois[pois["categoria_txt"].str.contains(cfg["pois"]["poi_metro"], regex=True)]
E_salud = cfg["competencia"]["pois_equifax"]
salud = pois[pois["categoria_txt"].str.contains(E_salud["incluir"], regex=True) & ~pois["categoria_txt"].str.contains(E_salud["excluir"], regex=True)]
mapas.mapa([
    mapas.capa(grandes, "Empresas grandes (200 o más trabajadores)", color="#7b3fa0", radio=3, popup=["rubro", "trabajadores_est"],
               etiquetas_popup={"rubro": "Rubro", "trabajadores_est": "Trabajadores"}, formato_popup={"trabajadores_est": "entero"}),
    mapas.capa(metro, "Estaciones de metro", color="#e07b24", radio=5, popup=["nombre", "cat2"], etiquetas_popup={"nombre": "Estación", "cat2": "Tipo"},
               titulo_popup="nombre"),
    mapas.capa(salud, "Lugares de salud (base de POIs de Equifax)", color="#2e8b57", radio=3, popup=["nombre", "cat2", "cat3"],
               etiquetas_popup={"nombre": "Nombre", "cat2": "Categoría", "cat3": "Detalle"}, titulo_popup="nombre", visible=False),
], titulo="Dónde se trabaja y cómo se llega", subtitulo="Empresas grandes (demanda de día), estaciones de metro y lugares de salud",
   archivo=os.path.join(carpeta_salida(cfg, "mapas"), "01_polos_y_equipamiento.html"))

# %% [markdown]
# ## 5. Reporte de calidad
# Para cada base: registros dentro del área, % de vacíos en columnas clave, duplicados y geometrías vacías.

# %%
calidad = pd.DataFrame([
    lectura.reporte_calidad("censo (manzanas)", censo.rename(columns={C["id"]: "id"}), [C["pob"], C["comuna"]]),
    lectura.reporte_calidad("personas", per, ["gse", "edad", "sexo", "lat", "lon"]),
    lectura.reporte_calidad("empresas", emp, ["trabajadores", "tamano", "rubro"]),
    lectura.reporte_calidad("bbrr", bbrr, ["destino", "avaluo"]),
    lectura.reporte_calidad("pois", pois, ["cat1", "cat2"]),
    lectura.reporte_calidad("calles", calles, ["nombre", "ini_izq", "jerarquia"]),
])
calidad

# %% [markdown]
# ### Coordenadas: cómo venían escritas y qué se corrigió
# Cada base escribe las coordenadas a su manera. Todas se leen con la misma función (`geoventas/coordenadas.py`):
# coma o punto decimal, números sin punto decimal (`-334372000`), separadores de miles de Excel (`-33.437.200`), grados,
# minutos y segundos (`33°26'14"S`), signo menos omitido y latitud/longitud intercambiadas. En Chile cada corrección es
# única (los rangos de latitud y longitud no se confunden en ninguna escala), así que no se adivina nada. Lo que no tiene
# arreglo (texto, 0, fuera del país) queda fuera y se cuenta aquí. Los conteos de formato son por valor (latitud y
# longitud por separado); los de corrección, por registro.

# %%
coords = pd.DataFrame([{"base": b, **i} for b, i in coordenadas.REGISTRO.items()]).fillna(0)
for c in coords.columns[1:]:
    coords[c] = coords[c].astype(int)
coords.rename(columns={"registros": "registros leídos", "validas": "válidas", "coma_decimal": "con coma decimal",
                       "separador_miles": "con separador de miles", "gms": "en grados/min/seg", "escaladas": "sin punto decimal (reescaladas)",
                       "signo_agregado": "sin signo menos (agregado)", "intercambiadas": "lat/lon intercambiadas", "vacias": "vacías",
                       "fuera_de_rango": "inválidas (fuera del país)"})

# %%
chk("Censo con manzanas en el área", len(censo) > 0, f"{len(censo):,} manzanas")
for _, r in coords.iterrows():
    con_dato = max(r["registros"] - r["vacias"], 1)
    chk(f"Coordenadas de {r['base']}: inválidas ≤ 1% de las que traen dato", r["fuera_de_rango"] / con_dato <= 0.01,
        coordenadas.texto_informe(r.to_dict()))
chk("Personas con GSE informado ≥ 90%", per["gse"].notna().mean() >= 0.9, f"{per['gse'].notna().mean():.1%}")
chk("Personas: no se guardan nombres ni RUT en claro", not any(c in per.columns for c in ("NOMBRE", "id", "RUTID")), "solo hash si hay sal")
chk("Empresas con trabajadores estimados", emp["trabajadores_est"].gt(0).all(), f"{miles(emp['trabajadores_est'].sum())} trabajadores")
chk("POIs con categoría", pois["categoria_txt"].str.len().gt(3).mean() > 0.95, "")
chk("Calles con numeración (para geocodificar)", calles["ini_izq"].notna().mean() > 0.5, f"{calles['ini_izq'].notna().mean():.0%} de tramos")

# %% [markdown]
# ## 6. Guardar para los siguientes notebooks

# %%
guardar(censo, cfg, "censo.parquet")
guardar(area, cfg, "area_estudio.gpkg")
guardar(per, cfg, "per.parquet")
guardar(emp, cfg, "emp.parquet")
insumos.registrar_huella_sal(cfg)      # el notebook 05 comprueba que los pacientes se seudonimicen con la misma sal
guardar(bbrr, cfg, "bbrr.parquet")
guardar(pois, cfg, "pois.parquet")
guardar(calles, cfg, "calles.parquet")
guardar(calidad, cfg, "calidad_bases.csv")
chk.guardar(cfg)
chk.tabla()
