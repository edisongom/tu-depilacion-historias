# %% [markdown]
# # 02 · Ventas históricas (5 años) y sedes de la clínica
# **Hito 1 del FRF · "Validación de datos de Clínica Alemana" y "Diagnóstico actual"**
#
# **Qué hace este notebook, paso a paso**
# 1. **Lee la data de ventas** sin saber de antemano su formato: reconoce las columnas por sinónimos, las fechas en
#    cualquier formato, tablas con un mes por columna y tablas **transaccionales** (una fila por atención, con fecha
#    diaria; si el archivo es grande se lee por bloques). Reconoce la **unidad de los montos** (pesos, miles, millones
#    o UF) y lleva todo a pesos.
# 2. **Arma el maestro de sedes del estudio:** une la hoja de sedes del cliente con nuestro levantamiento,
#    **geocodifica** las direcciones con el Maestro de Calles y decide qué sedes entran al modelo.
# 3. **Limpia** (duplicados, notas de crédito, meses faltantes) y **deflacta** (pesos de hoy).
# 4. Detecta **meses atípicos, quiebres de nivel y eventos** (aperturas, cierres, obras, convenios).
# 5. Mide **estacionalidad, crecimiento, mezcla de líneas y previsión, ticket**.
# 6. Estima la **curva de maduración** de una sede nueva con las aperturas de los 5 años.
# 7. Calcula la **venta mensual madura** de cada sede: es el número que calibra el modelo espacial.
# 8. Resume los **indicadores clave** de la red y escribe **conclusiones que se adaptan a los datos**.
#
# | Entra | Sale (`trabajo/`) |
# |---|---|
# | ventas, sedes y eventos del cliente · maestro de sedes · calles y censo (notebook 01) | `sedes_estudio.parquet`, `ventas_std.parquet`, `panel_mensual.parquet`, `venta_madura.csv`, `curva_maduracion.json`, `metricas_ventas.json` |
#
# > **¿Por qué "venta madura"?** Una sede recién abierta vende menos que en régimen, un mes de obras vende menos y
# > un error de digitación infla un mes. El modelo debe aprender del **comportamiento normal** de cada sede, así que
# > limpiamos todo eso antes de calibrar.

# %%
import os, sys, json
sys.path.insert(0, os.path.abspath("."))
import numpy as np, pandas as pd, geopandas as gpd
from IPython.display import display
import config_estudio
from geoventas import insumos, cliente, ventas as V, geocodificacion as GC, mapas, graficos, verificacion, metricas, conclusiones
from geoventas.utilidades import Cronometro, guardar, cargar, miles, mm, pct, carpeta_salida

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "02")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("02_ventas")
GRAF = carpeta_salida(cfg, "graficos"); MAPAS = carpeta_salida(cfg, "mapas")
print("Modo:", cfg["modo"])

# %% [markdown]
# ## 1. Leer la data de ventas
# El lector imprime **qué columna reconoció para cada dato**. Si algo quedó mal (por ejemplo, tomó "comuna" como zona),
# agrega el nombre real de la columna en `COLUMNAS_CLIENTE` dentro de `config_estudio.py` y vuelve a correr.
#
# **Unidad de los montos.** El estudio trabaja en pesos. La unidad se reconoce por el nombre de la columna
# (`monto_clp`, `venta_mm`, `venta_miles`, `monto_uf`…) o, si el nombre no lo dice, por la magnitud: la venta mediana
# de una sede en un mes y el ticket por atención tienen que ser cifras posibles en pesos. Si dos unidades son posibles
# (o ninguna), el notebook se detiene y pide `UNIDAD_MONTO` en `config_estudio.py`: nunca se adivina.

# %%
v_raw = cliente.leer_ventas_cliente(cfg)
unidad = v_raw.attrs.get("unidad_monto", {})
granularidad_lectura = v_raw.attrs.get("granularidad")
print(f"{len(v_raw):,} filas · periodos {v_raw['periodo'].min()} a {v_raw['periodo'].max()} · {v_raw['sede_cliente'].nunique()} códigos de sede")
v_raw.head()

# %% [markdown]
# ## 2. Sedes: hoja del cliente + nuestro levantamiento + geocodificación
# * **Emparejamiento:** cada código de sede del cliente se asocia a una sede del levantamiento (CAS-01, CAS-03…) por
#   nombre y dirección. Lo que quede con puntaje bajo se marca para **revisar** (y se corrige en `MAPA_SEDES`).
# * **Geocodificación:** la dirección del cliente se ubica con el **Maestro de Calles** (interpolando el número dentro del
#   tramo). Se compara con la coordenada del levantamiento (enlaces oficiales "Cómo llegar"): si están a menos de 300 m,
#   todo calza.

# %%
maestro = cliente.leer_maestro(cfg)           # coordenadas con coma o punto, escala, signo o intercambio: se leen igual
sc = cliente.leer_sedes_cliente(cfg)
if sc is None:      # sin hoja de sedes: se usan los códigos de la tabla de ventas como nombre
    sc = pd.DataFrame({"sede_cliente": sorted(v_raw["sede_cliente"].unique())}); sc["nombre"] = sc["sede_cliente"]
emparejamiento = cliente.emparejar_sedes(sc, maestro, cfg)
display(emparejamiento)
# Con datos reales, una sede con emparejamiento dudoso DETIENE el notebook y pide confirmarla en MAPA_SEDES.
insumos.detener_si_falta([insumos.verificar_emparejamiento(emparejamiento, cfg, maestro)], "Emparejamiento de sedes")

# %%
calles = cargar(cfg, "calles.parquet"); censo = cargar(cfg, "censo.parquet"); area = cargar(cfg, "area_estudio.gpkg")
C = cfg["columnas"]["censo"]
comunas = censo[[C["comuna"], C["cod_comuna"]]].drop_duplicates().rename(columns={C["comuna"]: "comuna", C["cod_comuna"]: "cod_comuna"})
geo = GC.Geocodificador(calles, comunas)
if "direccion" in sc:
    scg = geo.geocodificar_tabla(sc, "direccion")
else:
    scg = sc.assign(geo_lat=np.nan, geo_lon=np.nan, geo_calidad="sin dirección")
log("geocodificación lista")
scg[["sede_cliente", "nombre", "direccion", "geo_calidad", "geo_lat", "geo_lon"]] if "direccion" in scg else scg

# %%
s = scg.merge(emparejamiento[["sede_cliente", "id_maestro", "puntaje", "revisar"]], on="sede_cliente", how="left")
s = s.merge(maestro[["id", "nombre", "formato", "estado", "tipo_registro", "lat", "lon", "comuna"]].add_suffix("_maestro"),
            left_on="id_maestro", right_on="id_maestro", how="left")
s["dist_geo_vs_maestro_m"] = GC.comparar_coordenadas(s, "geo_lat", "geo_lon", "lat_maestro", "lon_maestro")
# coordenada final: la oficial del levantamiento si el emparejamiento es confiable; si no, la geocodificada
usa_maestro = s["lat_maestro"].notna() & ~s["revisar"].fillna(True)
s["lat"] = np.where(usa_maestro, s["lat_maestro"], s["geo_lat"]); s["lon"] = np.where(usa_maestro, s["lon_maestro"], s["geo_lon"])
s["fuente_coordenada"] = np.where(usa_maestro, "levantamiento (Cómo llegar oficial)", "geocodificada Maestro de Calles")
s["sede"] = np.where(s["id_maestro"].notna() & ~s["revisar"].fillna(True), s["id_maestro"], s["sede_cliente"])
# formato del modelo y exclusiones (estacionales, edificios del campus que reportan con la sede principal, cerradas…)
txt_formato = s.get("formato", pd.Series("", index=s.index)).fillna("").astype(str) + " | " + s["formato_maestro"].fillna("").astype(str)
# el formato que declara la clínica manda; si no lo trae, se usa el del levantamiento
fm_cliente = s.get("formato", pd.Series(None, index=s.index)).map(lambda t: cliente.formato_modelo(t, cfg) if pd.notna(t) else None)
s["formato_modelo"] = fm_cliente.fillna(s["formato_maestro"].map(lambda t: cliente.formato_modelo(t, cfg) if pd.notna(t) else None))
texto_excl = (txt_formato + " " + s["estado_maestro"].fillna("").astype(str) + " " + s["tipo_registro_maestro"].fillna("").astype(str)).str.lower()
s["motivo_exclusion"] = ""
for k in cfg["excluir_sedes"]:
    s.loc[texto_excl.str.contains(k, regex=False) & (s["motivo_exclusion"] == ""), "motivo_exclusion"] = f"formato/estado contiene '{k}'"
fin_serie = v_raw["periodo"].max()
if "fecha_cierre" in s:
    cerr = s["fecha_cierre"].notna() & (s["fecha_cierre"].dt.strftime("%Y-%m") <= fin_serie)
    s.loc[cerr & (s["motivo_exclusion"] == ""), "motivo_exclusion"] = "cerrada"
s.loc[s["formato_modelo"].isna() & (s["motivo_exclusion"] == ""), "motivo_exclusion"] = "formato no reconocido"
g = gpd.GeoDataFrame(s, geometry=gpd.points_from_xy(s["lon"], s["lat"]), crs="EPSG:4326")
g["en_area"] = g.within(area.geometry.iloc[0])
g.loc[~g["en_area"] & (g["motivo_exclusion"] == ""), "motivo_exclusion"] = "fuera del área de estudio"
g["en_modelo"] = g["motivo_exclusion"] == ""
gm = g.to_crs(cfg["estudio"]["crs_metrico"]); g["x"], g["y"] = gm.geometry.x, gm.geometry.y
sedes_estudio = g
sedes_estudio["nombre_visible"] = cliente.nombre_visible(sedes_estudio)      # el nombre que se ve en mapas, fichas e informes
sedes_estudio[["sede", "sede_cliente", "nombre_visible", "formato_modelo", "fuente_coordenada", "dist_geo_vs_maestro_m", "en_modelo", "motivo_exclusion"]]

# %%
ok_geo = sedes_estudio["dist_geo_vs_maestro_m"].dropna()
chk("Geocodificación con Maestro de Calles a ≤ 300 m de la coordenada oficial (≥ 80% de las sedes)",
    (ok_geo <= 300).mean() >= 0.8 if len(ok_geo) else True, f"{(ok_geo <= 300).mean():.0%} · mediana {ok_geo.median():.0f} m" if len(ok_geo) else "sin direcciones")
chk("Emparejamiento de sedes sin casos dudosos", not emparejamiento["revisar"].any(),
    ", ".join(emparejamiento.loc[emparejamiento["revisar"], "sede_cliente"]) or "todas calzan")
chk("Sedes en el modelo con formato asignado", sedes_estudio.loc[sedes_estudio["en_modelo"], "formato_modelo"].notna().all(),
    sedes_estudio.loc[sedes_estudio["en_modelo"], "formato_modelo"].value_counts().to_dict())

# %% [markdown]
# ### Mapa: sedes de la clínica
# Color = formato del modelo. En gris, las sedes que NO entran al modelo (pasa el mouse para ver el motivo). Los puntos
# amarillos son las direcciones geocodificadas con el Maestro de Calles: deben caer encima de la sede.

# %%
vis = sedes_estudio.copy()
vis["formato_mapa"] = np.where(vis["en_modelo"], vis["formato_modelo"].map(mapas.NOMBRE_FORMATO), "fuera del modelo")
vis["etiqueta"] = vis["nombre_visible"].astype(str) + np.where(vis["en_modelo"], "", " (fuera del modelo: " + vis["motivo_exclusion"] + ")")
vis["fuera"] = np.where(vis["en_modelo"], "Sí", "No · " + vis["motivo_exclusion"])
geo_pts = vis.dropna(subset=["geo_lat"]).copy()
geo_pts = gpd.GeoDataFrame(geo_pts.drop(columns="geometry"), geometry=gpd.points_from_xy(geo_pts["geo_lon"], geo_pts["geo_lat"]), crs="EPSG:4326")
mapas.mapa([
    mapas.capa(area, "Área de estudio", opacidad=0, borde="#8a94a3", peso=1),
    mapas.capa(geo_pts, "Dirección que informó la clínica (ubicada con el Maestro de Calles)", color="#c9a227", radio=4,
               popup=["sede_cliente", "direccion", "geo_calidad", "dist_geo_vs_maestro_m"],
               etiquetas_popup={"sede_cliente": "Código de la clínica", "direccion": "Dirección", "geo_calidad": "Calidad de la ubicación",
                                "dist_geo_vs_maestro_m": "Distancia a la ubicación oficial (m)"}, formato_popup={"dist_geo_vs_maestro_m": "entero"}),
    mapas.capa(vis[~vis["en_modelo"]], "Sedes que no entran al estudio (estacionales, cerradas o fuera del área)", color="#9aa3ae", icono="sede",
               popup=["nombre_visible", "formato", "direccion", "fuera"], titulo_popup="nombre_visible",
               etiquetas_popup={"formato": "Formato", "direccion": "Dirección", "fuera": "¿Entra al modelo?"},
               etiqueta="etiqueta", etiqueta_fija=True),
    mapas.capa_sedes(vis[vis["en_modelo"]], nombre="Sedes de Clínica Alemana en el estudio"),
], titulo="Sedes de Clínica Alemana en el estudio", subtitulo="Color = formato · en gris, las sedes que no entran al modelo",
   encuadrar=["Sedes de Clínica Alemana en el estudio"],
   ayuda=["Los puntos amarillos son las direcciones que informó la clínica: deben caer sobre la sede (si no, se revisa la dirección)."],
   archivo=os.path.join(MAPAS, "02_sedes.html"))

# %% [markdown]
# ## 3. Limpieza y pesos reales
# * **Tabla agregada o transaccional:** si casi todas las combinaciones sede × mes × línea × previsión tienen una sola
#   fila, la tabla es agregada y los **duplicados exactos** se eliminan (son errores de carga). Si hay varias filas por
#   combinación (una por atención o por día), la tabla es transaccional: las filas idénticas se **conservan** (pueden
#   ser dos atenciones distintas del mismo valor) y todo se suma a sede × mes × línea × previsión.
# * **Montos negativos** (notas de crédito) se mantienen: restan, como en la contabilidad.
# * **Deflactar:** con 5 años y la inflación de 2022 (12,8%), un peso de 2021 no vale lo mismo que uno de 2026. Se
#   expresa todo en **pesos del último mes**. Si se entrega la serie IPC del INE (`RUTAS["ipc"]`) se usa esa; si no,
#   una aproximación con la inflación anual (queda marcada como supuesto).

# %%
mapa_codigo = dict(zip(sedes_estudio["sede_cliente"], sedes_estudio["sede"]))
v = v_raw.assign(sede=v_raw["sede_cliente"].map(mapa_codigo).fillna(v_raw["sede_cliente"]))
v, rep_limpieza = V.limpiar_ventas(v, granularidad_lectura)
ipc = V.serie_ipc(cfg, v["periodo"])
v = V.deflactar(v, ipc, ya_real=unidad.get("unidad") == "uf")        # la UF ya se reajusta con la inflación
print("IPC:", ipc.attrs["fuente"])
rep_limpieza.assign(monto=rep_limpieza["monto"].map(mm))

# %%
chk("Unidad de los montos reconocida (todo en pesos)", unidad.get("unidad") is not None, unidad.get("explicacion", ""))
chk(f"Tabla {v.attrs.get('granularidad', '')}: duplicados resueltos según su tipo", True, rep_limpieza.iloc[1]["chequeo"] + f": {int(rep_limpieza.iloc[1]['filas'])} filas")
panel = V.panel_mensual(v)
graficos.serie_red(panel, os.path.join(GRAF, "02_serie_red.png"));

# %% [markdown]
# ## 4. Meses atípicos, quiebres y eventos
# Para cada sede se separa la venta en tres partes: **estacionalidad** (común a todas las sedes), **tendencia** (mediana
# móvil de 7 meses) y **residuo**. Un mes es **atípico** si su residuo supera 4,5 desviaciones robustas (MAD), y hay
# **quiebre** si la mediana de 6 meses cambia ≥ 8% de un semestre al siguiente y ese cambio es claramente mayor que el
# ruido normal de la sede (no se buscan quiebres en los 2 primeros años de una sede nueva: eso es la rampa). Los **eventos informados** por la
# clínica (hoja de eventos) se marcan aparte. Nada se borra: los meses marcados solo se excluyen del cálculo de la venta madura.

# %%
ev = cliente.leer_eventos(cfg)
if len(ev):
    ev["sede"] = ev["sede_cliente"].map(mapa_codigo).fillna(ev["sede_cliente"])
panel = V.detectar_atipicos(panel, cfg, ev)
marcas = panel[(panel["atipico"] | panel["quiebre"] | panel["faltante"] | (panel["evento"] != ""))]
print(f"Meses marcados: {len(marcas)} de {len(panel)}")
marcas[["sede", "periodo", "monto_real", "z", "atipico", "quiebre", "faltante", "evento", "motivo"]].assign(monto_real=lambda d: d["monto_real"].map(mm))

# %%
graficos.NOMBRES_SEDE = dict(zip(sedes_estudio["sede"], sedes_estudio["nombre_visible"]))     # los gráficos muestran el nombre real
graficos.series_sedes(panel[panel["sede"].isin(sedes_estudio.loc[sedes_estudio["en_modelo"], "sede"])], os.path.join(GRAF, "02_series_sedes.png"));

# %% [markdown]
# ## 5. Estacionalidad, crecimiento, mezcla y ticket
# * **Estacionalidad:** cuánto sube o baja cada mes respecto de un mes promedio (invierno suele ser alto por respiratorias).
# * **Crecimiento real:** venta anual en pesos de hoy, variación y crecimiento compuesto de 3 años.
# * **Mezcla:** qué % de la venta es consulta, laboratorio, imagen… y qué % es Isapre, Fonasa, particular.

# %%
graficos.estacionalidad(panel.attrs["indice_estacional"], os.path.join(GRAF, "02_estacionalidad.png"));
crec = V.crecimiento(panel)
crec_vista = crec.copy()
for c in crec_vista.columns[1:]:
    crec_vista[c] = crec_vista[c].map(lambda x: pct(x) if str(c).startswith(("var", "cagr")) else mm(x))
crec_vista

# %%
mix_lineas = V.mix(v, "linea"); mix_prev = V.mix(v, "prevision")
graficos.barras_mix(mix_lineas, "Mezcla de líneas de servicio por sede", os.path.join(GRAF, "02_mix_lineas.png"));
graficos.barras_mix(mix_prev, "Mezcla por previsión de salud", os.path.join(GRAF, "02_mix_prevision.png"));
ticket = V.ticket_por_linea(v)
ticket.pivot_table(index="sede", columns="linea", values="ticket_real").apply(lambda col: col.map(lambda x: miles(x) if pd.notna(x) else ""))

# %% [markdown]
# ## 6. Curva de maduración (ramp-up)
# Con las sedes que **abrieron dentro de los 5 años** se ajusta una curva común
# `venta(m) = régimen × (1 − (1 − r0) · e^(−m/τ))`: abre vendiendo `r0` del régimen y se acerca a él con un tiempo
# característico de `τ` meses. De ahí sale el % del régimen en los años 1, 2 y 3, que se usa para proyectar las sedes
# nuevas. Si no hubo aperturas, se usa el supuesto 60% / 85% / 100%.

# %%
edades = V.edad_sedes(panel, sedes_estudio[["sede", "fecha_apertura"]] if "fecha_apertura" in sedes_estudio else None)
curva = V.curva_maduracion(panel, edades, cfg)
print(f"Fuente: {curva['fuente']}")
if curva["r0"] is not None:
    print(f"r0 = {curva['r0']:.0%} del régimen al abrir · τ = {curva['tau']:.1f} meses")
print("Rampa (años 1, 2, 3):", [f"{r:.0%}" for r in curva["rampa_anual"]])
graficos.curva_maduracion(curva, os.path.join(GRAF, "02_maduracion.png"));

# %% [markdown]
# ## 7. Venta mensual madura por sede
# Promedio de los últimos 24 meses **desestacionalizados**, sin meses atípicos, faltantes ni con eventos. Si la sede
# todavía está madurando, cada mes se divide por su factor de rampa (se lleva a régimen).

# %%
vm = V.venta_madura(panel, edades, curva, cfg)
ventana = vm.attrs["ventana"]
vm = vm.merge(sedes_estudio[["sede", "nombre", "formato_modelo", "en_modelo"]], on="sede", how="left")
print("Ventana usada para la venta madura:", ventana)
vm.assign(**{c: vm[c].map(mm) for c in ("venta_mensual_madura", "venta_mensual_observada")})

# %% [markdown]
# ### Mapa: venta madura por sede
# El tamaño del círculo es proporcional a la venta mensual madura. Clic para ver ticket y atenciones.

# %%
vis = sedes_estudio[sedes_estudio["en_modelo"]].merge(vm[["sede", "venta_mensual_madura", "atenciones_mensuales", "ticket_promedio"]], on="sede")
vis["venta_MM"] = vis["venta_mensual_madura"] / 1e6
capas = []
for f, gsub in vis.groupby("formato_modelo"):
    gsub = gsub.copy()
    gsub["ficha"] = [mapas.ficha(r["nombre_visible"], [("Venta mensual en régimen", mapas.pesos(r["venta_mensual_madura"])),
                                                       ("Atenciones al mes", miles(r["atenciones_mensuales"])),
                                                       ("Ticket promedio", f"${miles(r['ticket_promedio'])}")],
                                  subtitulo=mapas.NOMBRE_FORMATO[f], color=mapas.COLOR_FORMATO[f]) for _, r in gsub.iterrows()]
    capas.append(mapas.capa(gsub, mapas.NOMBRE_FORMATO[f], color=mapas.COLOR_FORMATO[f],
                            radio=float(np.clip(4 + 3 * np.log10(max(gsub['venta_MM'].median(), 1)), 5, 14)),
                            ficha_html="ficha", etiqueta="nombre_visible", etiqueta_fija=True))
mapas.mapa(capas, titulo="Venta mensual de cada sede en régimen", subtitulo="Pesos de hoy · círculo más grande = sede que vende más · clic para ver el detalle",
           archivo=os.path.join(MAPAS, "02_venta_madura.html"))

# %% [markdown]
# ## 8. Indicadores clave y conclusiones
# Cifras que resumen la red (crecimiento real total y a red constante, volumen vs precio, estacionalidad, concentración,
# mezcla, productividad por m², calidad de los datos) y **conclusiones escritas según lo que muestran los datos**: el
# mismo código dice "la red crece con fuerza" o "la venta cae en términos reales", "venta repartida" o "la red depende
# de una sede", etc. Lo que no se puede medir con la data entregada (p. ej. crecimiento con menos de 24 meses) se avisa.

# %%
ind_ventas = metricas.ventas(panel, vm, crec, v, sedes_estudio)
conclusiones.mostrar(conclusiones.generar(ind_ventas, ["Ventas"]), "Conclusiones sobre las ventas")
metricas.tabla(ind_ventas)[["indicador", "valor", "lectura"]]

# %% [markdown]
# ## 9. Verificaciones

# %%
chk("Serie con al menos 24 meses", panel["periodo"].nunique() >= 24, f"{panel['periodo'].nunique()} meses")
chk("Todas las sedes del modelo tienen venta madura", vm.loc[vm["en_modelo"] == True, "venta_mensual_madura"].notna().all(), "")
chk("Rampa de maduración monótona creciente", np.all(np.diff(curva["rampa_anual"]) >= -1e-9), curva["rampa_anual"])
if cfg["modo"] == "simulacion":
    verdad = json.load(open(cfg["simulacion"]["verdad"], encoding="utf-8"))
    comp = vm[vm["en_modelo"] == True].assign(verdad=lambda d: d["sede"].map(verdad["venta_mensual_madura"]) * cfg["simulacion"].get("factor_ventas", 1))
    comp["error"] = comp["venta_mensual_madura"] / comp["verdad"] - 1
    chk("[simulación] venta madura recuperada (error absoluto medio ≤ 8%)", comp["error"].abs().mean() <= 0.08, f"{comp['error'].abs().mean():.1%}")
    chk("[simulación] mes faltante CAS-11 2022-09 detectado", bool(panel.query("sede=='CAS-11' and periodo=='2022-09'")["faltante"].any()), "")
    chk("[simulación] pico por error de digitación CAS-12 2023-03 detectado", bool(panel.query("sede=='CAS-12' and periodo=='2023-03'")["atipico"].any()), "")
    q = panel.query("sede=='CAS-05' and quiebre")["periodo"].tolist()
    chk("[simulación] quiebre por convenio CAS-05 (jul-2023 ± 2 meses) detectado", any("2023-05" <= p <= "2023-09" for p in q), q)
    if curva["r0"] is not None:
        chk("[simulación] rampa recuperada (r0 real 35%, τ real 10 meses)", abs(curva["r0"] - 0.35) <= 0.1 and 6 <= curva["tau"] <= 15,
            f"r0 {curva['r0']:.0%} · τ {curva['tau']:.1f}")
chk.guardar(cfg)
chk.tabla()

# %%
guardar(sedes_estudio, cfg, "sedes_estudio.parquet")
guardar(v, cfg, "ventas_std.parquet")
guardar(panel.drop(columns=[], errors="ignore"), cfg, "panel_mensual.parquet")
guardar(vm, cfg, "venta_madura.csv")
guardar({k: v_ for k, v_ in curva.items() if k != "tabla"}, cfg, "curva_maduracion.json")
guardar(V.mix_lineas_por_formato(v, sedes_estudio.loc[sedes_estudio["en_modelo"], ["sede", "formato_modelo"]]).reset_index(), cfg, "mix_lineas_formato.csv")
guardar(mix_prev.reset_index(), cfg, "mix_prevision.csv")
guardar(crec, cfg, "crecimiento.csv")
guardar(metricas.como_dict(ind_ventas), cfg, "metricas_ventas.json")
log("listo")
