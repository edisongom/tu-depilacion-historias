# %% [markdown]
# # 03 · Territorio (manzanas) y competencia
# **Hito 1 del FRF · "Mapeo de oferta competitiva" · Hito 2 · "estimación de la demanda por microterritorio"**
#
# **Qué hace:**
# 1. Arma la **unidad de análisis** del estudio: la **MANZANA del censo** (polígono de `SD06_SOCIODEMOGRAPHIC_BLOCK`).
#    Toda la demanda (población, GSE, gasto en salud) es la del censo, sin agregar, y el domicilio de cada paciente
#    (vía RUT, notebook 05) cae en su manzana real.
# 2. **Descarta de antemano las manzanas que no aportan**, cada una con su motivo:
#    * sin población, sin trabajadores y sin POIs (vacías);
#    * uso de suelo excluido (área verde, parque, plaza, cementerio, sitio eriazo…) y sin población;
#    * cubiertas en ≥ 80% por áreas verdes (si se entrega esa capa) con ≤ 10 habitantes.
# 3. Asigna cada persona, empresa, POI, propiedad y tramo de calle a su manzana con un índice espacial: la manzana que lo
#    contiene o, si el punto cae en la calle, la más cercana (personas ≤ 60 m; empresas, POIs y propiedades ≤ 300 m,
#    porque pueden estar en predios grandes o zonas industriales). Luego calcula todas las variables por manzana.
# 4. Arma el **universo de competencia** y mide la competencia alrededor de cada manzana.
#
# | Entra | Sale (`trabajo/`) |
# |---|---|
# | bases del notebook 01 · capa de áreas verdes (opcional) · universo de competencia levantado | `unidades.parquet` (manzanas útiles), `manzanas_descartadas.parquet`, `personas_ut.parquet`, `empresas_ut.parquet`, `competencia.parquet` |
#
# > **Mapas de manzanas.** Los mapas de este estudio muestran los **polígonos reales de las ~50 mil manzanas**. Arriba a
# > la izquierda se elige el **indicador** que pinta las manzanas, se salta a una **comuna** y se ajusta la opacidad; al
# > pasar el mouse se ve el valor de la manzana y al hacer **clic** su ficha completa. La leyenda dice cuántas manzanas
# > hay en cada color.

# %%
import os, sys
sys.path.insert(0, os.path.abspath("."))
import numpy as np, pandas as pd, geopandas as gpd
from IPython.display import display
import config_estudio
from geoventas import insumos, unidades, competencia, lectura, mapas, verificacion
from geoventas.utilidades import Cronometro, guardar, cargar, existe, miles, mm, carpeta_salida, norm_txt

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "03")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("03_territorio")
MAPAS = carpeta_salida(cfg, "mapas")
censo, per, emp, bbrr, pois, calles, area = (cargar(cfg, f) for f in ("censo.parquet", "per.parquet", "emp.parquet", "bbrr.parquet",
                                                                     "pois.parquet", "calles.parquet", "area_estudio.gpkg"))
if existe(cfg, "sedes_estudio.parquet"):
    sedes = cargar(cfg, "sedes_estudio.parquet")
else:                                          # aún sin datos de la clínica: las sedes (solo para los mapas) salen del maestro
    from geoventas import cliente, influencia
    sedes = influencia.sedes_red(cliente.leer_maestro(cfg), cargar(cfg, "area_estudio.gpkg"), cfg)[0]
    print("Sin datos de la clínica todavía: las sedes de los mapas son las del maestro del levantamiento.")
sedes = sedes[sedes["en_modelo"]].reset_index(drop=True)
verdes = gpd.read_file(lectura.ruta_local(cfg["rutas"]["areas_verdes"], cfg)) if cfg["rutas"].get("areas_verdes") else None
print(f"Manzanas del censo: {len(censo):,} · capa de áreas verdes: {'sí (' + miles(len(verdes)) + ' polígonos)' if verdes is not None else 'no (se usa USO_SUELO)'}")

# %% [markdown]
# ## 1. Manzanas útiles y filtros previos
# Todo es vectorizado (índice espacial STRtree): funciona igual con 50 mil manzanas y 7 millones de personas.

# %%
ut, descartes, per_ut, emp_ut = unidades.construir_unidades(censo, cfg, per=per, emp=emp, pois=pois, bbrr=bbrr, calles=calles,
                                                           areas_verdes=verdes, cronometro=log)
if len(descartes):
    resumen_desc = descartes.assign(motivo_corto=descartes["motivo"].str.replace(r" \(.*", "", regex=True)).groupby("motivo_corto").agg(
        manzanas=("ut", "size"), poblacion=("poblacion", "sum"), trabajadores=("trabajadores", "sum"),
        superficie_km2=("area_m2", lambda s: s.sum() / 1e6))
    resumen_desc.loc["Total"] = resumen_desc.sum()
    display(resumen_desc.assign(**{c: resumen_desc[c].map(miles) for c in ("manzanas", "poblacion", "trabajadores")},
                                superficie_km2=resumen_desc["superficie_km2"].map(lambda v: miles(v, 2))))

# %% [markdown]
# **Cómo leerlo:** las manzanas descartadas no tienen gente (o casi), así que no cambian la demanda; sacarlas acelera los
# cálculos y evita que un parque o un cerro "aparezca" como zona de pacientes. Si el censo trae otros nombres de uso de
# suelo, se agregan en `PARAMETROS["filtro_manzanas"]["usos_excluir"]`.
#
# **Mapa:** en gris las manzanas útiles; en color las descartadas según su motivo (clic = ficha con población,
# trabajadores, POIs, uso de suelo y % de área verde).

# %%
if len(descartes):
    d_vis = descartes.assign(motivo_corto=descartes["motivo"].str.replace(r" \(.*", "", regex=True))
    u_vis = ut[["ut", "comuna", "pob", "uso_suelo", "geometry"]].assign(estado="Se usa en el estudio")
    capas = [mapas.capa_manzanas(u_vis, "Manzanas que se usan", [mapas.ind("estado", "Manzanas del estudio", "texto",
                                                                              categorias={"Se usa en el estudio": "#c9ced6"})],
                                 ficha=mapas.inds("pob", "uso_suelo"), opacidad=0.5),
             mapas.capa_manzanas(d_vis, "Manzanas que se dejan fuera", [
                 mapas.ind("motivo_corto", "Por qué se deja fuera", "texto",
                           categorias={"sin población ni actividad": "#e07b24", "uso de suelo excluido": "#2e8b57", "área verde": "#8fd18a"},
                           nombres_categoria={"sin población ni actividad": "Sin habitantes, empresas ni comercio",
                                              "uso de suelo excluido": "Parque, plaza, cementerio, cerro u otro uso sin vivienda",
                                              "área verde": "Casi toda la manzana es área verde"},
                           descripcion="Estas manzanas no tienen demanda; se dejan fuera para que el cálculo sea más rápido y limpio.")],
                 ficha=[mapas.ind("motivo", "Detalle", "texto"), mapas.ind("poblacion", "Habitantes", "entero"),
                        mapas.ind("trabajadores", "Trabajadores", "entero"), mapas.ind("pois", "Comercios y servicios", "entero"),
                        mapas.ind("uso_suelo", "Uso de suelo (censo)", "texto"), mapas.ind("pct_area_verde", "% de área verde", "pct")],
                 opacidad=0.9)]
    if verdes is not None:
        capas.insert(0, mapas.capa(verdes, "Áreas verdes (capa entregada)", color="#b9e0ae", opacidad=0.35, peso=0.5, visible=False))
    mapas.mapa(capas, titulo="Manzanas que se dejan fuera del cálculo",
               subtitulo=f"{miles(len(descartes))} manzanas sin demanda (parques, cerros, sitios vacíos…) · {miles(len(ut))} manzanas en el estudio",
               ayuda=["En gris, las manzanas que sí se usan. En color, las que se dejan fuera y por qué."],
               archivo=os.path.join(MAPAS, "03_manzanas_descartadas.html"))

# %% [markdown]
# ### Diccionario de las variables principales (por manzana)
# | Variable | Qué es | Fuente |
# |---|---|---|
# | `ut` | identificador de la manzana | censo SD06 (`ID_BLOCK`) |
# | `pob`, `hog`, `pob_{GSE}`, `hog_{GSE}` | población y hogares totales y por GSE | censo SD06 (`POB`, `HOG`, `POB_AB`…) |
# | `gasto_salud_{GSE}`, `gasto_salud_total` | gasto mensual en salud (CLP) | censo (`G_SAL_AB`…) |
# | `pob_objetivo`, `hog_objetivo`, `pct_objetivo` | AB + C1a + C1b (segmento del FRF) | censo |
# | `pob_0_5` … `pob_60_mas`, `hombres`, `mujeres` | edad y sexo | censo |
# | `per_gse_*`, `per_edad_*`, `per_renta_hogar_mediana`, `per_vehiculos_prom`… | perfil de personas | per |
# | `trabajadores_est`, `emp_n`, `emp_salud_n` | población flotante diurna y empresas | emp |
# | `poi_metro`, `poi_mall`, `poi_oficinas`, `poi_salud`… | equipamiento | PI01 |
# | `bbrr_habitacional`, `bbrr_oficina`, `bbrr_avaluo_hab_mediano`… | destino y avalúo de propiedades | BBRR |
# | `calles_km`, `vias_principales_km` | vialidad | BC08 |
# | `area_km2`, `densidad_hab_km2`, `cx`, `cy` | superficie, densidad y punto interior (para los tiempos de viaje) | geometría |

# %%
cols = ["pob", "pob_objetivo", "hog_objetivo", "gasto_salud_total", "gasto_salud_objetivo", "trabajadores_est", "poi_total", "bbrr_total"]
pd.DataFrame({"total": ut[cols].sum(), "promedio por manzana": ut[cols].mean(), "mediana": ut[cols].median(),
              "máximo": ut[cols].max()}).apply(lambda col: col.map(miles))

# %%
com = ut.groupby("comuna")[["pob", "pob_objetivo", "gasto_salud_objetivo", "trabajadores_est"]].sum()
com["manzanas"] = ut.groupby("comuna").size()
com["% objetivo"] = 100 * com["pob_objetivo"] / com["pob"]
top_com = com.sort_values("gasto_salud_objetivo", ascending=False).head(15)
pd.DataFrame({"manzanas": top_com["manzanas"].map(miles), "población": top_com["pob"].map(miles),
              "población objetivo": top_com["pob_objetivo"].map(miles), "% objetivo": top_com["% objetivo"].map(lambda v: miles(v, 1)),
              "gasto salud objetivo (CLP/mes)": top_com["gasto_salud_objetivo"].map(mm), "trabajadores": top_com["trabajadores_est"].map(miles)})

# %% [markdown]
# ### Mapa: la demanda, manzana por manzana
# Elige el indicador arriba a la izquierda: población objetivo, % objetivo, gasto en salud, densidad, trabajadores (demanda
# diurna) o GSE predominante. Los colores son **cuantiles** (cada color agrupa una cantidad parecida de manzanas).

# %%
mapas.mapa([
    mapas.capa_manzanas(ut, "Demanda por manzana",
                        mapas.inds("pob_objetivo", "pct_objetivo", "gasto_salud_objetivo", "gasto_salud_total", "densidad_hab_km2",
                                   "trabajadores_est", "gse_predominante", "per_renta_hogar_mediana"),
                        ficha=mapas.inds("pob", "hog", "hog_objetivo", "uso_suelo", "area_km2")),
    mapas.capa_sedes(sedes),
], titulo="¿Dónde vive y trabaja el público de Clínica Alemana?",
   subtitulo=f"{miles(len(ut))} manzanas del censo · elige en el panel qué mostrar: personas, gasto en salud, trabajadores…",
   ayuda=["Las cruces son las sedes actuales de Clínica Alemana, con su nombre al acercarse."],
   archivo=os.path.join(MAPAS, "03_demanda_manzanas.html"))

# %% [markdown]
# ## 2. Universo de competencia
# Partimos del **levantamiento propio** (DEIS, Superintendencia, OSM, Farmanet, Overture y webs oficiales), que tiene
# **prioridad**, y le sumamos los **POIs de salud de Equifax** (PI01) que **no** estén ya. Un mismo lugar suele estar en
# las dos fuentes con nombres parecidos pero distintos ("Centro Médico Integramédica Plaza Egaña" ≈ "INTEGRAMEDICA
# EGAÑA") y coordenadas corridas, así que el cruce mira **coordenadas, nombre, dirección y tipo de lugar**
# (detalle en la sección 2.1). Roles en el estudio:
# * **En el modelo**: clínicas, centros médicos y laboratorios/toma de muestras, con peso según su segmento
#   (Premium 1,0 · Medio-alto 0,8 · Medio 0,55 · Masivo 0,35 · Público 0,2).
# * **Contexto** (dental, kine, farmacias, salud mental…): se cuenta en las isócronas como saturación de la oferta.
# * **Red propia**: las sedes de Clínica Alemana.

# %%
comp, unif = competencia.construir_competencia(cfg, area, pois)
tabla_comp = comp.assign(rol=np.where(comp["es_red_propia"], "red propia", np.where(comp["en_modelo"], "en el modelo", "contexto")))
pd.crosstab(tabla_comp["formato_FRF"].fillna("s/i"), tabla_comp["rol"], margins=True, margins_name="Total")

# %%
comp[comp["en_modelo"]].groupby(["grupo", "segmento_estimado"]).size().unstack(fill_value=0)

# %% [markdown]
# ### 2.1 Levantamiento + POIs de Equifax: un solo registro por lugar
# Para cada POI de salud de Equifax se buscan los lugares del levantamiento a ≤ 300 m y se decide si es el mismo:
# * **Nombre:** se compara sin tildes, mayúsculas ni signos, con las abreviaturas expandidas (C.M., Ctro., Lab., Dr.) y
#   sin SpA/Ltda.; tolera errores de tipeo, palabras en otro orden y nombres contenidos en otro ("Plaza Egaña" dentro de
#   "Integramédica Plaza Egaña"). Las palabras genéricas ("centro", "médico", "clínica", "dental") no bastan para unir.
# * **Distancia:** mientras más lejos, más parecido debe ser el nombre (0,50 a ≤ 30 m … 0,90 a 300 m).
# * **Dirección:** misma calle y número rebaja la exigencia.
# * **Tipo:** una farmacia nunca se une con un centro médico; tipos afines (centro médico ↔ laboratorio) exigen más.
# * **Cadenas y sucursales:** "Cruz Verde Los Leones" y "Cruz Verde Providencia" son dos lugares aunque compartan marca.
#
# Los POIs de Equifax que se repiten entre sí también se dejan una vez. Las decisiones quedan en
# `salidas/competencia/unificacion_pois_decisiones.csv` y los casos dudosos en `unificacion_pois_revisar.csv`, para
# revisarlos a mano si se quiere. Los umbrales están en `PARAMETROS["competencia"]["unificacion"]`.

# %%
if unif is not None:
    display(unif.resumen)
    dec = unif.decisiones
    unidos = dec[dec["decision"] == "duplicado del levantamiento"]
    distinto = unidos[unidos["nombre_equifax"].map(norm_txt) != unidos["nombre_levantamiento"].map(norm_txt)]
    print(f"De {miles(len(unidos))} duplicados, {miles(len(distinto))} tenían un nombre distinto en cada fuente. Ejemplos:")
    display(distinto.sample(min(12, len(distinto)), random_state=1)[["nombre_equifax", "nombre_levantamiento", "nombres_comparados",
                                                                     "distancia_m", "parecido_nombre", "misma_direccion", "motivo"]]
            .assign(distancia_m=lambda t: t["distancia_m"].round(0), parecido_nombre=lambda t: t["parecido_nombre"].round(2)))
    print(f"Casos dudosos para revisión manual: {miles(len(unif.revisar))} · 'nombres_comparados' muestra qué variante del nombre "
          "(nombre, otro nombre o marca) se comparó, ya normalizada")
    display(unif.revisar.head(8))
    carp = carpeta_salida(cfg, "competencia")
    dec.to_csv(os.path.join(carp, "unificacion_pois_decisiones.csv"), index=False, encoding="utf-8-sig")
    unif.revisar.to_csv(os.path.join(carp, "unificacion_pois_revisar.csv"), index=False, encoding="utf-8-sig")
else:
    print("No hay POIs de salud de Equifax en el área: la competencia es solo el levantamiento.")

# %% [markdown]
# ## 3. Competencia alrededor de cada manzana
# Dos medidas por manzana:
# * los competidores que caen **en** la manzana (para las capas GIS);
# * la competencia del modelo a **≤ 1 km** de la manzana, ponderada por segmento: es una lectura rápida de saturación.
#
# La competencia que usa el **modelo** es más precisa: se mide con el **tiempo de viaje exacto** de cada manzana a cada
# competidor (notebook 04).

# %%
vc = competencia.variables_competencia(comp, ut, cfg)
ut = ut.merge(vc, left_on="ut", right_index=True, how="left")
for c in vc.columns:
    ut[c] = ut[c].fillna(0)
pesos = [c for c in ("comp_clinica_peso", "comp_centro_medico_peso", "comp_laboratorio_peso") if c in ut]
ent = unidades.suma_entorno(ut, pesos, radio_m=1000)
ut["comp_entorno_peso"] = ent.sum(axis=1).values
print(f"Manzanas con competencia del modelo a ≤ 1 km: {(ut['comp_entorno_peso'] > 0).mean():.0%}")

# %%
en = comp[comp["en_modelo"]].copy()
en["grupo_txt"] = en["grupo"].map({"comp_clinica": "Clínica", "comp_centro_medico": "Centro médico", "comp_laboratorio": "Laboratorio / toma de muestras"})
ctx = comp[~comp["en_modelo"] & ~comp["es_red_propia"]]
mapas.mapa([
    mapas.capa_manzanas(ut, "Competencia alrededor de cada manzana", mapas.inds("comp_entorno_peso", "pob_objetivo"), ficha=mapas.inds("pob"), opacidad=0.7),
    mapas.capa(ctx, "Otros servicios de salud (dental, kinesiología, farmacias…)", color="#9aa3ae", radio=2,
               popup=["nombre", "categoria"], etiquetas_popup={"nombre": "Nombre", "categoria": "Tipo"}, titulo_popup="nombre", visible=False),
    mapas.capa(en, "Competencia: clínicas, centros médicos y laboratorios", campo_categoria="grupo_txt",
               colores_categoria={"Clínica": "#7b3fa0", "Centro médico": "#1f78b4", "Laboratorio / toma de muestras": "#2e9e44"},
               nombres_categoria={"Clínica": "Clínicas de la competencia", "Centro médico": "Centros médicos de la competencia",
                                  "Laboratorio / toma de muestras": "Laboratorios y tomas de muestras"},
               radio=4, popup=["nombre", "formato_FRF", "segmento_estimado", "fuente_universo"], titulo_popup="nombre",
               etiquetas_popup={"formato_FRF": "Tipo", "segmento_estimado": "Segmento", "fuente_universo": "Fuente"}, etiqueta="nombre"),
    mapas.capa_sedes(sedes),
], titulo="¿Dónde está la competencia?",
   subtitulo=f"{miles(len(en))} clínicas, centros médicos y laboratorios que compiten con Clínica Alemana · {miles(len(ctx))} otros servicios de salud",
   ayuda=["El color de las manzanas indica cuánta competencia hay a menos de 1 km (más oscuro = más competencia).",
          "Los puntos de colores son los competidores; haz clic en uno para ver su nombre, tipo y segmento."],
   archivo=os.path.join(MAPAS, "03_competencia.html"))

# %% [markdown]
# ## 4. Verificaciones

# %%
C = cfg["columnas"]["censo"]
pob_censo = pd.to_numeric(censo[C["pob"]], errors="coerce").sum()
pob_desc = descartes["poblacion"].sum() if len(descartes) else 0
chk("Población conservada (manzanas útiles + descartadas = censo)", abs((ut["pob"].sum() + pob_desc) / pob_censo - 1) < 1e-6,
    f"{miles(ut['pob'].sum())} + {miles(pob_desc)} = {miles(pob_censo)}")
chk("Las manzanas descartadas tienen ≤ 0,5% de la población", pob_desc / pob_censo <= 0.005, f"{pob_desc / pob_censo:.3%}")
chk("Identificador de manzana único", ut["ut"].is_unique, f"{miles(len(ut))} manzanas")
chk("Todas las manzanas útiles tienen polígono válido", bool(ut.geometry.is_valid.all() and ut.geometry.notna().all()),
    f"{int((~ut.geometry.is_valid).sum())} inválidas")
chk("Trabajadores asignados a una manzana ≥ 90%", ut["trabajadores_est"].sum() / emp["trabajadores_est"].sum() >= 0.9,
    f"{ut['trabajadores_est'].sum() / emp['trabajadores_est'].sum():.1%} (el resto está a más de 300 m de toda manzana)")
r = np.corrcoef(ut["pob"], ut.get("per_n", ut["pob"]))[0, 1]
chk("Base de personas coherente con el censo (correlación por manzana ≥ 0,6)", r >= 0.6, f"r = {r:.3f}")
chk("Personas ubicadas en una manzana ≥ 95%", pd.Series(per_ut["ut"]).notna().mean() >= 0.95, f"{pd.Series(per_ut['ut']).notna().mean():.1%}")
chk("Competencia del modelo con los 3 grupos", comp.loc[comp["en_modelo"], "grupo"].nunique() == 3, comp.loc[comp["en_modelo"], "grupo"].value_counts().to_dict())
chk("La red propia no aparece como competencia", not comp.loc[comp["en_modelo"], "nombre"].str.contains("Alemana", case=False, na=False).any(), "")
lev_area = competencia.leer_universo(cfg)
lev_area = lev_area[lev_area.within(area.geometry.iloc[0])]
chk("Levantamiento completo (ningún lugar del levantamiento se descarta ni se reemplaza)",
    (comp["fuente_universo"] == "levantamiento 19/20-11-2026").sum() == len(lev_area), f"{miles(len(lev_area))} lugares")
chk("Ninguna veterinaria entra como lugar de salud", not comp["nombre"].astype(str).str.contains("veterin", case=False).any(), "")
if unif is not None:
    d_ = unif.decisiones
    chk("Cada POI de salud de Equifax tiene una decisión (duplicado o nuevo) con su motivo", d_["motivo"].notna().all(),
        d_["decision"].value_counts().to_dict())
    agregados = (comp["fuente_universo"] != "levantamiento 19/20-11-2026").sum()
    chk("Los POIs de Equifax agregados son solo los nuevos (uno por lugar)", agregados == len(unif.nuevos), f"{miles(agregados)} agregados")
    ruta_v = os.path.join(os.path.dirname(cfg["rutas"]["censo"]), "verdad_pois_equifax.csv")
    if cfg["modo"] == "simulacion" and os.path.exists(ruta_v):
        v = d_.merge(pd.read_csv(ruta_v), left_on="id_poi", right_on="ID_POI")
        unido = v["decision"] == "duplicado del levantamiento"
        precision = (unido & (v["id_universo"] == v["id_universo_verdad"])).sum() / max(unido.sum(), 1)
        nuevos_v = v["verdad"] == "nuevo"
        falsos = (nuevos_v & (v["decision"] != "nuevo")).sum() / max(nuevos_v.sum(), 1)
        dup_v = v["verdad"].str.startswith("duplicado") & (v["variacion"] != "razón social distinta")
        hallados = (dup_v & (v["decision"] != "nuevo")).sum() / max(dup_v.sum(), 1)
        chk("[simulación] Duplicados unidos al lugar correcto ≥ 98%", precision >= 0.98, f"{precision:.1%} de {miles(unido.sum())}")
        chk("[simulación] Lugares nuevos unidos por error ≤ 1%", falsos <= 0.01, f"{falsos:.2%} de {miles(nuevos_v.sum())}")
        chk("[simulación] Duplicados encontrados ≥ 90% (sin contar los de razón social distinta)", hallados >= 0.90,
            f"{hallados:.1%} de {miles(dup_v.sum())}")
chk.guardar(cfg)
chk.tabla()

# %%
guardar(ut, cfg, "unidades.parquet")
guardar(descartes, cfg, "manzanas_descartadas.parquet")
cols_per = [c for c in ("rut_hash", "ut", "gse", "edad", "sexo", "renta_hogar", "direccion_verificada") if c in per_ut]
guardar(pd.DataFrame(per_ut[cols_per]), cfg, "personas_ut.parquet")          # sin nombres ni RUT en claro
cols_emp = [c for c in ("rut_hash", "ut", "rubro", "trabajadores_est") if c in emp_ut]
guardar(pd.DataFrame(emp_ut[cols_emp]), cfg, "empresas_ut.parquet")
guardar(comp, cfg, "competencia.parquet")
log("listo")
