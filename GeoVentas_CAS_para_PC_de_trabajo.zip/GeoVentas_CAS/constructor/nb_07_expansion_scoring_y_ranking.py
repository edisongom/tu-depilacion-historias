# %% [markdown]
# # 07 · Expansión: dónde abrir y con qué formato
# **Hito 2 del FRF · "Scoring multicriterio y estimación por punto" + "Ranking y asignación de formato"**
# **Hito 3 · "evaluación de hasta 5 ubicaciones propuestas por la clínica"**
#
# **Qué hace:**
# Los **candidatos** son **manzanas** (notebook 04): manzanas urbanas o de polos laborales que dan a una vía terciaria o
# superior. El sitio de cada una es el nodo de esa vía, y su venta se calcula con la demanda de **cada manzana** del área
# (tiempo exacto manzana → sitio).
#
# 1. Evalúa **cada candidato en cada formato** (clínica, centro médico, toma de muestras):
#    * **venta bruta**: lo que vendería la sede nueva;
#    * **canibalización**: lo que dejarían de vender las sedes actuales;
#    * **venta neta** = bruta − canibalización: lo que de verdad suma a la red;
#    * en tres escenarios: **conservador (P10), base (P50) y optimista (P90)**, todo en **régimen maduro** (año 3+).
# 2. Mide el **mercado dentro de la isócrona** de cada candidato (población, hogares objetivo, gasto, trabajadores,
#    competencia y saturación).
# 3. Calcula un **score multicriterio** (0 a 1) con 7 criterios y la **viabilidad** (venta neta ≥ P25 de las sedes
#    actuales del mismo formato).
# 4. Arma el **Top 20 por selección secuencial**: elige el mejor sitio, lo "abre" en el modelo, recalcula todo y elige el
#    siguiente. Así el plan no propone sitios que se roban venta entre sí.
# 5. Para **clínica de alta complejidad** entrega **macrozonas** (2–3 alternativas), porque esa decisión es de largo plazo.
# 6. Evalúa los **sitios propuestos por la clínica** (hasta 5) en los tres formatos y recomienda uno.
#
# | Criterio del score | Peso | Por qué |
# |---|---|---|
# | Venta neta | 40% | es el objetivo económico |
# | Hogares AB, C1a y C1b en la isócrona | 15% | segmento objetivo del FRF |
# | Gasto en salud en la isócrona | 10% | tamaño del mercado |
# | Saturación (competencia por 1.000 personas objetivo), invertida | 10% | menos competencia = mejor |
# | Accesibilidad (tipo de vía + metro) | 10% | visibilidad y acceso |
# | Canibalización relativa, invertida | 10% | no robarle a la propia red |
# | Población flotante (trabajadores) | 5% | demanda diurna |
#
# | Entra | Sale (`trabajo/`) |
# |---|---|
# | modelo (06) · manzanas candidatas y tiempos (04) · manzanas (03) · curva de maduración (02) | `candidatos_<formato>.parquet`, `top20.parquet`, `macrozonas.parquet`, `isocronas_top.parquet`, `sitios_propuestos_evaluados.csv`, `fichas_extras.json` |

# %%
import os, sys
sys.path.insert(0, os.path.abspath("."))
import numpy as np, pandas as pd, geopandas as gpd
from IPython.display import display
import config_estudio
from geoventas import insumos, modelo as M, expansion as X, red, unidades, geocodificacion as GC, cliente, graficos, mapas, verificacion, metricas, conclusiones
from geoventas.utilidades import Cronometro, guardar, guardar_si_hay, cargar, miles, mm, pct, carpeta_salida

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "07")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("07_expansion")
GRAF = carpeta_salida(cfg, "graficos"); MAPAS = carpeta_salida(cfg, "mapas")
ut = cargar(cfg, "unidades.parquet"); comp = cargar(cfg, "competencia.parquet")
sedes_estudio = cargar(cfg, "sedes_estudio.parquet")
sedes = sedes_estudio[sedes_estudio["en_modelo"]].reset_index(drop=True)
mod = cargar(cfg, "modelo.pkl"); th, thetas, d = mod["th"], mod["thetas"], mod["d"]
cand = cargar(cfg, "candidatos.parquet"); Tcand = cargar(cfg, "T_cand.npy").astype(np.float32)   # manzanas × manzanas candidatas
curva = cargar(cfg, "curva_maduracion.json"); rampa = curva["rampa_anual"]
mix_lineas = cargar(cfg, "mix_lineas_formato.csv").set_index("formato_modelo")
cfg["expansion"]["sd_log_sede"] = float(mod.get("sd_log_sede", 0.10))      # error propio de una sede nueva (notebook 06)
print(f"Manzanas candidatas: {len(cand):,} · escenarios con {len(thetas)} juegos de parámetros"
      + (f" × error propio de sede σ = {X.sd_sede(cfg):.0%}" if X.sd_sede(cfg) else " (sin error propio de sede)")
      + f" · rampa años 1-3: {[f'{r:.0%}' for r in rampa]}")

# %% [markdown]
# ## 1. Evaluar todos los candidatos en los 3 formatos
# Los candidatos a menos de la distancia mínima de una sede propia del mismo formato (o superior) quedan fuera:
# clínica 8 km, centro médico 2,5 km, toma de muestras 1,2 km (configurable).

# %%
evals = {}
for fmt in M.FORMATOS:
    evals[fmt] = X.evaluar_formato(fmt, cand, Tcand, ut, sedes, th, thetas, d, cfg)
    e = evals[fmt]
    log(f"{X.FMT_NOMBRE[fmt]}: {len(e):,} candidatos evaluados · viables {e['viable'].sum():,} · umbral {mm(e['umbral_viabilidad'].iloc[0])}/mes")
idoneo = X.formato_idoneo(evals)
print("Formato idóneo (el de mayor venta neta respecto de su umbral) entre los candidatos viables:")
print(idoneo[idoneo["indice_idoneo"] >= 1]["formato_idoneo"].map(X.FMT_NOMBRE).value_counts())

# %% [markdown]
# ### Mapa: potencial de cada manzana candidata
# Venta neta mensual (régimen, escenario base) si se abriera en esa manzana una sede de cada formato, su score y el
# **formato idóneo** (el de mayor venta neta respecto de su umbral de viabilidad). Elige el indicador arriba a la
# izquierda. Las manzanas sin valor en un formato están demasiado cerca de una sede propia de ese formato (o superior).

# %%
pot = cand[["id_cand", "ut", "comuna", "via_referencia", "geometry"]].copy()
etq = {"clinica": "clínica", "centro_medico": "centro médico", "toma_muestras": "toma de muestras"}
for fmt in M.FORMATOS:
    e = evals[fmt].set_index("id_cand")
    pot[f"neta_{fmt}"] = pot["id_cand"].map(e["venta_neta"])
    pot[f"score_{fmt}"] = pot["id_cand"].map(e["score"])
    pot[f"viable_{fmt}"] = pot["id_cand"].map(e["viable"]).map({True: "viable", False: "no viable"})
fi = idoneo.set_index("id_cand")
pot["formato_idoneo"] = pot["id_cand"].map(fi["formato_idoneo"].where(fi["indice_idoneo"] >= 1)).map(X.FMT_NOMBRE).fillna("Ninguno viable")
for f in M.FORMATOS:
    pot[f"viable_{f}"] = pot[f"viable_{f}"].map({"viable": "Sí, supera el mínimo de venta", "no viable": "No llega al mínimo de venta"})
nombre_corto = {"Clínica de Alta Complejidad": "Clínica", "Centro Médico Ambulatorio": "Centro médico",
                "Toma de Muestras / Laboratorio": "Toma de muestras", "Ninguno viable": "Ningún formato llega al mínimo de venta"}
ind_pot = ([mapas.ind("formato_idoneo", "Mejor formato para abrir en cada manzana", "texto",
                      categorias={**{X.FMT_NOMBRE[k]: c for k, c in mapas.COLOR_FORMATO.items()}, "Ninguno viable": "#d5d8dd"},
                      nombres_categoria=nombre_corto,
                      descripcion="El formato que más vende respecto de lo mínimo que se le exige (lo que vende una sede actual "
                                  "del mismo formato en el 25% más bajo).")]
           + [mapas.ind(f"neta_{f}", f"Venta nueva si se abre {('una ' if f != 'centro_medico' else 'un ') + etq[f]} aquí", "mm",
                        paleta="secuencial", unidad="pesos al mes (descontando lo que se quita a las sedes actuales)",
                        nulo="Muy cerca de una sede actual de ese formato",
                        descripcion="Lo que vendería la sede nueva MENOS lo que les quitaría a las sedes actuales: lo que de verdad suma a la red.")
              for f in M.FORMATOS]
           + [mapas.ind(f"score_{f}", f"Puntaje como {etq[f]} (0 a 100)", "puntaje", paleta="morado", unidad="puntos",
                        nulo="Muy cerca de una sede actual de ese formato",
                        descripcion="Combina venta nueva, público objetivo, gasto, competencia, acceso, canibalización y trabajadores.")
              for f in M.FORMATOS])
mapas.mapa([
    mapas.capa_manzanas(ut, "Demanda por manzana (fondo)", mapas.inds("pob_objetivo"), visible=False, opacidad=0.5),
    mapas.capa_manzanas(pot, "Manzanas candidatas", ind_pot,
                        ficha=[mapas.ind("via_referencia", "Vía de acceso", "texto")]
                        + [mapas.ind(f"viable_{f}", f"¿Sirve para {('una ' if f != 'centro_medico' else 'un ') + etq[f]}?", "texto") for f in M.FORMATOS],
                        etiqueta_id="Manzana candidata", opacidad=0.9),
    mapas.capa_sedes(sedes),
], titulo="¿Dónde conviene abrir y con qué formato?",
   subtitulo=f"{miles(len(cand))} manzanas candidatas (urbanas y frente a una avenida o calle principal) · venta en régimen, escenario base",
   ayuda=["Solo se pintan las manzanas candidatas: urbanas y con frente a una vía terciaria o superior.",
          "Al abrir, el color dice el MEJOR FORMATO para cada manzana. En el panel puedes ver la venta nueva o el puntaje de cada formato.",
          "Las manzanas grises no llegan al mínimo de venta en ningún formato."],
   archivo=os.path.join(MAPAS, "07_potencial_por_formato.html"))

# %% [markdown]
# ## 2. Top 20 por selección secuencial
# En cada paso se elige el candidato viable con mayor score entre los tres formatos, respetando el **tope por formato**
# (clínica 3, centro médico 10, toma de muestras 10) y una **distancia mínima entre sedes nuevas** del mismo formato.
# Ese sitio se agrega a la red y se recalcula la venta neta de todos los demás antes del paso siguiente.

# %%
top, d_plan = X.seleccion_secuencial(evals, Tcand, d, th, thetas, cfg, rampa)
nombre_sede = dict(zip(sedes["sede"], mapas.nombre_sede(sedes)))
if len(top) and "sedes_mas_canibalizadas" in top:
    import re
    top["sede_mas_canibalizada_cod"] = top["sedes_mas_canibalizadas"].astype(str).str.split(" \\(").str[0]
    top["sedes_mas_canibalizadas"] = top["sedes_mas_canibalizadas"].astype(str).map(
        lambda t: re.sub(r"[A-Z]+-\d+", lambda m_: nombre_sede.get(m_.group(0), m_.group(0)), t))
log(f"Top: {len(top)} ubicaciones")
cols = ["id_top", "formato_FRF", "comuna", "ut", "via_referencia", "venta_bruta", "canibalizacion", "venta_neta", "venta_neta_p10_marginal",
        "venta_neta_p90_marginal", "score", "sedes_mas_canibalizadas"]
vista = top[[c for c in cols if c in top]].copy()
for c in ("venta_bruta", "canibalizacion", "venta_neta", "venta_neta_p10_marginal", "venta_neta_p90_marginal"):
    if c in vista:
        vista[c] = vista[c].map(mm)
vista["score"] = vista["score"].round(3)
vista.rename(columns={"ut": "manzana"})

# %%
graficos.top_n(top, os.path.join(GRAF, "07_top.png"));
print(f"Venta neta incremental del plan completo (régimen, base): {mm(top['venta_neta'].sum())}/mes · {mm(12 * top['venta_neta'].sum())}/año")

# %% [markdown]
# ## 3. Clínica de alta complejidad: macrozonas
# Alrededor de cada sitio de referencia, la **macrozona** es el área donde cualquier candidato logra al menos el 80% de
# su venta neta. Da flexibilidad para buscar terreno. Siempre se entregan **2 a 3 alternativas**: primero las clínicas que
# entraron al plan y, si faltan, los mejores sitios de clínica que no entraron (`en_plan = False`), con su **brecha** frente
# al umbral de viabilidad (información útil para el comité, por el horizonte de inversión de una clínica).

# %%
macro = X.macrozonas(evals["clinica"], top, cfg)
macro.drop(columns="geometry").assign(**{c: macro[c].map(mm) for c in ("venta_neta_referencia", "umbral_viabilidad", "venta_neta_min", "venta_neta_max") if c in macro},
                                       brecha_vs_umbral=macro["brecha_vs_umbral"].map(pct) if "brecha_vs_umbral" in macro else None)

# %% [markdown]
# ## 4. Isócronas y fichas de cada ubicación del Top
# Para cada sitio: isócronas de 10, 15 y 30 minutos (auto, punta), perfil de la población dentro de su isócrona de
# scoring, competidores más cercanos y desglose de la venta por línea de servicio (según la mezcla típica del formato).

# %%
rd = cargar(cfg, "red.pkl")
iso_top = red.isocronas_sitios(rd, top[["id_top", "x", "y"]].rename(columns={"id_top": "id"}), cfg, ["auto_punta"], cronometro=log, minutos=[10, 15, 30]) if len(top) else gpd.GeoDataFrame()
comp_m = comp.to_crs(cfg["estudio"]["crs_metrico"])
extras = {}
mz_de = {r["id_top"]: r["macrozona"] for _, r in macro.iterrows() if r.get("id_top")}
for _, s in top.iterrows():
    minutos = cfg["expansion"]["isocrona_scoring_min"][s["formato"]]
    perfil = X.perfil_isocrona(Tcand[:, int(s["col_T"])], ut, minutos, cfg)
    lineas = (mix_lineas.loc[s["formato"]] * s["venta_neta"]).round(0).to_dict() if s["formato"] in mix_lineas.index else {}
    extras[s["id_top"]] = {"perfil": {k: round(float(v), 4) for k, v in perfil.items()}, "minutos_isocrona": minutos,
                           "competidores": X.competidores_cercanos(s["x"], s["y"], comp_m), "lineas": lineas, "macrozona": mz_de.get(s["id_top"], "")}
pd.DataFrame({k: v["perfil"] for k, v in extras.items()}).T.round(3).head(10)

# %% [markdown]
# ## 5. Sitios propuestos por la clínica
# Cada dirección se geocodifica con el Maestro de Calles, se calculan sus tiempos por la red y se evalúa en los tres
# formatos con el mismo modelo. La columna `formato_recomendado` es el formato con mejor venta neta respecto de su umbral.
# **Esta misma celda sirve para evaluar cualquier ubicación fuera del ranking** (FRF 1.2): basta con poner otra lista.

# %%
prop = cliente.leer_sitios_propuestos(cfg)
prop_eval = None
if prop is not None and len(prop):
    if not {"lat", "lon"}.issubset(prop.columns) or prop[["lat", "lon"]].isna().any().any():
        calles = cargar(cfg, "calles.parquet"); censo = cargar(cfg, "censo.parquet"); C = cfg["columnas"]["censo"]
        comunas = censo[[C["comuna"], C["cod_comuna"]]].drop_duplicates().rename(columns={C["comuna"]: "comuna", C["cod_comuna"]: "cod_comuna"})
        prop = GC.Geocodificador(calles, comunas).geocodificar_tabla(prop, "direccion")
        prop["lat"], prop["lon"] = prop["geo_lat"], prop["geo_lon"]
    prop = prop.dropna(subset=["lat", "lon"]).reset_index(drop=True)
    prop["id_sitio"] = [f"P{k + 1}" for k in range(len(prop))]
    pm = gpd.GeoDataFrame(prop, geometry=gpd.points_from_xy(prop["lon"], prop["lat"]), crs="EPSG:4326").to_crs(cfg["estudio"]["crs_metrico"])
    prop["x"], prop["y"] = pm.geometry.x.values, pm.geometry.y.values
    prop["ut"] = unidades.asignar_a_unidades(gpd.GeoDataFrame(prop, geometry=gpd.points_from_xy(prop["x"], prop["y"]),
                                                              crs=cfg["estudio"]["crs_metrico"]), ut, cfg)      # manzana del sitio
    Tsit = red.tiempos_a_puntos(rd, ut, prop[["x", "y"]].values, "auto_punta", cfg)
    # se evalúan contra la red ACTUAL (sin el Top 20), para que la clínica compare cada sitio por sí solo
    prop_eval = X.evaluar_sitios_dados(prop, Tsit, ut, d, th, thetas, cfg, rampa)
    idx_cols = [c for c in ["id_sitio", "nombre", "direccion", "ut", "formato_propuesto", "formato_recomendado"] if c in prop_eval]
    resumen_prop = prop_eval.pivot_table(index=idx_cols, columns="formato", values="venta_neta").reset_index()
    for f in M.FORMATOS:
        resumen_prop[f] = resumen_prop[f].map(mm)
    display(resumen_prop)
    display(prop_eval[["id_sitio", "formato", "venta_bruta", "canibalizacion", "venta_neta", "venta_neta_p10", "venta_neta_p90", "umbral_viabilidad", "indice_viabilidad", "viable"]]
            .assign(**{c: lambda d_, c=c: d_[c].map(mm) for c in ("venta_bruta", "canibalizacion", "venta_neta", "venta_neta_p10", "venta_neta_p90", "umbral_viabilidad")}).round(2))
else:
    print("No hay sitios propuestos (RUTAS['sitios_propuestos'] vacío).")

# %% [markdown]
# ## 6. Mapa del plan de expansión
# * **Manzanas del Top 20** (polígono) y su **sitio** (círculo grande) en orden de apertura, color por formato. Clic: ficha.
# * **Isócronas** de 15 minutos de cada sitio nuevo (apagadas al abrir: se prenden en el control de capas, arriba a la derecha).
# * **Macrozonas** de clínica (polígonos morados).
# * **Rombos negros** = sitios propuestos por la clínica.
# * **Líneas** = hacia la sede actual que más se canibaliza.

# %%
capas = [mapas.capa_manzanas(pot, "Manzanas candidatas (contexto)", ind_pot[:1], visible=False, opacidad=0.6, etiqueta_id="Manzana candidata")]
if len(macro):
    capas.append(mapas.capa_macrozonas(macro))
if len(iso_top):
    i15 = iso_top[iso_top["minutos"] == 15].merge(top[["id_top", "formato_FRF"]], left_on="id", right_on="id_top")
    i15["ficha"] = [mapas.ficha(f"Ubicación {r['id_top']}", [("Zona", "a 15 minutos en auto o menos (hora punta)"),
                                                             ("Superficie", f"{miles(r['area_km2'], 1)} km²")],
                                subtitulo=r["formato_FRF"], color=None) for _, r in i15.iterrows()]
    capas.append(mapas.capa(i15.to_crs("EPSG:4326"), "Zona a 15 min de cada ubicación nueva", campo_categoria="formato_FRF",
                            colores_categoria={X.FMT_NOMBRE[k]: c for k, c in mapas.COLOR_FORMATO.items()}, opacidad=0.08, peso=1,
                            ficha_html="ficha", visible=False))
if len(top):
    from shapely.geometry import LineString
    sx = sedes.set_index("sede")
    lin = []
    for _, r in top.iterrows():
        sc = str(r.get("sede_mas_canibalizada_cod", ""))
        if sc in sx.index:
            lin.append({"id_top": r["id_top"], "sede": nombre_sede.get(sc, sc), "ficha": mapas.ficha(
                f"#{int(r['orden'])} le quita más venta a…", [("Sede", nombre_sede.get(sc, sc)), ("Detalle", r.get("sedes_mas_canibalizadas", ""))]),
                "geometry": LineString([(r["lon"], r["lat"]), (sx.loc[sc, "lon"], sx.loc[sc, "lat"])])})
    if lin:
        capas.append(mapas.capa(gpd.GeoDataFrame(lin, crs="EPSG:4326"), "A qué sede actual le quita más venta cada ubicación", color="#8a94a3",
                                peso=1.4, ficha_html="ficha", visible=False))
    tm = cand.set_index("id_cand").loc[top["id_cand"], ["geometry"]].reset_index().merge(top[["id_cand", "id_top", "orden", "formato_FRF", "comuna", "venta_neta"]], on="id_cand")
    tm = gpd.GeoDataFrame(tm, geometry="geometry", crs=cand.crs).assign(manzana=lambda x: cand.set_index("id_cand").loc[x["id_cand"], "ut"].values)
    capas.append(mapas.capa_manzanas(tm, "Manzanas de las 20 ubicaciones", en_leyenda=False, indicadores=[mapas.ind("formato_FRF", "Formato", "texto", nombres_categoria=nombre_corto,
                                     categorias={X.FMT_NOMBRE[k]: c for k, c in mapas.COLOR_FORMATO.items()})],
                                     id_col="manzana", ficha=[mapas.ind("orden", "Orden de apertura", "entero"),
                                                              mapas.ind("venta_neta", "Venta nueva para la red", "mm")],
                                     opacidad=0.95))
    capas.append(mapas.capa_top(top))
if prop_eval is not None:
    pv = prop_eval[prop_eval["formato"] == prop_eval["formato_recomendado"]].copy()
    capas.append(mapas.capa_propuestos(pv))
capas.append(mapas.capa_sedes(sedes, nombre="Sedes actuales de Clínica Alemana"))
mapas.mapa(capas, titulo="Plan de expansión: 20 ubicaciones recomendadas",
           subtitulo=(f"Venta nueva para la red: {mapas.pesos(top['venta_neta'].sum())} al mes en régimen (escenario base)" if len(top) else ""),
           ayuda=["Los círculos con número son las 20 ubicaciones recomendadas: el número es el orden sugerido de apertura y el color, el formato.",
                  "Las cruces son las sedes actuales. Los rombos negros, los sitios que propuso la clínica.",
                  "Las áreas moradas son las macrozonas para una clínica nueva: cualquier terreno dentro logra al menos el 80% de la venta del mejor sitio.",
                  "Haz clic en cada ubicación para ver su venta, el rango posible y a qué sedes actuales les quita venta."],
           archivo=os.path.join(MAPAS, "07_plan_expansion.html"),
           encuadrar=[mapas.NOMBRE_TOP, mapas.NOMBRE_MACRO, "Sedes actuales de Clínica Alemana", mapas.NOMBRE_PROPUESTOS])

# %% [markdown]
# ## 7. Indicadores clave y conclusiones sobre el plan
# Cuánta venta nueva suma el plan y cuánto hace crecer la red, cuánta canibalización implica, qué tan amplios son los
# escenarios, qué vende el primer año, dónde se concentra el valor y **cuánto del segmento objetivo queda a ≤ 15 minutos
# de un centro médico o clínica gracias al plan**. Las conclusiones cambian según esas cifras (p. ej. canibalización
# baja, moderada o alta).

# %%
vm_red = cargar(cfg, "venta_madura.csv")
cobertura = metricas.cobertura_plan(ut, top, Tcand)
ind_plan = metricas.plan(top, vm_red, evals, macro, prop_eval, cobertura)
conclusiones.mostrar(conclusiones.generar(ind_plan, ["Plan"]), "Conclusiones sobre el plan de expansión")
metricas.tabla(ind_plan)[["indicador", "valor", "lectura"]]

# %% [markdown]
# ## 8. Verificaciones

# %%
E = cfg["expansion"]
if len(top):
    chk("Top: no supera 20 ubicaciones", len(top) <= E["n_top"], len(top))
    chk("Top: respeta el tope por formato", all((top["formato"] == k).sum() <= v for k, v in E["max_por_formato"].items()), top["formato"].value_counts().to_dict())
    ok = True
    for k, g in top.groupby("formato"):
        if len(g) > 1:
            dm = np.hypot(g["x"].values[:, None] - g["x"].values[None, :], g["y"].values[:, None] - g["y"].values[None, :]); np.fill_diagonal(dm, np.inf)
            ok &= dm.min() >= E["dist_min_entre_nuevas_km"][k] * 1000 - 1
    chk("Top: distancia mínima entre sedes nuevas del mismo formato", ok, "")
    chk("Top: todas viables (venta neta ≥ umbral)", (top["venta_neta"] >= top["umbral_viabilidad"] - 1e-6).all(), "")
    chk("Top: venta neta ≤ bruta y canibalización ≥ 0", ((top["venta_neta"] <= top["venta_bruta"] + 1e-6) & (top["canibalizacion"] >= -1e-6)).all(), "")
    chk("Top: escenarios ordenados P10 ≤ P50 ≤ P90", ((top["venta_neta_p10_marginal"] <= top["venta_neta_p50_marginal"] + 1e-6) &
                                                      (top["venta_neta_p50_marginal"] <= top["venta_neta_p90_marginal"] + 1e-6)).all(), "")
    chk("Top: proyección año 1 < año 3 (rampa)", (top["venta_anio_1"] < top["venta_anio_3"]).all(), "")
    ancho = (top["venta_neta_p90_marginal"] / top["venta_neta_p10_marginal"].where(top["venta_neta_p10_marginal"] > 0)).median()
    chk("Top: escenarios incluyen el error propio de una sede nueva (P90/P10 > 1,1)",
        not X.sd_sede(cfg) or ancho > 1.1, f"σ sede = {X.sd_sede(cfg):.0%} · P90/P10 mediano = {ancho:.2f}")
chk("Macrozonas de clínica informadas (2 a 3 alternativas, FRF 2.4)", 2 <= len(macro) <= E["n_macrozonas"], f"{len(macro)} · en el plan: {int(macro['en_plan'].sum()) if len(macro) else 0}")
if prop_eval is not None:
    chk("Sitios propuestos: todos geocodificados y evaluados", prop_eval["id_sitio"].nunique() == len(prop), f"{prop_eval['id_sitio'].nunique()} de {len(prop)}")
chk.guardar(cfg)
chk.tabla()

# %%
for fmt in M.FORMATOS:              # opcionales: lo que esta corrida no produce se borra (nada de corridas anteriores)
    e = evals.get(fmt)
    guardar_si_hay(None if e is None else e.drop(columns=[c for c in ("geometry",) if c in e]), cfg, f"candidatos_{fmt}.parquet")
guardar(top, cfg, "top20.parquet"); guardar(idoneo, cfg, "formato_idoneo.csv")
guardar_si_hay(macro, cfg, "macrozonas.parquet")
guardar_si_hay(iso_top, cfg, "isocronas_top.parquet")
guardar(extras, cfg, "fichas_extras.json")
guardar_si_hay(prop_eval, cfg, "sitios_propuestos_evaluados.csv")
guardar(metricas.como_dict(ind_plan), cfg, "metricas_plan.json")
log("listo")
