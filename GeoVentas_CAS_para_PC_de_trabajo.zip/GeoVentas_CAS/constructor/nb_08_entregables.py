# %% [markdown]
# # 08 · Entregables del estudio
# **Hito 3 del FRF · "Entrega de documentación y bases" + "Habilitación de Mapdrive®"** (sección 4 del FRF)
#
# | Entregable (FRF) | Archivo en `salidas/entregables/` |
# |---|---|
# | Informe Ejecutivo Estratégico (PDF) | `Informe_Ejecutivo_CAS.pdf` (indicadores clave + conclusiones que se adaptan a los datos) |
# | Conclusiones e indicadores (texto) | `Conclusiones_CAS.md` y hojas **Conclusiones** e **Indicadores** del Excel |
# | Fichas Técnicas por Ubicación (XLSX y PDF) | `Resultados_y_Fichas_CAS.xlsx` (hojas Ranking y Fichas) y `Fichas_Tecnicas_CAS.pdf` |
# | Capas GIS (GPKG) para Mapdrive® y para que la clínica las conserve | `Capas_GIS_CAS.gpkg` (incluye las isócronas de entorno de cada sede) |
# | Análisis de entorno de las sedes (punta y fuera de punta, 5 a 30 min) | hojas **Entorno sedes** y **Entorno detalle** del Excel |
# | Anexo Metodológico (PDF) | `Anexo_Metodologico_CAS.pdf` (y `.md`) |
# | Mapa web de resultados | `Mapa_Resultados_CAS.html` |
#
# El Anexo incluye el **procedimiento para recalibrar el modelo cada año** y para **evaluar ubicaciones fuera del
# ranking** (FRF 1.2).

# %%
import os, sys
sys.path.insert(0, os.path.abspath("."))
import numpy as np, pandas as pd, geopandas as gpd
import config_estudio
from geoventas import insumos, modelo as M, entregables as ENT, mapas, verificacion, metricas, conclusiones, entorno as ENT_
from geoventas.utilidades import Cronometro, cargar, existe, miles, mm, pct, carpeta_salida

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "08")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("08_entregables")
OUT = carpeta_salida(cfg, "entregables"); GRAF = carpeta_salida(cfg, "graficos")
ut = cargar(cfg, "unidades.parquet"); comp = cargar(cfg, "competencia.parquet")
cand = cargar(cfg, "candidatos.parquet")
ev_fmt = {f: cargar(cfg, f"candidatos_{f}.parquet") for f in M.FORMATOS if existe(cfg, f"candidatos_{f}.parquet")}
descartes = cargar(cfg, "manzanas_descartadas.parquet") if existe(cfg, "manzanas_descartadas.parquet") else None
tablas_rut = {n: cargar(cfg, f) for n, f in (("Afinidad", "afinidad.csv"), ("Multisede", "multisede.csv"), ("Fidelidad", "fidelidad.csv"),
                                               ("Convenios empresas", "convenios_empresas.csv")) if existe(cfg, f)}
sedes_estudio = cargar(cfg, "sedes_estudio.parquet"); sedes = sedes_estudio[sedes_estudio["en_modelo"]].reset_index(drop=True)
top = cargar(cfg, "top20.parquet"); extras = cargar(cfg, "fichas_extras.json")
macro = cargar(cfg, "macrozonas.parquet") if existe(cfg, "macrozonas.parquet") else gpd.GeoDataFrame()
iso_top = cargar(cfg, "isocronas_top.parquet") if existe(cfg, "isocronas_top.parquet") else gpd.GeoDataFrame()
iso_sedes = cargar(cfg, "isocronas_sedes.gpkg")
areas = cargar(cfg, "areas_influencia.gpkg") if existe(cfg, "areas_influencia.gpkg") else None
mod = cargar(cfg, "modelo.pkl"); par = cargar(cfg, "parametros.csv"); val = cargar(cfg, "validacion_sede_nueva.csv")
vm = cargar(cfg, "venta_madura.csv"); curva = cargar(cfg, "curva_maduracion.json")
ind = cargar(cfg, "indicadores_sede.csv") if existe(cfg, "indicadores_sede.csv") else None
prop = cargar(cfg, "sitios_propuestos_evaluados.csv") if existe(cfg, "sitios_propuestos_evaluados.csv") else None
crec = cargar(cfg, "crecimiento.csv")
ent_res = cargar(cfg, "entorno_sedes.csv"); ent_det = cargar(cfg, "entorno_sedes_detalle.csv"); iso_ent = cargar(cfg, "isocronas_entorno.gpkg")
indicadores = [m for f in ("metricas_ventas.json", "metricas_entorno.json", "metricas_influencia.json", "metricas_pacientes.json",
                            "metricas_modelo.json", "metricas_plan.json") if existe(cfg, f)       # influencia (04b) es opcional
               for m in metricas.desde_dict(cargar(cfg, f))]
inf_pre = cargar(cfg, "influencia_preliminar_sedes.csv") if existe(cfg, "influencia_preliminar_sedes.csv") else None
cmp_inf = cargar(cfg, "comparacion_influencia_preliminar.csv") if existe(cfg, "comparacion_influencia_preliminar.csv") else None
concl = conclusiones.generar(indicadores)
print(f"Top: {len(top)} · macrozonas: {len(macro)} · sitios propuestos evaluados: {0 if prop is None else prop['id_sitio'].nunique()} · "
      f"{len(indicadores)} indicadores · {len(concl)} conclusiones")

# %% [markdown]
# ## Conclusiones del estudio
# Se escriben a partir de los indicadores de cada fase y **cambian con los datos**: cada regla mira el valor del
# indicador (crecimiento, concentración, cobertura, confiabilidad del modelo, canibalización…) y elige la conclusión y la
# recomendación que corresponden. ✅ fortaleza · ⚠️ alerta · 💡 oportunidad · ℹ️ dato.

# %%
conclusiones.mostrar(concl)

# %% [markdown]
# ## 1. Capas GIS (GeoPackage, WGS84)
# Una sola base con todas las capas del estudio: se abre en QGIS/ArcGIS y se carga tal cual en Mapdrive®. Las capas de
# territorio son **polígonos de manzana** (los originales del censo, sin simplificar). Por privacidad, ninguna capa trae
# conteos de pacientes por manzana: el origen de los pacientes se entrega solo como áreas de influencia por sede.

# %%
top_g = gpd.GeoDataFrame(top.copy(), geometry=gpd.points_from_xy(top["lon"], top["lat"]), crs="EPSG:4326") if len(top) else None
cols_ut = [c for c in ["ut", "comuna", "cod_comuna", "pob", "hog", "pob_objetivo", "hog_objetivo", "pct_objetivo", "gasto_salud_total",
                         "gasto_salud_objetivo", "trabajadores_est", "densidad_hab_km2", "area_km2", "uso_suelo", "gse_predominante",
                         "comp_clinica_peso", "comp_centro_medico_peso", "comp_laboratorio_peso", "comp_entorno_peso", "oferta_contexto_n",
                         "min_a_cas", "min_a_cm_o_clinica", "pob_objetivo_entorno", "brecha", "demanda_potencial", "venta_cas_modelo",
                         "participacion_modelo_%", "sede_que_mas_capta", "geometry"] if c in ut]
ut_out = ut[cols_ut].copy()
for c in ("min_a_cas", "min_a_cm_o_clinica"):
    if c in ut_out:
        ut_out[c] = ut_out[c].replace(np.inf, np.nan)
# manzanas candidatas con su evaluación en los 3 formatos
cand_out = cand[[c for c in ("id_cand", "ut", "comuna", "via_referencia", "rango_via", "prioridad", "pob_objetivo_entorno",
                             "trabajadores_est_entorno", "geometry") if c in cand]].copy()
for f, e in ev_fmt.items():
    e = e.set_index("id_cand")
    for col, nom in (("venta_bruta", "bruta"), ("canibalizacion", "canib"), ("venta_neta", "neta"), ("venta_neta_p10", "neta_p10"),
                     ("venta_neta_p90", "neta_p90"), ("score", "score"), ("viable", "viable")):
        if col in e:
            cand_out[f"{nom}_{f}"] = cand_out["id_cand"].map(e[col])
top_mz = None
if len(top):
    top_mz = cand.set_index("id_cand").loc[top["id_cand"], ["ut", "geometry"]].reset_index().merge(
        top[["id_cand", "id_top", "orden", "formato_FRF", "comuna", "venta_neta", "score"]], on="id_cand")
    top_mz = gpd.GeoDataFrame(top_mz, geometry="geometry", crs=cand.crs)
capas = {"00_manzanas_demanda_y_modelo": ut_out, "01_manzanas_candidatas": cand_out,
         "10_manzanas_descartadas": descartes, "02_sedes_cas": sedes_estudio.drop(columns=[c for c in ("fecha_apertura", "fecha_cierre") if c in sedes_estudio]),
         "03_isocronas_sedes": iso_sedes, "04_areas_influencia": areas, "05_competencia": comp.drop(columns=[c for c in comp.columns if comp[c].dtype == object and c not in
                                                                                                         ("id_universo", "nombre", "formato_FRF", "tipo_competencia", "segmento_estimado", "categoria", "grupo", "fuente_universo", "comuna")]),
         "06_top20_ubicaciones": top_g, "06_top20_manzanas": top_mz, "07_isocronas_top20": iso_top,
         "08_macrozonas_clinica": macro if len(macro) else None,
         "11_isocronas_entorno_sedes": iso_ent.assign(modo=iso_ent["modo"].map(ENT_.NOMBRE_MODO).fillna(iso_ent["modo"]))}
if prop is not None:
    capas["09_sitios_propuestos"] = gpd.GeoDataFrame(prop, geometry=gpd.points_from_xy(prop["lon"], prop["lat"]), crs="EPSG:4326")
ruta_gpkg = ENT.guardar_gpkg(capas, os.path.join(OUT, "Capas_GIS_CAS.gpkg"))
import pyogrio
pd.DataFrame(pyogrio.list_layers(ruta_gpkg), columns=["capa", "geometría"])

# %% [markdown]
# ## 2. Excel de resultados y fichas técnicas
# Hojas: **LEEME** (cómo leer cada hoja), **Conclusiones**, **Indicadores**, **Ranking**, **Fichas** (una sección por ubicación: identificación, venta,
# proyección, desglose por línea, mercado, perfil, competencia y scoring), **Macrozonas**, **Sitios propuestos**,
# **Diagnóstico sedes**, **Validación**, **Parámetros**, **Supuestos** y **Verificaciones**.

# %%
fichas = ENT.ficha_larga(top, extras) if len(top) else pd.DataFrame()
cols_rank = ["id_top", "orden", "formato_FRF", "comuna", "ut", "via_referencia", "lat", "lon", "venta_bruta", "canibalizacion", "venta_neta",
             "venta_neta_p10_marginal", "venta_neta_p50_marginal", "venta_neta_p90_marginal", "umbral_viabilidad", "venta_anio_1", "venta_anio_2",
             "venta_anio_3", "venta_anual_regimen", "pob_isocrona", "hog_objetivo_isocrona", "gasto_salud_isocrona", "trabajadores_isocrona",
             "competencia_isocrona", "saturacion", "score", "sedes_mas_canibalizadas"]
diag = vm.merge(ind.drop(columns=[c for c in ("nombre", "formato_modelo", "venta_mensual_madura") if c in ind]), on="sede", how="left") if ind is not None else vm
notas = [("Modo", f"{cfg['modo']}" + (" — DATOS SIMULADOS: solo para probar el flujo; no usar para decisiones" if cfg["modo"] == "simulacion" else "")),
         ("Unidades", "Ventas en pesos chilenos del último mes de la serie (reales), por mes, en régimen maduro (año 3 en adelante) salvo las columnas venta_anio_1..3."),
         ("Escenarios", "P10 = conservador, P50 = base, P90 = optimista (bootstrap de los parámetros del modelo + error propio de una sede nueva, medido en la validación \"sede nueva\")."),
         ("Venta neta", "Venta bruta del sitio nuevo menos la venta que pierden las sedes actuales (canibalización)."),
         ("Viabilidad", "La venta neta supera el percentil 25 de la venta predicha de las sedes actuales del mismo formato."),
         ("Ranking", "Orden de apertura sugerido: cada sitio se eligió considerando que los anteriores ya estaban abiertos."),
         ("Fichas", "Formato largo: filtrar por id_top para ver la ficha de una ubicación."),
         ("Isócronas", "Minutos en auto en hora punta por la red vial (no buffers)."),
         ("Manzana", "Unidad de análisis: manzana del censo (columna ut = ID_BLOCK). Cada ubicación del Top es una manzana candidata; su sitio es el nodo de la vía de acceso."),
         ("Conclusiones", "Conclusiones del estudio escritas según los datos de esta corrida: tema, tipo (fortaleza, alerta, oportunidad, dato), detalle y qué hacer."),
         ("Indicadores", "Cifras clave de cada tema con su lectura en palabras (valor como texto y como número)."),
         ("Entorno sedes", f"Una fila por sede de la red (base de puntos del levantamiento): tipo de entorno, indicadores a {cfg['entorno']['minutos_referencia']} min en hora punta y fuera de punta, congestión, traslape con otras sedes, competidores más cercanos y un resumen en palabras."),
         ("Entorno detalle", "Una fila por sede × modo (punta / fuera de punta) × minutos (5 a 30): personas, poder de compra, actividad, generadores de flujo, propiedades y competencia."),
         ("Verificaciones", "Chequeos automáticos de todas las fases (✅ / ❌).")]
ruta_xlsx = ENT.guardar_excel({
    "Conclusiones": conclusiones.tabla(concl),
    "Indicadores": metricas.tabla(indicadores).drop(columns="clave"),
    "Entorno sedes": ENT_.tabla_resumen(ent_res, cfg["entorno"]["minutos_referencia"]),
    "Influencia preliminar": inf_pre,
    "Influencia prelim vs real": cmp_inf,
    "Entorno detalle": ENT_.tabla_detalle(ent_det),
    "Ranking": top[[c for c in cols_rank if c in top]].rename(columns={"ut": "manzana"}) if len(top) else None,
    "Fichas": fichas,
    "Macrozonas": macro.drop(columns="geometry") if len(macro) else None,
    "Sitios propuestos": prop,
    "Diagnostico sedes": diag,
    "Crecimiento": crec,
    **tablas_rut,
    "Manzanas descartadas": (descartes.drop(columns="geometry").assign(motivo=lambda t: t["motivo"].str.replace(r" \(.*", "", regex=True))
                             .groupby("motivo").agg(manzanas=("ut", "size"), poblacion=("poblacion", "sum")).reset_index()) if descartes is not None and len(descartes) else None,
    "Validacion sede nueva": val.assign(nombre=val["sede"].map(dict(zip(sedes["sede"], mapas.nombre_sede(sedes))))),
    "Parametros": par,
    "Supuestos": pd.DataFrame(cfg["supuestos"], columns=["supuesto", "valor", "justificación"]),
    "Verificaciones": verificacion.resumen_todas(cfg),
}, os.path.join(OUT, "Resultados_y_Fichas_CAS.xlsx"), notas)
log("Excel listo")

# %% [markdown]
# ## 3. Fichas técnicas en PDF (una página por ubicación)

# %%
muestra = os.path.join(GRAF, "08_muestra_ficha.png")
ruta_fichas = ENT.fichas_pdf(top, extras, ut, iso_top.to_crs(cfg["estudio"]["crs_metrico"]) if len(iso_top) else iso_top, comp, sedes,
                             os.path.join(OUT, "Fichas_Tecnicas_CAS.pdf"), cfg, png_muestra=muestra) if len(top) else None
log("fichas PDF listas · así se ve la primera:")
from IPython.display import Image, display
if ruta_fichas:
    display(Image(muestra, width=1000))

# %% [markdown]
# ## 4. Informe ejecutivo (PDF)

# %%
th = mod["th"]; met = mod["metricas"]
kpis = {"Sedes de Clínica Alemana en el estudio": f"{len(sedes)}", "Manzanas útiles (unidad de análisis)": miles(len(ut)),
        **metricas.kpis(indicadores)}
hallazgos = conclusiones.para_pdf(concl)          # conclusiones que se adaptan a los datos (reemplazan a los textos fijos)
figs = [os.path.join(GRAF, f) for f in ("07_top.png", "06_validacion_sede_nueva.png", "06_decaimiento.png", "04_entorno_curvas.png", "02_serie_red.png")]
ruta_inf = ENT.informe_ejecutivo_pdf(os.path.join(OUT, "Informe_Ejecutivo_CAS.pdf"), cfg, kpis, hallazgos, top, figs, cfg["supuestos"])
log("informe listo")
ruta_concl = os.path.join(OUT, "Conclusiones_CAS.md")
with open(ruta_concl, "w", encoding="utf-8") as f:
    f.write(f"# Conclusiones · {cfg['estudio']['nombre']}\n\n"
            + ("> DATOS SIMULADOS: solo para probar el flujo; no usar para decisiones.\n\n" if cfg["modo"] == "simulacion" else "")
            + "Escritas según los datos de esta corrida. ✅ fortaleza · ⚠️ alerta · 💡 oportunidad · ℹ️ dato.\n\n"
            + conclusiones.markdown(concl) + "\n\n## Indicadores clave\n\n"
            + ENT.tabla_md(metricas.tabla(indicadores)[["tema", "indicador", "valor", "lectura"]]) + "\n")
pd.Series(kpis)

# %% [markdown]
# ## 5. Anexo metodológico (con el procedimiento de recalibración anual)

# %%
secciones = [
    ("1. Fuentes y unidad de análisis",
     "Bases Equifax: censo por manzana (SD06), personas, empresas, bienes raíces, POIs (PI01) y Maestro de Calles (BC08). "
     "Data de Clínica Alemana: ventas mensuales por sede (5 años), hoja de sedes, origen de pacientes y eventos. "
     "Competencia: levantamiento propio (DEIS, Superintendencia de Salud, OSM, Farmanet, Overture y webs oficiales), con prioridad, + los POIs de "
     "salud de Equifax que no estaban; los lugares repetidos entre ambas fuentes se unieron por coordenadas, nombre, dirección y tipo (uno por lugar). "
     f"Unidad de análisis: la manzana del censo ({miles(len(ut))} manzanas útiles"
     + (f"; se descartaron {miles(len(descartes))} manzanas sin población ni actividad, de uso excluido o de áreas verdes" if descartes is not None and len(descartes) else "")
     + "). Demanda, tiempos de viaje, calibración, candidatos, mapas y capas GIS se trabajan sobre los polígonos de manzana."
     " Origen de los pacientes: RUT (en cualquier formato, llevado a una forma canónica) cruzado con las bases de personas (domicilio) y empresas "
     "(convenios), seudonimizado con SHA-256 + sal secreta."),
    ("2. Red vial e isócronas",
     "Grafo OSM de cada región del estudio (GraphML elegido por nombre de archivo) cargado con OSMnx. Tiempos con Dijkstra sobre matrices dispersas, en paralelo. Modos: auto valle (velocidad del grafo), auto punta "
     "(× factor 0,55–0,80 por tipo de vía), a pie (4,8 km/h) y transporte público (red multicapa: caminata + bus por vías principales + líneas GTFS). "
     "Las isócronas son el polígono de las calles alcanzadas (franja de 60 m) y se verificaron contra la receta clásica de OSMnx (nx.ego_graph)."),
    ("2b. Análisis de entorno de las sedes",
     f"Sedes de la base de puntos del levantamiento (maestro de sedes, {len(ent_res)} dentro del área de estudio). Para cada sede, modo "
     f"({', '.join(ENT_.NOMBRE_MODO.get(m, m).lower() for m in cfg['entorno']['modos'])}) y corte ({', '.join(map(str, cfg['entorno']['minutos']))} min): "
     "tiempos manzana → sede con Dijkstra en paralelo y sumas de todas las variables de las manzanas alcanzadas con una multiplicación de matrices "
     "(T ≤ m)ᵀ·V. Se informan personas, segmento objetivo, GSE, edades, gasto en salud, renta y avalúo medios, trabajadores, empresas, POIs generadores "
     "de flujo, propiedades por destino, competencia (y los 5 competidores más cercanos en minutos), traslape con otras sedes de la red "
     f"(a {cfg['entorno']['minutos_traslape']} min, sin contar edificios del mismo recinto) y la pérdida de público en hora punta. El tipo de entorno se asigna "
     f"con reglas a la vista a {cfg['entorno']['minutos_tipologia']} min en punta. Coherencia: la población por matrices coincide con la de los polígonos de isócrona."),
    ("3. Serie histórica",
     "Limpieza (duplicados, notas de crédito), deflactación al último mes, detección de meses atípicos (residuo robusto MAD), quiebres de nivel y eventos informados; "
     f"estacionalidad común; curva de maduración estimada (r0 = {curva.get('r0')}, τ = {curva.get('tau')} meses); venta madura = promedio desestacionalizado de los últimos "
     f"{cfg['ventas']['meses_calibracion']} meses válidos, llevando a régimen las sedes en maduración."),
    ("4. Modelo de ventas",
     "Huff con competencia: venta_ij = κ·D_i·A_j·e^(−β_f·t_ij) / (1 + Σ_k A_k·e^(−β·t_ik) + Σ_c w_c·A_g·e^(−β·t_ic)); "
     "D_i = Σ_g gasto_salud_ig·p_g + λ·trabajadores_i·gasto per cápita; A_j = e^(a_f + γ·log(m²_j/m² típico)). "
     "i = manzana. La competencia usa el tiempo exacto de cada manzana a cada competidor: Σ_c w_c·e^(−β·t_ic) se precalcula para "
     f"{cfg['competencia']['n_grilla_beta']} valores de β y se interpola con un polinomio de Hermite (error < 0,01%; < 0,1% en su derivada, verificado en el notebook 04). "
     f"Estimación por máxima verosimilitud cuasi-Poisson penalizada sobre unidades de tipo '{mod['nivel']}' (gradiente analítico, L-BFGS-B). "
     f"Incertidumbre: {mod['metodo_incertidumbre']} ({len(mod['thetas'])} réplicas), combinada con el error propio de una sede nueva "
     f"(σ = {mod.get('sd_log_sede', 0):.0%} en escala log, raíz del error cuadrático medio de la validación \"sede nueva\") → escenarios P10/P50/P90."),
    ("5. Parámetros estimados", ENT.tabla_md(par[["parametro", "valor_natural", "interpretacion"]], 4)),
    ("6. Validación", "Sede nueva (dejando una sede fuera y recalibrando):\n" + ENT.tabla_md(val[["sede", "formato", "venta_observada", "venta_predicha_como_nueva", "error_pct"]], 3)
     + "\n" + "\n".join(f"- {k}: {v}" for k, v in {**met, **(mod.get('cv') or {}), **(mod.get('benchmark') or {})}.items())),
    ("7. Expansión",
     f"Candidatos: manzanas urbanas o de polos laborales que dan a una vía terciaria o superior (sitio = nodo de esa vía a ≤ {cfg['expansion']['dist_max_via_m']} m), "
     f"separadas al menos {cfg['expansion']['separacion_min_m']} m ({miles(len(cand))} evaluadas). Para cada formato: venta bruta, canibalización y neta "
     "(P10/P50/P90); mercado dentro de la isócrona de scoring; score multicriterio (pesos en la configuración); viabilidad = venta neta ≥ P25 de las sedes actuales "
     "del formato; selección secuencial del Top 20 con topes por formato y distancias mínimas; macrozonas para clínica."),
    ("8. Supuestos", "\n".join(f"- {a}: {b}. {c}" for a, b, c in cfg["supuestos"])),
    ("8b. Indicadores clave", ENT.tabla_md(metricas.tabla(indicadores)[["tema", "indicador", "valor", "lectura"]])),
    ("9. Recalibración anual (procedimiento)",
     "1) Pedir a la clínica los 12 meses nuevos de ventas, origen y eventos, con el mismo formato. "
     "2) Actualizar las rutas en config_estudio.py (y las bases Equifax si hay versión nueva: censo, personas, empresas, POIs). "
     "3) Correr los notebooks 01 a 08 en orden (Run All). Los resultados anteriores quedan en su carpeta; conviene copiar 'salidas' con la fecha. "
     "4) Revisar las verificaciones (hoja Verificaciones del Excel): todo debe quedar en ✅. "
     "5) Comparar parámetros y error 'sede nueva' con la versión anterior: cambios grandes en β o en los pesos GSE deben tener explicación de negocio. "
     "6) Agregar las sedes abiertas en el año a la hoja Sedes: el modelo las incorpora automáticamente y su rampa mejora la curva de maduración."),
    ("10. Evaluar ubicaciones fuera del ranking",
     "Poner las direcciones (o lat/lon) en un CSV con columnas nombre, direccion y comuna, apuntar RUTAS['sitios_propuestos'] a ese archivo y correr el notebook 07: "
     "la sección 5 geocodifica, calcula los tiempos por la red y entrega venta bruta, canibalización y neta (P10/P50/P90) en los 3 formatos con el formato recomendado."),
]
ruta_anexo = ENT.anexo_metodologico(os.path.join(OUT, "Anexo_Metodologico_CAS.md"), cfg, secciones)
log("anexo listo")

# %% [markdown]
# ## 6. Mapa web final (todas las capas)
# Es el mismo contenido que se carga en Mapdrive®: manzanas (demanda, accesibilidad y modelo, con selector de
# indicador), manzanas candidatas, sedes y sus isócronas, áreas de influencia, competencia, Top 20 (manzana y sitio),
# macrozonas y sitios propuestos.

# %%
nombre_sede = dict(zip(sedes["sede"], mapas.nombre_sede(sedes)))
ut_vis = ut_out.copy()
if "brecha" in ut_vis and "brecha_txt" not in ut_vis and "brecha_txt" in ut:
    ut_vis["brecha_txt"] = ut["brecha_txt"].values
capas_m = [mapas.capa_manzanas(ut_vis, "Manzanas",
                               mapas.inds("pob_objetivo", "gasto_salud_objetivo", "pct_objetivo", "trabajadores_est", "min_a_cas", "brecha_txt",
                                          "participacion_modelo_%", "venta_cas_modelo")
                               + ([mapas.ind("sede_que_mas_capta", "Sede que más atiende a cada barrio (según el modelo)", "texto",
                                             categorias=mapas.colores_sedes(sedes["sede"]),
                                             nombres_categoria=nombre_sede)] if "sede_que_mas_capta" in ut_vis else []),
                               ficha=mapas.inds("pob", "gse_predominante", "comp_entorno_peso"), opacidad=0.7)]
if "neta_centro_medico" in cand_out:
    cv = cand_out.copy()
    cv["mejor_neta"] = cv[[c for c in cv if c.startswith("neta_") and not c.startswith("neta_p")]].max(axis=1)
    capas_m.append(mapas.capa_manzanas(cv, "Manzanas candidatas a sede nueva",
                                       [mapas.ind("mejor_neta", "Venta nueva del mejor formato", "mm", unidad="pesos al mes",
                                                  descripcion="Lo que sumaría a la red una sede nueva en esa manzana, con el formato que más conviene.")]
                                       + [mapas.ind(f"neta_{f}", f"Venta nueva si se abre {('un ' if f == 'centro_medico' else 'una ')}{mapas.NOMBRE_FORMATO[f].lower()} aquí",
                                                    "mm", unidad="pesos al mes", nulo="Muy cerca de una sede actual de ese formato") for f in ev_fmt],
                                       etiqueta_id="Manzana candidata", visible=False, opacidad=0.9))
i15 = iso_sedes[(iso_sedes["modo"] == "auto_punta") & (iso_sedes["minutos"] == 15)].copy()
i15["sede_txt"] = i15["id"].map(nombre_sede).fillna(i15["id"])
capas_m.append(mapas.capa(i15, "Zona a 15 min en auto de cada sede actual", color=mapas.COLOR_SEDE, opacidad=0.06, borde=mapas.COLOR_SEDE, peso=1.2,
                          popup=["sede_txt", "pob_objetivo"], titulo_popup="sede_txt", etiquetas_popup={"pob_objetivo": "Público objetivo dentro"},
                          formato_popup={"pob_objetivo": "entero"}, simplificar_m=30, visible=False))
if areas is not None:
    av = areas.to_crs("EPSG:4326").copy()
    av["sede_txt"] = av["sede"].map(nombre_sede).fillna(av["sede"])
    av["zona"] = np.where(av["area"].str.startswith("primaria"), "Zona principal (60% de la venta)", "Zona secundaria (hasta el 80% de la venta)")
    capas_m.append(mapas.capa(av, "Zonas reales de cada sede (domicilio de sus pacientes)", campo_categoria="zona",
                              colores_categoria={"Zona principal (60% de la venta)": "#0d3f7a", "Zona secundaria (hasta el 80% de la venta)": "#6aa6d6"},
                              opacidad=0.18, peso=1.2, popup=["sede_txt", "zona", "minutos_max"], titulo_popup="sede_txt",
                              etiquetas_popup={"zona": "Zona", "minutos_max": "Hasta (minutos en auto)"}, formato_popup={"minutos_max": "min"},
                              filtro="sede_txt", etiqueta_filtro="Ver las zonas reales de la sede", visible=False))
en = comp[comp["en_modelo"]].copy()
en["grupo_txt"] = en["grupo"].map({"comp_clinica": "Clínica", "comp_centro_medico": "Centro médico", "comp_laboratorio": "Laboratorio / toma de muestras"})
capas_m.append(mapas.capa(en, "Competencia: clínicas, centros médicos y laboratorios", campo_categoria="grupo_txt",
                          colores_categoria={"Clínica": "#7b3fa0", "Centro médico": "#1f78b4", "Laboratorio / toma de muestras": "#2e9e44"},
                          radio=3, popup=["nombre", "formato_FRF", "segmento_estimado"], titulo_popup="nombre",
                          etiquetas_popup={"formato_FRF": "Tipo", "segmento_estimado": "Segmento"}, visible=False))
if len(macro):
    capas_m.append(mapas.capa_macrozonas(macro))
if top_mz is not None:
    capas_m.append(mapas.capa_manzanas(top_mz, "Manzanas de las 20 ubicaciones", en_leyenda=False, indicadores=[mapas.ind("formato_FRF", "Formato", "texto",
                                       nombres_categoria=mapas.NOMBRE_CORTO_FORMATO, categorias=mapas.COLOR_FORMATO_FRF)],
                                       ficha=[mapas.ind("orden", "Orden de apertura", "entero"), mapas.ind("venta_neta", "Venta nueva para la red", "mm")],
                                       opacidad=0.95))
if len(top):
    capas_m.append(mapas.capa_top(top))
if prop is not None:
    capas_m.append(mapas.capa_propuestos(prop[prop["formato"] == prop["formato_recomendado"]]))
capas_m.append(mapas.capa_sedes(sedes, nombre="Sedes actuales de Clínica Alemana"))
mapas.mapa(capas_m, titulo=f"Plan de expansión de Clínica Alemana en {cfg['estudio']['nombre_area']}",
           subtitulo=(f"{len(top)} ubicaciones recomendadas · venta nueva para la red: {mapas.pesos(top['venta_neta'].sum())} al mes en régimen"
                      if len(top) else "Sin ubicaciones que superen el mínimo de venta"),
           ayuda=["Los círculos con número son las ubicaciones recomendadas (el número es el orden sugerido de apertura; el color, el formato). "
                  "Las cruces son las sedes actuales y los rombos negros, los sitios que propuso la clínica.",
                  "Las manzanas muestran, a elección en el panel: dónde vive el público objetivo, su gasto en salud, el tiempo a Clínica Alemana, "
                  "las zonas con demanda lejos de la red y lo que capta hoy Clínica Alemana.",
                  "En las capas (arriba a la derecha) se prenden la competencia, las zonas reales de cada sede y las candidatas."],
           archivo=os.path.join(OUT, "Mapa_Resultados_CAS.html"), alto=740,
           encuadrar=[mapas.NOMBRE_TOP, mapas.NOMBRE_MACRO, "Sedes actuales de Clínica Alemana", mapas.NOMBRE_PROPUESTOS])

# %% [markdown]
# ## 7. Verificación final de todo el estudio

# %%
temas = {c.tema for c in concl}
chk("Conclusiones escritas para ventas, modelo y plan (y mercado/pacientes si hay datos)", {"Ventas", "Mercado", "Modelo", "Plan"} <= temas,
    f"{len(concl)} conclusiones · temas: {', '.join(sorted(temas))}")
# participaciones que por definición están entre 0 y 100% (la venta como % del gasto NO: incluye pacientes de fuera del
# segmento o del área; su rango plausible se controla en el notebook 05)
fuera = [m.nombre for m in indicadores if m.formato == "pct" and not isinstance(m.valor, str) and not 0 <= m.valor <= 1
         and m.clave.startswith(("participacion", "cobertura", "pct_", "brecha_pct", "cruce", "sedes_dentro", "retencion", "venta_15min"))]
chk("Indicadores sin valores imposibles (participaciones y coberturas entre 0 y 100%)", not fuera, "; ".join(fuera) or "todos en rango")
for r in [ruta_gpkg, ruta_xlsx, ruta_inf, ruta_anexo, ruta_anexo.replace(".md", ".pdf"), ruta_concl, os.path.join(OUT, "Mapa_Resultados_CAS.html")] + ([ruta_fichas] if ruta_fichas else []):
    chk(f"Archivo generado: {os.path.basename(r)}", os.path.exists(r) and os.path.getsize(r) > 0, f"{os.path.getsize(r) / 1e6:,.1f} MB" if os.path.exists(r) else "no existe")
chk.guardar(cfg)
todas = verificacion.resumen_todas(cfg)
print(f"TOTAL: {(todas['resultado'] == '✅').sum()} de {len(todas)} verificaciones OK en todas las fases")
todas
