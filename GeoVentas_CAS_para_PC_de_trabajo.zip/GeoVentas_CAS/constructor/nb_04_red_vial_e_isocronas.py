# %% [markdown]
# # 04 · Red vial, tiempos de viaje e isócronas (OSMnx)
# **Hito 2 del FRF · "Isócronas y áreas de influencia": vehicular (punta y valle), peatonal y transporte público**
#
# **Qué hace:**
# 1. Carga el grafo vial de la región con **OSMnx** (`ox.load_graphml`) y lo recorta al área de estudio.
# 2. Arma 4 redes de tiempo: **auto en hora valle**, **auto en hora punta**, **a pie** y **transporte público**.
# 3. Muestra con datos por qué un **buffer** (círculo) no sirve y hay que usar **isócronas**.
# 4. Verifica nuestras isócronas contra la receta clásica de OSMnx/networkx.
# 5. Calcula lo que usa el modelo, **manzana por manzana** y con tiempos exactos por la red:
#    * minutos de cada manzana a cada sede (4 modos);
#    * el **potencial de competencia** de cada manzana (tiempo exacto a cada uno de los ~2 mil competidores);
#    * las **manzanas candidatas** a sede nueva y los minutos de cada manzana a cada candidata.
#    Cada manzana se "pega" al nodo de la red más cercano a su punto interior; muchas comparten nodo, así que el costo
#    depende de los nodos y no de las 50 mil manzanas.
# 6. Dibuja las **isócronas de cada sede** en los 4 modos y mide qué hay dentro (población, GSE, gasto, competencia).
# 7. Hace el **análisis de entorno** de cada sede de la red (base de puntos del levantamiento): qué hay a 5, 10, 15, 20 y
#    30 minutos en auto fuera de punta y en hora punta (personas, poder de compra, actividad, generadores de flujo,
#    competencia, traslape con otras sedes y congestión), con su tipo de entorno y conclusiones.
# 8. Mide la **accesibilidad** de cada manzana y detecta **brechas de cobertura** (mucha demanda objetivo, lejos de CAS).
#
# | Entra | Sale (`trabajo/`) |
# |---|---|
# | grafo `CL-RM_*.graphml` · GTFS (opcional) · manzanas, sedes y competencia (03) | `red.pkl`, `T_sedes_<modo>.npy`, `potencial_competencia.pkl`, `candidatos.parquet`, `T_cand.npy`, `isocronas_sedes.gpkg`, `unidades.parquet` (con accesibilidad), `entorno_sedes.csv`, `entorno_sedes_detalle.csv`, `isocronas_entorno.gpkg`, `metricas_entorno.json` |
#
# **Velocidad:** los tiempos se calculan con Dijkstra (scipy) **en paralelo en todos los núcleos** (`PARAMETROS["computo"]`).
# Con la RM completa: ~2–6 minutos en una VM de 8 núcleos.

# %%
import os, sys, time
sys.path.insert(0, os.path.abspath("."))
import numpy as np, pandas as pd, geopandas as gpd
from IPython.display import display
import config_estudio
from geoventas import insumos, red, competencia, expansion, unidades, graficos, mapas, verificacion
from geoventas.utilidades import Cronometro, guardar, cargar, miles, carpeta_salida, n_nucleos

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "04")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("04_red")
GRAF = carpeta_salida(cfg, "graficos"); MAPAS = carpeta_salida(cfg, "mapas")
ut = cargar(cfg, "unidades.parquet")
area = cargar(cfg, "area_estudio.gpkg"); comp = cargar(cfg, "competencia.parquet")
sedes = cargar(cfg, "sedes_estudio.parquet")
sedes = sedes[sedes["en_modelo"]].reset_index(drop=True)
print(f"Núcleos en paralelo: {n_nucleos(cfg)} · manzanas: {len(ut):,} · sedes: {len(sedes)} · competidores del modelo: {int(comp['en_modelo'].sum()):,}")

# %% [markdown]
# ## 1. Cargar el grafo con OSMnx y armar las 4 redes
# * **Auto valle:** el tiempo que trae el grafo (largo de cada calle ÷ velocidad de esa vía).
# * **Auto punta:** el mismo tiempo dividido por un factor de congestión según el tipo de vía (autopistas 0,55 … calles 0,80).
# * **A pie:** 4,8 km/h por todas las calles, en ambos sentidos.
# * **Transporte público:** una red de varias "capas": caminar, subir a un bus (espera 5 min) que avanza por las vías
#   principales a 13–19 km/h, y —si hay GTFS— subir al metro o a buses con sus tiempos programados (espera = ½ intervalo).

# %%
G = red.cargar_grafo(cfg, area, log)
rd = red.construir_red(G, cfg, gtfs=cfg["rutas"].get("gtfs"), cronometro=log)
print(rd.tp_info)
rd.resumen()

# %% [markdown]
# ## 2. ¿Por qué isócronas y no buffers?
# Tomamos pares de manzanas al azar y comparamos la **distancia en línea recta** con el **tiempo real por la red** en
# hora punta. Si un buffer sirviera, todos los puntos estarían sobre una línea. La dispersión vertical muestra que a la
# misma distancia hay lugares a 8 minutos y otros a 25: depende de autopistas, ríos, cerros y sentidos de tránsito.

# %%
nodos_ut = red.preparar_unidades(rd, ut)                 # nodo de red y distancia de acceso de cada manzana (una vez)
circ = red.circuidad(rd, ut, cfg, nodos_ut=nodos_ut)
graficos.circuidad(circ, os.path.join(GRAF, "04_circuidad.png"));

# %% [markdown]
# ## 3. Verificación contra la receta clásica de OSMnx
# La forma "de manual" de hacer una isócrona con OSMnx es: nodo más cercano (`ox.distance.nearest_nodes`) → subgrafo
# alcanzable en X segundos (`nx.ego_graph(..., distance="travel_time")`) → calles del subgrafo con una franja.
# Nuestra versión hace lo mismo con matrices dispersas (mucho más rápida para miles de puntos). Deben coincidir.

# %%
s0 = sedes.iloc[0]
MIN_PRUEBA = 5
t0 = time.time()
ref = red.isocrona_osmnx_referencia(G, s0["lat"], s0["lon"], MIN_PRUEBA)
t_ref = time.time() - t0
nuestra = red.isocronas_sitios(rd, pd.DataFrame({"id": [s0["sede"]], "x": [s0["x"]], "y": [s0["y"]]}), cfg, ["auto_valle"],
                               cronometro=lambda m: None, sentido="desde", minutos=[MIN_PRUEBA], con_acceso=False).geometry.iloc[0]
t_nuestra = time.time() - t0 - t_ref
iou = nuestra.intersection(ref).area / nuestra.union(ref).area
print(f"Sede {s0['sede']} · isócrona de {MIN_PRUEBA} min en auto (valle)")
print(f"  receta OSMnx/networkx: {ref.area / 1e6:.1f} km² en {t_ref:.1f} s")
print(f"  nuestra (matrices dispersas + geometría real de las calles): {nuestra.area / 1e6:.1f} km² en {t_nuestra:.2f} s")
print(f"  coincidencia (intersección / unión, IoU): {iou:.0%}")
display(mapas.mapa([mapas.capa(gpd.GeoDataFrame(geometry=[ref], crs=32719), "Receta clásica de OSMnx", color="#e07b24", opacidad=0.35, peso=1.5),
            mapas.capa(gpd.GeoDataFrame(geometry=[nuestra], crs=32719), "Cálculo del estudio", color="#1f5fa8", opacidad=0.35, peso=1.5),
            mapas.capa_sedes(sedes.iloc[[0]])],
           titulo=f"Control de calidad: zona a {MIN_PRUEBA} minutos en auto", subtitulo=f"Las dos manchas deben coincidir (coinciden en un {iou:.0%})",
           archivo=os.path.join(MAPAS, "04_verificacion_osmnx.html"), alto=460))
chk("Isócrona propia coincide con la receta OSMnx/networkx (IoU ≥ 85%)", iou >= 0.85, f"IoU {iou:.1%}")
# el grafo de OSMnx ya no se necesita (todo sigue con la red compacta): se libera (~3–4 GB en la RM completa)
del G
import gc
gc.collect()

# %% [markdown]
# ## 4. Matrices de tiempos (lo que usa el modelo)
# * **Manzana → sede** en los 4 modos (exacto, desde el punto interior de cada manzana).
# * **Potencial de competencia** (punta): para cada manzana y cada grupo de competencia (clínicas, centros médicos,
#   laboratorios), la suma Σ peso·e^(−β·minutos) sobre **todos** los competidores, con el **tiempo exacto** de la manzana a
#   cada competidor. Como β se estima en el notebook 06, la suma se guarda para 48 valores de β y el modelo la interpola
#   (polinomio de Hermite: error < 0,01%, y < 0,1% en su derivada). Así el modelo es exacto por manzana sin guardar 100 millones de pares.
# * **Manzana → manzana candidata** (punta): ver la sección siguiente. Se guarda en float16 (precisión 0,03 min).
#
# Un tiempo "infinito" significa que está a más del horizonte (60 min): ahí la sede no compite.

# %%
print(f"Manzanas que comparten nodo: {len(ut):,} manzanas → {len(np.unique(nodos_ut[0])):,} nodos distintos · "
      f"acceso mediano a la red {np.median(nodos_ut[1]):.0f} m")
lejos = nodos_ut[1] > 500
if lejos.any():
    print(f"⚠️  {int(lejos.sum()):,} manzanas a más de 500 m de la red ({miles(ut.loc[lejos, 'pob'].sum())} habitantes): "
          "su tiempo incluye ese tramo a 15 km/h (auto) o a pie.")
T = {}
for modo in red.MODOS:
    T[modo] = red.tiempos_a_puntos(rd, ut, sedes[["x", "y"]].values, modo, cfg, nodos_ut=nodos_ut)
    guardar(T[modo], cfg, f"T_sedes_{modo}.npy")
    log(f"tiempos a sedes · {modo}: {np.isfinite(T[modo]).mean():.0%} de pares dentro de {cfg['red']['horizonte_min']:.0f} min")
pc = competencia.potencial_competencia(comp, ut, rd, cfg, nodos_ut=nodos_ut, cronometro=log)
guardar(pc, cfg, "potencial_competencia.pkl")
ver_pc = competencia.verificar_potencial(pc, comp, ut, rd, cfg, nodos_ut=nodos_ut)
print(f"Potencial de competencia: {pc.resumen['competidores']:,} competidores {pc.resumen['por_grupo']}")
print(f"  manzanas sin competidores alcanzables (≤ {cfg['red']['horizonte_min']:.0f} min): {pc.resumen['manzanas_sin_competencia_alcanzable']}")
print(f"  control: interpolado vs cálculo directo en {ver_pc['manzanas']} manzanas al azar → error relativo máx "
      f"{ver_pc['error_rel_max_S']:.1e} (suma) y {ver_pc['error_rel_max_ST']:.1e} (su derivada)")

# %% [markdown]
# ### Manzanas candidatas a sede nueva
# Una manzana es **candidata** si (todo editable en `PARAMETROS["expansion"]`):
# * está en zona urbana o en un polo laboral: en su entorno (≤ 600 m) viven ≥ 1.700 personas o trabajan ≥ 1.500;
# * **da a una vía terciaria o superior**: hay un nodo de esa vía a ≤ 150 m. Ese nodo es el **sitio** desde el que se
#   miden los tiempos (una sede necesita frente a una vía relevante).
#
# Se priorizan por la demanda objetivo y los trabajadores de su entorno; si dos candidatas quedan a menos de 250 m, queda
# la de mayor prioridad. Se evalúan las 2.500 primeras con tiempos exactos (notebook 07).

# %%
cand = expansion.generar_candidatos(ut, rd, cfg)
Tcand = red.tiempos_a_puntos(rd, ut, cand[["x", "y"]].values, "auto_punta", cfg, nodos_ut=nodos_ut).astype(np.float16)
guardar(cand, cfg, "candidatos.parquet"); guardar(Tcand, cfg, "T_cand.npy")
log(f"manzanas candidatas: {len(cand):,} · matriz de tiempos {Tcand.shape[0]:,} × {Tcand.shape[1]:,} ({Tcand.nbytes / 1e6:,.0f} MB en float16)")
cand.groupby("comuna").size().sort_values(ascending=False).head(10).rename("manzanas candidatas").to_frame().T

# %% [markdown]
# ### ¿Cuánto cambia el tiempo según el modo?
# Para cada sede: población AB/C1a/C1b que llega en 15 minutos en cada modo.

# %%
filas = []
for j, s in sedes.iterrows():
    fila = {"sede": s["sede"], "nombre": s["nombre"]}
    for modo in red.MODOS:
        fila[f"objetivo a ≤15 min · {modo}"] = ut.loc[T[modo][:, j] <= 15, "pob_objetivo"].sum()
    filas.append(fila)
pd.DataFrame(filas).set_index(["sede", "nombre"]).apply(lambda col: col.map(miles))

# %% [markdown]
# ## 5. Isócronas de las sedes (4 modos)
# Cada isócrona es el área desde la que se llega **a** la sede en X minutos o menos (sentido "hacia": así viaja el
# paciente). Los recorridos (Dijkstra) toman un instante; lo costoso es dibujar cada polígono, así que todos los polígonos
# de los 4 modos se reparten en lotes de costo parejo entre los núcleos. Isócronas chicas: franja exacta de 60 m
# alrededor de las calles alcanzadas; grandes: la misma franja sobre una grilla fina (misma área ±1,5%).

# %%
sit = sedes[["sede", "x", "y"]].rename(columns={"sede": "id"})
iso = red.isocronas_sitios(rd, sit, cfg, cronometro=log)
cols_m = ["pob", "pob_objetivo", "hog_objetivo", "gasto_salud_total", "trabajadores_est", "comp_clinica_peso", "comp_centro_medico_peso", "comp_laboratorio_peso", "oferta_contexto_n"]
cols_m = [c for c in cols_m if c in ut]
iso = red.metricas_en_isocronas(iso, ut, cfg, cols_m)
iso = iso.merge(sedes[["sede", "nombre", "formato_modelo"]], left_on="id", right_on="sede", how="left")
t = iso[iso["minutos"].isin([10, 15, 30])].pivot_table(index=["sede", "nombre"], columns=["modo", "minutos"], values="pob_objetivo", aggfunc="sum")
t.apply(lambda col: col.map(miles))

# %% [markdown]
# ### Mapa: isócronas de las sedes
# Una capa por modo (prende una a la vez). Los colores van de 5 minutos (oscuro, al centro) a 30 minutos (claro).
# Clic en una isócrona para ver cuánta población, gasto y competencia contiene.

# %%
iso_vis = iso.to_crs("EPSG:4326").copy()
iso_vis["sede_txt"] = iso_vis["sede"].map(dict(zip(sedes["sede"], mapas.nombre_sede(sedes)))).fillna(iso_vis["sede"])
iso_vis["zona"] = "Llegan en " + iso_vis["minutos"].astype(int).astype(str) + " min o menos"
iso_vis = iso_vis.sort_values("minutos", ascending=False)       # las grandes abajo, las chicas arriba
nombres = {"auto_punta": "En auto, hora punta", "auto_valle": "En auto, fuera de punta", "pie": "Caminando", "tp": "En transporte público"}
mins_todos = sorted(iso_vis["minutos"].astype(int).unique())
tonos = ["#0d3f7a", "#2f74b5", "#6aa6d6", "#a9cbe8", "#d6e6f4", "#eef4fb"]
colores_zona = {f"Llegan en {m_} min o menos": tonos[min(k, len(tonos) - 1)] for k, m_ in enumerate(mins_todos)}
iso_vis["ficha"] = [mapas.ficha(r["sede_txt"], [("Zona", f"a {int(r['minutos'])} minutos o menos"),
                                                ("Superficie", f"{miles(r['area_km2'], 1)} km²"),
                                                ("Personas que viven ahí", miles(r["pob"])),
                                                ("Público objetivo (AB, C1a, C1b)", miles(r["pob_objetivo"])),
                                                ("Gasto en salud al mes", mapas.pesos(r["gasto_salud_total"])),
                                                ("Competencia (centros médicos)", miles(r.get("comp_centro_medico_peso", 0), 1))],
                                subtitulo=nombres[r["modo"]], color=colores_zona.get(r["zona"])) for _, r in iso_vis.iterrows()]
orden_fmt = {"clinica": 0, "centro_medico": 1, "toma_muestras": 2}
principal = mapas.nombre_sede(sedes.assign(_o=sedes["formato_modelo"].map(orden_fmt)).sort_values(["_o", "sede"])).iloc[0]   # la clínica principal
capas = [mapas.capa_manzanas(ut, "Demanda por manzana (fondo)", mapas.inds("pob_objetivo", "gasto_salud_objetivo"),
                             ficha=mapas.inds("pob"), visible=False, opacidad=0.6)]
for k, modo in enumerate(red.MODOS):
    sub = iso_vis[iso_vis["modo"] == modo]
    capas.append(mapas.capa(sub, nombres[modo], campo_categoria="zona", colores_categoria=colores_zona, opacidad=0.38, peso=0.8,
                            ficha_html="ficha", etiqueta="zona", visible=(k == 0), simplificar_m=40,
                            filtro="sede_txt", etiqueta_filtro="Ver las zonas de la sede", filtro_inicial=principal))
if cfg["rutas"].get("gtfs"):
    import zipfile, io as _io
    try:
        with zipfile.ZipFile(cfg["rutas"]["gtfs"]) as z:
            est = pd.read_csv(_io.BytesIO(z.read("stops.txt")))
        capas.append(mapas.capa(mapas.puntos(est, "stop_lon", "stop_lat"), "Estaciones de metro", color="#e07b24", radio=3,
                                popup=["stop_name"], etiquetas_popup={"stop_name": "Estación"}, visible=False))
    except Exception as e:
        print("GTFS no disponible para el mapa:", e)
capas.append(mapas.capa_sedes(sedes))
mapas.mapa(capas, titulo="¿Desde dónde se llega a cada sede en 5, 10, 15, 20 o 30 minutos?",
           subtitulo="Zonas de viaje por las calles reales (no círculos) · elige la sede en el panel y el modo de viaje en las capas",
           ayuda=["Cada mancha azul es la zona desde la que se llega a la sede en ese tiempo o menos: más oscuro = más cerca.",
                  "En el panel eliges la sede. En las capas (arriba a la derecha) eliges el modo: auto en hora punta, fuera de punta, caminando o en transporte público.",
                  "Haz clic en una zona para ver cuánta gente, público objetivo y gasto en salud hay dentro."],
           archivo=os.path.join(MAPAS, "04_isocronas_sedes.html"))

# %% [markdown]
# ## 6. Análisis de entorno de cada sede (base de puntos de la red Alemana)
# Se usa la **base de puntos del levantamiento** (`RUTAS["maestro_sedes"]`: todas las sedes oficiales de la red, no solo
# las que entran al modelo) y, para cada sede, se mide qué hay en la zona desde la que se llega en **5, 10, 15, 20 y 30
# minutos en auto, fuera de punta y en hora punta** (`PARAMETROS["entorno"]`):
#
# | Tema | Qué se mide en cada zona |
# |---|---|
# | Personas | población, hogares, segmento objetivo (AB, C1a, C1b), mezcla de GSE, menores de 18 y 60+, densidad |
# | Poder de compra | gasto en salud al mes (total y del segmento), renta media del hogar, avalúo medio de la vivienda |
# | Actividad | trabajadores, empresas (y de salud), trabajadores por habitante |
# | Generadores de flujo | estaciones de metro, paraderos, malls, supermercados, educación, oficinas, restaurantes, gimnasios, propiedades por destino |
# | Competencia | clínicas, centros médicos y laboratorios, competidores por 10.000 personas del segmento, los 5 más cercanos en minutos |
# | Red propia | otras sedes de la red a pocos minutos y **traslape**: qué parte del segmento de su zona inmediata también está cerca de otra sede |
# | Congestión | cuánto público objetivo pierde cada sede en hora punta y en cuántos minutos reúne 100 mil personas del segmento |
#
# **Cómo se calcula (vectorizado y en paralelo):** tiempos manzana → sede con Dijkstra repartido entre los núcleos (una
# matriz por modo) y, para todos los cortes a la vez, una multiplicación de matrices `(T ≤ m)ᵀ · V` (sedes × variables).
# Los polígonos se dibujan en paralelo solo para el mapa, y se reutilizan los de la sección 5 cuando ya existen. Las sedes
# del maestro fuera del área de estudio (otras regiones) se informan; para analizarlas basta agregar su región y su grafo.

# %%
from geoventas import cliente, entorno as ENT_, metricas, conclusiones
from geoventas.utilidades import pct
E_ = cfg["entorno"]; ref_e = E_["minutos_referencia"]; mt_e = E_["minutos_traslape"]
maestro = cliente.leer_maestro(cfg)
sit_e, inf_e = ENT_.sitios_maestro(maestro, area, cfg)
print(f"Sedes oficiales en el maestro: {inf_e['en_maestro']} · analizadas (dentro del área): {inf_e['analizadas']}"
      + (f" · fuera del área: {', '.join(f'{v} en {k}' for k, v in inf_e.get('fuera_por_region', {}).items())}" if inf_e["fuera_del_area"] else "")
      + (f" · sin coordenada válida: {', '.join(inf_e['sin_coordenadas'])}" if inf_e["sin_coordenadas"] else ""))
ent = ENT_.analizar(rd, ut, sit_e, comp, cfg, nodos_ut=nodos_ut, cronometro=log)
iso_ent = ENT_.poligonos(rd, sit_e, ent["detalle"], cfg, iso_previas=iso, cronometro=log)
log(f"entorno listo: {len(ent['detalle'])} combinaciones sede × modo × minutos · {len(iso_ent)} isócronas")
res_e = ent["resumen"]
col_e = lambda c: res_e[c] if c in res_e else pd.Series(np.nan, index=res_e.index)
pd.DataFrame({"Sede": res_e["nombre_visible"], "Formato": res_e["formato_modelo"].map(ENT_.NOMBRE_FORMATO).fillna("otro"),
              "Tipo de entorno": res_e["tipo_entorno"],
              f"Segmento a {ref_e} min · punta": col_e(f"pob_objetivo_{ref_e}min").map(miles),
              f"Segmento a {ref_e} min · fuera de punta": col_e(f"pob_objetivo_{ref_e}min_valle").map(miles),
              "Pierde en punta": col_e("perdida_punta_objetivo").map(lambda v: pct(v, 0)),
              f"Minutos para {miles(E_['personas_objetivo_meta'])} del segmento (punta)": col_e("minutos_meta_auto_punta").round(1),
              f"Competidores a {ref_e} min": col_e(f"comp_total_{ref_e}min").map(miles),
              f"Comparte su zona de {mt_e} min": col_e("traslape_red").map(lambda v: pct(v, 0)),
              "Competidor más cercano": col_e("competidor_mas_cercano")})

# %% [markdown]
# ### El entorno de cada sede, en palabras
# El texto cambia con las cifras de cada sede (tipo de entorno, alcance frente a una sede típica de su formato,
# congestión, generadores de flujo, competencia y traslape con el resto de la red).

# %%
from IPython.display import Markdown
Markdown("\n".join(f"- **{r['nombre_visible']}.** {r['texto']}" for _, r in res_e.iterrows()))

# %% [markdown]
# ### Público objetivo según los minutos de viaje, fuera de punta y en hora punta
# La distancia entre la línea punteada (fuera de punta) y la continua (hora punta) es lo que la congestión le quita a cada
# sede. Una curva que sube rápido es una sede con mucho público cerca.

# %%
graficos.entorno_curvas(ent["detalle"], os.path.join(GRAF, "04_entorno_curvas.png"));

# %% [markdown]
# ### Mapa: entorno de cada sede (hora punta y fuera de punta)
# Elige la sede en el panel y la hora en las capas. Clic en una zona para ver qué hay dentro.

# %%
iv = iso_ent.to_crs("EPSG:4326").copy()
iv["sede_txt"] = iv["nombre_visible"].fillna(iv["sede"])
iv["zona"] = "Llegan en " + iv["minutos"].astype(int).astype(str) + " min o menos"
iv = iv.sort_values("minutos", ascending=False)
tonos = ["#0d3f7a", "#2f74b5", "#6aa6d6", "#a9cbe8", "#d6e6f4", "#eef4fb"]
colz = {f"Llegan en {m_} min o menos": tonos[min(k, len(tonos) - 1)] for k, m_ in enumerate(sorted(iv["minutos"].astype(int).unique()))}
iv["ficha"] = [mapas.ficha(r["sede_txt"], [("Zona", f"a {int(r['minutos'])} minutos o menos"), ("Personas", miles(r["poblacion"])),
                                          ("Segmento objetivo (AB, C1a, C1b)", f"{miles(r['pob_objetivo'])} ({pct(r['pct_objetivo'], 0)})"),
                                          ("Gasto en salud del segmento al mes", mapas.pesos(r["gasto_salud_objetivo_mes"])),
                                          ("Trabajadores", miles(r["trabajadores"])),
                                          ("Estaciones de metro · malls", f"{miles(r.get('poi_metro', 0))} · {miles(r.get('poi_mall', 0))}"),
                                          ("Competencia: clínicas · centros médicos · laboratorios",
                                           f"{miles(r['comp_clinicas'])} · {miles(r['comp_centros_medicos'])} · {miles(r['comp_laboratorios'])}"),
                                          ("Compartido con otras sedes de la red", pct(r["traslape_red"], 0))],
                               subtitulo=ENT_.NOMBRE_MODO.get(r["modo"], r["modo"]), color=colz.get(r["zona"])) for _, r in iv.iterrows()]
inicial_e = res_e.sort_values(f"pob_objetivo_{ref_e}min", ascending=False)["nombre_visible"].iloc[0]
capas = [mapas.capa_manzanas(ut, "Demanda por manzana (fondo)", mapas.inds("pob_objetivo", "gasto_salud_objetivo"), ficha=mapas.inds("pob"),
                             visible=False, opacidad=0.6)]
for k, modo in enumerate(E_["modos"]):
    capas.append(mapas.capa(iv[iv["modo"] == modo], ENT_.NOMBRE_MODO.get(modo, modo), campo_categoria="zona", colores_categoria=colz, opacidad=0.38,
                            peso=0.8, ficha_html="ficha", etiqueta="zona", visible=(modo == ent["modo_ref"]), simplificar_m=40,
                            filtro="sede_txt", etiqueta_filtro="Ver el entorno de la sede", filtro_inicial=inicial_e))
cm_ = comp[comp["en_modelo"]].copy()
cm_["grupo_txt"] = cm_["grupo"].map({"comp_clinica": "Clínica", "comp_centro_medico": "Centro médico", "comp_laboratorio": "Laboratorio / toma de muestras"})
capas.append(mapas.capa(cm_, "Competencia", campo_categoria="grupo_txt", colores_categoria={"Clínica": "#7b3fa0", "Centro médico": "#1f78b4",
                        "Laboratorio / toma de muestras": "#2e9e44"}, radio=3, popup=["nombre", "formato_FRF"], titulo_popup="nombre",
                        etiquetas_popup={"formato_FRF": "Tipo"}, visible=False))
capas.append(mapas.capa_sedes(sit_e.to_crs("EPSG:4326"), nombre="Sedes de la red Alemana (base de puntos)"))
mapas.mapa(capas, titulo="Entorno de cada sede: ¿qué hay a 5, 10, 15, 20 y 30 minutos?",
           subtitulo="Zonas de viaje en auto por las calles reales, en hora punta y fuera de punta · elige la sede en el panel",
           ayuda=["Cada mancha azul es la zona desde la que se llega a la sede en ese tiempo o menos (más oscuro = más cerca).",
                  "En las capas eliges la hora: en punta la zona se achica por la congestión.",
                  "Haz clic en una zona para ver personas, segmento objetivo, gasto, trabajadores, metro, malls, competencia y cuánto comparte con otras sedes."],
           archivo=os.path.join(MAPAS, "04_entorno_sedes.html"), encuadrar=["Sedes de la red Alemana (base de puntos)"])

# %% [markdown]
# ### Conclusiones sobre el entorno de las sedes

# %%
ind_ent = metricas.entorno(res_e, inf_e, ref_e, mt_e)
conclusiones.mostrar(conclusiones.generar(ind_ent, ["Entorno"]), "Conclusiones sobre el entorno de las sedes")
metricas.tabla(ind_ent)[["indicador", "valor", "lectura"]]

# %% [markdown]
# ## 7. Accesibilidad y brechas de cobertura
# Para cada manzana: minutos (auto, punta) a la sede CAS más cercana, y al centro médico o clínica más cercano.
#
# Una **brecha** es una manzana con **alta demanda en su barrio** (está en el 20% de manzanas con más población objetivo a
# ≤ 600 m) que queda a **más de 15 minutos** de cualquier centro médico o clínica de CAS. Se usa el entorno y no la manzana
# sola para que una manzana chica en un barrio denso no quede fuera. Las brechas son el primer indicio de dónde podría
# haber espacio para crecer (el notebook 07 lo cuantifica con el modelo).

# %%
Tp = T["auto_punta"]
orden = {"clinica": 3, "centro_medico": 2, "toma_muestras": 1}
nivel = sedes["formato_modelo"].map(orden).values
ut["min_a_cas"] = np.min(Tp, axis=1)
ut["min_a_cm_o_clinica"] = np.min(np.where(nivel[None, :] >= 2, Tp, np.inf), axis=1)
ut["pob_objetivo_entorno"] = unidades.suma_entorno(ut, ["pob_objetivo"], radio_m=600)["pob_objetivo_entorno"].values
p80 = ut.loc[ut["pob_objetivo_entorno"] > 0, "pob_objetivo_entorno"].quantile(0.8)
alta = ut["pob_objetivo_entorno"] >= p80
ut["brecha"] = alta & (ut["min_a_cm_o_clinica"] > 15)
ut["brecha_txt"] = np.select([ut["brecha"], alta], ["Brecha: alta demanda a más de 15 min", "Alta demanda cubierta (≤ 15 min)"], "Resto")
w = ut["pob_objetivo"]
print(f"Brechas: {int(ut['brecha'].sum()):,} manzanas con {miles(w[ut['brecha']].sum())} personas del segmento objetivo "
      f"({w[ut['brecha']].sum() / max(w.sum(), 1):.0%} del total)")
(ut.loc[ut["brecha"]].groupby("comuna").agg(manzanas=("ut", "size"), poblacion_objetivo=("pob_objetivo", "sum"))
   .sort_values("poblacion_objetivo", ascending=False).head(12).apply(lambda col: col.map(miles)))

# %%
mapas.mapa([
    mapas.capa_manzanas(ut.assign(min_a_cas=ut["min_a_cas"].replace(np.inf, np.nan),
                                  min_a_cm_o_clinica=ut["min_a_cm_o_clinica"].replace(np.inf, np.nan)),
                        "Accesibilidad por manzana", mapas.inds("brecha_txt", "min_a_cas", "min_a_cm_o_clinica", "pob_objetivo_entorno"),
                        ficha=mapas.inds("pob", "pob_objetivo")),
    mapas.capa_sedes(sedes),
], titulo="¿Dónde falta Clínica Alemana?",
   subtitulo=f"En rojo: {miles(int(ut['brecha'].sum()))} manzanas con mucho público objetivo a más de 15 minutos de un centro médico o clínica "
             f"({miles(w[ut['brecha']].sum())} personas AB, C1a y C1b)",
   ayuda=["Rojo = barrios con mucho público objetivo y lejos de Clínica Alemana: son la primera pista de dónde abrir.",
          "Azul = barrios con mucho público objetivo que ya tienen una sede cerca.",
          "En el panel puedes cambiar a los minutos en auto a la sede más cercana."],
   archivo=os.path.join(MAPAS, "04_accesibilidad_brechas.html"))

# %% [markdown]
# ## 8. Verificaciones y guardado

# %%
chk("Punta más lenta que valle (en promedio)", np.nanmean(np.where(np.isfinite(T["auto_punta"]), T["auto_punta"], np.nan)) >=
    np.nanmean(np.where(np.isfinite(T["auto_valle"]), T["auto_valle"], np.nan)), "")
chk("Todas las sedes alcanzan población en 15 min (auto punta)", (np.isfinite(T["auto_punta"]) & (T["auto_punta"] <= 15)).any(0).all(), "")
chk("Isócronas anidadas (10 min ⊂ 15 min ⊂ 30 min, por área)", iso.sort_values("minutos").groupby(["id", "modo"])["area_km2"].apply(lambda s: s.is_monotonic_increasing).all(), "")
chk("Transporte público: red multicapa construida", rd.M["tp"].shape[0] > rd.n, f"{rd.M['tp'].shape[0]:,} nodos")
chk("Manzanas candidatas generadas", len(cand) > 0, f"{len(cand):,}")
chk("Candidatas sobre una vía terciaria o superior (sitio a ≤ 150 m de la manzana)",
    bool((cand["rango_via"] >= 2).all() and (cand["dist_nodo_m"] <= cfg["expansion"]["dist_max_via_m"]).all()), "")
from scipy.spatial import cKDTree
dmin = cKDTree(cand[["x", "y"]].values).query(cand[["x", "y"]].values, k=2)[0][:, 1].min() if len(cand) > 1 else np.inf
chk("Separación mínima entre manzanas candidatas", dmin >= cfg["expansion"]["separacion_min_m"] - 1, f"mínima {dmin:.0f} m")
chk("Toda manzana con nodo de red asignado", np.isfinite(nodos_ut[1]).all(), f"acceso p95 = {np.percentile(nodos_ut[1], 95):.0f} m")
chk("Potencial de competencia: interpolación exacta (error < 0,1%)",
    max(ver_pc["error_rel_max_S"], ver_pc["error_rel_max_ST"]) < 1e-3, f"{max(ver_pc['error_rel_max_S'], ver_pc['error_rel_max_ST']):.1e}")
chk("Competidores alcanzables desde alguna manzana ≥ 95%",
    1 - pc.resumen["competidores_sin_manzanas_alcanzables"] / max(pc.resumen["competidores"], 1) >= 0.95,
    f"{pc.resumen['competidores_sin_manzanas_alcanzables']} sin manzanas a ≤ {cfg['red']['horizonte_min']:.0f} min")
d_e = ent["detalle"]
crece = d_e.sort_values("minutos").groupby(["sede", "modo"])["poblacion"].apply(lambda s: bool((s.diff().dropna() >= -1e-6).all())).all()
chk("Entorno: todas las sedes oficiales del maestro dentro del área, analizadas", len(res_e) == inf_e["analizadas"] > 0,
    f"{inf_e['analizadas']} de {inf_e['en_maestro']} (el resto está en otras regiones)")
chk("Entorno: la zona crece con los minutos en todas las sedes y modos", bool(crece), "")
if {"auto_valle", "auto_punta"} <= set(E_["modos"]):
    pv_e = d_e.pivot_table(index=["sede", "minutos"], columns="modo", values="poblacion")
    chk("Entorno: en hora punta nunca se llega a más población que fuera de punta", bool((pv_e["auto_punta"] <= pv_e["auto_valle"] + 1).all()), "")
cmp_e = red.metricas_en_isocronas(iso_ent[["sede", "modo", "minutos", "geometry"]].copy(), ut, cfg, ["pob"]).merge(
    d_e[["sede", "modo", "minutos", "poblacion"]], on=["sede", "modo", "minutos"])
dif_e = float((cmp_e["pob"] / cmp_e["poblacion"].where(cmp_e["poblacion"] > 0) - 1).abs().median())
chk("Entorno: población por matrices = por polígonos de isócrona (diferencia mediana ≤ 5%)", dif_e <= 0.05, f"{dif_e:.1%}")
chk.guardar(cfg)
guardar(res_e, cfg, "entorno_sedes.csv"); guardar(d_e, cfg, "entorno_sedes_detalle.csv")
guardar(iso_ent, cfg, "isocronas_entorno.gpkg"); guardar(metricas.como_dict(ind_ent), cfg, "metricas_entorno.json")
guardar(rd, cfg, "red.pkl")
guardar(iso.drop(columns=[c for c in ("sede",) if c in iso]), cfg, "isocronas_sedes.gpkg")
guardar(ut, cfg, "unidades.parquet")
log("listo")
chk.tabla()
