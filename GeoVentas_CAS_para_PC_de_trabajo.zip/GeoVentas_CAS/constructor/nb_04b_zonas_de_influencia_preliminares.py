# %% [markdown]
# # 04b · Zonas de influencia preliminares (sin RUT ni ventas de la clínica)
# **Se puede correr ANTES de recibir los datos de Clínica Alemana.** Usa solo lo que ya está disponible:
#
# | Insumo | De dónde sale |
# |---|---|
# | Demanda de cada manzana: gasto en salud por GSE + trabajadores | censo SD06, personas y empresas Equifax (notebooks 01 y 03) |
# | Competencia ponderada por segmento | levantamiento propio + POIs de salud de Equifax, sin duplicados (notebook 03) |
# | Tiempos reales por la red vial, en hora punta y fuera de punta | grafo vial OSM (se arma aquí si el notebook 04 aún no corrió) |
# | Sedes de la red Alemana | base de puntos del levantamiento (`RUTAS["maestro_sedes"]`) |
#
# **Qué hace:** aplica el mismo modelo de Huff con competencia del notebook 06, con **parámetros de referencia** (en vez
# de calibrados), y define la zona de cada sede **igual que las reales del notebook 05**: las manzanas más cercanas que
# reúnen el **60%** de su demanda (zona primaria) y hasta el **80%** (secundaria). Además arma:
# * la **zona de influencia total de la red** (60% y 80% de la demanda que captaría toda la red);
# * el **territorio de cada sede**: las manzanas donde es la clínica, el centro médico o la toma de muestras de la red que
#   más captaría (reparte el área entre las sedes de cada formato);
# * la **sensibilidad**: las zonas si la gente viaja más (β × 0,75) o menos (β × 1,25) de lo supuesto.
#
# **Orden para correrlo sin datos de la clínica:** 01 → 03 → 04b (el 02 necesita las ventas). En `config_estudio.py`
# basta decidir `RUT_PACIENTES` (si la clínica mandará el RUT tal cual: `"en_claro"`; no hace falta el archivo todavía).
#
# | Entra | Sale |
# |---|---|
# | manzanas y competencia (03) · maestro de sedes · grafo vial | `trabajo/`: `influencia_preliminar_sedes.csv`, `influencia_preliminar_red.csv`, `influencia_preliminar_manzanas.parquet`, `influencia_preliminar_zonas.parquet`, `influencia_preliminar.gpkg`, `metricas_influencia.json` · `salidas/preliminar/`: Excel, GeoPackage y mapa |
#
# > **Son zonas MODELADAS, no observadas.** Sirven para planificar desde ya (dónde está el público de cada sede, cuánto se
# > pisan las sedes, qué cambia en hora punta). Cuando lleguen los RUT, el notebook 05 las **compara automáticamente** con
# > las reales; con las ventas, el notebook 06 calibra los parámetros.

# %%
import os, sys, json
sys.path.insert(0, os.path.abspath("."))
import numpy as np, pandas as pd, geopandas as gpd
from IPython.display import display, Markdown
import config_estudio
from geoventas import insumos, cliente, red, competencia, influencia as INF, modelo as M, mapas, graficos, verificacion, metricas, conclusiones
from geoventas import entregables as ENT
from geoventas.utilidades import Cronometro, guardar, cargar, existe, miles, pct, carpeta_salida

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "04b")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("04b_influencia")
I = cfg["influencia"]
GRAF = carpeta_salida(cfg, "graficos"); MAPAS = carpeta_salida(cfg, "mapas"); SAL = carpeta_salida(cfg, "preliminar")
ut = cargar(cfg, "unidades.parquet"); comp = cargar(cfg, "competencia.parquet"); area = cargar(cfg, "area_estudio.gpkg")
print(f"Manzanas: {len(ut):,} · competidores del modelo: {int(comp['en_modelo'].sum()):,} · "
      f"datos de la clínica: {'sí' if cfg['rutas'].get('ventas_cliente') else 'no (no se necesitan aquí)'}")

# %% [markdown]
# ## 1. Sedes de la red (base de puntos del levantamiento)
# Se usa la misma regla del notebook 02 para decidir qué sedes entran: fuera las estacionales, los edificios de un campus
# que reportan con la sede principal, los registros por verificar y las de otras regiones.

# %%
sedes_todas, inf_s = INF.sedes_red(cliente.leer_maestro(cfg), area, cfg)
sedes = sedes_todas[sedes_todas["en_modelo"]].reset_index(drop=True)
print(f"Sedes oficiales en el maestro: {inf_s['en_maestro']} · en el área: {inf_s['analizadas']} · en el análisis: {len(sedes)}"
      + (f" · fuera del área: {', '.join(f'{v} en {k}' for k, v in inf_s.get('fuera_por_region', {}).items())}" if inf_s["fuera_del_area"] else ""))
sedes_todas[["sede", "nombre_visible", "formato_modelo", "en_modelo", "motivo_exclusion"]].rename(columns={"nombre_visible": "sede (nombre)", "formato_modelo": "formato"})

# %% [markdown]
# ## 2. Red vial, tiempos y competencia
# Si el notebook 04 ya corrió se reutilizan su red y su potencial de competencia; si no, se arman aquí (en paralelo).

# %%
if existe(cfg, "red.pkl"):
    rd = cargar(cfg, "red.pkl")
    log("red vial: la del notebook 04")
else:
    G = red.cargar_grafo(cfg, area, log)
    rd = red.construir_red(G, cfg, gtfs=cfg["rutas"].get("gtfs"), cronometro=log)
    del G
    guardar(rd, cfg, "red.pkl")
nodos_ut = red.preparar_unidades(rd, ut)
T = {}
for modo in I["modos"]:                         # Dijkstra en paralelo: los destinos se reparten entre los núcleos
    T[modo] = red.tiempos_a_puntos(rd, ut, sedes[["x", "y"]].to_numpy(float), modo, cfg, nodos_ut=nodos_ut)
    log(f"tiempos manzana → sede · {modo}: {np.isfinite(T[modo]).mean():.0%} de pares dentro de {cfg['red']['horizonte_min']:.0f} min")
pc = cargar(cfg, "potencial_competencia.pkl") if existe(cfg, "potencial_competencia.pkl") else None
if pc is None or pc.n != len(ut):
    pc = competencia.potencial_competencia(comp, ut, rd, cfg, nodos_ut=nodos_ut, cronometro=log)
    guardar(pc, cfg, "potencial_competencia.pkl")
log(f"potencial de competencia: {pc.resumen['competidores']:,} competidores")

# %% [markdown]
# ## 3. Supuestos del modelo de referencia
# Mientras no haya ventas, los parámetros son **supuestos documentados** (todos en `config_estudio.py`). El que más mueve
# las zonas es β (cuánto pesa la distancia); por eso la sección 6 muestra el rango con β ± 25%.

# %%
th0 = INF.theta_referencia(cfg["gse"], cfg)
filas = []
for k, f in enumerate(M.FORMATOS):
    b = cfg["modelo"]["beta_prior"][f]
    filas.append({"supuesto": f"Caída por minuto β · {mapas.NOMBRE_FORMATO[f].lower()}", "valor": b,
                  "lectura": f"el atractivo cae a la mitad cada {np.log(2) / b:.1f} min", "dónde se cambia": 'PARAMETROS["modelo"]["beta_prior"]'})
    filas.append({"supuesto": f"Atractivo de una sede · {mapas.NOMBRE_FORMATO[f].lower()}", "valor": I["atractivo_formato"][f],
                  "lectura": f"{np.exp(I['atractivo_formato'][f]):.2f} veces un centro médico a igual distancia", "dónde se cambia": 'PARAMETROS["influencia"]["atractivo_formato"]'})
filas.append({"supuesto": "Competencia", "valor": "", "lectura": "un competidor de segmento premium atrae lo mismo que una sede propia del mismo formato; "
              "los demás según su segmento (peso_segmento)", "dónde se cambia": 'PARAMETROS["competencia"]["peso_segmento"]'})
filas.append({"supuesto": "Peso de un trabajador frente a un residente λ", "valor": I["peso_trabajadores"], "lectura": "demanda de día (oficinas, comercio)",
              "dónde se cambia": 'PARAMETROS["influencia"]["peso_trabajadores"]'})
filas.append({"supuesto": "Pesos por GSE (AB = 1)", "valor": ", ".join(f"{g} {v}" for g, v in cfg["modelo"]["pesos_gse_iniciales"].items()),
              "lectura": "cuánto del gasto en salud de cada GSE es demanda para la red", "dónde se cambia": 'PARAMETROS["modelo"]["pesos_gse_iniciales"]'})
supuestos = pd.DataFrame(filas)
supuestos

# %% [markdown]
# ## 4. Zonas de influencia de cada sede
# * **t50 / t60 / t80:** minutos (en auto) que reúnen el 50, 60 y 80% de la demanda que captaría la sede.
# * **Zona primaria / secundaria:** manzanas hasta el 60% / del 60 al 80% de esa demanda (la misma regla que las zonas reales).
# * **Territorio propio:** manzanas donde la sede es la de su formato que más captaría (la clínica, el centro médico o la
#   toma de muestras de la red con más atractivo para esa manzana); el % dice cuánto de su demanda viene de ahí (el resto
#   lo comparte con otras sedes del mismo formato).

# %%
r = INF.analizar(ut, sedes, T, pc, cfg, cronometro=log)
res = r["resumen"]
p_ = res[res["modo"] == "auto_punta"].set_index("sede")
v_ = res[res["modo"] == "auto_valle"].set_index("sede") if "auto_valle" in I["modos"] else None
rng_ = r["sensibilidad"].pivot_table(index="sede", columns="beta_x", values="t80_min")
vista = pd.DataFrame({"Sede": p_["nombre_visible"], "Formato": p_["formato_modelo"].map(mapas.NOMBRE_FORMATO),
                      "t50 (min, punta)": p_["t50_min"].round(1), "t80 (min, punta)": p_["t80_min"].round(1),
                      "t80 si se viaja más / menos": [f"{rng_.loc[s].max():.0f} / {rng_.loc[s].min():.0f}" for s in p_.index],
                      "t80 (min, fuera de punta)": v_["t80_min"].round(1) if v_ is not None else np.nan,
                      "Segmento objetivo zona primaria": p_["pob_objetivo_primaria"].map(miles),
                      "Segmento objetivo zona secundaria": p_["pob_objetivo_secundaria"].map(miles),
                      "Segmento objetivo en su territorio": p_["pob_objetivo_territorio"].map(miles),
                      "Demanda desde su territorio propio": p_["demanda_en_territorio_propio"].map(lambda x: pct(x, 0)),
                      "Comunas principales": p_["comunas_principales"]})
vista.reset_index(drop=True)

# %%
graficos.NOMBRES_SEDE = dict(zip(sedes["sede"], sedes["nombre_visible"]))
graficos.influencia_t80(res, r["sensibilidad"], os.path.join(GRAF, "04b_alcance_sedes.png"));

# %% [markdown]
# ## 5. Zona de influencia total de la red
# Toda la red como una sola: las manzanas más cercanas a alguna sede que reúnen el 60% (primaria) y hasta el 80%
# (secundaria) de la demanda que captaría la red completa. Se compara hora punta y fuera de punta.

# %%
red_t = r["red"]
rv = red_t[red_t["zona"].isin(["primaria", "secundaria"])].copy()
pd.DataFrame({"Hora": rv["modo"].map({"auto_punta": "Punta", "auto_valle": "Fuera de punta"}), "Zona": rv["zona"],
              "Población": rv["pob"].map(miles), "Segmento objetivo": rv["pob_objetivo"].map(miles),
              "Gasto en salud del segmento al mes": rv["gasto_salud_objetivo"].map(mapas.pesos),
              "Trabajadores": rv["trabajadores_est"].map(miles), "Competidores": rv["comp_n_modelo"].map(miles),
              "Superficie (km²)": rv["area_km2"].round(1), "t80 de la red (min)": rv["t80_min"].round(1)}).reset_index(drop=True)

# %% [markdown]
# ## 6. Sensibilidad: ¿y si la gente viaja más o menos de lo supuesto?
# Minutos que reúnen el 80% de la demanda con β × 0,75 (la gente viaja más), β supuesto y β × 1,25 (viaja menos).

# %%
sens = r["sensibilidad"].pivot_table(index="sede", columns="beta_x", values="t80_min").round(1)
sens.index = [dict(zip(sedes["sede"], sedes["nombre_visible"])).get(s, "Toda la red") for s in sens.index]
sens.columns = [f"β × {c:g}" for c in sens.columns]
sens

# %% [markdown]
# ## 7. Mapa de las zonas de influencia preliminares
# * **Manzanas:** zona de la red, sede que más captaría (territorio), minutos a la sede más cercana y público objetivo.
# * **Zonas de cada sede:** primaria y secundaria (elige la sede en el panel).
# * **Territorios:** el área de cada sede (dónde es la opción Alemana que más captaría).

# %%
pol = INF.poligonos(ut, sedes, r["Z"], r["zona_red"], cfg, territorio=r["territorio"])
log(f"contornos: {len(pol)} polígonos")
nombre_s = dict(zip(sedes["sede"], sedes["nombre_visible"]))
uv = ut[["ut", "comuna", "pob", "pob_objetivo", "geometry"]].merge(r["manzanas"], on="ut")
uv["zona_red_txt"] = uv["zona_red"].map({"primaria": "Zona primaria de la red (60% de la demanda)", "secundaria": "Zona secundaria (hasta el 80%)",
                                         "fuera": "Fuera (último 20%)"})
dom_cols = [c for c in uv.columns if c.startswith("sede_dominante_")]
for c in dom_cols:
    uv[c] = uv[c].fillna("ninguna")
ART = {"clinica": "Clínica", "centro_medico": "Centro médico", "toma_muestras": "Toma de muestras"}
capas = [mapas.capa_manzanas(uv, "Manzanas", [
    mapas.ind("zona_red_txt", "Zona de influencia de la red (hora punta)", "texto",
              categorias={"Zona primaria de la red (60% de la demanda)": "#0d3f7a", "Zona secundaria (hasta el 80%)": "#6aa6d6", "Fuera (último 20%)": "#e6e6e6"})]
    + [mapas.ind(c, f"{ART[c[15:]]} de la red que más captaría (territorio)", "texto", categorias=mapas.colores_sedes(list(sedes["sede"])),
                 nombres_categoria=nombre_s) for c in dom_cols] + [
    mapas.ind("min_red", "Minutos a la sede más cercana (auto, punta)", "min", invertir=True, unidad="minutos en auto", nulo="más de 60 min"),
    mapas.ind("pob_objetivo", "Personas del segmento objetivo (AB, C1a, C1b)", "entero", unidad="personas por manzana")],
    ficha=mapas.inds("pob"), opacidad=0.7)]
zs = pol[pol["sede"].isin(sedes["sede"]) & pol["zona"].isin(["primaria", "secundaria"])].to_crs("EPSG:4326").copy()
zs["sede_txt"] = zs["sede"].map(nombre_s)
zs["zona_txt"] = zs["zona"].map({"primaria": "Zona primaria (60% de la demanda)", "secundaria": "Zona secundaria (hasta el 80%)"})
capas.append(mapas.capa(zs.sort_values("zona", ascending=False), "Zonas de influencia de cada sede", campo_categoria="zona_txt",
                        colores_categoria={"Zona primaria (60% de la demanda)": "#0d3f7a", "Zona secundaria (hasta el 80%)": "#6aa6d6"},
                        opacidad=0.25, peso=1.2, popup=["sede_txt", "zona_txt"], titulo_popup="sede_txt", etiquetas_popup={"zona_txt": "Zona"},
                        filtro="sede_txt", etiqueta_filtro="Ver las zonas de la sede", visible=False))
te = pol[pol["zona"] == "territorio"].to_crs("EPSG:4326").copy()
te["sede_txt"] = te["sede"].map(nombre_s)
capas.append(mapas.capa(te, "Territorio de cada sede (dentro de su formato)", campo_categoria="sede_txt",
                        colores_categoria={nombre_s[k]: c for k, c in mapas.colores_sedes(list(sedes["sede"])).items()},
                        opacidad=0.15, peso=1.5, popup=["sede_txt"], titulo_popup="sede_txt", visible=False))
rz = pol[(pol["sede"] == "RED")].to_crs("EPSG:4326").copy()
rz["zona_txt"] = rz["zona"].map({"primaria": "Red: zona primaria (60%)", "secundaria": "Red: zona secundaria (hasta 80%)"})
capas.append(mapas.capa(rz, "Zona de influencia total de la red", campo_categoria="zona_txt",
                        colores_categoria={"Red: zona primaria (60%)": "#c0392b", "Red: zona secundaria (hasta 80%)": "#e59866"},
                        opacidad=0.0, peso=2.5, popup=["zona_txt"], visible=True))
capas.append(mapas.capa_sedes(sedes, nombre="Sedes de la red Alemana"))
mapas.mapa(capas, titulo="Zonas de influencia preliminares de la red Alemana (sin datos de la clínica)",
           subtitulo="Modeladas con demanda, competencia y tiempos reales por la red · se validan cuando lleguen los RUT",
           ayuda=["Las manzanas muestran, a elección en el panel: la zona de influencia de la red, qué sede captaría más en cada barrio, "
                  "los minutos a la sede más cercana y el público objetivo.",
                  "Las líneas rojas encierran la zona de influencia total de la red (60% y 80% de su demanda).",
                  "En las capas puedes prender las zonas primaria y secundaria de cada sede (elige la sede en el panel) y el territorio de cada una "
                  "(dónde es la clínica, el centro médico o la toma de muestras de la red que más captaría).",
                  "Son zonas modeladas con supuestos de referencia: cuando lleguen los RUT de los pacientes se reemplazan por las reales."],
           archivo=os.path.join(MAPAS, "04b_zonas_influencia_preliminares.html"), alto=720, encuadrar=["Sedes de la red Alemana"])

# %% [markdown]
# ## 8. Indicadores y conclusiones

# %%
ind_inf = metricas.influencia(r, sedes)
concl_inf = conclusiones.generar(ind_inf, ["Influencia"])
conclusiones.mostrar(concl_inf, "Conclusiones sobre las zonas de influencia preliminares")
metricas.tabla(ind_inf)[["indicador", "valor", "lectura"]]

# %% [markdown]
# ## 9. Entregables preliminares
# En `salidas/preliminar/`: un Excel (conclusiones, sedes, red, sensibilidad, supuestos) y un GeoPackage (manzanas con su
# zona y sede dominante, zonas de cada sede, territorios, zona total de la red y sedes) para QGIS o Mapdrive®.

# %%
notas = [("Qué es", "Zonas de influencia MODELADAS de la red Alemana con toda la data disponible, ANTES de recibir RUT y ventas de la clínica."),
         ("Cómo se definen", "Zona primaria = manzanas más cercanas (minutos en auto) que reúnen el 60% de la demanda que captaría cada sede; secundaria = hasta el 80%. Misma regla que las zonas reales del notebook 05."),
         ("Territorio", "Manzanas donde la sede es la de su formato (clínica, centro médico o toma de muestras) que más captaría: reparte el área entre las sedes de cada formato."),
         ("Supuestos", "Ver hoja Supuestos: β por formato, atractivo por formato, peso de los trabajadores y pesos por GSE. Se reemplazan al calibrar con ventas (notebook 06)."),
         ("Validación", "Cuando lleguen los RUT, el notebook 05 compara estas zonas con las reales (qué parte de la venta real cae dentro de la zona modelada).")]
if cfg["modo"] == "simulacion":
    notas.insert(0, ("Modo", "DATOS SIMULADOS: solo para probar el flujo; no usar para decisiones"))
hojas = {"Conclusiones": conclusiones.tabla(concl_inf), "Indicadores": metricas.tabla(ind_inf).drop(columns="clave"),
         "Sedes": vista.reset_index(drop=True), "Red": red_t, "Sensibilidad": sens.reset_index().rename(columns={"index": "sede"}),
         "Supuestos": supuestos, "Sedes del maestro": sedes_todas.drop(columns="geometry")[["sede", "nombre_visible", "formato", "estado", "formato_modelo", "en_modelo", "motivo_exclusion"]]}
ruta_x = ENT.guardar_excel(hojas, os.path.join(SAL, "Zonas_Influencia_Preliminares_CAS.xlsx"), notas)
capas_g = {"manzanas_zona_y_sede_dominante": gpd.GeoDataFrame(uv.drop(columns=["zona_red_txt"]), geometry="geometry", crs=ut.crs),
           "zonas_de_cada_sede": pol[pol["zona"].isin(["primaria", "secundaria"]) & (pol["sede"] != "RED")].assign(nombre=lambda d: d["sede"].map(nombre_s)),
           "territorio_de_cada_sede": pol[pol["zona"] == "territorio"].assign(nombre=lambda d: d["sede"].map(nombre_s)),
           "zona_total_de_la_red": pol[pol["sede"] == "RED"], "sedes": sedes.drop(columns=[c for c in ("recinto",) if c in sedes])}
ruta_g = ENT.guardar_gpkg(capas_g, os.path.join(SAL, "Zonas_Influencia_Preliminares_CAS.gpkg"))
log("entregables preliminares listos")

# %% [markdown]
# ## 10. Verificaciones

# %%
tt = res[["t50_min", "t60_min", "t80_min"]]
chk("Sedes de la red en el análisis (base de puntos del levantamiento)", len(sedes) > 0, f"{len(sedes)} de {inf_s['en_maestro']} oficiales")
chk("Zonas anidadas: t50 ≤ t60 ≤ t80 en todas las sedes y horas", bool(((tt["t50_min"] <= tt["t60_min"] + 1e-9) & (tt["t60_min"] <= tt["t80_min"] + 1e-9)).all()), "")
if {"auto_punta", "auto_valle"} <= set(I["modos"]):
    rp, rv2 = red_t.query("modo == 'auto_punta' and zona != 'toda la red'")["area_km2"].sum(), red_t.query("modo == 'auto_valle' and zona != 'toda la red'")["area_km2"].sum()
    chk("En hora punta la zona de la red es más chica que fuera de punta", rp <= rv2 + 1e-9, f"{rp:,.0f} vs {rv2:,.0f} km²")
mon = r["sensibilidad"].pivot_table(index="sede", columns="beta_x", values="t80_min")
chk("Sensibilidad coherente: si la gente viaja más (β menor) la zona crece", bool((mon.diff(axis=1).iloc[:, 1:] <= 1e-6).all().all()), "")
terr_ = r["territorio"]
fmt_ = sedes["formato_modelo"].to_numpy()
cubre = all(bool((terr_[:, fmt_ == f].sum(1)[r["mu"][:, fmt_ == f].sum(1) > 0] == 1).all()) for f in np.unique(fmt_))
chk("Territorios: cada manzana con demanda tiene exactamente una sede que más capta en cada formato", cubre, "")
chk("Contornos válidos", bool(pol.geometry.is_valid.all() and len(pol)), f"{len(pol)} polígonos")
chk("Entregables preliminares generados", os.path.exists(ruta_x) and os.path.exists(ruta_g), os.path.basename(ruta_x))
if cfg["modo"] == "simulacion":
    verdad = json.load(open(cfg["simulacion"]["verdad"], encoding="utf-8"))
    thv = np.r_[np.log(verdad["kappa"]), np.log(verdad["lambda"]), [verdad["a"][f] for f in M.FORMATOS], np.log([verdad["beta"][f] for f in M.FORMATOS]),
                [verdad["a_comp"][g] for g in M.GRUPOS_COMP], np.log([verdad["pesos_gse"][g] for g in cfg["gse"][1:]]), 0.0]
    mu_v, _, _ = INF.captacion(thv, INF.datos(ut, sedes, T[r["modo_ref"]], pc, cfg))
    _, tz_v = INF.zonas_por_sede(mu_v, T[r["modo_ref"]], tuple(I["cortes"]))
    dif = np.abs(p_.loc[sedes["sede"], "t80_min"].to_numpy() - tz_v[:, 2])
    chk("[simulación] t80 preliminar vs con los parámetros verdaderos (diferencia mediana ≤ 3 min)", float(np.median(dif)) <= 3,
        f"mediana {np.median(dif):.1f} min · máxima {dif.max():.1f} min")
chk.guardar(cfg)
guardar(res, cfg, "influencia_preliminar_sedes.csv"); guardar(red_t, cfg, "influencia_preliminar_red.csv")
guardar(r["manzanas"], cfg, "influencia_preliminar_manzanas.parquet"); guardar(r["zonas_largo"], cfg, "influencia_preliminar_zonas.parquet")
guardar(pol, cfg, "influencia_preliminar.gpkg"); guardar(metricas.como_dict(ind_inf), cfg, "metricas_influencia.json")
log("listo")
chk.tabla()
