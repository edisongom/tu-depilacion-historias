# -*- coding: utf-8 -*-
"""Prueba el estudio en escenarios distintos al base (solo simulación), cada uno en su propia carpeta.

Dos familias de escenarios:
  * INSUMOS que faltan o cambian (sin origen, origen por zona, RUT sin dígito verificador, solo ventas).
  * VENTAS distintas (en miles, en millones, unidad ambigua, transaccional, red 10 veces más grande o 20 veces más
    chica, historia corta). Las variantes se generan desde la tabla simulada (simulacion.variantes_ventas) y, cuando
    representan la misma venta (o la misma × un factor), el resultado se COMPARA con la corrida base: venta madura,
    parámetros del modelo y Top 20 deben coincidir (× el factor).

Cada escenario parte de una COPIA de los resultados de la corrida base (trabajo_simulacion/) y vuelve a correr los
notebooks afectados con variables de entorno (ver config_estudio.obtener_config). Como la copia trae resultados de la
corrida completa, también comprueba que ningún notebook use un resultado viejo.

Uso:  python constructor/probar_escenarios.py [--kernel grafos-peru] [--solo sin_origen,minimo]
Deja los notebooks ejecutados en ejecutados_escenarios/<escenario>/ y un resumen en ejecutados_escenarios/resumen.csv.
"""
import argparse
import glob
import json
import os
import shutil
import sys
import time

import nbformat
import numpy as np
import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
sys.path.insert(0, RAIZ)

# Fallas que se esperan en un escenario (comparaciones con la verdad de la simulación que dejan de aplicar)
VERDAD_SERIE = ["[simulación] mes faltante", "[simulación] pico por error", "[simulación] quiebre por convenio", "Serie con al menos 24 meses"]

ESCENARIOS = {
    # ---------------------------------------------------------------- insumos que faltan o cambian
    "sin_origen": {"desde": "05", "env": {"GEOVENTAS_SIN": "origen_pacientes"},
                   "que": "la clínica no entrega origen de pacientes"},
    # con datos reales el asistente se detiene y pide RUT_PACIENTES = "sin_rut" (el archivo no trae RUT); aquí se simula
    # que el equipo ya lo cambió
    "origen_zona": {"desde": "05", "env": {"GEOVENTAS_USAR": "origen_pacientes=origen_pacientes_por_zona",
                                           "GEOVENTAS_RUT_PACIENTES": "sin_rut"},
                    "que": "el origen viene agregado por zona censal (sin RUT)"},
    "rut_sin_dv": {"desde": "05", "env": {"GEOVENTAS_USAR": "origen_pacientes=origen_pacientes_sin_dv"},
                   "que": "la clínica manda el RUT sin dígito verificador (19027025, 19.027.025, 019027025): se detecta y se calcula"},
    # sin hoja de sedes los códigos de la clínica (S100…) no se emparejan por nombre: con datos reales el notebook 02 se
    # detiene y pide MAPA_SEDES; aquí se simula que el equipo lo completó (se toma de la corrida base)
    "minimo": {"desde": "02", "env": {"GEOVENTAS_SIN": "sedes_cliente,eventos_cliente,sitios_propuestos,gtfs,areas_verdes,origen_pacientes"},
               "mapa_sedes": True,
               "que": "solo ventas: sin hoja de sedes, eventos, sitios propuestos, GTFS, áreas verdes ni origen"},
    # ---------------------------------------------------------------- ventas distintas
    "ventas_en_miles": {"desde": "02", "hasta": "02", "variante": "ventas_en_miles", "comparar": {"factor": 1.0},
                        "que": "montos en miles de pesos (columna 'venta_miles'): se reconoce por el nombre y se lleva a pesos"},
    "ventas_en_millones": {"desde": "02", "hasta": "02", "variante": "ventas_en_millones", "comparar": {"factor": 1.0},
                           "que": "montos en millones con coma decimal ('945,803526') y sin la unidad en el nombre: se reconoce por la magnitud"},
    "ventas_unidad_ambigua": {"desde": "02", "hasta": "02", "variante": "ventas_unidad_ambigua", "debe_detenerse": "UNIDAD_MONTO",
                              "que": "montos sin unidad en el nombre y sin atenciones (pesos y miles son posibles): el notebook se detiene y la pide"},
    "ventas_unidad_declarada": {"desde": "02", "hasta": "02", "variante": "ventas_unidad_ambigua", "env": {"GEOVENTAS_UNIDAD_MONTO": "pesos"},
                                "comparar": {"factor": 1.0},
                                "que": "la misma tabla ambigua, con UNIDAD_MONTO = \"pesos\" escrito en la configuración"},
    "ventas_transaccionales": {"desde": "02", "hasta": "02", "variante": "ventas_transaccionales", "comparar": {"factor": 1.0},
                               "que": "una fila por atención con fecha diaria (94 mil filas) y filas idénticas legítimas: se agrega sin perder un peso"},
    "ventas_x10": {"desde": "02", "variante": "ventas_x10", "perfil": "completo", "env": {"GEOVENTAS_FACTOR_VENTAS": "10"},
                   "comparar": {"factor": 10.0, "parametros": True, "top": True},
                   "que": "una red que vende 10 veces más: mismos parámetros y mismo Top 20 (× 10)"},
    "ventas_div20": {"desde": "02", "variante": "ventas_div20", "perfil": "completo", "env": {"GEOVENTAS_FACTOR_VENTAS": "0.05"},
                     "comparar": {"factor": 0.05, "parametros": True, "top": True},
                     "que": "una red que vende 20 veces menos: mismos parámetros y mismo Top 20 (÷ 20)"},
    # ---------------------------------------------------------------- coordenadas en formatos mezclados
    "coordenadas_mixtas": {"desde": "01", "hasta": "04", "coordenadas": True, "comparar_coordenadas": True,
                           "que": "personas, empresas, BBRR, maestro de sedes y competencia con coordenadas en 8 formatos mezclados "
                                  "(coma, sin punto decimal, miles de Excel, grados/min/seg, sin signo, lat/lon intercambiadas, signo tipográfico)"},
    # ---------------------------------------------------------------- antes de recibir datos de la clínica
    "sin_datos_clinica": {"limpio": True, "notebooks": ["01", "03", "04b"], "comparar_influencia": True,
                          "env": {"GEOVENTAS_SIN": "ventas_cliente,sedes_cliente,origen_pacientes,eventos_cliente,sitios_propuestos"},
                          "que": "carpeta de trabajo VACÍA y sin ningún dato de la clínica (ni ventas, ni sedes, ni RUT): 01 → 03 → 04b arman las zonas de influencia preliminares"},
    "historia_corta": {"desde": "02", "variante": "ventas_historia_corta", "esperadas": VERDAD_SERIE,
                       "que": "solo 18 meses de ventas: el estudio corre, avisa lo que no se puede medir y usa la rampa supuesta"},
}


def ejecutar(ruta, destino, kernel):
    from nbclient import NotebookClient
    nb = nbformat.read(ruta, as_version=4)
    t0 = time.time()
    error = ""
    try:
        NotebookClient(nb, timeout=7200, kernel_name=kernel, resources={"metadata": {"path": RAIZ}}).execute()
    except Exception as e:                         # se guarda igual el notebook, con la celda que falló
        error = f"{type(e).__name__}: {str(e).strip()[:4000]}"
    nbformat.write(nb, destino)
    return time.time() - t0, error


def comparar_coordenadas(trabajo, base):
    """Mismos puntos que la corrida base aunque las coordenadas vengan escritas de otra forma."""
    out = []
    for f in ("per.parquet", "emp.parquet", "bbrr.parquet"):
        a = pd.read_parquet(os.path.join(base, f), columns=["lat", "lon"])
        b = pd.read_parquet(os.path.join(trabajo, f), columns=["lat", "lon"])
        d = float(np.nanmax(np.abs(a.to_numpy() - b.to_numpy()))) if len(a) == len(b) else np.nan
        out.append((f"{f}: mismos registros y coordenadas que la base", len(a) == len(b) and d < 1e-5,
                    f"{len(b):,} vs {len(a):,} registros · diferencia máxima {d:.1e}°"))
    a = pd.read_parquet(os.path.join(base, "sedes_estudio.parquet")).set_index("sede")[["lat", "lon"]]
    b = pd.read_parquet(os.path.join(trabajo, "sedes_estudio.parquet")).set_index("sede")[["lat", "lon"]].reindex(a.index)
    d = float(np.nanmax(np.abs(a.to_numpy() - b.to_numpy())))
    out.append(("Sedes del estudio en el mismo lugar", d < 1e-5, f"diferencia máxima {d:.1e}°"))
    a, b = pd.read_csv(os.path.join(base, "entorno_sedes.csv")), pd.read_csv(os.path.join(trabajo, "entorno_sedes.csv"))
    col = [c for c in a.columns if c.startswith("pob_objetivo_") and c.endswith("min")][0]
    d = float((b.set_index("sede")[col] / a.set_index("sede")[col] - 1).abs().max())
    out.append((f"Entorno de las sedes igual a la base ({col})", len(a) == len(b) and d < 1e-6, f"{len(b)} sedes · diferencia máxima {d:.1e}"))
    a, b = pd.read_parquet(os.path.join(base, "unidades.parquet"), columns=["pob", "trabajadores_est"]), \
        pd.read_parquet(os.path.join(trabajo, "unidades.parquet"), columns=["pob", "trabajadores_est"])
    out.append(("Manzanas con la misma población y trabajadores", len(a) == len(b) and np.allclose(a.to_numpy(), b.to_numpy()),
                f"{len(b):,} manzanas"))
    return out


def comparar_influencia(trabajo, base):
    """Las zonas preliminares sin datos de la clínica deben ser las mismas que con todos los datos (no usan la clínica)."""
    out = [("No se usó ningún dato de la clínica (no existe sedes_estudio ni venta madura)",
            not os.path.exists(os.path.join(trabajo, "sedes_estudio.parquet")) and not os.path.exists(os.path.join(trabajo, "venta_madura.csv")), "")]
    a = pd.read_csv(os.path.join(base, "influencia_preliminar_sedes.csv")).set_index(["sede", "modo"])
    b = pd.read_csv(os.path.join(trabajo, "influencia_preliminar_sedes.csv")).set_index(["sede", "modo"]).reindex(a.index)
    cols = ["t50_min", "t60_min", "t80_min", "pob_objetivo_primaria", "pob_objetivo_secundaria", "pob_objetivo_territorio"]
    d = float(np.nanmax(np.abs(b[cols].to_numpy() / a[cols].to_numpy() - 1)))
    out.append(("Zonas de influencia preliminares iguales a la corrida con todos los datos", d < 1e-6, f"{len(b)} sedes × hora · diferencia máxima {d:.1e}"))
    return out


def comparar(esc, trabajo, base, hasta):
    """Comparaciones con la corrida base (la misma venta × factor). Devuelve lista de (chequeo, ok, detalle)."""
    c = esc["comparar"]
    f = c["factor"]
    out = []
    vb = pd.read_csv(os.path.join(base, "venta_madura.csv")).set_index("sede")["venta_mensual_madura"]
    ve = pd.read_csv(os.path.join(trabajo, "venta_madura.csv")).set_index("sede")["venta_mensual_madura"]
    dif = float((ve.reindex(vb.index) / (vb * f) - 1).abs().max())
    out.append((f"Venta madura de cada sede = corrida base × {f:g}", dif < 1e-4, f"diferencia máxima {dif:.1e}"))
    if c.get("parametros") and hasta >= "06":
        pb = pd.read_csv(os.path.join(base, "parametros.csv")).set_index("parametro")["valor"]
        pe = pd.read_csv(os.path.join(trabajo, "parametros.csv")).set_index("parametro")["valor"]
        sin_k = [p for p in pb.index if p != "log_kappa"]
        d = float((pe[sin_k] - pb[sin_k]).abs().max())
        dk = float(pe["log_kappa"] - pb["log_kappa"] - np.log(f))
        out.append(("Parámetros del modelo iguales a la base (solo cambia κ en log del factor)", d < 1e-3 and abs(dk) < 1e-3,
                    f"diferencia máxima {d:.1e} · κ {dk:+.1e}"))
    if c.get("top") and hasta >= "07":
        tb, te = pd.read_parquet(os.path.join(base, "top20.parquet")), pd.read_parquet(os.path.join(trabajo, "top20.parquet"))
        mismos = list(tb["id_cand"]) == list(te["id_cand"]) and list(tb["formato"]) == list(te["formato"])
        r = float((te["venta_neta"].values / (tb["venta_neta"].values * f) - 1).__abs__().max()) if mismos else np.nan
        out.append((f"Top 20 idéntico a la base (mismas manzanas, formatos y orden; venta neta × {f:g})", mismos and r < 1e-3,
                    f"{len(te)} ubicaciones · diferencia de venta máxima {r:.1e}" if mismos else
                    f"distintas: {len(set(tb['id_cand']) & set(te['id_cand']))} de {len(tb)} en común"))
    return out


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--kernel", default="python3")
    ap.add_argument("--solo", default=None)
    a = ap.parse_args()
    base = os.path.join(RAIZ, "trabajo_simulacion")
    notebooks = sorted(glob.glob(os.path.join(RAIZ, "0[0-8]*_*.ipynb")))      # incluye el 04b
    from geoventas.simulacion import variantes_ventas
    variantes = variantes_ventas(os.path.join(RAIZ, "datos_simulados", "cliente", "ventas_sede_mes_linea.csv"),
                                 os.path.join(RAIZ, "datos_simulados", "cliente", "variantes"))
    var_coord = None
    if any(e.get("coordenadas") for n, e in ESCENARIOS.items() if not a.solo or n in a.solo.split(",")):
        import config_estudio
        from geoventas.simulacion import variantes_coordenadas
        os.environ["GEOVENTAS_ESCENARIO"] = ""
        var_coord = variantes_coordenadas(config_estudio.obtener_config("simulacion"), os.path.join(RAIZ, "datos_simulados", "variantes_coordenadas"))
    filas = []
    for nombre, esc in ESCENARIOS.items():
        if a.solo and nombre not in a.solo.split(","):
            continue
        trabajo = os.path.join(RAIZ, f"trabajo_simulacion_{nombre}")
        salidas = os.path.join(RAIZ, f"salidas_simulacion_{nombre}")
        for c in (trabajo, salidas):
            shutil.rmtree(c, ignore_errors=True)
        if esc.get("limpio"):
            os.makedirs(trabajo, exist_ok=True)        # carpeta vacía: nada de la corrida completa
        else:
            shutil.copytree(base, trabajo)            # resultados de la corrida completa (incluso los que ya no deberían usarse)
        os.environ.update({"GEOVENTAS_ESCENARIO": nombre, "GEOVENTAS_PERFIL": esc.get("perfil", "rapido"), "GEOVENTAS_SIN": "",
                           "GEOVENTAS_USAR": "", "GEOVENTAS_MAPA_SEDES": "", "GEOVENTAS_RUT_PACIENTES": "", "GEOVENTAS_RUT_CON_DV": "",
                           "GEOVENTAS_UNIDAD_MONTO": "", "GEOVENTAS_FACTOR_VENTAS": "", "GEOVENTAS_RUTAS": ""})
        os.environ.update(esc.get("env", {}))
        if esc.get("variante"):
            os.environ["GEOVENTAS_RUTAS"] = json.dumps({"ventas_cliente": variantes[esc["variante"]]})
        if esc.get("coordenadas"):
            os.environ["GEOVENTAS_RUTAS"] = json.dumps(var_coord)
        if esc.get("mapa_sedes"):
            se = pd.read_parquet(os.path.join(base, "sedes_estudio.parquet"))
            se = se[se["id_maestro"].notna()]
            os.environ["GEOVENTAS_MAPA_SEDES"] = json.dumps(dict(zip(se["sede_cliente"].astype(str), se["id_maestro"].astype(str))))
        carpeta = os.path.join(RAIZ, "ejecutados_escenarios", nombre)
        shutil.rmtree(carpeta, ignore_errors=True)
        os.makedirs(carpeta, exist_ok=True)
        print(f"== {nombre}: {esc['que']}", flush=True)
        hasta = esc.get("hasta", "08")
        esperadas = esc.get("esperadas", [])
        for ruta in notebooks:
            nb = os.path.basename(ruta).split("_")[0]
            if esc.get("notebooks"):
                if nb not in esc["notebooks"]:
                    continue
            elif nb < esc["desde"] or nb > hasta:
                continue
            ver = os.path.join(trabajo, f"verificaciones_{nb}_*.csv")
            for f in glob.glob(ver):                  # la de la corrida base no cuenta
                os.remove(f)
            seg, error = ejecutar(ruta, os.path.join(carpeta, os.path.basename(ruta)), a.kernel)
            if esc.get("debe_detenerse"):
                ok = esc["debe_detenerse"] in error
                linea = next((l.strip() for l in error.splitlines() if "UNIDAD_MONTO" in l or "❌" in l), error[:200])
                filas.append({"escenario": nombre, "notebook": nb, "segundos": round(seg), "error": "",
                              "verificaciones_ok": int(ok), "verificaciones": 1,
                              "fallidas": "" if ok else f"no se detuvo pidiendo {esc['debe_detenerse']}", "esperadas": "",
                              "detalle": "se detuvo y pidió: " + linea if ok else error[:300]})
                print(f"   {nb}: {seg:5.0f} s · {'se detuvo y pidió la unidad ✅' if ok else '❌ ' + error[:200]}", flush=True)
                break
            v = pd.read_csv(glob.glob(ver)[0], encoding="utf-8-sig") if glob.glob(ver) else None
            bien = v["resultado"].eq("✅") if v is not None else pd.Series(dtype=bool)
            fall = v.loc[~bien, "chequeo"].astype(str).tolist() if v is not None else []
            esp = [x for x in fall if any(e in x for e in esperadas)]
            filas.append({"escenario": nombre, "notebook": nb, "segundos": round(seg), "error": error[:300],
                          "verificaciones_ok": int(bien.sum()), "verificaciones": len(bien),
                          "fallidas": "; ".join(x for x in fall if x not in esp), "esperadas": "; ".join(esp), "detalle": ""})
            print(f"   {nb}: {seg:5.0f} s · {'ERROR ' + error[:200] if error else f'{int(bien.sum())}/{len(bien)} verificaciones'}"
                  + (f" ({len(esp)} esperadas)" if esp else ""), flush=True)
            if error:
                break
        sin_error = not any(f["error"] for f in filas if f["escenario"] == nombre)
        comparaciones = (comparar(esc, trabajo, base, hasta) if esc.get("comparar") else []) + \
                        (comparar_coordenadas(trabajo, base) if esc.get("comparar_coordenadas") else []) + \
                        (comparar_influencia(trabajo, base) if esc.get("comparar_influencia") else [])
        if sin_error and comparaciones:
            for chequeo, ok, det in comparaciones:
                filas.append({"escenario": nombre, "notebook": "vs base", "segundos": 0, "error": "", "verificaciones_ok": int(ok),
                              "verificaciones": 1, "fallidas": "" if ok else chequeo, "esperadas": "", "detalle": f"{chequeo}: {det}"})
                print(f"   vs base: {'✅' if ok else '❌'} {chequeo} · {det}", flush=True)
    r = pd.DataFrame(filas)
    os.makedirs(os.path.join(RAIZ, "ejecutados_escenarios"), exist_ok=True)
    ruta_r = os.path.join(RAIZ, "ejecutados_escenarios", "resumen.csv")
    if a.solo and os.path.exists(ruta_r):            # con --solo se reemplazan solo los escenarios que se corrieron
        previo = pd.read_csv(ruta_r, encoding="utf-8-sig", dtype={"notebook": str})
        r = pd.concat([previo[~previo["escenario"].isin(r["escenario"])], r], ignore_index=True)
    r.to_csv(ruta_r, index=False, encoding="utf-8-sig")
    print(r.drop(columns=["detalle"], errors="ignore").to_string(index=False))
