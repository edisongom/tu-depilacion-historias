# %% [markdown]
# # 06 · Modelo de estimación de ventas
# **Hito 2 del FRF · "Modelo de estimación de ventas" + "Validación de desempeño"**
#
# ## La idea, en simple
# Cada manzana tiene un **presupuesto mensual de gasto en salud** (más alto donde viven hogares AB, C1a y C1b, y más
# alto donde trabaja mucha gente). Ese gasto se reparte entre:
# * las **sedes de Clínica Alemana**,
# * la **competencia** (clínicas, centros médicos, laboratorios),
# * y "**no ir a ninguna**" (atenderse en otra parte o no gastar).
#
# Cada alternativa se lleva una parte según su **atractivo** (formato, tamaño) y **cuánto cuesta llegar** (minutos por la
# red, en hora punta). Mientras más lejos, menos atractivo: el atractivo cae a la mitad cada cierto número de minutos.
# La venta de una sede es la suma de lo que capta en todas las manzanas. Este es el **modelo de Huff**, el estándar
# para estimar ventas de locales nuevos.
#
# $$\text{venta}_{ij} = \kappa \cdot D_i \cdot \frac{A_j\, e^{-\beta_{f(j)}\, t_{ij}}}{1 + \sum_{k} A_k\, e^{-\beta_{f(k)}\, t_{ik}} + \sum_{c} w_c\, A_{g(c)}\, e^{-\beta_{f(g)}\, t_{ic}}}
# \qquad D_i = \sum_{g} \text{gasto}_{ig}\, p_g + \lambda \cdot \text{trabajadores}_i \cdot \text{gasto per cápita}$$
#
# | Símbolo | Qué significa | Cómo se obtiene |
# |---|---|---|
# | $D_i$ | demanda potencial de la manzana $i$ | censo (gasto en salud por GSE) + empresas (trabajadores) |
# | $p_g$ | peso de afinidad del GSE $g$ con CAS (AB = 1) | **se estima** con los datos de origen de pacientes |
# | $\lambda$ | cuánto pesa la demanda de quienes trabajan en la manzana | **se estima** |
# | $A_j$ | atractivo de la sede: por formato y por tamaño ($m^2$ relativos al típico, elevado a $\gamma$) | **se estima** |
# | $\beta_f$ | caída por minuto de viaje, por formato | **se estima** (clínica: la gente viaja más; toma de muestras: menos) |
# | $w_c$ | peso del competidor según su segmento (Premium 1,0 … Público 0,2) | levantamiento de competencia |
# | $t_{ic}$ | minutos exactos de la manzana $i$ al competidor $c$ | red vial (notebook 04, potencial de competencia) |
# | $\kappa$ | escala general | **se estima** |
#
# **Cómo se estima:** máxima verosimilitud cuasi-Poisson (el estándar para conteos y montos) con "priors" suaves que
# evitan valores absurdos cuando hay pocos datos, gradiente analítico y el optimizador L-BFGS-B. Los pesos GSE llevan además
# una **penalización de suavidad**: los GSE vecinos (C1a, C1b, C2) viven en las mismas zonas, así que sus efectos por
# separado son difíciles de distinguir; la curva AB → E debe bajar en forma suave, sin zigzag.
#
# **Cómo se valida (lo más importante):**
# 1. **Sede nueva:** se saca una sede, se recalibra con las demás y se predice su venta como si se abriera hoy. Es
#    exactamente el uso que tendrá el modelo. Se reporta el error por sede (FRF Hito 2.1).
# 2. **Validación cruzada espacial:** se esconden zonas completas del mapa y se predicen.
# 3. **Benchmark de machine learning:** un gradient boosting con la misma validación. Si el ML no le gana claramente al
#    Huff, preferimos el Huff porque es interpretable y sirve para simular aperturas.
#
# | Entra | Sale (`trabajo/`) |
# |---|---|
# | manzanas (03) · tiempos (04) · unidades de calibración (05) · venta madura (02) | `modelo.pkl`, `parametros.csv`, `validacion_sede_nueva.csv` |

# %%
import os, sys, json
sys.path.insert(0, os.path.abspath("."))
import numpy as np, pandas as pd
from IPython.display import display
import config_estudio
from dataclasses import replace
from geoventas import insumos, modelo as M, graficos, mapas, verificacion, metricas, conclusiones
from geoventas.utilidades import Cronometro, guardar, cargar, existe, mm, pct, carpeta_salida, n_nucleos

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "06")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("06_modelo")
GRAF = carpeta_salida(cfg, "graficos"); MAPAS = carpeta_salida(cfg, "mapas")
ut = cargar(cfg, "unidades.parquet")
sedes_estudio = cargar(cfg, "sedes_estudio.parquet")
sedes = sedes_estudio[sedes_estudio["en_modelo"]].reset_index(drop=True)
vm = cargar(cfg, "venta_madura.csv"); vm = vm[vm["sede"].isin(sedes["sede"])]
T = cargar(cfg, "T_sedes_auto_punta.npy"); pc = cargar(cfg, "potencial_competencia.pkl")
U = cargar(cfg, "unidades_calib.pkl")
nivel = U["nivel"]
d = M.armar_datos(ut, sedes, T, pc, U, cfg)
print(f"Nivel de calibración: {nivel} · observaciones: {d.S.shape[0]:,} · sedes: {len(d.sedes)} · manzanas: {len(ut):,} · "
      f"competidores: {pc.resumen['competidores']:,} (tiempo exacto de cada manzana a cada uno) · núcleos: {n_nucleos(cfg)}")
print("Capacidad relativa de cada sede (log m² / m² típico del formato):", dict(zip(d.sedes, np.round(d.z, 2))))

# %% [markdown]
# ## 1. Calibración

# %%
th, res = M.ajustar(d, cfg, nivel)
log(f"optimizador: {'convergió' if res.convergio else 'NO convergió'} en {res.nit} iteraciones · gradiente máx {abs(res.jac).max():.1e}")
print(f"Dispersión φ = {res.phi:,.0f} (en pesos): la venta observada varía más que un conteo puro (normal en montos); la verosimilitud se pondera por φ.")
err_grad = M.chequeo_gradiente(th, d, cfg, nivel)
print(f"Control matemático: error relativo del gradiente analítico vs numérico = {err_grad:.1e} (debe ser < 1e-4)")

# %% [markdown]
# ### Parámetros estimados y cómo leerlos
# * **Caída por minuto (β):** la línea "el atractivo cae a la mitad cada X min" es la forma más fácil de leerlo.
# * **Pesos GSE:** cuánto gasta en CAS, en proporción, un peso del gasto en salud de cada GSE respecto de AB.
# * **Atractivo de la competencia:** si es menor que el de una sede CAS del mismo formato, CAS gana a igual distancia.

# %%
par = M.tabla_parametros(th, d)
par[["parametro", "valor_natural", "interpretacion"]].assign(valor_natural=par["valor_natural"].round(4))

# %%
pg = M.pesos_gse(th, d)
pd.DataFrame({"peso inicial (supuesto)": cfg["modelo"]["pesos_gse_iniciales"], "peso estimado": pg}).round(3)

# %% [markdown]
# ## 2. Ajuste por sede (dentro de la muestra)
# Cada punto es una sede: si está sobre la diagonal, el modelo reproduce bien su venta mensual. (Escala logarítmica,
# porque una clínica vende 50 veces más que una toma de muestras.)

# %%
aj = M.ajuste_por_sede(th, d, vm)
met = M.metricas_ajuste(th, d)
graficos.NOMBRES_SEDE = dict(zip(sedes_estudio["sede"], mapas.nombre_sede(sedes_estudio)))
graficos.ajuste_sedes(aj, ruta=os.path.join(GRAF, "06_ajuste_sedes.png"));
print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in met.items()})
aj.assign(venta_observada=aj["venta_observada"].map(mm), venta_predicha=aj["venta_predicha"].map(mm), error_pct=aj["error_pct"].map(pct))

# %% [markdown]
# ## 3. ¿Cuánto pesa la distancia? Curvas de caída
# Las curvas muestran el atractivo relativo según los minutos de viaje. Con origen por manzana (RUT), los puntos son lo
# observado (venta por unidad de demanda en cada banda de tiempo).

# %%
graficos.decaimiento(th, None, M.decaimiento_observado(d, nivel), os.path.join(GRAF, "06_decaimiento.png"));

# %% [markdown]
# ## 4. Validación "sede nueva" (la prueba más exigente)
# Para cada sede: se elimina del modelo, se recalibra con las otras y se predice su venta **como si fuera una apertura**.
# Las 11 recalibraciones corren en paralelo (una por núcleo).

# %%
val = M.validar_sede_fuera(d, cfg, th, nivel, vm)
log("validación sede nueva lista")
graficos.validacion_sede_nueva(val, os.path.join(GRAF, "06_validacion_sede_nueva.png"));
print(f"Error absoluto mediano: {val['error_pct'].abs().median():.1%} · sedes dentro de ±25%: {(val['error_pct'].abs() <= 0.25).mean():.0%}")
sd_sede = M.sd_error_sede(val)
print(f"Error propio de una sede nueva (σ en escala log, raíz del error cuadrático medio): {sd_sede:.1%}. "
      "Se suma a los escenarios P10/P90 de los sitios nuevos en el notebook 07.")
val.assign(**{c: val[c].map(mm) for c in ("venta_observada", "venta_predicha_como_nueva", "venta_predicha_con_todas")}, error_pct=val["error_pct"].map(pct))

# %% [markdown]
# **Cómo leerlo:** un error de +20% significa que, si esa sede no existiera y la abriéramos hoy, el modelo habría
# estimado un 20% más de lo que realmente vende.
#
# **Para qué más sirve:** este error mide algo que el bootstrap (sección 5) no ve: cada sede tiene un atractivo propio
# no observado (estacionamiento, equipo médico, convenios, visibilidad). Su tamaño típico (σ, impreso arriba) se suma a
# los escenarios de los sitios nuevos, para que el P10 y el P90 de una apertura sean realistas y no demasiado angostos. Errores grandes en una sede puntual suelen tener explicación de negocio
# (convenios, estacionamiento, una especialidad estrella) que conviene conversar con la clínica en la sesión de validación.

# %% [markdown]
# ## 5. Incertidumbre: escenarios conservador (P10), base (P50) y optimista (P90)
# Con suficientes unidades se hace **bootstrap**: se remuestrean las zonas de origen con reemplazo y se recalibra
# muchas veces (en paralelo). La dispersión de los parámetros da los escenarios que pide el FRF.

# %%
thetas, metodo = M.incertidumbre(d, cfg, th, nivel)
log(f"incertidumbre: {metodo} · {len(thetas)} réplicas")
banda = (np.percentile(thetas, 10, axis=0), np.percentile(thetas, 90, axis=0))
par = M.tabla_parametros(th, d, banda)
graficos.decaimiento(th, thetas, M.decaimiento_observado(d, nivel), os.path.join(GRAF, "06_decaimiento.png"));
par[["parametro", "valor_natural", "p10_natural", "p90_natural", "interpretacion"]].round(4)

# %% [markdown]
# ## 6. Validación cruzada espacial y comparación con machine learning
# Se esconden **bloques de zonas vecinas** (no zonas sueltas, para que el modelo no "copie" al vecino) y se predicen.
# El indicador es el **% de desvío explicado** fuera de muestra (1 = perfecto, 0 = no mejor que el promedio).

# %%
coords = M.coordenadas_unidades(d, ut)
cv = M.cv_espacial(d, cfg, th, nivel, coords)
if cv:
    print(f"Huff · validación cruzada espacial ({cv['bloques']} bloques): desvío explicado {cv['desvio_explicado_cv']:.1%} · correlación {cv['correlacion_cv']:.3f}")
    graficos.cv_scatter(cv["y"], cv["pred"], "Huff: venta por unidad, observada vs predicha fuera de muestra", os.path.join(GRAF, "06_cv_espacial.png"));
bench = None
if nivel == "unidad":
    yh = (d.S[:len(ut)] * d.mask[:len(ut)]).sum(1)
    X = ut[[c for c in ["pob", "pob_objetivo", "gasto_salud_total", "gasto_salud_objetivo", "trabajadores_est", "densidad_hab_km2",
                        "comp_clinica_peso", "comp_centro_medico_peso", "comp_laboratorio_peso", "min_a_cas", "pct_objetivo", "poi_metro"] if c in ut]].copy()
    X["min_a_cas"] = X.get("min_a_cas", pd.Series(60, index=X.index)).replace(np.inf, 90)
    bench = M.benchmark_ml(X, yh, ut[["cx", "cy"]].values, n_bloques=cfg["modelo"]["n_bloques_cv"])
    print(f"Gradient boosting · misma validación espacial: desvío explicado {bench['desvio_explicado_cv']:.1%}")
    display(bench["importancia"].head(8))

# %% [markdown]
# ## 7. Mapas del modelo
# **(a) Por manzana** (elige el indicador arriba a la izquierda):
# * **participación modelada de CAS** en el gasto en salud de la manzana (venta CAS predicha ÷ demanda potencial);
# * **venta CAS modelada** y **demanda potencial**;
# * la **sede CAS que más capta** en cada manzana (su área de mercado según el modelo).
# **(b) Residuo por comuna:** dónde el modelo sobreestima (azul) o subestima (rojo) la venta observada. Un residuo con
# patrón geográfico claro indicaría que falta alguna variable.

# %%
mu = M.predecir(th, d)
Dt = d.G @ np.r_[1.0, np.exp(th[11:-1])] + np.exp(th[1]) * d.W
ut["venta_cas_modelo"] = mu.sum(1)
ut["demanda_potencial"] = Dt
ut["participacion_modelo_%"] = 100 * mu.sum(1) / np.maximum(Dt, 1)
ut["sede_que_mas_capta"] = np.where(mu.sum(1) > 0, np.array(d.sedes)[mu.argmax(1)], None)
# residuo por comuna: venta observada (reparto descriptivo del notebook 05) vs venta del modelo, sedes con origen
res_g = None
if existe(cfg, "flujos.parquet"):
    fl = cargar(cfg, "flujos.parquet")
    js = [k for k, s in enumerate(d.sedes) if s in set(fl["sede"])]
    com = ut.set_index("ut")["comuna"]
    obs_c = fl.assign(comuna=fl["ut"].map(com)).groupby("comuna")["venta_mensual"].sum()
    pred_c = pd.Series(mu[:, js].sum(1), index=ut["comuna"].values).groupby(level=0).sum()
    res_g = ut[["comuna", "geometry"]].assign(geometry=ut.geometry.buffer(15)).dissolve("comuna").reset_index()   # 15 m: cierra las calles
    res_g["observado_MM"] = (res_g["comuna"].map(obs_c).fillna(0) / 1e6).round(1)
    res_g["modelo_MM"] = (res_g["comuna"].map(pred_c).fillna(0) / 1e6).round(1)
    res_g["residuo_%"] = (100 * (res_g["observado_MM"] / res_g["modelo_MM"].replace(0, np.nan) - 1)).clip(-100, 200).round(1)
colores_sede = mapas.colores_sedes(d.sedes)
nombre_sede = dict(zip(sedes["sede"], mapas.nombre_sede(sedes)))
capas = [mapas.capa_manzanas(ut, "Modelo por manzana",
                             mapas.inds("participacion_modelo_%", "venta_cas_modelo", "demanda_potencial")
                             + [mapas.ind("sede_que_mas_capta", "Sede que más atiende a cada barrio (según el modelo)", "texto",
                                          categorias=colores_sede, nombres_categoria=nombre_sede,
                                          descripcion="Para cada manzana, la sede de Clínica Alemana a la que el modelo le asigna más venta: "
                                                      "es el 'territorio' de cada sede.")],
                             ficha=mapas.inds("pob", "pob_objetivo", "min_a_cas"))]
if res_g is not None:
    r_ = res_g["residuo_%"]
    res_g["calce"] = np.select([r_ > 25, r_ > 10, r_ >= -10, r_ >= -25], [
        "La venta real supera mucho al modelo (más de +25%)", "La venta real supera al modelo (+10% a +25%)", "Calza con el modelo (±10%)",
        "La venta real queda bajo el modelo (−10% a −25%)"], "La venta real queda muy bajo el modelo (menos de −25%)")
    res_g["comuna_txt"] = res_g["comuna"].astype(str).str.title()
    capas.append(mapas.capa(res_g.to_crs("EPSG:4326"), "¿El modelo calza con la venta real de cada comuna?", campo_categoria="calce",
                            colores_categoria={"La venta real supera mucho al modelo (más de +25%)": "#2166ac",
                                               "La venta real supera al modelo (+10% a +25%)": "#67a9cf", "Calza con el modelo (±10%)": "#f0f0f0",
                                               "La venta real queda bajo el modelo (−10% a −25%)": "#ef8a62",
                                               "La venta real queda muy bajo el modelo (menos de −25%)": "#b2182b"},
                            popup=["comuna_txt", "observado_MM", "modelo_MM", "residuo_%"], titulo_popup="comuna_txt",
                            etiquetas_popup={"observado_MM": "Venta real (millones al mes)", "modelo_MM": "Venta del modelo (millones al mes)",
                                             "residuo_%": "Diferencia (%)"},
                            peso=0.6, opacidad=0.6, visible=False, simplificar_m=40))
capas.append(mapas.capa_sedes(sedes))
mapas.mapa(capas, titulo="Lo que dice el modelo, manzana por manzana",
           subtitulo="Qué parte del gasto en salud capta Clínica Alemana, cuánto vende en cada barrio y qué sede lo atiende",
           ayuda=["Elige en el panel: la participación (de cada $100 de gasto en salud, cuántos van a Clínica Alemana), la venta "
                  "estimada, el mercado potencial o qué sede atiende cada barrio.",
                  "En las capas puedes prender el control por comuna: dónde la venta real calza con el modelo y dónde no."],
           archivo=os.path.join(MAPAS, "06_modelo.html"))

# %% [markdown]
# ## 8. ¿Sirve igual con ventas mucho más altas o más bajas? (invariancia de escala)
# El modelo se vuelve a calibrar con las ventas multiplicadas por 0,000001 (como si vinieran en millones) y por 1.000.
# Los parámetros que importan (caída con la distancia, pesos GSE, demanda flotante, competencia, tamaño) deben salir
# **idénticos**; solo cambia la escala κ. Así se comprueba que el modelo funciona igual con una red que vende 20 veces
# más o 20 veces menos, y con montos en cualquier unidad.

# %%
dif_escala = {}
for k in (1e-6, 1e3):
    th_k, _ = M.ajustar(replace(d, S=d.S * k, phi=None), cfg, nivel, th_ini=np.r_[th[0] + np.log(k), th[1:]])
    dif_escala[k] = float(np.abs(th_k[1:] - th[1:]).max())
    print(f"ventas × {k:g}: diferencia máxima en los parámetros (sin κ) = {dif_escala[k]:.1e} · κ cambia en log {th_k[0] - th[0]:+.3f} (esperado {np.log(k):+.3f})")
log("invariancia de escala comprobada")

# %% [markdown]
# ## 9. Indicadores clave y conclusiones sobre el modelo
# Qué tan confiable es (error "sede nueva", sesgo, validación cruzada, comparación con machine learning) y qué dice
# sobre el negocio (peso de la distancia, demanda de trabajadores, competencia, tamaño). La confiabilidad se clasifica
# en alta, media o baja y **la recomendación de uso cambia según esa clasificación**.

# %%
mod_tmp = {"th": th, "d": d, "metricas": met, "sd_log_sede": sd_sede, "cv": {k: v for k, v in (cv or {}).items() if k not in ("y", "pred", "grupos")},
           "benchmark": None if bench is None else {"desvio_explicado_cv": bench["desvio_explicado_cv"]}}
ind_modelo = metricas.modelo(mod_tmp, val, aj, metricas.nombres_sedes(sedes_estudio))
conclusiones.mostrar(conclusiones.generar(ind_modelo, ["Modelo"]), "Conclusiones sobre el modelo")
metricas.tabla(ind_modelo)[["indicador", "valor", "lectura"]]

# %% [markdown]
# ## 10. Verificaciones

# %%
chk("Optimizador convergió (gradiente ≈ 0)", res.convergio, f"{abs(res.jac).max():.1e} · {res.message}")
chk("Gradiente analítico = numérico", err_grad < 1e-4, f"{err_grad:.1e}")
chk("Venta total predicha ≈ observada (±5%)", abs(met["venta_predicha_total"] / met["venta_observada_total"] - 1) < 0.05,
    f"{met['venta_predicha_total'] / met['venta_observada_total'] - 1:+.2%}")
chk("β con vida media plausible (2 a 60 min)", all(2 <= np.log(2) / np.exp(th[5 + f]) <= 60 for f in range(3)),
    [f"{np.log(2) / np.exp(th[5 + f]):.1f} min" for f in range(3)])
chk("β ordenados: clínica ≤ centro médico ≤ toma de muestras (la gente viaja más a una clínica)", np.exp(th[5]) <= np.exp(th[6]) <= np.exp(th[7]), "")
chk("Validación sede nueva: error absoluto mediano ≤ 25%", val["error_pct"].abs().median() <= 0.25, f"{val['error_pct'].abs().median():.1%}")
chk("Escenarios: P10 < P50 < P90 en las β", all(banda[0][5 + f] <= th[5 + f] <= banda[1][5 + f] for f in range(3)), "")
chk("Invariancia de escala: ventas × 0,000001 y × 1.000 dan los mismos parámetros (solo cambia κ)", max(dif_escala.values()) < 1e-3,
    f"diferencia máxima {max(dif_escala.values()):.1e}")
if cv:
    chk("Validación cruzada espacial: desvío explicado ≥ 50%", cv["desvio_explicado_cv"] >= 0.5, f"{cv['desvio_explicado_cv']:.1%}")
if cfg["modo"] == "simulacion":
    verdad = json.load(open(cfg["simulacion"]["verdad"], encoding="utf-8"))
    for f, nombre in enumerate(M.FORMATOS):
        b_true, b_est = verdad["beta"][nombre], np.exp(th[5 + f])
        chk(f"[simulación] β {nombre} recuperado (±25%)", abs(b_est / b_true - 1) <= 0.25, f"real {b_true:.3f} · estimado {b_est:.3f}")
    err_p = np.mean([abs(pg[g] - verdad["pesos_gse"][g]) for g in ("C1A", "C1B", "C2")])
    chk("[simulación] pesos GSE recuperados (error medio ≤ 0,15)", err_p <= 0.15, {g: f"real {verdad['pesos_gse'][g]} · est {pg[g]:.2f}" for g in ("C1A", "C1B", "C2")})
    chk("[simulación] efecto del tamaño γ recuperado (±0,3)", abs(th[-1] - verdad["gamma_capacidad"]) <= 0.3, f"real {verdad['gamma_capacidad']} · estimado {th[-1]:.2f}")
    chk("[simulación] peso de la demanda flotante λ recuperado (±30%)", abs(np.exp(th[1]) / verdad["lambda"] - 1) <= 0.3,
        f"real {verdad['lambda']} · estimado {np.exp(th[1]):.2f}")
chk.guardar(cfg)
chk.tabla()

# %%
guardar({"th": th, "thetas": thetas, "metodo_incertidumbre": metodo, "nivel": nivel, "d": d, "metricas": met, "sd_log_sede": sd_sede,
         "cv": {k: v for k, v in (cv or {}).items() if k not in ("y", "pred", "grupos")},
         "benchmark": None if bench is None else {"desvio_explicado_cv": bench["desvio_explicado_cv"]}}, cfg, "modelo.pkl")
guardar(par, cfg, "parametros.csv"); guardar(val, cfg, "validacion_sede_nueva.csv"); guardar(aj, cfg, "ajuste_sedes.csv")
guardar(ut, cfg, "unidades.parquet")
guardar(metricas.como_dict(ind_modelo), cfg, "metricas_modelo.json")
log("listo")
