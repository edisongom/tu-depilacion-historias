# %% [markdown]
# # 00 · Simulación de datos (solo para probar el flujo)
#
# **Para qué sirve este notebook:** todavía no tenemos la data de Clínica Alemana y las bases Equifax viven en el bucket
# de la empresa. Para poder probar TODO el estudio de punta a punta, este notebook crea bases **simuladas** con
# **exactamente los mismos nombres de archivo y de columnas** que las reales.
#
# | Base real (bucket Equifax) | Archivo simulado | Qué tiene |
# |---|---|---|
# | `SD06_SOCIODEMOGRAPHIC_BLOCK_2026.gpkg` | igual | manzanas con población, hogares, ingreso y gasto por GSE (153 columnas) |
# | `PI01_POI.gpkg` | igual | puntos de interés con CAT1/CAT2/CAT3 (28 columnas); los de salud repiten lugares del levantamiento con otro nombre y otras coordenadas, como en la base real |
# | `MKTS_BBRR_2026_01.txt` | igual | bienes raíces, separador `|` (23 columnas) |
# | `BC08_STREET.gpkg` | igual | maestro de calles con numeración (33 columnas) |
# | `personas_20260825_tramos_sociedades.parquet` | igual | personas (72 columnas) |
# | `BD_EMPRESAS_ACTIVAS_3007.txt` | igual | empresas, separador `|` (31 columnas) |
# | (data de la clínica) | `cliente/*.csv` | 5 años de ventas, sedes, **atenciones con RUT** en formatos mezclados (origen de pacientes), las mismas atenciones con RUT sin dígito verificador (prueba), origen por zona censal (alternativo), eventos y sitios propuestos |
#
# **Qué es real y qué es inventado**
# * **Real:** el grafo vial de la Región Metropolitana (OpenStreetMap), los límites comunales, las sedes de Clínica Alemana
#   y el universo de competencia que levantamos.
# * **Simulado:** todo lo demás. Los nombres de personas dicen "SIMULADO" y los RUT son inventados.
#
# **Truco clave para validar:** las ventas de la clínica se generan con el **mismo modelo** que usaremos después,
# con parámetros conocidos (guardados en `datos_simulados/verdad.json`) **más ruido realista**. Así, en el notebook 06
# podemos comprobar si el modelo "descubre" esos parámetros. Si los recupera, confiamos en que funciona.
#
# > ⚠️ **En el PC de trabajo NO hay que correr este notebook.** Basta con poner `MODO = "real"` en `config_estudio.py`.
#
# Tiempo aproximado: 6–10 minutos (la mayor parte es cargar el grafo de la RM y calcular tiempos de viaje).

# %%
# Configuración e importaciones (igual en todos los notebooks)
import os, sys, json
sys.path.insert(0, os.path.abspath("."))          # carpeta del proyecto, donde está config_estudio.py
import pandas as pd, geopandas as gpd
import config_estudio
from geoventas import insumos, simulacion, mapas, esquemas

cfg = config_estudio.obtener_config("simulacion")
insumos.exigir(cfg, "00")          # grafo vial real, maestro de sedes y universo de competencia
print("Las bases simuladas quedarán en:", os.path.dirname(cfg["rutas"]["censo"]))

# %% [markdown]
# ## 1. Crear las bases
# Si las bases ya existen, no se vuelven a crear (cambia `REHACER = True` para forzarlo).

# %%
REHACER = False
if REHACER or not os.path.exists(cfg["simulacion"]["verdad"]):
    verdad = simulacion.simular(cfg, os.path.join("insumos", "comunas_rm.gpkg"))
else:
    verdad = json.load(open(cfg["simulacion"]["verdad"], encoding="utf-8"))
    print("Bases simuladas ya existentes: se reutilizan.")

# %% [markdown]
# ## 2. ¿Quedaron con la misma estructura que las reales?
# Cada archivo debe tener **exactamente las mismas columnas, con los mismos nombres y en el mismo orden** que las bases
# reales del bucket (`geoventas/esquemas.py` tiene la lista de cada una, transcrita de las bases reales).

# %%
import pyarrow.parquet as pq
filas = []
for base, esperado in esquemas.ESQUEMAS.items():
    ruta = cfg["rutas"][base]
    if ruta.endswith(".parquet"):
        cols = list(pq.read_schema(ruta).names)
    elif ruta.endswith(".txt"):
        cols = list(pd.read_csv(ruta, sep="|", nrows=2).columns)
    else:
        cols = list(gpd.read_file(ruta, rows=2).columns)
    faltan, nuevas = esquemas.comparar(base, cols)
    filas.append({"base": base, "archivo": os.path.basename(ruta), "columnas reales": len(esperado), "columnas simuladas": len(cols),
                  "mismos nombres y orden": "✅" if cols == esperado else "❌", "faltan": ", ".join(faltan) or "—",
                  "sobran": ", ".join(nuevas) or "—", "tamaño MB": round(os.path.getsize(ruta) / 1e6, 1)})
estructura = pd.DataFrame(filas)
assert (estructura["mismos nombres y orden"] == "✅").all(), "Alguna base simulada no tiene la estructura real"
estructura

# %% [markdown]
# ## 3. Data simulada de la clínica
# Así luce la data de ventas que suponemos que enviará Clínica Alemana (formato de la hoja "Ventas" que le pedimos):
# una fila por sede, mes, línea de prestación y previsión, con atenciones, pacientes y monto en pesos.
# Trae **errores típicos a propósito** (un mes duplicado, un mes faltante, un pico por error de digitación y notas de crédito)
# para comprobar que el notebook 02 los detecta.

# %%
ventas = pd.read_csv(cfg["rutas"]["ventas_cliente"])
print(f"{len(ventas):,} filas · {ventas['id_sede'].nunique()} sedes · de {ventas['mes'].min()} a {ventas['mes'].max()}")
ventas.head(8)

# %%
# Atenciones con RUT, como las enviaría la clínica: una fila por atención. El RUT viene en formatos mezclados
# (con y sin puntos, con y sin guion), trae algunos dígitos verificadores malos, pacientes que no están en la base de
# personas y atenciones pagadas por empresas (convenios). El notebook 05 limpia y cruza todo eso.
# Por buena práctica, aquí el RUT se muestra **enmascarado** (aunque sea simulado): nunca se imprimen RUT en claro.
atenciones = pd.read_csv(cfg["rutas"]["origen_pacientes"], dtype={"rut_paciente": str})
print(f"{len(atenciones):,} atenciones · {atenciones['id_sede'].nunique()} sedes · {atenciones['fecha'].str[-4:].min()}–{atenciones['fecha'].str[-4:].max()}")
print("Previsión:", atenciones["prevision"].value_counts().to_dict())
vista = atenciones.head(8).copy()
vista["rut_paciente"] = vista["rut_paciente"].str.replace(r"[0-9kK]", "•", regex=True)   # se ve el formato, no el número
vista

# %%
# Formatos del RUT en el archivo de atenciones (sin mostrar ningún RUT): todos se llevan a la misma forma canónica.
from geoventas import rut
display(rut.formatos(atenciones["rut_paciente"]))
print("Detección del dígito verificador:", rut.detectar_dv(atenciones["rut_paciente"])["explicacion"])

# %% [markdown]
# ### POIs de salud de Equifax: duplicados conocidos
# En la base real, muchos lugares de salud están **a la vez** en el levantamiento propio y en los POIs de Equifax, con
# nombres que se parecen pero no son iguales y coordenadas algo distintas. La simulación reproduce eso a propósito (y
# guarda la verdad en `datos_simulados/verdad_pois_equifax.csv`) para medir, en el notebook 03, cuántos duplicados
# encuentra la unificación y si alguna vez une dos lugares distintos.

# %%
vp = pd.read_csv(os.path.join(os.path.dirname(cfg["rutas"]["censo"]), "verdad_pois_equifax.csv"))
tabla_vp = vp.groupby(["verdad", "variacion"]).size().rename("POIs").reset_index()
ejemplos = vp[vp["verdad"] == "duplicado del levantamiento"].groupby("variacion")["nombre_pi01"].first()
tabla_vp["ejemplo de nombre en PI01"] = tabla_vp["variacion"].map(ejemplos).fillna("")
tabla_vp

# %%
# Alternativa (si la clínica no puede enviar RUT): origen agregado por zona censal y año. Los grupos con < 5 pacientes
# vienen sumados a la comuna, y lo que no tiene domicilio va como "SIN INFORMACION".
origen_zona = pd.read_csv(cfg["rutas"]["origen_pacientes_por_zona"])
print(origen_zona["zona_domicilio"].map(lambda z: "zona censal (código)" if str(z).isdigit() else ("sin información" if "SIN" in str(z) else "comuna")).value_counts())
origen_zona.head()

# %% [markdown]
# ## 4. Mapa de lo simulado
# Población AB/C1a/C1b por manzana (muestra), líneas de metro simuladas y sedes de la clínica. **Cómo usar el mapa:**
# arriba a la derecha prendes y apagas capas y cambias el fondo; haz clic en un elemento para ver su ficha.

# %%
censo = gpd.read_file(cfg["rutas"]["censo"], columns=["ID_BLOCK", "COMUNA", "POB", "POB_AB", "POB_C1A", "POB_C1B", "PRED"])
censo["POB_OBJETIVO"] = censo[["POB_AB", "POB_C1A", "POB_C1B"]].sum(axis=1)
muestra = censo.sample(min(8000, len(censo)), random_state=1)
import zipfile, io
with zipfile.ZipFile(cfg["rutas"]["gtfs"]) as z:
    est = pd.read_csv(io.BytesIO(z.read("stops.txt")))
from geoventas import cliente
sedes = cliente.leer_maestro(cfg)
sedes = sedes[sedes["region"].str.contains("Metropolitana", na=False)]
muestra = muestra.rename(columns={"ID_BLOCK": "ut", "COMUNA": "comuna", "POB": "pob", "POB_OBJETIVO": "pob_objetivo"})
mapas.mapa([
    mapas.capa_manzanas(muestra, "Manzanas simuladas (muestra de 8 mil)", mapas.inds("pob_objetivo", "pob")),
    mapas.capa(mapas.puntos(est, "stop_lon", "stop_lat"), "Estaciones de metro simuladas", color="#e07b24", radio=4, popup=["stop_name"],
               etiquetas_popup={"stop_name": "Estación"}),
    mapas.capa(mapas.puntos(sedes), "Sedes de Clínica Alemana (ubicación real)", color=mapas.COLOR_SEDE, icono="sede",
               popup=["nombre", "formato"], etiquetas_popup={"nombre": "Sede", "formato": "Formato"}, titulo_popup="nombre",
               etiqueta="nombre", etiqueta_fija=True),
], titulo="Datos simulados para probar el estudio", subtitulo="Manzanas, metro y sedes: la población es inventada, las sedes y el grafo vial son reales",
   archivo=os.path.join(cfg["carpetas"]["salidas"], "mapas", "00_datos_simulados.html"))

# %% [markdown]
# ## 5. Parámetros "verdaderos" (los que el modelo debería recuperar en el notebook 06)

# %%
pd.DataFrame({"parámetro": ["β clínica", "β centro médico", "β toma de muestras", "peso GSE C1A", "peso GSE C1B", "peso GSE C2",
                            "rampa: % del régimen al abrir", "rampa: meses característicos"],
              "valor verdadero": [verdad["beta"]["clinica"], verdad["beta"]["centro_medico"], verdad["beta"]["toma_muestras"],
                                  verdad["pesos_gse"]["C1A"], verdad["pesos_gse"]["C1B"], verdad["pesos_gse"]["C2"], 0.35, 10]})
