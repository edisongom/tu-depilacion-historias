# %% [markdown]
# # 05 · Pacientes (RUT), zonas de influencia reales y diagnóstico espacial
# **Hito 1 del FRF · "comportamiento espacial de sus pacientes" · Hito 2 · "áreas de influencia"**
#
# **La idea:** la clínica envía sus atenciones con el **RUT del paciente**. Cruzando ese RUT con las bases de Equifax:
# * **personas (per)** → dónde vive cada paciente (su **manzana**) y quién es (GSE, edad, sexo, renta del hogar);
# * **empresas (emp)** → si el RUT es de una empresa (convenios), dónde está.
#
# Con eso se miden, **por sede y sin estimar**: las zonas de influencia reales, la penetración por manzana, el perfil y
# la **afinidad** de sus pacientes frente a la población de su área, los pacientes que usan **varias sedes**
# (canibalización observada), la **fidelidad** y la venta a **empresas**.
#
# **Privacidad (FRF 2.6, leyes 19.628 / 21.719):**
# * El RUT se transforma en un código irreversible (hash SHA-256 con una sal secreta) **en el momento de leerlo**: nunca se
#   guarda en claro. Si la clínica prefiere mandarlo ya seudonimizado, se usa la sal que acuerden (`GEOVENTAS_SAL_RUT`).
# * Todo lo que sale de este notebook es **agregado**, y los mapas solo muestran zonas con al menos 5 pacientes.
#
# | Entra | Sale (`trabajo/`) |
# |---|---|
# | atenciones con RUT (o, si no hay, origen por zona) · venta madura (02) · manzanas y personas/empresas ubicadas (03) · tiempos (04) | `flujos.parquet`, `unidades_calib.pkl`, `indicadores_sede.csv`, `areas_influencia.gpkg`, `afinidad.csv`, `multisede.csv`, `fidelidad.csv`, … |

# %%
import os, sys
sys.path.insert(0, os.path.abspath("."))
import numpy as np, pandas as pd
from IPython.display import display
import config_estudio
from geoventas import insumos, cliente, origen, pacientes, mapas, verificacion, metricas, conclusiones
from geoventas.utilidades import Cronometro, guardar, guardar_si_hay, cargar, existe, miles, mm, pct, carpeta_salida

cfg = config_estudio.obtener_config()
insumos.exigir(cfg, "05")          # revisa decisiones, archivos, columnas y resultados previos; si falta algo, se detiene y dice qué hacer
log = Cronometro()
chk = verificacion.Chequeos("05_origen")
MAPAS = carpeta_salida(cfg, "mapas")
O = cfg["origen"]
ut = cargar(cfg, "unidades.parquet"); censo = cargar(cfg, "censo.parquet")
sedes_estudio = cargar(cfg, "sedes_estudio.parquet")
sedes = sedes_estudio[sedes_estudio["en_modelo"]].reset_index(drop=True)
vm = cargar(cfg, "venta_madura.csv"); vm = vm[vm["sede"].isin(sedes["sede"])]
T = cargar(cfg, "T_sedes_auto_punta.npy")
mapa_codigo = dict(zip(sedes_estudio["sede_cliente"], sedes_estudio["sede"]))
print(f"Sedes en el modelo: {len(sedes)} · manzanas: {len(ut):,}")

# %% [markdown]
# ## 1. Leer el origen de los pacientes
# El lector reconoce solo si viene **RUT** (en claro o ya seudonimizado), **coordenadas** o **zona** (manzana / zona censal
# / comuna). El RUT puede venir escrito de cualquier forma: `0190270254`, `190270254`, `19027025-4`, `19.027.025-4`,
# `190270254.0` (Excel)… Todo se lleva a la **misma forma canónica** que personas y empresas (`190270254`), se valida
# su dígito verificador y se reemplaza por su hash. Si el archivo trae **solo el número, sin dígito verificador**, se
# detecta en la columna completa y el dígito se calcula; si la columna es ambigua, el notebook se detiene y pide
# `RUT_CON_DV = True` o `False` en `config_estudio.py`.

# %%
orig, tipo = cliente.leer_origen(cfg)
print("Tipo de origen detectado:", tipo.upper())
if tipo != "sin_origen":
    orig["sede"] = orig["sede_cliente"].map(mapa_codigo).fillna(orig["sede_cliente"])
    print("Columnas que quedaron:", list(orig.columns), "→ ninguna con el RUT en claro")
    chk("El RUT nunca queda en claro (solo su hash)", not any(c in orig.columns for c in ("rut", "rut_paciente", "RUT")), "")
if tipo == "rut" and orig.attrs.get("rut"):
    print("Formato del RUT de los pacientes:", orig.attrs["rut"]["explicacion"])
    if orig.attrs.get("rut_formatos"):
        display(pd.DataFrame(orig.attrs["rut_formatos"]))
    if orig["rut_valido"].notna().any():
        validos = orig["rut_valido"].astype(float).mean()
        chk("RUT de los pacientes con dígito verificador válido ≥ 95%", validos >= 0.95, f"{validos:.2%}")

# %% [markdown]
# ## 2. Cruce con personas y empresas
# Cada atención queda en uno de estos grupos:
# * **persona**: el RUT está en `per` → se ubica en la manzana de su domicilio;
# * **empresa**: el RUT es de una persona jurídica que está en `emp` (convenio) → se ubica en la dirección de la empresa;
# * **fuera del área**: está en las bases pero vive fuera del área de estudio;
# * **sin cruce**: no está en `per` ni en `emp` (extranjeros sin registro, RUT mal digitados…).

# %%
o, cruce = None, np.nan
if tipo == "rut":
    personas = cargar(cfg, "personas_ut.parquet"); empresas = cargar(cfg, "empresas_ut.parquet")
    o = pacientes.cruzar_ruts(orig, personas, empresas, cfg)
    resumen = pacientes.resumen_cruce(o)
    cruce = resumen.set_index("nivel").reindex(["persona", "empresa"])["% monto"].fillna(0).sum()
    invalidos = 1 - orig["rut_valido"].astype(float).mean() if orig["rut_valido"].notna().any() else np.nan
    print(f"Atenciones ubicadas (persona o empresa): {cruce:.1%} del monto · RUT con dígito verificador inválido: {invalidos:.2%}")
    if cruce < O["min_cruce_aceptable"]:
        print(f"⚠️  El cruce es bajo (< {O['min_cruce_aceptable']:.0%}). Revisar con la clínica el formato del RUT o la sal del hash.")
    display(resumen.assign(monto=resumen["monto"].map(mm), **{"% monto": resumen["% monto"].map(pct), "% pacientes": resumen["% pacientes"].map(pct)}))
    display(pacientes.cruce_por_sede(o).apply(lambda c: c.map(lambda v: pct(v, 0))))

# %% [markdown]
# ## 3. Flujos manzana × sede
# Solo las **personas** ubicadas forman la demanda residencial (las empresas se analizan aparte, sección 8). Los flujos
# se llevan a **venta mensual en régimen**: la distribución espacial viene de los RUT; el nivel, de la serie de 5 años.

# %%
if tipo == "rut":
    flujos = pacientes.flujos_rut(o)
elif tipo == "zona":
    mz = origen.tabla_manzanas(censo, ut, cfg)
    flujos, resumen = origen.flujos_desde_zonas(orig, mz, cfg)
elif tipo == "coordenadas":
    flujos, resumen = origen.flujos_desde_coordenadas(orig, ut, cfg)
else:
    flujos, resumen = None, pd.DataFrame()
    print("⚠️  Sin datos de origen: el modelo se calibrará con la venta total de cada sede.")
if flujos is not None:
    flujos = origen.escalar_flujos(flujos, vm, ut)
    log(f"flujos: {len(flujos):,} pares unidad-sede · {flujos['ut'].nunique():,} manzanas de origen")
nivel, share_fino = origen.elegir_nivel(resumen, cfg, tipo)
print(f"Nivel de calibración: {nivel.upper()}")

# %% [markdown]
# ## 4. Indicadores por sede
# * **t50 / t60 / t80**: minutos en auto (punta) dentro de los cuales vive la gente que genera el 50 / 60 / 80% de la venta.
# * **% de la venta por banda de minutos**.
# * **Penetración**: venta / gasto en salud de la población que vive a menos de t80.

# %%
if flujos is not None:
    ind = origen.indicadores_sede(flujos, T, ut, sedes, vm).merge(sedes[["sede", "nombre", "formato_modelo"]], on="sede")
    cols = ["sede", "nombre", "formato_modelo", "venta_mensual_madura", "t50_min", "t60_min", "t80_min", "unidades_origen", "penetracion_gasto_t80"] + \
           [c for c in ind.columns if c.startswith("% venta")]
    vista = ind[cols].copy()
    vista["venta_mensual_madura"] = vista["venta_mensual_madura"].map(mm)
    for c in [c for c in cols if c.startswith("% venta")] + ["penetracion_gasto_t80"]:
        vista[c] = vista[c].map(pct)
    display(vista.round(1))
else:
    ind = vm.merge(sedes[["sede", "nombre", "formato_modelo"]], on="sede")

# %% [markdown]
# ## 5. Zonas de influencia REALES
# Se ordenan las manzanas de origen por tiempo de viaje y se acumula la venta: la **primaria** son las más cercanas que
# juntan el 60% de la venta; la **secundaria**, las que siguen hasta el 80%. El polígono es el contorno de esas manzanas.
# Se compara con la isócrona teórica de 15 minutos: si la zona real es más chica, la sede capta menos de lo que su
# accesibilidad permitiría; si es más grande, atrae desde lejos (marca, especialidades).

# %%
areas = None
if flujos is not None:
    areas = origen.areas_influencia(flujos, T, ut, sedes, cfg)
    display(areas.drop(columns="geometry").assign(venta_mensual=lambda d: d["venta_mensual"].map(mm), pob=lambda d: d["pob"].map(miles)))
    iso = cargar(cfg, "isocronas_sedes.gpkg")
    iso15 = iso[(iso["modo"] == "auto_punta") & (iso["minutos"] == 15)]
    a_vis = areas.to_crs("EPSG:4326").copy()
    kmin = O["min_pacientes_publicacion"]
    # pacientes por manzana y sede, con anonimato: una manzana se muestra solo si tiene ≥ kmin pacientes de esa sede
    col_n = "pacientes" if "pacientes" in flujos else "venta_mensual"
    pm = flujos.pivot_table(index="ut", columns="sede", values=col_n, aggfunc="sum").reindex(columns=list(sedes["sede"])).fillna(0)
    total = pm.sum(axis=1)
    vis = ut[["ut", "comuna", "pob", "geometry"]].merge(pm.where(pm >= kmin), left_on="ut", right_index=True, how="inner")
    vis["pacientes_cas"] = total.reindex(vis["ut"]).where(lambda x: x >= kmin).values
    vis["sede_principal"] = pm.idxmax(axis=1).reindex(vis["ut"]).where(total.reindex(vis["ut"]).values >= kmin).values
    vis = vis[vis["pacientes_cas"].notna()]
    nombre_sede = dict(zip(sedes["sede"], mapas.nombre_sede(sedes)))
    orden_fmt = {"clinica": 0, "centro_medico": 1, "toma_muestras": 2}
    principal = nombre_sede[sedes.assign(_o=sedes["formato_modelo"].map(orden_fmt)).sort_values(["_o", "sede"])["sede"].iloc[0]]
    ind_sedes = [mapas.ind(s_, f"Pacientes de {nombre_sede[s_]}", "entero", paleta="azul", unidad="pacientes que viven en la manzana",
                           nulo=f"Menos de {kmin} pacientes (no se muestra)") for s_ in sedes["sede"]]
    colores_sede = mapas.colores_sedes(sedes["sede"])
    capas = [mapas.capa_manzanas(vis, "Pacientes por manzana",
                                 [mapas.ind("pacientes_cas", "Pacientes de Clínica Alemana (todas las sedes)", "entero", paleta="azul",
                                            unidad="pacientes que viven en la manzana",
                                            descripcion="Cuántos pacientes de la red viven en cada manzana (con su RUT, cruzado con su domicilio)."),
                                  mapas.ind("sede_principal", "Sede a la que más van los vecinos", "texto", categorias=colores_sede,
                                            nombres_categoria=nombre_sede,
                                            descripcion="Para cada manzana, la sede donde se atiende la mayoría de sus pacientes.")] + ind_sedes,
                                 ficha=mapas.inds("pob"), opacidad=0.85),
             mapas.capa(a_vis.assign(sede_txt=a_vis["sede"].map(nombre_sede).fillna(a_vis["sede"]),
                                     zona=np.where(a_vis["area"].str.startswith("primaria"), "Zona principal (60% de la venta)",
                                                   "Zona secundaria (hasta el 80% de la venta)")),
                        "Zonas reales de cada sede (según el domicilio de sus pacientes)", campo_categoria="zona",
                        colores_categoria={"Zona principal (60% de la venta)": "#0d3f7a", "Zona secundaria (hasta el 80% de la venta)": "#6aa6d6"},
                        opacidad=0.18, peso=1.4, popup=["sede_txt", "zona", "minutos_max", "unidades", "pob"], titulo_popup="sede_txt",
                        etiquetas_popup={"zona": "Zona", "minutos_max": "Hasta (minutos en auto)", "unidades": "Manzanas", "pob": "Personas que viven ahí"},
                        formato_popup={"minutos_max": "min", "unidades": "entero", "pob": "entero"},
                        filtro="sede_txt", etiqueta_filtro="Ver las zonas reales de la sede",
                        filtro_inicial=principal, visible=False),
             mapas.capa(iso15.assign(sede_txt=iso15["id"].map(nombre_sede)), "Zona teórica a 15 min en auto (para comparar)",
                        color="#ffffff", opacidad=0.0, borde="#5c6879", peso=1.6, popup=["sede_txt", "pob_objetivo"], titulo_popup="sede_txt",
                        etiquetas_popup={"pob_objetivo": "Público objetivo dentro"}, formato_popup={"pob_objetivo": "entero"},
                        filtro="sede_txt", etiqueta_filtro="Ver las zonas reales de la sede",
                        filtro_inicial=principal, visible=False),
             mapas.capa_sedes(sedes)]
    mapas.mapa(capas, titulo="¿De dónde vienen los pacientes de cada sede?",
               subtitulo="Con el RUT de cada atención, ubicado en el domicilio del paciente · elige la sede en el panel",
               ayuda=["Más oscuro = más pacientes viven en esa manzana.",
                      "En el panel puedes ver los pacientes de toda la red, de una sede, o a qué sede va cada barrio.",
                      "En las capas (arriba a la derecha) se prenden las ZONAS REALES de cada sede (las manzanas que suman el 60% y el 80% de su venta) "
                      "y, para comparar, la zona teórica a 15 minutos en auto."],
               archivo=os.path.join(MAPAS, "05_zonas_influencia_reales.html"),
               nota=f"Privacidad: solo se pintan manzanas con {kmin} o más pacientes.")

# %% [markdown]
# ### ¿Qué tan buenas eran las zonas preliminares (sin RUT)?
# Si se corrió el notebook 04b (zonas modeladas antes de recibir los datos de la clínica), aquí se comparan con las
# reales: qué parte de la venta real de cada sede cae dentro de su zona preliminar (primaria + secundaria, que por
# construcción reúne el 80% de la demanda modelada: **80% es el calce perfecto**) y el t80 real frente al modelado.

# %%
cmp_inf = None
if flujos is not None and existe(cfg, "influencia_preliminar_zonas.parquet") and existe(cfg, "influencia_preliminar_sedes.csv"):
    from geoventas import influencia as INF
    cmp_inf = INF.comparar_con_reales(cargar(cfg, "influencia_preliminar_zonas.parquet"), flujos, ind, cargar(cfg, "influencia_preliminar_sedes.csv"))
    nombre_c = dict(zip(sedes["sede"], sedes["nombre_visible"])) if "nombre_visible" in sedes else {}
    print(f"Venta real dentro de la zona preliminar (mediana de las sedes): {cmp_inf['venta_real_en_zona_modelada'].median():.0%} (calce perfecto: 80%) · "
          f"diferencia mediana de t80: {cmp_inf['diferencia_t80_min'].abs().median():.1f} min")
    display(cmp_inf.assign(sede=cmp_inf["sede"].map(nombre_c).fillna(cmp_inf["sede"]),
                           **{c: cmp_inf[c].map(lambda v: pct(v, 0)) for c in ("venta_real_en_zona_modelada", "venta_real_en_primaria_modelada")}).round(1))
else:
    print("No hay zonas preliminares (notebook 04b) o no hay origen por manzana: no se comparan.")

# %% [markdown]
# ## 6. Perfil de los pacientes y afinidad
# **Índice de afinidad** = (% de pacientes de la sede en una categoría) ÷ (% de la población del área de la sede en esa
# categoría) × 100. **100** = igual que la población; **200** = el doble; **50** = la mitad. El área es la de t80 de la sede.
# Con RUT esto es exacto (GSE, edad y sexo de cada paciente desde `per`); sin RUT solo hay un perfil aproximado.

# %%
afin = pd.DataFrame()
if o is not None:
    t80 = ind.set_index("sede")["t80_min"].to_dict()
    afin = pacientes.afinidad(o, ut, T, list(sedes["sede"]), t80, cfg)
    for dim in ("GSE", "edad", "sexo"):
        print(f"Índice de afinidad por {dim} (100 = igual que la población del área):")
        display(afin[afin["dimensión"] == dim].pivot_table(index="sede", columns="categoría", values="índice de afinidad").round(0))
elif flujos is not None:
    display(origen.perfil_ecologico(flujos, ut, cfg))

# %% [markdown]
# ## 7. Pacientes que usan varias sedes (canibalización observada) y fidelidad
# La tabla muestra, para los pacientes de cada sede (fila), qué % también se atiende en otra sede (columna). Es la
# sustitución **real** entre sedes: si una sede nueva queda cerca de una con mucho traslape, la canibalizará más.

# %%
multi = fid = conv = None
if o is not None:
    multi, uso = pacientes.multisede(o, list(sedes["sede"]))
    display(uso.assign(**{"% pacientes": uso["% pacientes"].map(pct)}))
    display(multi.apply(lambda c: c.map(lambda v: pct(v, 0))))
    fid = pacientes.fidelidad(o)
    display(fid.round(3))

# %% [markdown]
# ## 8. Empresas (convenios)

# %%
if o is not None:
    conv = pacientes.empresas_convenio(o)
    if len(conv):
        display(conv.assign(monto=conv["monto"].map(mm), **{"% de la venta con RUT": conv["% de la venta con RUT"].map(pct)}))
    else:
        print("Sin atenciones de empresas.")

# %% [markdown]
# ## 9. Origen–destino por comuna y penetración por manzana

# %%
if flujos is not None:
    od = origen.matriz_od_comunas(flujos, ut, sedes)
    display(od.head(15).apply(lambda col: col.map(lambda v: pct(v, 0))))

# %%
if o is not None:
    pen = pacientes.penetracion_por_unidad(o, ut)
    kmin = O["min_pacientes_publicacion"]
    pen = pen[pen["pacientes"] >= kmin]
    g = ut[["ut", "geometry", "pob_objetivo"]].merge(pen.drop(columns=["comuna"], errors="ignore"), on="ut")
    g["pacientes_por_1000_hab"] = (1000 * g["pacientes"] / g["pob"].replace(0, np.nan))
    g = g.merge(ut[["ut", "comuna"]], on="ut")
    print(f"Manzanas con ≥ {kmin} pacientes: {len(g):,} · concentran {g['pacientes'].sum() / max(pacientes.penetracion_por_unidad(o, ut)['pacientes'].sum(), 1):.0%} de los pacientes ubicados")
    mapas.mapa([mapas.capa_manzanas(g, "Penetración por manzana",
                                    [mapas.ind("pacientes_por_1000_hab", "Pacientes de Clínica Alemana por cada 1.000 vecinos", "decimal", paleta="azul",
                                               unidad="pacientes por cada 1.000 habitantes",
                                               descripcion="De cada 1.000 personas que viven en la manzana, cuántas se atienden en Clínica Alemana."),
                                     mapas.ind("pacientes", "Pacientes de Clínica Alemana", "entero", paleta="azul", unidad="pacientes")],
                                    ficha=mapas.inds("pob", "pob_objetivo")),
                mapas.capa_sedes(sedes)],
               titulo="¿Dónde tiene más pacientes Clínica Alemana?", subtitulo="Pacientes por cada 1.000 vecinos, manzana por manzana",
               nota=f"Privacidad: solo se pintan manzanas con {kmin} o más pacientes.",
               archivo=os.path.join(MAPAS, "05_penetracion.html"))

# %% [markdown]
# ## 10. ¿Y si la clínica manda el origen por ZONA en vez de RUT?
# El notebook también acepta origen agregado por manzana / zona censal / comuna. En la simulación existe ese archivo:
# lo procesamos y comparamos el t80 de cada sede con el obtenido por RUT (deberían parecerse).

# %%
ruta_zona = cfg["rutas"].get("origen_pacientes_por_zona")
if tipo == "rut" and ruta_zona and os.path.exists(ruta_zona):
    oz, tz = cliente.leer_origen(cfg, ruta_zona)
    oz["sede"] = oz["sede_cliente"].map(mapa_codigo).fillna(oz["sede_cliente"])
    fz, rz = origen.flujos_desde_zonas(oz, origen.tabla_manzanas(censo, ut, cfg), cfg)
    iz = origen.indicadores_sede(origen.escalar_flujos(fz, vm, ut), T, ut, sedes, vm)
    comp_t80 = ind[["sede", "t80_min"]].merge(iz[["sede", "t80_min"]], on="sede", suffixes=(" (RUT)", " (zona)"))
    display(comp_t80.round(1))
    dif = (comp_t80["t80_min (RUT)"] - comp_t80["t80_min (zona)"]).abs().median()
    chk("[simulación] t80 por zona censal ≈ t80 por RUT (diferencia mediana ≤ 3 min)", dif <= 3, f"{dif:.1f} min")

# %% [markdown]
# ## 11. Indicadores clave y conclusiones: mercado y pacientes
# Tamaño del mercado (población y gasto en salud del área), **qué parte de ese gasto equivale a la venta de la red**,
# cobertura y brechas, competencia y, con el origen de los pacientes: cruce del RUT, alcance de cada formato (t80),
# retención, uso de varias sedes, afinidad por GSE y comunas de origen. La cuota sobre el gasto sirve además como
# **control de unidades**: si la venta resultara mayor que el 60% del gasto en salud de toda el área (o menor que el
# 0,1%), los montos o el gasto del censo vienen en otra unidad.

# %%
pct_multi = (float(uso.loc[uso["sedes distintas usadas"] > 1, "% pacientes"].sum()) if multi is not None else None)
resumen_origen = {"tipo": tipo, "nivel": nivel, "cruce": None if not np.isfinite(cruce) else float(cruce),
                  "en_zona_preliminar": None if cmp_inf is None or not len(cmp_inf) else float(cmp_inf["venta_real_en_zona_modelada"].median()),
                  "pacientes": int(orig["rut_hash"].nunique()) if tipo == "rut" else None,
                  "atenciones": float(orig["atenciones"].sum()) if tipo == "rut" and "atenciones" in orig else None, "pct_multisede": pct_multi}
comp = cargar(cfg, "competencia.parquet")
ind_mercado = metricas.mercado(ut, vm, comp)
ind_pacientes = metricas.pacientes(resumen_origen, ind if flujos is not None else None, fid, afin, od if flujos is not None else None,
                                   metricas.nombres_sedes(sedes_estudio))
conclusiones.mostrar(conclusiones.generar(ind_mercado + ind_pacientes, ["Mercado", "Pacientes"]), "Conclusiones sobre el mercado y los pacientes")
metricas.tabla(ind_mercado + ind_pacientes)[["tema", "indicador", "valor", "lectura"]]

# %% [markdown]
# ## 12. Unidades de calibración del modelo
# * **rut / coordenadas** → nivel **unidad**: cada manzana es una observación del modelo.
# * **zona** → nivel **zona**: cada zona reportada es una observación (suma de sus manzanas) y lo que la clínica sumó a la
#   comuna forma un "resto de comuna" por sede (ajuste exacto, sin repartir).
# * **sin origen** → nivel **total** (venta total de cada sede).

# %%
if nivel == "zona":
    U = origen.unidades_desde_zonas(orig, origen.tabla_manzanas(censo, ut, cfg), ut, sedes, vm)
else:
    U = origen.unidades_calibracion(nivel, ut, sedes, flujos, vm)
print(f"Observaciones: {U['S'].shape[0]:,} · sedes con origen: {len(U['sedes_con_origen'])} de {len(U['sedes'])} · pares en el ajuste: {U['mask'].sum():,}")

# %%
if tipo == "rut":
    chk(f"Cruce de RUT con per/emp ≥ {O['min_cruce_aceptable']:.0%} del monto", cruce >= O["min_cruce_aceptable"], f"{cruce:.1%}")
cuota = next((m.valor for m in ind_mercado if m.clave == "cuota_gasto_salud"), None)
if cuota is not None:
    chk("Venta de la red entre 0,1% y 60% del gasto en salud del área (unidades de montos y gasto coherentes)", 0.001 <= cuota <= 0.6, pct(cuota))
chk("Unidades de calibración: la venta observada suma la venta madura de cada sede (±2%)",
    np.allclose((U["S"] * U["mask"]).sum(0), vm.set_index("sede").loc[U["sedes"], "venta_mensual_madura"].values, rtol=0.02),
    f"{(U['S'] * U['mask']).sum() / vm['venta_mensual_madura'].sum():.3f}")
if flujos is not None:
    chk("t80 menor que el horizonte en todas las sedes", (ind["t80_min"] < cfg["red"]["horizonte_min"]).all(), ind["t80_min"].round(1).tolist())
    chk("Toma de muestras más local que clínicas (t80 mediano menor)", ind.loc[ind["formato_modelo"] == "toma_muestras", "t80_min"].median() <
        ind.loc[ind["formato_modelo"] == "clinica", "t80_min"].median(), "")
if multi is not None:
    chk("Pacientes multisede detectados", (uso["sedes distintas usadas"] > 1).any(), f"{uso.loc[uso['sedes distintas usadas'] > 1, '% pacientes'].sum():.1%} usa 2+ sedes")
chk.guardar(cfg)
# Los resultados opcionales que esta corrida no produce se BORRAN (no queda ninguno de una corrida anterior)
hay = flujos is not None
guardar_si_hay(flujos, cfg, "flujos.parquet"); guardar_si_hay(ind if hay else None, cfg, "indicadores_sede.csv")
guardar_si_hay(areas, cfg, "areas_influencia.gpkg"); guardar_si_hay(od.reset_index() if hay else None, cfg, "od_comunas.csv")
for nombre, t in (("afinidad.csv", afin), ("fidelidad.csv", fid), ("convenios_empresas.csv", conv)):
    guardar_si_hay(t, cfg, nombre)
guardar_si_hay(None if multi is None else multi.reset_index().rename(columns={"index": "sede"}), cfg, "multisede.csv")
guardar_si_hay(cmp_inf, cfg, "comparacion_influencia_preliminar.csv")
guardar(U, cfg, "unidades_calib.pkl")
guardar(metricas.como_dict(ind_mercado + ind_pacientes), cfg, "metricas_pacientes.json")
log("listo")
chk.tabla()
