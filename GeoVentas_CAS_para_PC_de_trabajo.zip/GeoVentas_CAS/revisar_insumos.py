# -*- coding: utf-8 -*-
"""Revisión completa del estudio: decisiones, archivos, columnas, parámetros y avance de cada notebook.

Uso (desde esta carpeta):   python revisar_insumos.py              revisa el modo de config_estudio.py
                            python revisar_insumos.py real         revisa el modo real (útil antes de cambiar MODO)
                            python revisar_insumos.py real --descargar
                                    baja a cache_gcs/ los archivos gs:// para revisar también las columnas de los .gpkg
No modifica nada (salvo la descarga opcional a la caché). Termina con código 1 si falta algo obligatorio.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config_estudio                     # noqa: E402
from geoventas import insumos             # noqa: E402

if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    cfg = config_estudio.obtener_config(args[0] if args else None)
    items = insumos.revisar(cfg, descargar="--descargar" in sys.argv)
    print(insumos.como_texto(items, f"Revisión completa del estudio · modo {cfg['modo']}", detiene=False))
    sys.exit(1 if any(i.estado == insumos.FALTA for i in items) else 0)
