# -*- coding: utf-8 -*-
"""Mapas interactivos (Leaflet) que se ven DENTRO del notebook y además se guardan como .html autocontenidos,
pensados para que los entienda cualquier persona (sin saber de estadística ni de mapas) y para presentar al cliente.

Dos tipos de capa:

* `capa_manzanas(...)`: los POLÍGONOS de las manzanas del censo (decenas de miles), con un SELECTOR DE INDICADOR.
    - La geometría se guarda cuantizada (~1 m), en diferencias y comprimida (gzip) dentro del HTML: mapas livianos.
    - Se dibuja en un canvas propio, por nivel de color (fluido aunque sean 50 mil manzanas).
    - La leyenda habla en lenguaje simple: 5 niveles con nombre ("Muy alto", "Alto"… o "Muy cerca"… "Muy lejos"),
      rangos redondeados, unidades claras y cuántas manzanas hay en cada nivel.
    - Al pasar el mouse se ve la comuna y el valor; al hacer clic, la ficha de la manzana.

* `capa(...)`: capas chicas (sedes, competidores, isócronas, áreas, macrozonas, Top 20): con ícono de sede, número de
  orden, rombo, punto o polígono; etiquetas con el nombre real y fichas con valores en pesos, minutos o personas.

Todos los mapas traen: título y subtítulo, botón "¿Cómo leer este mapa?", nombres de calles y comunas sobre las
manzanas, buscador de comuna, transparencia, vista inicial, fuente de los datos y aviso cuando los datos son simulados.
"""
import base64
import gzip
import html
import json
import os

import numpy as np
import pandas as pd
import geopandas as gpd
import shapely

# ---------------------------------------------------------------------------------------------- PALETAS (5 niveles)
PALETA_SEC = ["#fdf2e3", "#fcc98a", "#f78e4f", "#de4b2b", "#a3121a"]          # naranjo → rojo (demanda)
PALETA_AZUL = ["#eaf2fb", "#b5d2ec", "#6aa6d6", "#2f74b5", "#0d3f7a"]         # azules (acceso, modelo, pacientes)
PALETA_VERDE = ["#ecf7e9", "#b8e1ae", "#72bf6a", "#2f9147", "#0c5e2a"]
PALETA_MORADO = ["#f3f0f8", "#cfc8e4", "#9f93c8", "#7057a8", "#46207f"]
PALETA_DIV = ["#b2182b", "#ef8a62", "#f7f7f7", "#67a9cf", "#2166ac"]
PALETAS = {"secuencial": PALETA_SEC, "azul": PALETA_AZUL, "verde": PALETA_VERDE, "morado": PALETA_MORADO, "divergente": PALETA_DIV}
COLORES_CAT = ["#1f5fa8", "#c0392b", "#2e8b57", "#7b3fa0", "#e07b24", "#c9a227", "#5aa0d8", "#8c8c8c", "#17375e", "#9e480e",
               "#4d4d4d", "#997300", "#43682b", "#698ed0", "#f1975a"]
COLOR_FORMATO = {"clinica": "#6a3d9a", "centro_medico": "#1f78b4", "toma_muestras": "#2e9e44"}
NOMBRE_FORMATO = {"clinica": "Clínica", "centro_medico": "Centro médico", "toma_muestras": "Toma de muestras"}
COLOR_SEDE = "#0e2a47"                                   # ícono de las sedes actuales
# para pintar "qué sede atiende cada barrio": colores que NO se confunden con los de formato (morado, azul, verde)
COLORES_SEDE = ["#e07b24", "#0f9d9a", "#c0392b", "#c9a227", "#8c564b", "#d6609c", "#5f6b7a", "#8a9a2b", "#f08a5d", "#3fb8d8", "#17375e",
                "#b07aa1", "#9c755f", "#76b7b2", "#ff9da7"]


def colores_sedes(codigos):
    """{código de sede: color} con la paleta de sedes (distinta de la de formatos)."""
    return {c: COLORES_SEDE[i % len(COLORES_SEDE)] for i, c in enumerate(codigos)}
FORMATOS_VALOR = ("entero", "decimal", "pct", "pct100", "mm", "clp", "min", "km2", "puntaje", "texto")
ESCALA = 1e5                                             # coordenadas cuantizadas a 1e-5 grados (≈ 1 m)
NIVELES = ["Muy bajo", "Bajo", "Medio", "Alto", "Muy alto"]
NIVELES_DISTANCIA = ["Muy cerca", "Cerca", "Distancia media", "Lejos", "Muy lejos"]
ANTETITULO = "Estudio de demanda y localización · Clínica Alemana de Santiago"
FUENTE = "Fuentes: Censo 2026 y bases Equifax · red vial OpenStreetMap · competencia: levantamiento propio · datos de la clínica"
AYUDA_BASE = [
    "Cada figura pintada es una <b>manzana</b> del censo.",
    "El color va de <b>claro (poco)</b> a <b>oscuro (mucho)</b>. La leyenda (abajo a la derecha) dice qué significa cada color y cuántas manzanas hay en cada nivel.",
    "En el panel de la izquierda eliges <b>qué mostrar</b>, saltas a una <b>comuna</b> y ajustas la transparencia.",
    "Pasa el mouse sobre una manzana para ver su valor; haz <b>clic</b> para ver su ficha completa.",
    "Arriba a la derecha prendes o apagas capas (sedes, competencia, zonas de viaje) y cambias el fondo (mapa o satélite).",
]
COLORES_GSE = {"AB": "#3f007d", "C1A": "#6a51a3", "C1B": "#9e9ac8", "C2": "#4292c6", "C3": "#9ecae1", "D": "#fdae6b", "E": "#e6550d",
               "s/i": "#d9d9d9"}
NOMBRES_GSE = {"AB": "AB · alto", "C1A": "C1a · medio-alto", "C1B": "C1b · medio-alto", "C2": "C2 · medio", "C3": "C3 · medio-bajo",
               "D": "D · bajo", "E": "E · muy bajo", "s/i": "sin información"}


# --------------------------------------------------------------------------------------------- DEFINICIÓN DE CAPAS
def ind(col, etiqueta, fmt="entero", paleta="secuencial", invertir=False, clases=5, descripcion="", categorias=None,
        centro=None, cero_aparte=None, nulo="sin dato", unidad="", niveles=None, nombres_categoria=None, nombre_cero=None):
    """Indicador de una capa de manzanas (lo que se puede elegir en el panel).
    etiqueta     nombre en lenguaje simple ("Personas de nivel socioeconómico alto")
    fmt          entero | decimal | pct (fracción 0–1) | pct100 (ya en %) | mm (pesos → "$X millones") | clp | min | km2 |
                 puntaje (0–1 → 0 a 100) | texto (categorías)
    unidad       cómo se lee el número en la leyenda ("personas por manzana", "minutos en auto")
    paleta       secuencial | azul | verde | morado | divergente (con `centro`)
    invertir     True = el color más intenso para los valores BAJOS (p. ej. minutos: cerca = mejor)
    niveles      5 nombres de menor a mayor valor (por defecto Muy bajo … Muy alto; con invertir: Muy cerca … Muy lejos)
    categorias   {valor: color} para fmt="texto" (también fija el ORDEN de la leyenda)
    nombres_categoria  {valor: texto visible} (p. ej. código de sede -> nombre real)
    cero_aparte  None = automático (si > 20% de las manzanas vale 0, el 0 es un nivel propio "Ninguno")
    nulo         cómo se llama el valor vacío (p. ej. "más de 60 min")"""
    if fmt not in FORMATOS_VALOR:
        raise ValueError(f"formato '{fmt}' no reconocido: usa uno de {FORMATOS_VALOR}")
    niveles = niveles or (NIVELES_DISTANCIA if (fmt == "min") else NIVELES)
    return dict(col=col, etiqueta=etiqueta, fmt=fmt, paleta=paleta, invertir=invertir, clases=clases, descripcion=descripcion,
                categorias=categorias, centro=centro, cero_aparte=cero_aparte, nulo=nulo, unidad=unidad, niveles=list(niveles),
                nombres_categoria=nombres_categoria or {}, nombre_cero=nombre_cero)


def _catalogo():
    """Indicadores estándar por manzana: mismo nombre, unidad y colores en todos los mapas del estudio."""
    return {
        "pob": ind("pob", "Personas que viven en la manzana", "entero", unidad="personas por manzana",
                   descripcion="Total de habitantes de la manzana según el censo."),
        "pob_objetivo": ind("pob_objetivo", "Personas de nivel socioeconómico alto (AB, C1a y C1b)", "entero", unidad="personas por manzana",
                            descripcion="Cuántas personas del público objetivo de Clínica Alemana viven en cada manzana."),
        "pct_objetivo": ind("pct_objetivo", "% de vecinos de nivel socioeconómico alto", "pct", paleta="morado", unidad="% de los habitantes",
                            descripcion="Qué parte de los habitantes de la manzana es AB, C1a o C1b."),
        "hog": ind("hog", "Hogares", "entero", unidad="hogares"),
        "hog_objetivo": ind("hog_objetivo", "Hogares de nivel socioeconómico alto", "entero", unidad="hogares"),
        "densidad_hab_km2": ind("densidad_hab_km2", "Densidad (personas por km²)", "entero", paleta="morado", unidad="personas por km²",
                                descripcion="Qué tan poblada está la manzana para su tamaño."),
        "gasto_salud_total": ind("gasto_salud_total", "Gasto en salud de todos los hogares", "mm", unidad="pesos al mes",
                                 descripcion="Lo que gastan en salud, al mes, todos los hogares de la manzana (censo)."),
        "gasto_salud_objetivo": ind("gasto_salud_objetivo", "Gasto en salud del público objetivo", "mm", unidad="pesos al mes",
                                    descripcion="Lo que gastan en salud, al mes, los hogares AB, C1a y C1b de la manzana."),
        "trabajadores_est": ind("trabajadores_est", "Personas que trabajan en la manzana", "entero", paleta="verde",
                                unidad="trabajadores", nombre_cero="Nadie trabaja ahí",
                                descripcion="Demanda de día: trabajadores de las empresas ubicadas en la manzana."),
        "gse_predominante": ind("gse_predominante", "Nivel socioeconómico más común", "texto", categorias=COLORES_GSE,
                                nombres_categoria=NOMBRES_GSE, descripcion="El grupo socioeconómico con más personas en la manzana."),
        "per_renta_hogar_mediana": ind("per_renta_hogar_mediana", "Ingreso típico del hogar", "clp", paleta="morado", unidad="pesos al mes"),
        "per_n": ind("per_n", "Personas en la base Equifax", "entero"),
        "uso_suelo": ind("uso_suelo", "Uso de suelo (censo)", "texto"),
        "area_km2": ind("area_km2", "Superficie", "km2"),
        "comuna": ind("comuna", "Comuna", "texto"),
        "min_a_cas": ind("min_a_cas", "Minutos en auto a la Clínica Alemana más cercana", "min", paleta="azul", invertir=True,
                         unidad="minutos en auto, hora punta", nulo="Más de 60 min",
                         descripcion="Tiempo de viaje por las calles, en hora punta, hasta la sede de Clínica Alemana más cercana."),
        "min_a_cm_o_clinica": ind("min_a_cm_o_clinica", "Minutos en auto al centro médico o clínica más cercano", "min", paleta="azul",
                                  invertir=True, unidad="minutos en auto, hora punta", nulo="Más de 60 min",
                                  descripcion="Igual que el anterior, sin contar las tomas de muestras."),
        "pob_objetivo_entorno": ind("pob_objetivo_entorno", "Público objetivo en el barrio (a 600 m)", "entero", unidad="personas a menos de 600 m",
                                    descripcion="Personas AB, C1a y C1b que viven a menos de 600 m de la manzana."),
        "brecha_txt": ind("brecha_txt", "¿Está bien cubierta por Clínica Alemana?", "texto",
                          categorias={"Brecha: alta demanda a más de 15 min": "#c0392b",
                                      "Alta demanda cubierta (≤ 15 min)": "#5aa0d8", "Resto": "#e3e3e3"},
                          nombres_categoria={"Brecha: alta demanda a más de 15 min": "Mucha demanda y LEJOS (más de 15 min): oportunidad",
                                             "Alta demanda cubierta (≤ 15 min)": "Mucha demanda y cerca (15 min o menos)",
                                             "Resto": "Demanda menor"},
                          descripcion="En rojo, barrios con mucho público objetivo que quedan a más de 15 minutos en auto de un "
                                      "centro médico o clínica de Clínica Alemana: ahí hay espacio para crecer."),
        "comp_entorno_peso": ind("comp_entorno_peso", "Competencia cercana (a menos de 1 km)", "decimal", paleta="morado",
                                 unidad="competidores ponderados", nombre_cero="Sin competencia cerca",
                                 descripcion="Clínicas, centros médicos y laboratorios a menos de 1 km. Los premium pesan más que los masivos."),
        "venta_cas_modelo": ind("venta_cas_modelo", "Venta estimada de Clínica Alemana desde la manzana", "mm", paleta="azul",
                                unidad="pesos al mes", descripcion="Lo que, según el modelo, gastan en Clínica Alemana las personas de la manzana."),
        "participacion_modelo_%": ind("participacion_modelo_%", "Parte del gasto en salud que va a Clínica Alemana", "pct100", paleta="azul",
                                      unidad="% del gasto en salud (estimado)",
                                      descripcion="De cada $100 que la manzana gasta en salud, cuántos van a Clínica Alemana según el modelo."),
        "demanda_potencial": ind("demanda_potencial", "Mercado potencial de la manzana", "mm", unidad="pesos al mes",
                                 descripcion="Gasto en salud ponderado por la afinidad de cada grupo socioeconómico con Clínica Alemana."),
    }


def inds(*cols, **cambios):
    """Indicadores del catálogo estándar por nombre de columna (los que no están en el catálogo se ignoran).
    `cambios` permite ajustar uno: inds("pob", "min_a_cas", min_a_cas={"etiqueta": "…"})."""
    cat = _catalogo()
    out = []
    for c in cols:
        if c in cat:
            d = dict(cat[c])
            d.update(cambios.get(c, {}))
            out.append(d)
    return out


def capa_manzanas(gdf, nombre, indicadores, id_col="ut", etiqueta_id="Manzana", ficha=None, visible=True, opacidad=0.8,
                  simplificar_m=1.5, inicial=0, descripcion=None, en_leyenda=True):
    """Capa de POLÍGONOS DE MANZANA con selector de indicador.
    indicadores  lista de `ind(...)`: los que se pueden pintar (el primero, o `inicial`, se muestra al abrir)
    ficha        lista de `ind(...)` adicionales que solo aparecen en la ficha al hacer clic
    simplificar_m  tolerancia de simplificación para la vista web (1,5 m: invisible; el GPKG conserva el original)"""
    return dict(tipo="manzanas", gdf=gdf, nombre=nombre, indicadores=list(indicadores), id_col=id_col, etiqueta_id=etiqueta_id,
                ficha=list(ficha or []), visible=visible, opacidad=opacidad, simplificar_m=simplificar_m, inicial=inicial,
                descripcion=descripcion, en_leyenda=en_leyenda)


def capa(gdf, nombre, color=None, campo_color=None, campo_categoria=None, colores_categoria=None, popup=None, etiqueta=None,
         radio=5, opacidad=0.55, borde=None, peso=1, visible=True, paleta="secuencial", invertir=False, formato_popup=None,
         simplificar_m=None, decimales=None, etiquetas_popup=None, icono=None, campo_numero=None, etiqueta_fija=False,
         ficha_html=None, nombres_categoria=None, titulo_popup=None, filtro=None, etiqueta_filtro="Ver", filtro_inicial=None):
    """Capa chica en GeoJSON (puntos o pocos polígonos).
    color / campo_color / campo_categoria   color fijo, por valor (cuantiles) o por categoría (colores_categoria fija el orden)
    icono        None (punto) | "sede" (cruz blanca en círculo) | "numero" (círculo con el número de `campo_numero`) |
                 "rombo" (rombo con el texto de `campo_numero`)
    etiqueta     columna que aparece al pasar el mouse; etiqueta_fija=True la deja escrita al acercarse (zoom ≥ 12)
    popup        columnas de la ficha (etiquetas_popup = {columna: texto}, formato_popup = {columna: fmt de `ind`})
    ficha_html   columna con la ficha ya armada en HTML (reemplaza a popup)
    titulo_popup columna que va como título de la ficha
    filtro       columna para filtrar desde el panel (p. ej. el nombre de la sede): se muestra un selector "etiqueta_filtro"
                 con sus valores; filtro_inicial = valor que se ve al abrir (None = todos)"""
    return dict(tipo="geojson", gdf=gdf, nombre=nombre, color=color, campo_color=campo_color, campo_categoria=campo_categoria,
                colores_categoria=colores_categoria, popup=popup or [], etiqueta=etiqueta, radio=radio, opacidad=opacidad,
                borde=borde, peso=peso, visible=visible, paleta=paleta, invertir=invertir, simplificar_m=simplificar_m,
                decimales=decimales, etiquetas_popup=etiquetas_popup or {}, formato_popup=formato_popup or {}, icono=icono,
                campo_numero=campo_numero, etiqueta_fija=etiqueta_fija, ficha_html=ficha_html,
                nombres_categoria=nombres_categoria or {}, titulo_popup=titulo_popup, filtro=filtro, etiqueta_filtro=etiqueta_filtro,
                filtro_inicial=filtro_inicial)


def nombre_sede(sedes):
    """Serie con el nombre real de cada sede (columna nombre_visible del notebook 02; si no está, nombre o código)."""
    for c in ("nombre_visible", "nombre"):
        if c in sedes:
            return sedes[c].astype(str)
    return sedes["sede"].astype(str)


def capa_sedes(sedes, nombre="Sedes de Clínica Alemana", visible=True, por_formato=True, filas_extra=None):
    """Las sedes actuales con su NOMBRE REAL: ícono de cruz (color por formato), nombre escrito al acercarse y ficha con
    formato y dirección. filas_extra = {etiqueta: función(fila) -> texto} para agregar datos a la ficha."""
    s = sedes.copy()
    s["_nombre"] = nombre_sede(s).values
    s["_formato"] = s["formato_modelo"].map(NOMBRE_FORMATO).fillna("Sede") if "formato_modelo" in s else "Sede"
    fichas = []
    for _, r in s.iterrows():
        filas = [("Formato", r["_formato"])]
        if "direccion" in s and pd.notna(r.get("direccion")):
            filas.append(("Dirección", r["direccion"]))
        for et, fn in (filas_extra or {}).items():
            filas.append((et, fn(r)))
        fichas.append(ficha(r["_nombre"], filas, subtitulo="Sede actual de Clínica Alemana",
                            color=COLOR_FORMATO.get(r.get("formato_modelo"), COLOR_SEDE)))
    s["_ficha"] = fichas
    colores = {NOMBRE_FORMATO[k]: c for k, c in COLOR_FORMATO.items()} if por_formato else None
    return capa(s, nombre, color=COLOR_SEDE, campo_categoria="_formato" if por_formato else None, colores_categoria=colores,
                icono="sede", ficha_html="_ficha", etiqueta="_nombre", etiqueta_fija=True, visible=visible)


NOMBRE_CORTO_FORMATO = {"Clínica de Alta Complejidad": "Clínica", "Centro Médico Ambulatorio": "Centro médico",
                        "Toma de Muestras / Laboratorio": "Toma de muestras", "Ninguno viable": "Ningún formato llega al mínimo de venta"}
COLOR_FORMATO_FRF = {"Clínica de Alta Complejidad": COLOR_FORMATO["clinica"], "Centro Médico Ambulatorio": COLOR_FORMATO["centro_medico"],
                     "Toma de Muestras / Laboratorio": COLOR_FORMATO["toma_muestras"]}
NOMBRE_TOP = "Las 20 ubicaciones recomendadas (número = orden de apertura)"
NOMBRE_MACRO = "Macrozonas para una clínica nueva"
NOMBRE_PROPUESTOS = "Sitios propuestos por la clínica"


def capa_top(top, nombre=NOMBRE_TOP):
    """Las ubicaciones recomendadas: círculo con su número de orden (color = formato) y ficha en lenguaje simple."""
    tg = gpd.GeoDataFrame(top.copy(), geometry=gpd.points_from_xy(top["lon"], top["lat"]), crs="EPSG:4326")
    tg["numero"] = tg["orden"].astype(int)
    corto = tg["formato_FRF"].map(NOMBRE_CORTO_FORMATO).fillna(tg["formato_FRF"])
    tg["etiqueta"] = "#" + tg["numero"].astype(str) + " · " + corto + " · " + tg["comuna"].astype(str).str.title()
    tg["ficha"] = [ficha(f"#{int(r['orden'])} · {NOMBRE_CORTO_FORMATO.get(r['formato_FRF'], r['formato_FRF'])} en {str(r['comuna']).title()}", [
        ("Venta nueva para la red (escenario base)", pesos(r["venta_neta"]) + " al mes"),
        ("Rango posible (conservador – optimista)",
         f"{pesos(r.get('venta_neta_p10_marginal', np.nan))} – {pesos(r.get('venta_neta_p90_marginal', np.nan))}"),
        ("Lo que vendería la sede", pesos(r["venta_bruta"]) + " al mes"),
        ("Lo que les quita a las sedes actuales", pesos(r["canibalizacion"]) + " al mes"),
        ("Sedes que más pierden", r.get("sedes_mas_canibalizadas", "")),
        ("Vía de acceso", r.get("via_referencia", "")), ("Manzana", r.get("ut", "")),
        ("Puntaje (0 a 100)", f"{100 * r['score']:.0f}" if pd.notna(r.get("score")) else "")],
        subtitulo=f"Orden de apertura sugerido: {int(r['orden'])} de {len(tg)}", color=COLOR_FORMATO_FRF.get(r["formato_FRF"]))
        for _, r in tg.iterrows()]
    return capa(tg, nombre, campo_categoria="formato_FRF", colores_categoria=COLOR_FORMATO_FRF, nombres_categoria=NOMBRE_CORTO_FORMATO,
                icono="numero", campo_numero="numero", ficha_html="ficha", etiqueta="etiqueta")


def capa_macrozonas(macro, nombre=NOMBRE_MACRO, visible=True):
    """Macrozonas para una clínica nueva, con ficha en lenguaje simple."""
    mz = macro.to_crs("EPSG:4326").copy()
    mz["ficha"] = [ficha(f"Macrozona {r['macrozona']} para una clínica", [
        ("¿Entra en el plan?", "Sí" if r["en_plan"] else "No: es una alternativa"), ("Comunas", r.get("comunas", "")),
        ("Sitios equivalentes dentro", f"{int(r.get('sitios_equivalentes', 0)):,}".replace(",", ".")),
        ("Venta nueva del sitio de referencia", pesos(r.get("venta_neta_referencia", np.nan)) + " al mes"),
        ("Frente al mínimo exigido", f"{100 * r['brecha_vs_umbral']:+.0f}%" if pd.notna(r.get("brecha_vs_umbral")) else "—")],
        subtitulo="Zona amplia donde cualquier terreno logra al menos el 80% de la venta del mejor sitio", color=COLOR_FORMATO["clinica"])
        for _, r in mz.iterrows()]
    return capa(mz, nombre, color=COLOR_FORMATO["clinica"], opacidad=0.16, borde=COLOR_FORMATO["clinica"], peso=2.2, ficha_html="ficha",
                etiqueta="macrozona", visible=visible)


def capa_propuestos(pv, nombre=NOMBRE_PROPUESTOS):
    """Sitios propuestos por la clínica: rombo negro con su código (P1, P2…) y ficha con el formato que más conviene."""
    pv = pv.copy()
    pv["numero"] = pv["id_sitio"].astype(str)
    nombres_fmt = {"clinica": "Clínica", "centro_medico": "Centro médico", "toma_muestras": "Toma de muestras"}
    pv["ficha"] = [ficha(f"{r['id_sitio']} · {r.get('nombre', '')}", [
        ("Dirección", r.get("direccion", "")), ("Formato que más conviene", nombres_fmt.get(r["formato_recomendado"], r["formato_recomendado"])),
        ("Venta nueva para la red", pesos(r["venta_neta"]) + " al mes"),
        ("¿Supera el mínimo de venta?", "Sí" if bool(r["viable"]) else "No")], subtitulo="Sitio propuesto por la clínica", color="#111111")
        for _, r in pv.iterrows()]
    return capa(gpd.GeoDataFrame(pv, geometry=gpd.points_from_xy(pv["lon"], pv["lat"]), crs="EPSG:4326"), nombre,
                color="#111111", icono="rombo", campo_numero="numero", ficha_html="ficha", etiqueta="nombre")


def fila_ficha(etiqueta, valor):
    """Una fila de ficha HTML (para armar `ficha_html` en los notebooks)."""
    return f"<tr><td>{html.escape(str(etiqueta))}</td><td><b>{html.escape(str(valor))}</b></td></tr>"


def ficha(titulo, filas, subtitulo=None, color=None, nota=None):
    """Ficha HTML de tarjeta: título (con franja de color), subtítulo, filas (etiqueta, valor) y nota al pie."""
    franja = f"<div class='f-franja' style='background:{color}'></div>" if color else ""
    sub = f"<div class='f-sub'>{html.escape(str(subtitulo))}</div>" if subtitulo else ""
    pie = f"<div class='f-nota'>{html.escape(str(nota))}</div>" if nota else ""
    return (f"<div class='ficha'>{franja}<div class='f-tit'>{html.escape(str(titulo))}</div>{sub}<table>"
            + "".join(fila_ficha(a, b) for a, b in filas if b is not None and str(b) not in ("", "nan", "None")) + f"</table>{pie}</div>")


def pesos(v, decimales=None):
    """$ en millones para fichas: 54.512.300 -> '$54,5 millones'; 8.342.600.000 -> '$8.343 millones'."""
    if v is None or not np.isfinite(v):
        return "—"
    m = v / 1e6
    d = decimales if decimales is not None else (0 if abs(m) >= 100 else 1)
    txt = f"{m:,.{d}f}".replace(",", "§").replace(".", ",").replace("§", ".")
    return f"${txt} millones"


# --------------------------------------------------------------------------------------------- CODIFICACIÓN COMPACTA
def _zigzag(v):
    v = np.asarray(v, np.int64)
    return ((v << 1) ^ (v >> 63)).astype(np.uint64)


def _varint(v):
    """Enteros sin signo -> bytes en formato varint (7 bits por byte), vectorizado."""
    v = np.asarray(v, np.uint64)
    if not len(v):
        return b""
    nb = np.ones(len(v), np.int64)
    for k in range(1, 10):
        nb += (v >= (np.uint64(1) << np.uint64(7 * k))).astype(np.int64)
    pos = np.repeat(np.arange(len(v)), nb)
    k = np.arange(nb.sum()) - np.repeat(np.cumsum(nb) - nb, nb)
    byte = (v[pos] >> (np.uint64(7) * k.astype(np.uint64))) & np.uint64(0x7F)
    cont = (k < nb[pos] - 1).astype(np.uint64) << np.uint64(7)
    return (byte | cont).astype(np.uint8).tobytes()


def _codificar_geometria(geoms):
    """Polígonos/multipolígonos (WGS84) -> bytes: [n_features, partes por feature…, anillos por parte…, puntos por
    anillo…, coordenadas (lat, lon) cuantizadas en diferencias…], todo en varint zigzag. El punto de cierre se omite."""
    geoms = np.asarray(geoms)
    partes, f_de_parte = shapely.get_parts(geoms, return_index=True)
    anillos_ext = shapely.get_exterior_ring(partes)
    n_int = shapely.get_num_interior_rings(partes)
    listas = []
    for i, p in enumerate(partes):
        listas.append(anillos_ext[i])
        for k in range(n_int[i]):
            listas.append(shapely.get_interior_ring(p, k))
    anillos = np.asarray(listas, dtype=object)
    coords, a_de_coord = shapely.get_coordinates(anillos, return_index=True)
    npts = np.bincount(a_de_coord, minlength=len(anillos))
    ultimo = np.cumsum(npts) - 1
    keep = np.ones(len(coords), bool)
    keep[ultimo[npts > 3]] = False
    coords = coords[keep]
    npts = npts - (npts > 3)
    q = np.round(coords[:, [1, 0]] * ESCALA).astype(np.int64)    # (lat, lon)
    dq = np.diff(q, axis=0, prepend=np.zeros((1, 2), np.int64)).ravel()
    partes_por_f = np.bincount(f_de_parte, minlength=len(geoms))
    anillos_por_parte = 1 + n_int
    cab = np.r_[len(geoms), partes_por_f, anillos_por_parte, npts].astype(np.uint64)
    return _varint(cab) + _varint(_zigzag(dq))


def _textos(s):
    """Serie -> lista de textos con None en los vacíos (NaN, None, pd.NA, NaT). Valor a valor: en pandas 3,
    `where(..., None)` vuelve a convertir None en NaN y eso mezclaría números con textos."""
    return [None if (v is None or (not isinstance(v, str) and pd.isna(v))) else str(v) for v in s.tolist()]


def _b64gz(datos):
    return base64.b64encode(gzip.compress(datos, compresslevel=9, mtime=0)).decode("ascii")


def _redondear(v, fmt):
    if fmt in ("entero", "clp", "mm"):
        return np.round(v, 0)
    if fmt in ("pct", "puntaje"):
        return np.round(v, 4)
    if fmt == "min":
        return np.round(v, 1)
    return np.round(v, 3)


def _redondo(x, cifras=2):
    """Redondea a `cifras` cifras significativas (cortes de leyenda fáciles de leer: 4.873 -> 4.900; 0,0493 -> 0,049)."""
    if x == 0 or not np.isfinite(x):
        return float(x)
    e = int(np.floor(np.log10(abs(x)))) - (cifras - 1)
    return float(np.round(x / 10 ** e) * 10 ** e)


def _clases(v, d):
    """Cortes y colores de un indicador numérico: 5 niveles por cuantiles, con cortes redondeados (fáciles de leer);
    el 0 aparte si es muy frecuente; divergente con centro."""
    v = np.asarray(v, float)
    v = v[np.isfinite(v)]
    pal = list(PALETAS.get(d["paleta"], PALETA_SEC))
    if d["invertir"]:
        pal = pal[::-1]
    if not len(v):
        return {"cortes": [0, 1], "colores": pal[:1], "cero": False, "niveles": d["niveles"][-1:]}
    cero = d["cero_aparte"] if d["cero_aparte"] is not None else bool((v == 0).mean() > 0.2 and (v > 0).any())
    base = v[v > 0] if cero else v
    n = max(2, int(d["clases"]))
    if d["paleta"] == "divergente" and d["centro"] is not None:
        c = float(d["centro"])
        m = float(np.nanpercentile(np.abs(base - c), 97)) or 1.0
        cortes = list(np.linspace(c - m, c + m, n + 1))
        cortes[0], cortes[-1] = min(cortes[0], float(base.min())), max(cortes[-1], float(base.max()))
    else:
        q = np.quantile(base, np.linspace(0, 1, n + 1))
        internos = [_redondo(x) for x in q[1:-1]]
        cortes = [float(base.min())]
        for x in internos:
            if x > cortes[-1]:
                cortes.append(x)
        if float(base.max()) > cortes[-1]:
            cortes.append(float(base.max()))
        if len(cortes) < 2:
            cortes = [float(base.min()), float(base.max()) + 1e-9]
    k = len(cortes) - 1
    sel = np.round(np.linspace(0, len(pal) - 1, k)).astype(int) if k <= len(pal) else np.arange(k) % len(pal)
    niv = d["niveles"]
    sel_n = np.round(np.linspace(0, len(niv) - 1, k)).astype(int) if k <= len(niv) else np.arange(k) % len(niv)
    return {"cortes": [float(x) for x in cortes], "colores": [pal[i] for i in sel], "cero": cero,
            "niveles": [niv[i] for i in sel_n]}


def _preparar_manzanas(c):
    g = c["gdf"]
    if g is None or not len(g):
        return None, None
    if not isinstance(g, gpd.GeoDataFrame):
        raise TypeError("capa_manzanas necesita un GeoDataFrame con los polígonos de las manzanas")
    g = g[g.geometry.notna() & ~g.geometry.is_empty].copy()
    if c["simplificar_m"]:
        gm = g.to_crs(32719)
        g = g.set_geometry(gm.geometry.simplify(c["simplificar_m"], preserve_topology=True).to_crs("EPSG:4326").values)
    g = g.to_crs("EPSG:4326")
    geom = _codificar_geometria(g.geometry.values)
    ids = g[c["id_col"]].astype(str).tolist() if c["id_col"] in g else [str(i) for i in range(len(g))]
    comunas = pd.Series(_textos(g["comuna"]), index=g.index).fillna("").str.title() if "comuna" in g else pd.Series([""] * len(g), index=g.index)
    lista_com = sorted(comunas.unique().tolist())
    attr = {"ids": ids, "comunas": lista_com, "comuna": comunas.map({k: i for i, k in enumerate(lista_com)}).astype(int).tolist(),
            "valores": {}}
    defs_ind = []
    pintables = {d["col"] for d in c["indicadores"]}
    vistos = set()
    for d in c["indicadores"] + c["ficha"]:
        col = d["col"]
        if col not in g or col in vistos:
            continue
        vistos.add(col)
        s = g[col]
        if d["fmt"] == "texto":
            vals = _textos(s)
            attr["valores"][col] = vals
            presentes = {x for x in vals if x is not None}
            dic = dict(d["categorias"] or {})
            orden = [k for k in dic if k in presentes] + sorted(presentes - set(dic))
            for i, k in enumerate(orden):
                dic.setdefault(k, COLORES_CAT[i % len(COLORES_CAT)])
            meta = {"categorias": {k: dic[k] for k in orden}, "orden": orden,
                    "nombres": {k: str(d["nombres_categoria"].get(k, k)) for k in orden}}
        else:
            v = pd.to_numeric(s, errors="coerce").astype(float).replace([np.inf, -np.inf], np.nan).values
            vr = _redondear(v, d["fmt"])
            attr["valores"][col] = [None if not np.isfinite(x) else (int(x) if float(x).is_integer() and abs(x) < 2**53 else float(x)) for x in vr]
            meta = _clases(v, d)
        defs_ind.append({**{k: d[k] for k in ("col", "etiqueta", "fmt", "descripcion", "nulo", "unidad", "invertir", "nombre_cero")},
                         **meta, "pintable": col in pintables})
    datos = {"g": _b64gz(geom), "a": _b64gz(json.dumps(attr, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))}
    b = g.total_bounds
    rp = g.geometry.representative_point()
    w = pd.to_numeric(g["pob"], errors="coerce").fillna(0).clip(lower=0).values if "pob" in g else np.ones(len(g))
    if (w > 0).sum() >= 20:
        def _q(v, p):                              # cuantil ponderado por población: encuadra donde vive la gente
            o = np.argsort(v)
            cum = np.cumsum(w[o]) / w.sum()
            return float(v[o][min(np.searchsorted(cum, p), len(v) - 1)])
        xs, ys = rp.x.values, rp.y.values
        vista = [[_q(ys, 0.03), _q(xs, 0.03)], [_q(ys, 0.97), _q(xs, 0.97)]]
    else:
        vista = [[float(b[1]), float(b[0])], [float(b[3]), float(b[2])]]
    bx = g.bounds.assign(_c=comunas.values).groupby("_c").agg(minx=("minx", "min"), miny=("miny", "min"),
                                                              maxx=("maxx", "max"), maxy=("maxy", "max"))
    lim = {str(k): [[float(r.miny), float(r.minx)], [float(r.maxy), float(r.maxx)]] for k, r in bx.iterrows() if str(k)}
    meta = {"indicadores": defs_ind, "inicial": int(c["inicial"]), "limites_comuna": lim,
            "bounds": [[float(b[1]), float(b[0])], [float(b[3]), float(b[2])]], "vista": vista, "n": len(g)}
    return datos, meta


# --------------------------------------------------------------------------------------------- GEOJSON (capas chicas)
def _geojson(c):
    g = c["gdf"]
    if g is None or len(g) == 0:
        return None
    if not isinstance(g, gpd.GeoDataFrame):
        g = gpd.GeoDataFrame(g, geometry=gpd.points_from_xy(g["lon"], g["lat"]), crs="EPSG:4326")
    g = g[g.geometry.notna() & ~g.geometry.is_empty]
    if not len(g):
        return None
    es_poligono = g.geom_type.isin(["Polygon", "MultiPolygon"]).any()
    simp = c.get("simplificar_m") or (8 if es_poligono else None)
    if simp:
        crs0 = g.crs
        g = g.to_crs(32719).copy()
        if es_poligono:
            g["geometry"] = g.geometry.map(_sin_huecos_chicos)
        g["geometry"] = g.geometry.simplify(simp)
        g = g.to_crs(crs0)
    dec = c.get("decimales") or 5
    g = g.to_crs("EPSG:4326")
    extra = [c.get("campo_color"), c.get("campo_categoria"), c.get("etiqueta"), c.get("campo_numero"), c.get("ficha_html"),
             c.get("titulo_popup"), c.get("filtro")]
    cols = list(dict.fromkeys([x for x in (c["popup"] + extra) if x and x in g.columns]))
    g = g[cols + ["geometry"]].copy()
    for k in cols:
        s = g[k]
        if pd.api.types.is_float_dtype(s):
            g[k] = s.round(4 if s.abs().max() < 100 else 0)
        elif not pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s):
            g[k] = pd.Series(_textos(s), index=g.index, dtype=object)
        g[k] = g[k].map(lambda v: None if isinstance(v, float) and not np.isfinite(v) else v)
    g["geometry"] = g.geometry.set_precision(10 ** -dec)
    return json.loads(g.to_json(drop_id=True))


def _sin_huecos_chicos(geom, area_min_m2=250_000):
    from shapely.geometry import Polygon, MultiPolygon
    if geom is None or geom.is_empty or geom.geom_type not in ("Polygon", "MultiPolygon"):
        return geom
    partes = geom.geoms if geom.geom_type == "MultiPolygon" else [geom]
    nuevas = [Polygon(p.exterior, [r for r in p.interiors if Polygon(r).area >= area_min_m2]) for p in partes if p.area >= area_min_m2 / 25]
    if not nuevas:
        return geom
    return MultiPolygon(nuevas) if len(nuevas) > 1 else nuevas[0]


def _quiebres(gj, campo, n=5):
    v = np.array([f["properties"].get(campo) for f in gj["features"]], dtype=float)
    v = v[np.isfinite(v)]
    if not len(v):
        return [0, 1]
    q = np.unique(np.quantile(v, np.linspace(0, 1, n + 1)))
    return q.tolist() if len(q) > 1 else [float(v.min()), float(v.max()) + 1e-9]


# --------------------------------------------------------------------------------------------- MAPA
def mapa(capas, titulo="Mapa", archivo=None, centro=None, zoom=None, alto=660, mostrar=True, nota=None, subtitulo=None,
         encuadrar=None, ayuda=None, antetitulo=None):
    """Arma el mapa, lo guarda en `archivo` (si se indica) y lo muestra en el notebook.
    ayuda      frases en lenguaje simple para el botón "¿Cómo leer este mapa?" (se suman a las generales)
    nota       texto al pie (p. ej. una advertencia de anonimato)
    encuadrar  nombres de las capas en que se centra la vista al abrir (por defecto: las manzanas visibles, o donde
               vive la gente; sin manzanas visibles, las demás capas)"""
    simples, compactos, defs, limites, limites_mz, pedidas, limites_vis = {}, {}, [], [], [], [], []
    for k, c in enumerate(capas):
        if c is None:
            continue
        cid = f"c{k}"
        if c.get("tipo") == "manzanas":
            datos, meta = _preparar_manzanas(c)
            if datos is None:
                continue
            compactos[cid] = datos
            defs.append({"id": cid, "tipo": "manzanas", "nombre": c["nombre"], "visible": c["visible"], "opacidad": c["opacidad"],
                         "etiqueta_id": c["etiqueta_id"], "descripcion": c["descripcion"], "en_leyenda": c.get("en_leyenda", True), **meta})
            caja_mz = np.array([meta["vista"][0][1], meta["vista"][0][0], meta["vista"][1][1], meta["vista"][1][0]])
            if meta["n"] < 200:
                caja_mz = np.array([meta["bounds"][0][1], meta["bounds"][0][0], meta["bounds"][1][1], meta["bounds"][1][0]])
            limites_mz.append((bool(c["visible"]), caja_mz))
            if encuadrar and c["nombre"] in encuadrar:
                pedidas.append(caja_mz)
            continue
        gj = _geojson(c)
        if gj is None or not gj["features"]:
            continue
        d = {kk: v for kk, v in c.items() if kk != "gdf"}
        d["id"] = cid
        if c.get("campo_color"):
            d["quiebres"] = _quiebres(gj, c["campo_color"])
            pal = PALETAS.get(c["paleta"], PALETA_SEC)
            n = max(1, len(d["quiebres"]) - 1)
            idx = np.round(np.linspace(0, len(pal) - 1, n)).astype(int)
            d["colores"] = [(pal[::-1] if c["invertir"] else pal)[i] for i in idx]
        if c.get("campo_categoria"):
            presentes = {str(f["properties"].get(c["campo_categoria"])) for f in gj["features"]}
            dic = dict(c.get("colores_categoria") or {})
            orden = [k for k in dic if k in presentes] + sorted(presentes - set(dic))
            for i, v in enumerate(orden):
                dic.setdefault(v, COLORES_CAT[i % len(COLORES_CAT)])
            d["colores_categoria"] = {v: dic[v] for v in orden}
            d["orden_categoria"] = orden
        texto = json.dumps(gj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        simples[cid] = {"gz": _b64gz(texto)} if len(texto) > 60_000 else gj
        defs.append(d)
        g = c["gdf"]
        if isinstance(g, gpd.GeoDataFrame) and len(g):
            if c.get("filtro") and c.get("filtro_inicial") and c["filtro"] in g:       # con filtro: lo que se ve al abrir
                sub = g[g[c["filtro"]].astype(str) == str(c["filtro_inicial"])]
                g = sub if len(sub) else g
            caja = g.to_crs("EPSG:4326").total_bounds
            limites.append(caja)
            if c.get("visible", True):
                limites_vis.append(caja)
            if encuadrar and c["nombre"] in encuadrar:
                pedidas.append(caja)
    if pedidas:
        limites, limites_mz = pedidas, []
    if limites_mz:
        vis_mz = [b for v, b in limites_mz if v]
        limites = vis_mz or limites_vis or limites or [b for _, b in limites_mz]     # sin manzanas visibles: las capas visibles
    if limites:
        b = np.array(limites)
        bounds = [[float(np.nanmin(b[:, 1])), float(np.nanmin(b[:, 0]))], [float(np.nanmax(b[:, 3])), float(np.nanmax(b[:, 2]))]]
    else:
        bounds = [[-33.65, -70.85], [-33.30, -70.45]]                 # mapa sin capas: vista por defecto (Santiago)
    simulado = os.environ.get("GEOVENTAS_MODO", "") == "simulacion"
    pagina = _html(titulo, subtitulo, simples, compactos, defs, bounds, centro, zoom, nota, AYUDA_BASE + list(ayuda or []),
                   antetitulo or ANTETITULO, simulado)
    if archivo:
        os.makedirs(os.path.dirname(os.path.abspath(archivo)), exist_ok=True)
        with open(archivo, "w", encoding="utf-8") as f:
            f.write(pagina)
    obj = MapaHTML(pagina, alto, archivo)
    if mostrar:
        try:
            from IPython import get_ipython
            from IPython.display import display
            if get_ipython() is not None:
                display(obj)
                return None
        except ImportError:
            pass
    return obj


class MapaHTML:
    """Se muestra solo en Jupyter (iframe con el HTML embebido)."""

    def __init__(self, pagina, alto, archivo):
        self.pagina, self.alto, self.archivo = pagina, alto, archivo

    @property
    def mb(self):
        return len(self.pagina.encode("utf-8")) / 1e6

    def _repr_html_(self):
        pie = (f"<div style='font:12px Arial;color:#555'>Archivo: {html.escape(self.archivo)} · {self.mb:,.1f} MB</div>"
               if self.archivo else "")
        return (f"<iframe srcdoc=\"{html.escape(self.pagina, quote=True)}\" style='width:100%;height:{self.alto}px;border:1px solid #ccc;"
                f"border-radius:8px' sandbox='allow-scripts allow-popups'></iframe>{pie}")


def _json_seguro(obj):
    """JSON para incrustar dentro de <script>: sin '</' (no puede cerrar el script por accidente)."""
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")


def _html(titulo, subtitulo, simples, compactos, defs, bounds, centro, zoom, nota, ayuda, antetitulo, simulado):
    vista = f"m.setView([{centro[0]},{centro[1]}],{zoom or 12});" if centro else f"m.fitBounds({json.dumps(bounds)},{{padding:[30,30]}});"
    return (_PLANTILLA
            .replace("__TITULO_TXT__", html.escape(titulo))
            .replace("__ANTETITULO__", html.escape(antetitulo or ""))
            .replace("__SUBTITULO__", html.escape(subtitulo or ""))
            .replace("__SIMULADO__", "<span class='sim'>DATOS SIMULADOS · solo para probar</span>" if simulado else "")
            .replace("__NOTA__", html.escape(nota or ""))
            .replace("__FUENTE__", html.escape(FUENTE))
            .replace("__AYUDA__", "".join(f"<li>{a}</li>" for a in ayuda))
            .replace("__VISTA__", vista)
            .replace("__SIMPLES__", _json_seguro(simples))
            .replace("__COMPACTOS__", _json_seguro(compactos))
            .replace("__DEFS__", _json_seguro(defs)))


_PLANTILLA = r"""<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITULO_TXT__</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
:root{--tinta:#1c2533;--suave:#5c6879;--linea:#e4e8ee;--fondo:#ffffff;--marca:#0e2a47;--acento:#c0392b;--sombra:0 2px 10px rgba(16,30,54,.16)}
html,body,#m{height:100%;margin:0;background:#f3f4f6;font-family:Inter,"Segoe UI",Roboto,Arial,sans-serif;color:var(--tinta)}
.card{background:var(--fondo);border-radius:10px;box-shadow:var(--sombra);border:1px solid var(--linea)}
.cab{position:absolute;z-index:1000;top:12px;left:56px;max-width:min(62%,700px);padding:10px 14px 10px 16px;border-left:5px solid var(--marca)}
.cab .ante{font-size:10.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--suave);font-weight:600}
.cab .tit{font-size:17px;font-weight:700;line-height:1.25;margin-top:2px}
.cab .sub{font-size:12.5px;color:var(--suave);margin-top:3px;line-height:1.35}
.cab .acc{margin-top:7px;display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.btn{font:600 12px Inter,Arial;border:1px solid var(--linea);background:#f7f9fb;color:var(--marca);border-radius:16px;padding:4px 11px;cursor:pointer}
.btn:hover{background:#eef3f8}
.sim{font:700 10.5px Inter,Arial;color:#fff;background:#d35400;border-radius:4px;padding:3px 7px;letter-spacing:.03em}
.ayuda{position:absolute;z-index:1001;top:110px;left:56px;width:min(420px,80%);padding:12px 16px;display:none;font-size:12.5px;line-height:1.45}
.ayuda h3{margin:0 0 6px;font-size:13.5px;color:var(--marca)} .ayuda ul{margin:0;padding-left:18px} .ayuda li{margin:4px 0}
.ayuda .cerrar{float:right;cursor:pointer;color:var(--suave);font-size:16px;line-height:1}
.panel{width:262px;padding:11px 13px;font-size:12.5px}
.panel .ptit{font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:var(--marca);margin-bottom:6px;display:flex;justify-content:space-between;cursor:pointer}
.panel label{display:block;font-size:11.5px;color:var(--suave);margin:8px 0 3px;font-weight:600}
.panel select{width:100%;font:500 12.5px Inter,Arial;padding:5px 6px;border:1px solid #cfd6df;border-radius:6px;background:#fff;color:var(--tinta)}
.panel .desc{font-size:11.5px;color:var(--suave);margin:5px 0 2px;line-height:1.38}
.panel input[type=range]{width:100%;accent-color:var(--marca)}
.panel.cerrado .cuerpo{display:none}
.ley{padding:10px 12px;font-size:12px;line-height:1.3;max-height:min(46vh,420px);overflow:auto;width:255px}
.ley .lt{font-weight:700;font-size:12.5px;margin-bottom:1px}
.ley .lu{color:var(--suave);font-size:11.3px;margin-bottom:6px}
.ley .fila{display:flex;align-items:center;gap:8px;margin:3px 0}
.ley .sw{width:22px;height:14px;border-radius:3px;border:1px solid rgba(0,0,0,.12);flex:0 0 auto}
.ley .nv{font-weight:600;min-width:66px} .ley .rg{color:var(--tinta);flex:1} .ley .n{color:#8a94a3;font-size:10.5px;white-space:nowrap}
.ley .nota{color:#8a94a3;font-size:10.5px;margin-top:6px;line-height:1.3}
.ley hr{border:0;border-top:1px solid var(--linea);margin:8px 0}
.ley .ico{flex:0 0 22px;display:flex;justify-content:center}
.pie{position:absolute;z-index:999;bottom:8px;left:96px;max-width:calc(100% - 400px);font-size:10.5px;color:#4a5566;line-height:1.35;background:rgba(255,255,255,.9);padding:4px 9px;border-radius:6px;box-shadow:0 1px 4px rgba(16,30,54,.12)}
.pie .nota{color:#7a1f12;font-weight:600}
.leaflet-control-layers{border-radius:10px!important;box-shadow:var(--sombra)!important;border:1px solid var(--linea)!important;font:500 12px Inter,Arial}
.leaflet-control-layers-expanded{padding:8px 12px 8px 9px} .leaflet-control-layers-separator{margin:6px -12px 6px -9px}
.leaflet-control-layers label{margin:2px 0}
.leaflet-popup-content-wrapper{border-radius:10px} .leaflet-popup-content{margin:0;min-width:240px}
.ficha{padding:12px 14px 10px;font-size:12.5px;position:relative} .ficha .f-franja{position:absolute;left:0;top:0;bottom:0;width:5px;border-radius:10px 0 0 10px}
.ficha .f-tit{font-weight:700;font-size:13.5px;color:var(--marca);line-height:1.3} .ficha .f-sub{color:var(--suave);font-size:11.5px;margin:2px 0 6px}
.ficha table{border-collapse:collapse;width:100%} .ficha td{padding:4px 2px;border-bottom:1px solid #eef1f4;vertical-align:top}
.ficha td:first-child{color:var(--suave);padding-right:10px} .ficha td:last-child{text-align:right}
.ficha tr.act td{background:#fff6dc} .ficha .f-nota{color:#8a94a3;font-size:10.5px;margin-top:6px}
.hover{position:absolute;z-index:1001;pointer-events:none;background:rgba(20,30,45,.92);color:#fff;font-size:12px;padding:5px 9px;border-radius:6px;display:none;white-space:nowrap;box-shadow:0 2px 6px rgba(0,0,0,.25)}
.hover b{font-weight:600}
.cargando{position:absolute;z-index:1002;top:50%;left:50%;transform:translate(-50%,-50%);padding:12px 18px;font-size:13px}
canvas.manzanas{position:absolute;left:0;top:0;pointer-events:none}
.ico-sede{width:24px;height:24px;border-radius:50%;background:var(--marca);border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.45);color:#fff;font:700 16px/22px Inter,Arial;text-align:center}
.ico-num{width:26px;height:26px;border-radius:50%;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.45);color:#fff;font:700 12px/22px Inter,Arial;text-align:center}
.ico-rombo{width:20px;height:20px;transform:rotate(45deg);background:#111;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.45)}
.ico-rombo span{display:block;transform:rotate(-45deg);color:#fff;font:700 9px/16px Inter,Arial;text-align:center}
.leaflet-tooltip.etq{background:rgba(255,255,255,.94);border:1px solid #d9dee5;border-radius:5px;box-shadow:0 1px 3px rgba(0,0,0,.15);font:600 11.5px Inter,Arial;color:var(--marca);padding:2px 6px}
.zoom-lejos .leaflet-tooltip.etq{display:none}
.boton-vista{background:#fff;border-radius:6px;box-shadow:var(--sombra);font:600 15px Inter,Arial;width:30px;height:30px;line-height:30px;text-align:center;cursor:pointer;color:var(--marca)}
@media (max-width:760px){.cab{max-width:calc(100% - 80px)}.panel{width:200px}.ley{width:200px;max-height:32vh}.pie{display:none}}
</style></head>
<body><div id="m"></div>
<div class="cab card"><div class="ante">__ANTETITULO__</div><div class="tit">__TITULO_TXT__</div><div class="sub">__SUBTITULO__</div>
<div class="acc"><button class="btn" id="btn-ayuda">¿Cómo leer este mapa?</button>__SIMULADO__</div></div>
<div class="ayuda card" id="ayuda"><span class="cerrar" id="cerrar-ayuda">×</span><h3>¿Cómo leer este mapa?</h3><ul>__AYUDA__</ul></div>
<div class="pie"><span class="nota">__NOTA__</span> __FUENTE__</div>
<div class="hover" id="hover"></div><div class="cargando card" id="cargando">Cargando el mapa…</div>
<script>
const SIMPLES=__SIMPLES__;
const COMPACTOS=__COMPACTOS__;
const DEFS=__DEFS__;
const m=L.map('m',{preferCanvas:true,zoomSnap:0.5,zoomControl:true});__VISTA__
const VISTA0={c:m.getCenter(),z:m.getZoom()};
const gris=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}',{maxZoom:16,attribution:'Esri'}).addTo(m);
const osm=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'});
const sat=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxZoom:18,attribution:'Esri'});
m.createPane('nombres');m.getPane('nombres').style.zIndex=380;m.getPane('nombres').style.pointerEvents='none';
const nombres=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Reference/MapServer/tile/{z}/{y}/{x}',{maxZoom:16,pane:'nombres',attribution:'Esri'}).addTo(m);
document.getElementById('btn-ayuda').onclick=()=>{const a=document.getElementById('ayuda');a.style.display=a.style.display==='block'?'none':'block';};
document.getElementById('cerrar-ayuda').onclick=()=>{document.getElementById('ayuda').style.display='none';};
function zoomClase(){m.getContainer().classList.toggle('zoom-lejos',m.getZoom()<12.5);}m.on('zoomend',zoomClase);zoomClase();

// ---------- números en español de Chile
const nf=(v,d)=>v.toLocaleString('es-CL',{minimumFractionDigits:d,maximumFractionDigits:d});
function fmtv(v,f){
  if(v===null||v===undefined||(typeof v==='number'&&!isFinite(v)))return '—';
  if(typeof v!=='number')return String(v);
  switch(f){
    case 'entero':return nf(v,0);
    case 'decimal':return nf(v,Math.abs(v)<10?1:0);
    case 'pct':{const p=100*v;return nf(p,Math.abs(p)>=10?0:(Math.abs(p)>=1||p===0?1:2))+'%';}
    case 'pct100':return nf(v,Math.abs(v)>=10?0:(Math.abs(v)>=1||v===0?1:2))+'%';
    case 'mm':{const x=v/1e6;return '$'+nf(x,Math.abs(x)>=100||x===0?0:1)+(x===1?' millón':' millones');}
    case 'clp':return '$'+nf(v,0);
    case 'min':return nf(v,v<10?1:0)+' min';
    case 'km2':return nf(v,v<1?3:1)+' km²';
    case 'puntaje':return nf(100*v,0)+' de 100';
    default:return nf(v,Math.abs(v)<10?2:0);
  }}
function fmtCorto(v,f){ // para rangos de la leyenda: sin unidad repetida
  if(f==='mm'){const x=v/1e6;return '$'+nf(x,Math.abs(x)>=100||x===0?0:1);}
  if(f==='min')return nf(v,v<10?1:0);
  return fmtv(v,f);}
const fmtg=v=>typeof v==='number'?v.toLocaleString('es-CL',{maximumFractionDigits:Math.abs(v)<10?2:0}):esc(v);
function esc(t){return String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

// ---------- descompresión (nativa; si el navegador es antiguo, fflate desde CDN)
function cargarScript(src){return new Promise((ok,mal)=>{const s=document.createElement('script');s.src=src;s.onload=ok;s.onerror=mal;document.head.appendChild(s);});}
async function gunzip(b64){
  const bin=Uint8Array.from(atob(b64),c=>c.charCodeAt(0));
  if(window.DecompressionStream){const ds=new DecompressionStream('gzip');
    return new Uint8Array(await new Response(new Blob([bin]).stream().pipeThrough(ds)).arrayBuffer());}
  if(!window.fflate)await cargarScript('https://cdn.jsdelivr.net/npm/fflate@0.8.2/umd/index.js');
  return fflate.gunzipSync(bin);}
function leerVarints(b){const out=[];let v=0,s=1;for(let i=0;i<b.length;i++){const x=b[i];v+=(x&127)*s;if(x&128){s*=128;}else{out.push(v);v=0;s=1;}}return out;}
const zz=n=>(n%2===0)?n/2:-(n+1)/2;

// ---------- capa de manzanas: canvas propio + índice espacial
const R2=2*Math.PI;
function proy(lat,lon){const s=Math.sin(lat*Math.PI/180);return [0.5+lon/360,0.5-Math.log((1+s)/(1-s))/(2*R2)];}
async function decodificar(dat){
  const vs=leerVarints(await gunzip(dat.g));const attr=JSON.parse(new TextDecoder().decode(await gunzip(dat.a)));
  let p=0;const nf_=vs[p++];const pf=vs.slice(p,p+nf_);p+=nf_;const np_=pf.reduce((a,b)=>a+b,0);
  const ap=vs.slice(p,p+np_);p+=np_;const na=ap.reduce((a,b)=>a+b,0);const pa=vs.slice(p,p+na);p+=na;
  const npt=pa.reduce((a,b)=>a+b,0);const XY=new Float64Array(npt*2);let la=0,lo=0;
  for(let i=0;i<npt;i++){la+=zz(vs[p++]);lo+=zz(vs[p++]);const q=proy(la/1e5,lo/1e5);XY[2*i]=q[0];XY[2*i+1]=q[1];}
  const anillosF=new Array(nf_);const caja=new Float64Array(nf_*4);let ia=0,ipart=0,ip=0;
  for(let f=0;f<nf_;f++){const an=[];let x0=1,y0=1,x1=0,y1=0;
    for(let k=0;k<pf[f];k++){const nr=ap[ipart++];for(let r=0;r<nr;r++){const n=pa[ia++];an.push([ip,n]);
      for(let j=ip;j<ip+n;j++){const x=XY[2*j],y=XY[2*j+1];if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}ip+=n;}}
    anillosF[f]=an;caja[4*f]=x0;caja[4*f+1]=y0;caja[4*f+2]=x1;caja[4*f+3]=y1;}
  let X0=1,Y0=1,X1=0,Y1=0;for(let f=0;f<nf_;f++){X0=Math.min(X0,caja[4*f]);Y0=Math.min(Y0,caja[4*f+1]);X1=Math.max(X1,caja[4*f+2]);Y1=Math.max(Y1,caja[4*f+3]);}
  const G=Math.max(8,Math.ceil(Math.sqrt(nf_/3)));const cw=(X1-X0)/G||1e-9,ch=(Y1-Y0)/G||1e-9;const grilla=new Map();
  for(let f=0;f<nf_;f++){const a=Math.floor((caja[4*f]-X0)/cw),b=Math.floor((caja[4*f+2]-X0)/cw),c=Math.floor((caja[4*f+1]-Y0)/ch),d=Math.floor((caja[4*f+3]-Y0)/ch);
    for(let i=a;i<=b;i++)for(let j=c;j<=d;j++){const k=i*100003+j;if(!grilla.has(k))grilla.set(k,[]);grilla.get(k).push(f);}}
  return {n:nf_,XY,anillosF,caja,attr,grilla,X0,Y0,cw,ch};}
function dentro(D,f,x,y){let c=false;for(const [ini,n] of D.anillosF[f]){for(let i=0,j=n-1;i<n;j=i++){const xi=D.XY[2*(ini+i)],yi=D.XY[2*(ini+i)+1],xj=D.XY[2*(ini+j)],yj=D.XY[2*(ini+j)+1];
  if(((yi>y)!==(yj>y))&&(x<(xj-xi)*(y-yi)/(yj-yi)+xi))c=!c;}}return c;}
function buscar(D,x,y){const k=Math.floor((x-D.X0)/D.cw)*100003+Math.floor((y-D.Y0)/D.ch);const l=D.grilla.get(k);if(!l)return -1;
  for(const f of l){if(x>=D.caja[4*f]&&x<=D.caja[4*f+2]&&y>=D.caja[4*f+1]&&y<=D.caja[4*f+3]&&dentro(D,f,x,y))return f;}return -1;}
function claseDe(ind,v){if(v===null||v===undefined)return -1;
  if(ind.categorias){return ind.orden.indexOf(String(v));}
  if(ind.cero&&v===0)return -2;const q=ind.cortes;for(let i=1;i<q.length;i++){if(v<=q[i])return Math.min(i-1,ind.colores.length-1);}return ind.colores.length-1;}
function colorClase(ind,k){if(k===-1)return '#d5d8dd';if(k===-2)return '#eeeff1';return ind.categorias?ind.categorias[ind.orden[k]]:ind.colores[k];}
function valorTexto(ind,v){if(v===null||v===undefined)return ind.nulo||'sin dato';if(ind.categorias||typeof v!=='number')return esc((ind.nombres&&ind.nombres[v])||String(v));return fmtv(v,ind.fmt);}

const CapaManzanas=L.Layer.extend({
  initialize(def,D){this.def=def;this.D=D;this.alfa=def.opacidad;this.pint=def.indicadores.filter(x=>x.pintable);this.ind=this.pint[Math.min(def.inicial,this.pint.length-1)];this._clasificar();this.sel=-1;},
  _clasificar(){const v=this.D.attr.valores[this.ind.col];this.cl=new Int16Array(this.D.n);for(let f=0;f<this.D.n;f++)this.cl[f]=claseDe(this.ind,v[f]);},
  setIndicador(col){this.ind=this.pint.find(x=>x.col===col);this._clasificar();this._dibujar();},
  setOpacidad(a){this.alfa=a;this._dibujar();},
  onAdd(map){this._map=map;this.c=L.DomUtil.create('canvas','manzanas');this.h=L.DomUtil.create('canvas','manzanas');
    const pane=map.getPane('manzanas')||map.createPane('manzanas');pane.style.zIndex=350;pane.style.pointerEvents='none';pane.appendChild(this.c);pane.appendChild(this.h);
    map.on('moveend zoomend resize viewreset',this._dibujar,this);map.on('zoomstart',this._ocultar,this);this._dibujar();},
  onRemove(map){L.DomUtil.remove(this.c);L.DomUtil.remove(this.h);map.off('moveend zoomend resize viewreset',this._dibujar,this);map.off('zoomstart',this._ocultar,this);},
  _ocultar(){this.c.style.visibility='hidden';this.h.style.visibility='hidden';},
  _marco(cv){const m=this._map,s=m.getSize(),tl=m.containerPointToLayerPoint([0,0]),r=window.devicePixelRatio||1;
    L.DomUtil.setPosition(cv,tl);cv.width=s.x*r;cv.height=s.y*r;cv.style.width=s.x+'px';cv.style.height=s.y+'px';
    const ctx=cv.getContext('2d');ctx.setTransform(r,0,0,r,0,0);const esc=256*Math.pow(2,m.getZoom()),o=m.getPixelOrigin();
    return {ctx,esc,ox:o.x+tl.x,oy:o.y+tl.y,w:s.x,h:s.y};},
  _camino(p,f,P){const D=this.D;for(const [ini,n] of D.anillosF[f]){for(let j=0;j<n;j++){const x=D.XY[2*(ini+j)]*P.esc-P.ox,y=D.XY[2*(ini+j)+1]*P.esc-P.oy;if(j===0)p.moveTo(x,y);else p.lineTo(x,y);}p.closePath();}},
  _dibujar(){if(!this._map)return;const P=this._marco(this.c),D=this.D;this.c.style.visibility='visible';this.h.style.visibility='visible';
    const x0=P.ox/P.esc,x1=(P.ox+P.w)/P.esc,y0=P.oy/P.esc,y1=(P.oy+P.h)/P.esc;const caminos=new Map();
    for(let f=0;f<D.n;f++){if(D.caja[4*f+2]<x0||D.caja[4*f]>x1||D.caja[4*f+3]<y0||D.caja[4*f+1]>y1)continue;
      const k=this.cl[f];if(!caminos.has(k))caminos.set(k,new Path2D());this._camino(caminos.get(k),f,P);}
    const z=this._map.getZoom();
    for(const [k,p] of caminos){P.ctx.globalAlpha=(k===-1||k===-2)?Math.min(this.alfa,0.55):this.alfa;P.ctx.fillStyle=colorClase(this.ind,k);P.ctx.fill(p,'evenodd');
      if(z>=14){P.ctx.globalAlpha=Math.min(1,this.alfa+0.1);P.ctx.strokeStyle='#ffffff';P.ctx.lineWidth=z>=16?1:0.6;P.ctx.stroke(p);}}
    this._resaltar(this.sel);},
  _resaltar(f){this.sel=f;const P=this._marco(this.h);if(f<0)return;const p=new Path2D();this._camino(p,f,P);
    P.ctx.strokeStyle='#0e2a47';P.ctx.lineWidth=2.6;P.ctx.stroke(p);P.ctx.strokeStyle='#ffffff';P.ctx.lineWidth=0.9;P.ctx.stroke(p);},
  buscarEn(ll){const q=proy(ll.lat,ll.lng);return buscar(this.D,q[0],q[1]);},
  comuna(f){const a=this.D.attr;return esc(a.comunas[a.comuna[f]]||'');},
  ficha(f){const a=this.D.attr;let h=`<div class="ficha"><div class="f-franja" style="background:${colorClase(this.ind,this.cl[f])}"></div>`+
      `<div class="f-tit">${this.def.etiqueta_id} ${esc(a.ids[f])}</div><div class="f-sub">${this.comuna(f)}</div><table>`;
    for(const ind of this.def.indicadores){const v=a.valores[ind.col];if(!v)continue;h+=`<tr class="${ind.col===this.ind.col?'act':''}"><td>${ind.etiqueta}</td><td><b>${valorTexto(ind,v[f])}</b></td></tr>`;}
    return h+'</table></div>';},
  resumen(f){const a=this.D.attr;const c=this.comuna(f);return `${c?'<b>'+c+'</b> · ':''}${this.ind.etiqueta}: <b>${valorTexto(this.ind,a.valores[this.ind.col][f])}</b>`;},
  leyenda(){const ind=this.ind;const n={};for(let f=0;f<this.D.n;f++){const k=this.cl[f];n[k]=(n[k]||0)+1;}
    const cuenta=k=>`<span class="n">${(n[k]||0).toLocaleString('es-CL')}</span>`;
    let h=`<div class="lt">${ind.etiqueta}</div>`;
    if(ind.categorias){h+=`<div class="lu">${this.def.nombre}</div>`;
      ind.orden.forEach((k,i)=>{h+=`<div class="fila"><span class="sw" style="background:${ind.categorias[k]}"></span><span class="rg">${(ind.nombres&&ind.nombres[k])||k}</span>${cuenta(i)}</div>`;});}
    else{h+=`<div class="lu">${ind.unidad?ind.unidad+' · ':''}${ind.invertir?'más oscuro = más cerca / mejor':'más oscuro = más'}</div>`;
      const filas=[];for(let i=0;i<ind.colores.length;i++){const a=ind.cortes[i],b=ind.cortes[i+1];
        const rg=(i===0?(ind.cero?'más de 0':'')+(ind.cero?'':fmtCorto(a,ind.fmt)):fmtCorto(a,ind.fmt))+' a '+fmtCorto(b,ind.fmt)+(ind.fmt==='mm'?' millones':ind.fmt==='min'?' min':'');
        filas.push(`<div class="fila"><span class="sw" style="background:${ind.colores[i]}"></span><span class="nv">${ind.niveles[i]}</span><span class="rg">${rg}</span>${cuenta(i)}</div>`);}
      h+=(ind.invertir?filas:filas.slice().reverse()).join('');
      if(ind.cero)h+=`<div class="fila"><span class="sw" style="background:#eeeff1"></span><span class="nv">${ind.nombre_cero||'Ninguno'}</span><span class="rg">0</span>${cuenta(-2)}</div>`;}
    if(n[-1])h+=`<div class="fila"><span class="sw" style="background:#d5d8dd"></span><span class="rg">${ind.nulo||'sin dato'}</span>${cuenta(-1)}</div>`;
    h+=`<div class="nota">Números a la derecha: cuántas manzanas hay en cada nivel${ind.categorias?'':'. Cada nivel agrupa una cantidad parecida de manzanas'}.</div>`;
    return h;}
});

// ---------- capas chicas (GeoJSON): sedes, competencia, Top 20, isócronas, áreas
async function datosGeojson(id){const v=SIMPLES[id];return (v&&v.gz)?JSON.parse(new TextDecoder().decode(await gunzip(v.gz))):v;}
function colorDe(d,p){
 if(d.campo_color){const v=p[d.campo_color];if(v===null||v===undefined)return '#ccc';const q=d.quiebres;
   for(let i=1;i<q.length;i++){if(v<=q[i])return d.colores[Math.min(i-1,d.colores.length-1)];}return d.colores[d.colores.length-1];}
 if(d.campo_categoria){return d.colores_categoria[String(p[d.campo_categoria])]||'#999';}
 return d.color||'#1f5fa8';}
function iconoHtml(d,p){const c=colorDe(d,p);const t=d.campo_numero?(p[d.campo_numero]??''):'';
 if(d.icono==='sede')return {html:`<div class="ico-sede" style="background:${c}">+</div>`,s:24};
 if(d.icono==='numero')return {html:`<div class="ico-num" style="background:${c}">${t}</div>`,s:26};
 if(d.icono==='rombo')return {html:`<div class="ico-rombo"><span>${t}</span></div>`,s:20};
 return null;}
function fichaGeojson(d,p){
 if(d.ficha_html&&p[d.ficha_html])return p[d.ficha_html];
 const tit=d.titulo_popup&&p[d.titulo_popup]?p[d.titulo_popup]:d.nombre;
 let h=`<div class="ficha"><div class="f-franja" style="background:${colorDe(d,p)}"></div><div class="f-tit">${tit}</div><div class="f-sub">${d.titulo_popup?d.nombre:''}</div><table>`;
 for(const k of d.popup){if(k===d.titulo_popup)continue;const v=p[k];if(v===undefined||v===null)continue;
   const f=(d.formato_popup||{})[k];const et=(d.etiquetas_popup||{})[k]||k;
   h+=`<tr><td>${et}</td><td><b>${f?fmtv(v,f):(typeof v==='boolean'?(v?'Sí':'No'):fmtg(v))}</b></td></tr>`;}
 return h+'</table></div>';}
function filtroDe(d,valor){return f=>!(d.filtro&&valor)||String(f.properties[d.filtro])===valor;}
function capaGeojson(d,gj){return L.geoJSON(gj,{filter:filtroDe(d,d.filtro_inicial),
  style:f=>({color:d.borde||colorDe(d,f.properties),weight:d.peso,fillColor:colorDe(d,f.properties),fillOpacity:d.opacidad,opacity:0.95}),
  pointToLayer:(f,ll)=>{const ic=iconoHtml(d,f.properties);
    if(ic)return L.marker(ll,{icon:L.divIcon({className:'',html:ic.html,iconSize:[ic.s,ic.s],iconAnchor:[ic.s/2,ic.s/2]}),riseOnHover:true});
    return L.circleMarker(ll,{radius:d.radio,color:d.borde||'#ffffff',weight:1,fillColor:colorDe(d,f.properties),fillOpacity:0.9,bubblingMouseEvents:false});},
  onEachFeature:(f,l)=>{l.bindPopup(fichaGeojson(d,f.properties),{maxWidth:380,autoPanPaddingTopLeft:L.point(290,150),autoPanPaddingBottomRight:L.point(290,30)});
    if(d.etiqueta&&f.properties[d.etiqueta]!=null)l.bindTooltip(String(f.properties[d.etiqueta]),d.etiqueta_fija?{permanent:true,direction:'right',offset:[12,0],className:'etq'}:{sticky:true,className:'etq'});}});}
function leyendaGeojson(d){let h=`<div class="lt">${d.nombre}</div>`;
 const muestra=(c,cat)=>{if(d.icono){const ic=iconoHtml(d,cat!==undefined?{[d.campo_categoria]:cat}:{});return `<span class="ico">${ic.html.replace(/>\d*<\/div>$/,'></div>').replace('width:26px','width:18px')}</span>`;}
   if(d.opacidad===0)return `<span class="sw" style="background:transparent;border:2px solid ${d.borde||c}"></span>`;
   return `<span class="sw" style="background:${c};${d.borde?'border:2px solid '+d.borde:''}"></span>`;};
 if(d.campo_color){const q=d.quiebres;for(let i=d.colores.length-1;i>=0;i--)h+=`<div class="fila">${muestra(d.colores[i])}<span class="rg">${fmtg(q[i])} a ${fmtg(q[i+1])}</span></div>`;}
 else if(d.campo_categoria){for(const k of d.orden_categoria){const c=d.colores_categoria[k];h+=`<div class="fila">${muestra(c,k)}<span class="rg">${(d.nombres_categoria||{})[k]||k}</span></div>`;}}
 else h+=`<div class="fila">${muestra(d.color||'#1f5fa8')}<span class="rg">${d.nombre}</span></div>`;return h;}

// ---------- armado
(async function(){
 const over={'Nombres de calles y comunas':nombres},manz=[],ord=[],filtrables=[];
 for(const d of DEFS){
   if(d.tipo==='manzanas'){const D=await decodificar(COMPACTOS[d.id]);const c=new CapaManzanas(d,D);if(d.visible)c.addTo(m);over[d.nombre]=c;manz.push(c);ord.push({d,c});}
   else{const gj=await datosGeojson(d.id);const c=capaGeojson(d,gj);if(d.visible)c.addTo(m);over[d.nombre]=c;ord.push({d,c});
     if(d.filtro)filtrables.push({d,c,gj});}}
 document.getElementById('cargando').style.display='none';
 L.control.layers({'Mapa gris':gris,'Mapa de calles':osm,'Satélite':sat},over,{collapsed:window.innerWidth<760}).addTo(m);
 L.control.scale({imperial:false,position:'bottomleft'}).addTo(m);
 const bv=L.control({position:'topleft'});bv.onAdd=()=>{const b=L.DomUtil.create('div','boton-vista');b.title='Volver a la vista inicial';b.innerHTML='⟲';
   L.DomEvent.disableClickPropagation(b);b.onclick=()=>m.setView(VISTA0.c,VISTA0.z);return b;};bv.addTo(m);
 const campos=[...new Set(filtrables.map(x=>x.d.filtro))];
 if(manz.length||campos.length){const pn=L.control({position:'topleft'});pn.onAdd=()=>{const div=L.DomUtil.create('div','panel card'+(window.innerWidth<760?' cerrado':''));L.DomEvent.disableClickPropagation(div);L.DomEvent.disableScrollPropagation(div);
   let h='<div class="ptit" id="ptit">Qué mostrar en el mapa <span>▾</span></div><div class="cuerpo">';
   campos.forEach((cp,j)=>{const fx=filtrables.filter(x=>x.d.filtro===cp);const vals=[...new Set(fx.flatMap(x=>x.gj.features.map(f=>String(f.properties[cp]))))].sort((a,b)=>a.localeCompare(b,'es'));
     const ini=fx[0].d.filtro_inicial||'';h+=`<label>${fx[0].d.etiqueta_filtro}</label><select class="selfil" data-cp="${esc(cp)}"><option value="">Todas</option>`+vals.map(v=>`<option ${v===ini?'selected':''}>${esc(v)}</option>`).join('')+'</select>';});
   const conSel=manz.filter(c=>c.pint.length>1);
   manz.forEach((c,i)=>{if(c.pint.length>1){h+=`<label>${conSel.length>1?c.def.nombre:'Indicador'}</label><select data-i="${i}" class="selind">`+c.pint.map(x=>`<option value="${x.col}" ${x.col===c.ind.col?'selected':''}>${x.etiqueta}</option>`).join('')+'</select>'+`<div class="desc" id="desc${i}">${c.ind.descripcion||''}</div>`;}
     else if(manz.length===1&&c.ind.descripcion)h+=`<div class="desc">${c.ind.descripcion}</div>`;});
   const lim=manz.length?(manz[0].def.limites_comuna||{}):{};const ks=Object.keys(lim).filter(k=>k).sort((a,b)=>a.localeCompare(b,'es'));
   if(ks.length>1)h+='<label>Ir a una comuna</label><select id="comuna"><option value="">Toda el área de estudio</option>'+ks.map(k=>`<option>${k}</option>`).join('')+'</select>';
   if(manz.length)h+=`<label>Intensidad del color de las manzanas</label><input type="range" id="opac" min="0.15" max="1" step="0.05" value="${manz[0].alfa}">`;
   h+='</div>';
   div.innerHTML=h;return div;};pn.addTo(m);
   document.getElementById('ptit').onclick=()=>document.querySelector('.panel').classList.toggle('cerrado');
   document.querySelectorAll('.selind').forEach(s=>s.addEventListener('change',e=>{const i=+e.target.dataset.i;manz[i].setIndicador(e.target.value);document.getElementById('desc'+i).textContent=manz[i].ind.descripcion||'';ley.actualizar();}));
   const sc=document.getElementById('comuna');if(sc)sc.addEventListener('change',e=>{const b=e.target.value?manz[0].def.limites_comuna[e.target.value]:manz[0].def.vista;m.fitBounds(b,{padding:[30,30]});});
   const op=document.getElementById('opac');if(op)op.addEventListener('input',e=>manz.forEach(c=>c.setOpacidad(+e.target.value)));
   document.querySelectorAll('.selfil').forEach(sel=>sel.addEventListener('change',e=>{const cp=e.target.dataset.cp,v=e.target.value;
     filtrables.filter(x=>x.d.filtro===cp).forEach(x=>{x.c.clearLayers();x.c.options.filter=filtroDe(x.d,v);x.c.addData(x.gj);});
     const capas=filtrables.filter(x=>x.d.filtro===cp&&m.hasLayer(x.c)).map(x=>x.c.getBounds()).filter(b=>b.isValid());
     if(v&&capas.length){let b=capas[0];capas.slice(1).forEach(x=>b.extend(x));m.fitBounds(b,{padding:[40,40]});}}));}
 const ley=L.control({position:'bottomright'});ley.onAdd=()=>{const d=L.DomUtil.create('div','ley card');L.DomEvent.disableScrollPropagation(d);L.DomEvent.disableClickPropagation(d);ley.div=d;return d;};
 ley.actualizar=()=>{const partes=ord.filter(o=>m.hasLayer(o.c)&&o.d.en_leyenda!==false).reverse().map(o=>o.d.tipo==='manzanas'?o.c.leyenda():leyendaGeojson(o.d));
   ley.div.innerHTML=partes.length?partes.join('<hr>'):'<div class="lu">Prende una capa para ver su leyenda.</div>';};
 ley.addTo(m);ley.actualizar();m.on('overlayadd overlayremove',ley.actualizar);
 const hv=document.getElementById('hover');let pend=null;
 function activa(ll){for(let i=manz.length-1;i>=0;i--){const c=manz[i];if(!m.hasLayer(c))continue;const f=c.buscarEn(ll);if(f>=0)return [c,f];}return [null,-1];}
 m.on('mousemove',e=>{pend=e;requestAnimationFrame(()=>{if(!pend)return;const ev=pend;pend=null;const [c,f]=activa(ev.latlng);
   manz.forEach(x=>{if(x!==c&&x.sel>=0)x._resaltar(-1);});
   if(c){if(c.sel!==f)c._resaltar(f);hv.style.display='block';hv.innerHTML=c.resumen(f);hv.style.left=(ev.containerPoint.x+14)+'px';hv.style.top=(ev.containerPoint.y+12)+'px';m.getContainer().style.cursor='pointer';}
   else{hv.style.display='none';m.getContainer().style.cursor='';}});});
 m.on('mouseout',()=>{hv.style.display='none';manz.forEach(x=>x._resaltar(-1));});
 m.on('click',e=>{const [c,f]=activa(e.latlng);if(c)L.popup({maxWidth:380,autoPanPaddingTopLeft:L.point(290,150),autoPanPaddingBottomRight:L.point(290,30)}).setLatLng(e.latlng).setContent(c.ficha(f)).openOn(m);});
})().catch(err=>{document.getElementById('cargando').textContent='No se pudo cargar el mapa: '+err;});
</script></body></html>"""


def puntos(df, x="lon", y="lat", crs="EPSG:4326"):
    """DataFrame con coordenadas -> GeoDataFrame de puntos."""
    return gpd.GeoDataFrame(df.copy(), geometry=gpd.points_from_xy(df[x], df[y]), crs=crs)
