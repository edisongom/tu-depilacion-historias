# -*- coding: utf-8 -*-
"""Análisis con el RUT de los pacientes (cruzado con las bases de personas y empresas de Equifax).

Con el RUT de cada atención se sabe DÓNDE VIVE cada paciente (manzana de su domicilio en `per`) y QUIÉN ES (GSE, edad,
sexo, renta del hogar). Si el RUT es de una empresa (convenio), se ubica con `emp`. Eso permite medir, por sede:
  · zonas de influencia REALES (no estimadas): manzanas de donde sale el 60% / 80% de la venta;
  · penetración: pacientes / población de cada zona;
  · afinidad: % de pacientes de cada GSE, tramo de edad y sexo vs % de la población de su área;
  · pacientes que usan VARIAS sedes (sustitución observada = canibalización real entre sedes);
  · frecuencia y fidelidad (atenciones por paciente, recurrentes, retención anual);
  · venta a empresas (convenios).
Privacidad: el RUT llega o se transforma en hash al leerlo; los resultados se publican agregados y solo para manzanas con
al menos `min_pacientes_publicacion` pacientes (5 por defecto).
"""
import numpy as np
import pandas as pd

TRAMOS_EDAD = [(-1, 5, "0_5"), (5, 13, "6_13"), (13, 17, "14_17"), (17, 24, "18_24"), (24, 44, "25_44"), (44, 59, "45_59"), (59, 200, "60_mas")]


def cruzar_ruts(at, personas, empresas, cfg):
    """Agrega a cada atención el tipo de cliente y su ubicación/perfil:
         persona          RUT encontrado en per (domicilio -> manzana)
         empresa          RUT encontrado en emp (dirección comercial -> manzana)
         persona sin dirección verificada (si se exige verificación)
         fuera del área   RUT encontrado pero con domicilio fuera del área de estudio
         sin cruce        RUT que no está en per ni en emp (p. ej. extranjeros sin registro)
         sin RUT          la atención no trae un RUT legible (un RUT vacío nunca se cruza con otro vacío)"""
    O = cfg["origen"]
    o = at.copy()
    con_rut = lambda df: df[df["rut_hash"].astype(str).str.len() > 0]
    p = con_rut(personas).drop_duplicates("rut_hash").set_index("rut_hash")
    e = (con_rut(empresas).drop_duplicates("rut_hash").set_index("rut_hash") if empresas is not None and len(empresas)
         else pd.DataFrame(columns=["ut"]))
    vacio = o["rut_hash"].astype(str).str.len().eq(0).values
    en_p = o["rut_hash"].isin(p.index).values & ~vacio
    en_e = o["rut_hash"].isin(e.index).values & ~en_p & ~vacio
    o["tipo"] = np.select([vacio, en_p, en_e], ["sin RUT", "persona", "empresa"], "sin cruce")
    for c in ("ut", "gse", "edad", "sexo", "renta_hogar", "direccion_verificada"):
        if c in p:
            o[c] = p[c].reindex(o["rut_hash"]).values
    if "ut" in e and en_e.any():
        o.loc[en_e, "ut"] = e["ut"].reindex(o.loc[en_e, "rut_hash"]).values
        for c in ("rubro", "trabajadores_est"):
            if c in e:
                o.loc[en_e, f"emp_{c}"] = e[c].reindex(o.loc[en_e, "rut_hash"]).values
    if O.get("solo_direccion_verificada") and "direccion_verificada" in o:
        v = o["direccion_verificada"].astype(str).str.upper().str[:1]
        o.loc[(o["tipo"] == "persona") & ~v.isin(["S", "1", "T"]), "tipo"] = "persona sin dirección verificada"
    o.loc[o["tipo"].isin(["persona", "empresa"]) & o["ut"].isna(), "tipo"] = "fuera del área"
    return o


def resumen_cruce(o):
    """Cuánto de la venta y de los pacientes se pudo ubicar, por tipo de resultado del cruce."""
    t = o.groupby("tipo").agg(atenciones=("atenciones", "sum"), monto=("monto", "sum"), pacientes=("rut_hash", "nunique"))
    t["% monto"] = t["monto"] / t["monto"].sum()
    t["% pacientes"] = t["pacientes"] / o["rut_hash"].nunique()
    return t.sort_values("monto", ascending=False).reset_index().rename(columns={"tipo": "nivel"})


def cruce_por_sede(o):
    t = o.pivot_table(index="sede", columns="tipo", values="monto", aggfunc="sum", fill_value=0)
    return t.div(t.sum(axis=1), axis=0)


def flujos_rut(o):
    """Flujos manzana × sede de las PERSONAS ubicadas (monto, atenciones y pacientes distintos)."""
    p = o[o["tipo"] == "persona"]
    f = p.groupby(["ut", "sede"]).agg(monto=("monto", "sum"), atenciones=("atenciones", "sum"), pacientes=("rut_hash", "nunique")).reset_index()
    f["nivel"] = "rut (domicilio per)"
    return f


def multisede(o, sedes):
    """Pacientes que usan más de una sede. matriz[a, b] = % de los pacientes de la sede a que también se atienden en b.
    Es la sustitución OBSERVADA entre sedes: sirve para validar la canibalización que predice el modelo."""
    p = o[o["tipo"] == "persona"][["rut_hash", "sede"]].drop_duplicates()
    p = p[p["sede"].isin(sedes)]
    codigos, uniq = pd.factorize(p["rut_hash"])
    js = p["sede"].map({s: k for k, s in enumerate(sedes)}).values
    from scipy import sparse
    M = sparse.csr_matrix((np.ones(len(p)), (codigos, js)), shape=(len(uniq), len(sedes)))
    co = (M.T @ M).toarray()
    diag = np.diag(co).astype(float)
    pct = pd.DataFrame(co / np.maximum(diag[:, None], 1), index=sedes, columns=sedes)
    n_sedes = np.asarray(M.sum(1)).ravel()
    dist = pd.Series(n_sedes).value_counts().sort_index()
    resumen = pd.DataFrame({"sedes distintas usadas": dist.index, "pacientes": dist.values, "% pacientes": dist.values / dist.sum()})
    return pct, resumen


def fidelidad(o):
    """Por sede: pacientes, atenciones por paciente, % con una sola atención, pacientes nuevos por año y retención
    (de los pacientes de un año, cuántos vuelven el año siguiente)."""
    p = o[o["tipo"].isin(["persona", "sin cruce", "fuera del área", "persona sin dirección verificada"])].copy()
    p["anio"] = p["periodo"].astype(str).str[:4]
    g = p.groupby(["sede", "rut_hash"]).agg(at=("atenciones", "sum"), primero=("anio", "min"))
    filas = []
    for s, d in g.groupby(level=0):
        fila = {"sede": s, "pacientes": len(d), "atenciones_por_paciente": d["at"].mean(), "% una sola atención": (d["at"] <= 1).mean()}
        for a, n in d["primero"].value_counts().sort_index().items():
            fila[f"pacientes nuevos {a}"] = n
        filas.append(fila)
    out = pd.DataFrame(filas)
    anios = sorted(p["anio"].unique())
    ret = []
    for s, d in p.groupby("sede"):
        por_anio = d.groupby("anio")["rut_hash"].apply(set)
        for a, b in zip(anios[:-1], anios[1:]):
            if a in por_anio and b in por_anio and len(por_anio[a]):
                ret.append({"sede": s, "de": a, "a": b, "retención": len(por_anio[a] & por_anio[b]) / len(por_anio[a])})
    if ret:
        r = pd.DataFrame(ret).groupby("sede")["retención"].mean().rename("retención anual promedio")
        out = out.merge(r, left_on="sede", right_index=True, how="left")
    return out


def afinidad(o, ut, T, sedes, t80, cfg):
    """Índice de afinidad por GSE, tramo de edad y sexo: (% de pacientes de la sede en la categoría) /
    (% de la población del área de la sede, a ≤ t80 minutos) × 100. 100 = igual que la población; 200 = el doble."""
    G = cfg["gse"]
    p = o[o["tipo"] == "persona"].drop_duplicates(["sede", "rut_hash"]).copy()
    p["tramo_edad"] = pd.cut(pd.to_numeric(p["edad"], errors="coerce"), [a for a, _, _ in TRAMOS_EDAD] + [200],
                             labels=[n for _, _, n in TRAMOS_EDAD])
    p["sexo_c"] = p["sexo"].astype(str).str.upper().str[:1].map({"F": "mujer", "M": "hombre"})
    filas = []
    for j, s in enumerate(sedes):
        ps = p[p["sede"] == s]
        if not len(ps) or not np.isfinite(t80.get(s, np.nan)):
            continue
        area = np.isfinite(T[:, j]) & (T[:, j] <= t80[s])
        u = ut.loc[area]
        pob = {"GSE": pd.Series({g: u[f"pob_{g}"].sum() for g in G}),
               "edad": pd.Series({n: u[f"pob_{n}"].sum() for _, _, n in TRAMOS_EDAD if f"pob_{n}" in u}),
               "sexo": pd.Series({"hombre": u["hombres"].sum(), "mujer": u["mujeres"].sum()})}
        pac = {"GSE": ps["gse"].value_counts(), "edad": ps["tramo_edad"].value_counts(), "sexo": ps["sexo_c"].value_counts()}
        for dim in ("GSE", "edad", "sexo"):
            a = pac[dim].reindex(pob[dim].index).fillna(0)
            pa, pp = a / max(a.sum(), 1), pob[dim] / max(pob[dim].sum(), 1)
            for cat in pob[dim].index:
                filas.append({"sede": s, "dimensión": dim, "categoría": cat, "% pacientes": pa[cat], "% población del área": pp[cat],
                              "índice de afinidad": 100 * pa[cat] / pp[cat] if pp[cat] > 0 else np.nan})
    return pd.DataFrame(filas)


def penetracion_por_unidad(o, ut, minimo=5):
    """Pacientes distintos de toda la red por unidad / población (solo unidades con ≥ minimo pacientes)."""
    p = o[o["tipo"] == "persona"].groupby("ut")["rut_hash"].nunique().rename("pacientes")
    t = ut[["ut", "pob", "comuna"]].merge(p, left_on="ut", right_index=True, how="left").fillna({"pacientes": 0})
    t["pacientes_por_1000_hab"] = 1000 * t["pacientes"] / t["pob"].replace(0, np.nan)
    return t


def empresas_convenio(o):
    """Venta a empresas (RUT de persona jurídica cruzado con emp), por sede."""
    e = o[o["tipo"] == "empresa"]
    if not len(e):
        return pd.DataFrame()
    t = e.groupby("sede").agg(empresas=("rut_hash", "nunique"), atenciones=("atenciones", "sum"), monto=("monto", "sum"))
    t["% de la venta con RUT"] = t["monto"] / o.groupby("sede")["monto"].sum().reindex(t.index)
    if "emp_rubro" in e:
        t["rubros principales"] = e.groupby("sede")["emp_rubro"].agg(lambda s: ", ".join(s.value_counts().head(3).index.astype(str)))
    return t.reset_index()
