# -*- coding: utf-8 -*-
"""Entregables del FRF (sección 4): capas GIS, Excel con fichas técnicas, fichas PDF por ubicación, informe ejecutivo
en PDF y anexo metodológico (Markdown + PDF)."""
import json
import os
import textwrap

import numpy as np
import shapely
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

from .utilidades import miles, mm
from .mapas import COLOR_FORMATO, _sin_huecos_chicos


def _limpiar(df, gpkg=False):
    """Columnas aptas para GPKG/Excel: listas y dicts a JSON, columnas de texto con tipos mezclados a texto,
    infinitos a vacío (los formatos de archivo no los aceptan)."""
    df = df.copy()
    for c in df.columns:
        if c == "geometry" or str(df[c].dtype) == "geometry":
            continue
        if df[c].dtype == object or str(df[c].dtype).startswith(("string", "str")):
            a_json = lambda v: json.dumps(v, ensure_ascii=False, default=str) if isinstance(v, (list, dict, np.ndarray)) else v
            if gpkg:   # GPKG exige un solo tipo por columna: todo a texto
                df[c] = df[c].map(lambda v: None if v is None or (isinstance(v, float) and np.isnan(v)) else str(a_json(v)))
            else:      # Excel acepta tipos mezclados: los números siguen siendo números
                df[c] = df[c].map(a_json)
        elif pd.api.types.is_float_dtype(df[c]):
            df[c] = df[c].replace([np.inf, -np.inf], np.nan)
    df.columns = [str(c) for c in df.columns]
    return df


def guardar_gpkg(capas, ruta):
    """Un GeoPackage con una capa por entrada {nombre: GeoDataFrame}, en WGS84 (listo para Mapdrive, QGIS o ArcGIS)."""
    if os.path.exists(ruta):
        os.remove(ruta)
    for nombre, g in capas.items():
        if g is None or len(g) == 0:
            continue
        _limpiar(g, gpkg=True).to_crs("EPSG:4326").to_file(ruta, layer=nombre, driver="GPKG")
    return ruta


def guardar_excel(hojas, ruta, notas=None):
    """Excel con formato: encabezado azul, filtros, paneles fijos, anchos ajustados, miles y porcentajes."""
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    with pd.ExcelWriter(ruta, engine="openpyxl") as xw:
        if notas:
            pd.DataFrame(notas, columns=["tema", "detalle"]).to_excel(xw, sheet_name="LEEME", index=False)
            ws = xw.sheets["LEEME"]; ws.column_dimensions["A"].width = 32; ws.column_dimensions["B"].width = 120
            for c in ws[1]:
                c.font = Font(name="Arial", bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F4E79")
        for nombre, df in hojas.items():
            if df is None:
                continue
            df = _limpiar(pd.DataFrame(df).drop(columns="geometry", errors="ignore"))
            df.to_excel(xw, sheet_name=nombre[:31], index=False)
            ws = xw.sheets[nombre[:31]]
            for c in ws[1]:
                c.font = Font(name="Arial", bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F4E79")
                c.alignment = Alignment(wrap_text=True, vertical="center")
            ws.freeze_panes = "B2"; ws.auto_filter.ref = ws.dimensions
            for j, col in enumerate(df.columns, start=1):
                s = df[col]
                ancho = min(55, max(10, len(str(col)) + 2, int(s.map(lambda v: len(str(v)) if pd.notna(v) else 0).quantile(0.9)) + 2 if len(s) else 10))
                ws.column_dimensions[get_column_letter(j)].width = ancho
                nom = str(col).lower()
                fmt = None
                if pd.api.types.is_float_dtype(s):
                    if nom.startswith(("pct", "%", "s_", "share")) or "pct" in nom or nom in ("score", "error_pct", "brecha_vs_umbral") or nom.endswith("_pct"):
                        fmt = "0.0%"
                    elif s.abs().max() >= 1000:
                        fmt = "#,##0"
                    else:
                        fmt = "0.000"
                elif pd.api.types.is_integer_dtype(s):
                    fmt = "#,##0"
                for row in ws.iter_rows(min_row=2, min_col=j, max_col=j):
                    for c in row:
                        c.font = Font(name="Arial", size=10)
                        if fmt:
                            c.number_format = fmt
    return ruta


def ficha_larga(top, extras):
    """Fichas técnicas en formato largo (sitio, sección, indicador, valor): fácil de filtrar en Excel."""
    filas = []
    for _, s in top.iterrows():
        e = extras.get(s["id_top"], {})
        sec = {
            "1. Identificación": {"Orden en el plan": s["orden"], "Formato recomendado": s["formato_FRF"], "Comuna": s.get("comuna"),
                                  "Vía de referencia": s.get("via_referencia"), "Latitud": round(s["lat"], 6), "Longitud": round(s["lon"], 6),
                                  "Macrozona (clínica)": e.get("macrozona", "")},
            "2. Venta mensual en régimen (CLP)": {
                "Venta bruta (base)": s["venta_bruta"], "Canibalización (base)": s["canibalizacion"], "Venta neta (base)": s["venta_neta"],
                "Venta neta conservador (P10)": s.get("venta_neta_p10_marginal", np.nan), "Venta neta optimista (P90)": s.get("venta_neta_p90_marginal", np.nan),
                "Umbral de viabilidad": s["umbral_viabilidad"], "Sedes más canibalizadas": s.get("sedes_mas_canibalizadas", "")},
            "3. Proyección anual (CLP, escenario base)": {"Año 1": s.get("venta_anio_1"), "Año 2": s.get("venta_anio_2"),
                                                          "Año 3": s.get("venta_anio_3"), "Régimen": s.get("venta_anual_regimen")},
            "4. Desglose por línea (CLP/mes, base)": e.get("lineas", {}),
            "5. Población y gasto (isócrona de scoring)": {"Minutos de la isócrona": e.get("minutos_isocrona"), "Población": s["pob_isocrona"],
                                                          "Hogares AB, C1a y C1b": s["hog_objetivo_isocrona"],
                                                          "Población AB, C1a y C1b": s["pob_objetivo_isocrona"],
                                                          "Gasto mensual en salud": s["gasto_salud_isocrona"], "Trabajadores": s["trabajadores_isocrona"]},
            "6. Perfil (isócrona)": e.get("perfil", {}),
            "7. Entorno competitivo": {"Competencia ponderada en la isócrona": s["competencia_isocrona"],
                                       "Saturación (competencia por 1.000 personas objetivo)": s["saturacion"],
                                       "Otra oferta de salud (dental, kine, farmacias…)": s.get("oferta_contexto_isocrona"),
                                       "5 competidores más cercanos": e.get("competidores", "")},
            "8. Scoring": {k: s[k] for k in s.index if str(k).startswith("s_")} | {"Score total": s["score"]},
        }
        for seccion, d in sec.items():
            for k, v in d.items():
                if isinstance(v, (float, np.floating)):
                    v = round(float(v)) if abs(v) >= 1000 else round(float(v), 4)
                filas.append({"id_top": s["id_top"], "seccion": seccion, "indicador": k, "valor": v})
    return pd.DataFrame(filas)


# --------------------------------------------------------------------------------------------- PDF
def _tabla_texto(ax, filas, x0=0.0, y0=1.0, dy=0.04, ancho=0.98, fs=8):
    """Tabla de dos columnas (indicador ··· valor). Si el valor es largo, va en la línea siguiente para no encimarse."""
    y = y0
    for k, v in filas:
        if k.startswith("##"):
            y -= dy * 0.4
            ax.text(x0, y, k[2:].strip(), fontsize=fs + 1.5, weight="bold", color="#1F4E79", transform=ax.transAxes, va="top")
        elif len(str(v)) > 22:
            ax.text(x0, y, k, fontsize=fs, transform=ax.transAxes, va="top")
            for linea in textwrap.wrap(str(v), 58) or [""]:          # valores largos: en varias líneas, sin cortarse
                y -= dy * 0.85
                ax.text(x0 + ancho, y, linea, fontsize=fs, transform=ax.transAxes, va="top", ha="right", weight="bold")
        else:
            ax.text(x0, y, k, fontsize=fs, transform=ax.transAxes, va="top")
            ax.text(x0 + ancho, y, str(v), fontsize=fs, transform=ax.transAxes, va="top", ha="right", weight="bold")
        y -= dy
    return y


def _dibujar_poligonos(ax, geoms, colores, borde="white", ancho=0.15, alfa=0.75, zorder=1):
    """Dibuja miles de polígonos de una vez: una sola PolyCollection rasterizada (≈10 veces más rápido que
    GeoDataFrame.plot y un PDF mucho más liviano). Solo anillos exteriores: las manzanas no tienen huecos relevantes."""
    from matplotlib.collections import PolyCollection
    partes, idx = shapely.get_parts(np.asarray(geoms), return_index=True)
    anillos = shapely.get_exterior_ring(partes)
    vacio = shapely.is_empty(anillos)
    anillos, idx = anillos[~vacio], idx[~vacio]
    xy, ix = shapely.get_coordinates(anillos, return_index=True)
    vertices = np.split(xy, np.flatnonzero(np.diff(ix)) + 1)
    pc = PolyCollection(vertices, facecolors=[colores[i] for i in idx], edgecolors=borde, linewidths=ancho, alpha=alfa,
                        zorder=zorder, rasterized=True)
    ax.add_collection(pc)
    return pc


def fichas_pdf(top, extras, manzanas, isos, comp, sedes, ruta, cfg, png_muestra=None):
    """Una página por ubicación del Top: mapa de su isócrona sobre las MANZANAS (población objetivo), la manzana
    candidata destacada, competencia y sedes, + indicadores."""
    crs = cfg["estudio"]["crs_metrico"]
    mzm = manzanas.to_crs(crs); compm = comp[comp["en_modelo"]].to_crs(crs); sm = sedes.to_crs(crs)
    geo_mz = mzm.set_index("ut").geometry if "ut" in mzm else None
    with PdfPages(ruta) as pdf:
        for k_pag, (_, s) in enumerate(top.iterrows()):
            e = extras.get(s["id_top"], {})
            fig = plt.figure(figsize=(11.7, 8.3))
            fig.suptitle(f"{s['id_top']} · {s['formato_FRF']} · {s.get('comuna', '')}", fontsize=14, weight="bold", x=0.02, ha="left", color="#1F4E79")
            ax = fig.add_axes([0.02, 0.06, 0.52, 0.84])
            iso = isos[isos["id"] == s["id_top"]].copy()
            if len(iso):
                iso["geometry"] = iso.geometry.map(_sin_huecos_chicos)          # contorno limpio (sin manzanas sueltas)
                ref = iso[iso["minutos"] == 15] if (iso["minutos"] == 15).any() else iso.sort_values("minutos").iloc[[0]]
                b = ref.total_bounds; pad = 2500
                x0, y0, x1, y1 = b[0] - pad, b[1] - pad, b[2] + pad, b[3] + pad
                vista = mzm.cx[x0:x1, y0:y1]
                if len(vista):
                    v = vista["pob_objetivo"].values.astype(float)
                    cortes = np.unique(np.quantile(v[v > 0], np.linspace(0, 1, 7))) if (v > 0).any() else np.array([0, 1])
                    clase = np.digitize(v, cortes[1:-1], right=True) if len(cortes) > 2 else np.zeros(len(v), int)
                    cm = plt.get_cmap("YlGnBu")
                    colores_mz = [cm(0.12 + 0.85 * c / max(len(cortes) - 2, 1)) if x > 0 else (0.93, 0.93, 0.93, 1) for c, x in zip(clase, v)]
                    _dibujar_poligonos(ax, vista.geometry.values, colores_mz)
                if geo_mz is not None and str(s.get("ut", "")) in geo_mz.index:
                    gpd.GeoSeries([geo_mz.loc[str(s["ut"])]], crs=crs).plot(ax=ax, facecolor=COLOR_FORMATO[s["formato"]], edgecolor="k",
                                                                            linewidth=1.2, alpha=0.9, zorder=4)
                colores = {10: "#C00000", 15: "#ED7D31", 30: "#595959"}
                from matplotlib.patches import Patch
                ley = []
                for _, r in iso.sort_values("minutos", ascending=False).iterrows():
                    c = colores.get(int(r["minutos"]), "#7F7F7F")
                    gpd.GeoSeries([r.geometry], crs=crs).plot(ax=ax, facecolor=c, alpha=0.16, edgecolor="none")
                    partes = getattr(r.geometry, "geoms", [r.geometry])                 # solo el contorno exterior (sin huecos)
                    gpd.GeoSeries([p.exterior for p in partes if p.area > 1e5], crs=crs).plot(ax=ax, color=c, linewidth=2.0, alpha=0.95)
                    ley.append(Patch(facecolor=c, alpha=0.35, edgecolor=c, label=f"isócrona {int(r['minutos'])} min"))
                cc = compm.cx[x0:x1, y0:y1]
                h1 = ax.scatter(cc.geometry.x, cc.geometry.y, s=7, c="#303030", marker="x", linewidths=0.6, alpha=0.55, label="competencia")
                ss = sm.cx[x0:x1, y0:y1]
                h2 = ax.scatter(ss.geometry.x, ss.geometry.y, s=70, c="#C00000", marker="s", edgecolor="w", label="sedes de Clínica Alemana")
                h3 = ax.scatter([s["x"]], [s["y"]], s=320, c=COLOR_FORMATO[s["formato"]], marker="*", edgecolor="k", zorder=5, label="ubicación propuesta")
                ax.set_xlim(x0, x1); ax.set_ylim(y0, y1)
                ax.legend(handles=ley[::-1] + [h1, h2, h3], loc="lower left", fontsize=8, framealpha=0.9)
            ax.set_axis_off()
            ax.set_title("Isócronas en auto (hora punta) · fondo: población AB, C1a y C1b por manzana (más oscuro = más)"
                         + (f" · manzana {s['ut']}" if s.get("ut") is not None else ""), fontsize=9)
            ax2 = fig.add_axes([0.58, 0.06, 0.40, 0.84]); ax2.set_axis_off()
            filas = [("## Venta mensual en régimen (pesos reales)", ""),
                     ("Venta bruta", mm(s["venta_bruta"])), ("Canibalización a sedes actuales", mm(s["canibalizacion"])),
                     ("Venta neta (escenario base)", mm(s["venta_neta"])),
                     ("Venta neta conservador (P10)", mm(s.get('venta_neta_p10_marginal', np.nan))), ("Venta neta optimista (P90)", mm(s.get('venta_neta_p90_marginal', np.nan))),
                     ("Umbral de viabilidad", mm(s["umbral_viabilidad"])), ("Sedes que más pierden", str(s.get("sedes_mas_canibalizadas", ""))),
                     ("## Proyección anual (escenario base)", ""), ("Año 1", mm(s.get("venta_anio_1"))), ("Año 2", mm(s.get("venta_anio_2"))),
                     ("Año 3", mm(s.get("venta_anio_3"))),
                     (f"## Mercado en la isócrona de {e.get('minutos_isocrona', '')} min", ""), ("Población", miles(s["pob_isocrona"])),
                     ("Hogares AB, C1a y C1b", miles(s["hog_objetivo_isocrona"])), ("Gasto mensual en salud", mm(s["gasto_salud_isocrona"])),
                     ("Trabajadores (población flotante)", miles(s["trabajadores_isocrona"])),
                     ("## Entorno competitivo", ""), ("Competencia ponderada", miles(s["competencia_isocrona"], 1)),
                     ("Saturación (por 1.000 personas objetivo)", miles(s["saturacion"], 2)),
                     ("## Scoring", ""), ("Score total (0 a 1)", miles(s["score"], 3)),
                     ("## Ubicación", ""), ("Manzana (ID_BLOCK)", str(s.get("ut", ""))),
                     ("Vía de acceso", textwrap.shorten(str(s.get("via_referencia", "")) or "s/n", 48, placeholder="…")),
                     ("Coordenadas del sitio", f"{s['lat']:.5f}, {s['lon']:.5f}")]
            y = _tabla_texto(ax2, filas)
            comp_txt = e.get("competidores", "")
            ax2.text(0, y - 0.02, "Competidores más cercanos:\n" + "\n".join(textwrap.wrap(comp_txt, 75)[:6]), fontsize=7, transform=ax2.transAxes, va="top")
            pdf.savefig(fig, dpi=200)                            # 200 ppp para la capa de manzanas (rasterizada)
            if png_muestra and k_pag == 0:                       # vista previa de la primera ficha (para el notebook)
                fig.savefig(png_muestra, dpi=100, bbox_inches="tight")
            plt.close(fig)
    return ruta


SIMBOLOS_PDF = {"⚠️": "!", "✅": "✓", "❌": "✗", "➖": "–"}     # emojis que la fuente del PDF no trae -> equivalentes


def _sin_emojis(texto):
    """Texto apto para matplotlib: emojis → símbolos de la fuente y '$' escapado (dos '$' en una línea se leerían
    como una fórmula matemática y el texto saldría en cursiva)."""
    for k, v in SIMBOLOS_PDF.items():
        texto = texto.replace(k, v)
    return texto.replace(r"\$", "$").replace("$", r"\$")


def _pagina_texto(pdf, titulo, parrafos, fs=9):
    parrafos = [_sin_emojis(p) for p in parrafos]
    fig = plt.figure(figsize=(8.3, 11.7))
    fig.text(0.07, 0.95, titulo, fontsize=15, weight="bold", color="#1F4E79")
    y = 0.91
    for p in parrafos:
        if p.startswith("# "):
            y -= 0.008
            fig.text(0.07, y, p[2:], fontsize=fs + 2, weight="bold", color="#1F4E79"); y -= 0.025
            continue
        for linea in textwrap.wrap(p, 100) or [""]:
            fig.text(0.07, y, linea, fontsize=fs, family="DejaVu Sans"); y -= 0.0165
            if y < 0.05:
                pdf.savefig(fig); plt.close(fig)
                fig = plt.figure(figsize=(8.3, 11.7)); y = 0.95
        y -= 0.006
    pdf.savefig(fig); plt.close(fig)


def informe_ejecutivo_pdf(ruta, cfg, kpis, hallazgos, top, figuras, supuestos):
    """Informe ejecutivo: resumen, hallazgos, desempeño del modelo, ranking por formato y supuestos."""
    with PdfPages(ruta) as pdf:
        fig = plt.figure(figsize=(8.3, 11.7))
        fig.text(0.07, 0.88, "Informe Ejecutivo Estratégico", fontsize=24, weight="bold", color="#1F4E79")
        fig.text(0.07, 0.84, cfg["estudio"]["nombre"], fontsize=12)
        fig.text(0.07, 0.81, f"Modo: {cfg['modo']}" + (" · DATOS SIMULADOS (solo para probar el flujo)" if cfg["modo"] == "simulacion" else ""), fontsize=10, color="#C00000")
        y = 0.74
        for k, v in kpis.items():
            fig.text(0.07, y, _sin_emojis(k), fontsize=11); fig.text(0.93, y, _sin_emojis(v), fontsize=11, weight="bold", ha="right"); y -= 0.035
        pdf.savefig(fig); plt.close(fig)
        _pagina_texto(pdf, "Conclusiones del estudio", ["Escritas según los datos de esta corrida: ✓ fortaleza · ! alerta · → oportunidad · • dato."] + hallazgos)
        for f in figuras:
            if os.path.exists(f):
                img = plt.imread(f)
                fig = plt.figure(figsize=(8.3, 11.7)); ax = fig.add_axes([0.05, 0.25, 0.9, 0.65]); ax.imshow(img); ax.set_axis_off()
                pdf.savefig(fig); plt.close(fig)
        if len(top):
            cols = ["id_top", "formato_FRF", "comuna", "venta_neta", "venta_neta_p10_marginal", "venta_neta_p90_marginal", "score"]
            t = top[[c for c in cols if c in top]].copy()
            for c in ("venta_neta", "venta_neta_p10_marginal", "venta_neta_p90_marginal"):
                if c in t:
                    t[c] = t[c].map(mm)
            t["score"] = t["score"].map(lambda v: f"{v:.3f}")
            fig = plt.figure(figsize=(11.7, 8.3)); ax = fig.add_axes([0.02, 0.02, 0.96, 0.9]); ax.set_axis_off()
            ax.set_title("Ranking de ubicaciones prioritarias (venta neta mensual en régimen, P10 y P90)", fontsize=12, loc="left")
            tb = ax.table(cellText=t.values, colLabels=["Id", "Formato", "Comuna", "Neta base", "Neta P10", "Neta P90", "Score"][:t.shape[1]], loc="upper center", cellLoc="left")
            tb.auto_set_font_size(False); tb.set_fontsize(8); tb.scale(1, 1.25)
            pdf.savefig(fig); plt.close(fig)
        _pagina_texto(pdf, "Supuestos y alcances", [f"• {a}: {b}. {c}" for a, b, c in supuestos] +
                      ["", "Las ventas estimadas son proyecciones del modelo bajo los supuestos documentados en el Anexo Metodológico, "
                           "no compromisos de resultado (FRF sección 6)."])
    return ruta


def anexo_metodologico(ruta_md, cfg, secciones):
    """Anexo metodológico en Markdown (y PDF al lado). `secciones`: lista de (título, texto)."""
    L = [f"# Anexo metodológico · {cfg['estudio']['nombre']}", ""]
    for t, txt in secciones:
        L += [f"## {t}", "", txt, ""]
    with open(ruta_md, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    with PdfPages(ruta_md.replace(".md", ".pdf")) as pdf:
        par = []
        for t, txt in secciones:
            par.append("# " + t)
            par += [l for l in txt.split("\n")]
        _pagina_texto(pdf, "Anexo metodológico", par, fs=8)
    return ruta_md


def tabla_md(df, dec=3):
    if df is None or len(df) == 0:
        return ""
    f = lambda v: (f"{v:,.{dec}f}" if abs(v) < 1e5 else f"{v:,.0f}") if isinstance(v, (float, np.floating)) and np.isfinite(v) else str(v)
    filas = ["| " + " | ".join(map(str, df.columns)) + " |", "|" + "---|" * len(df.columns)]
    filas += ["| " + " | ".join(f(v) for v in r) + " |" for r in df.itertuples(index=False)]
    return "\n".join(filas)
