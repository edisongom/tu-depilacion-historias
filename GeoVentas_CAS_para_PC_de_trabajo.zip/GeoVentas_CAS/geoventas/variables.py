# -*- coding: utf-8 -*-
"""Variables territoriales por MANZANA, a partir de las bases Equifax con sus columnas originales.

Cada función recibe una tabla que ya trae la columna `clave` (id de la unidad a la que pertenece cada registro) y
devuelve una tabla indexada por esa clave (el id de la manzana).

  censo   población, hogares, viviendas, ingreso y gasto por GSE, edades, uso de suelo
  per     perfil de las personas (edad, sexo, GSE, hijos, autos, BBRR, Dicom, renta del hogar)
  emp     empresas y trabajadores (población flotante diurna)
  pois    equipamiento (metro, malls, colegios, oficinas, salud...) según CAT1/CAT2/CAT3
  bbrr    destino de las propiedades (habitacional, comercio, oficinas, salud) y avalúo
  calles  km de vías y de vías principales (Maestro de Calles)
"""
import numpy as np
import pandas as pd

from .utilidades import norm_serie

def _num(df, col):
    return pd.to_numeric(df[col], errors="coerce").fillna(0.0) if col in df.columns else pd.Series(0.0, index=df.index)


def factor_gasto_mensual(cfg):
    """Factor que lleva el gasto del censo a CLP mensuales totales de la manzana."""
    return {"mensual_total": 1.0, "anual_total": 1 / 12}.get(cfg["censo"]["unidad_gasto"], 1.0)


def columnas_censo(censo, cfg):
    """Variables numéricas de cada manzana (sin agregar): población, hogares, ingreso, gasto por GSE y categoría, edades."""
    C = cfg["columnas"]["censo"]; G = cfg["gse"]; cat = cfg["censo"]["categoria_gasto_salud"]
    df = censo
    out = pd.DataFrame(index=df.index)
    for k in ("pob", "hog", "viv", "ing", "gasto", "hombres", "mujeres", "casas", "deptos"):
        out[k] = _num(df, C[k]).values
    fac = factor_gasto_mensual(cfg)
    unidad = cfg["censo"]["unidad_gasto"]
    for g in G:
        out[f"pob_{g}"] = _num(df, C["pob_gse"].format(gse=g)).values
        out[f"hog_{g}"] = _num(df, C["hog_gse"].format(gse=g)).values
        out[f"ing_{g}"] = _num(df, C["ing_gse"].format(gse=g)).values
        gs = _num(df, C["gasto_cat_gse"].format(cat=cat, gse=g)).values
        if unidad == "mensual_por_hogar":
            gs = gs * out[f"hog_{g}"].values
        elif unidad == "mensual_por_persona":
            gs = gs * out[f"pob_{g}"].values
        out[f"gasto_salud_{g}"] = gs * fac
    for c in cfg["censo"]["categorias_gasto"]:
        out[f"gasto_{c.lower()}"] = _num(df, C["gasto_cat"].format(cat=c)).values * fac
    for e in C["edades"]:
        out[e.lower()] = _num(df, e).values
    out["n_manzanas"] = 1.0
    return out


def derivadas(t, cfg):
    """Variables derivadas que se recalculan después de agregar (no se suman)."""
    G = cfg["gse"]; obj = cfg["gse_objetivo"]
    t["gasto_salud_total"] = t[[f"gasto_salud_{g}" for g in G]].sum(axis=1)
    t["pob_objetivo"] = t[[f"pob_{g}" for g in obj]].sum(axis=1)
    t["hog_objetivo"] = t[[f"hog_{g}" for g in obj]].sum(axis=1)
    t["gasto_salud_objetivo"] = t[[f"gasto_salud_{g}" for g in obj]].sum(axis=1)
    pob = t["pob"].replace(0, np.nan)
    t["pct_objetivo"] = (t["pob_objetivo"] / pob).fillna(0)
    viv = (t["casas"] + t["deptos"]).replace(0, np.nan)
    t["pct_deptos"] = (t["deptos"] / viv).fillna(0)
    t["pct_60_mas"] = (t.get("pob_60_mas", 0) / pob).fillna(0)
    return t


def variables_censo(censo, cfg, clave):
    """Variables del censo por manzana (1 a 1) + comuna y GSE predominantes."""
    C = cfg["columnas"]["censo"]
    num = columnas_censo(censo, cfg)
    num["_k"] = censo[clave].values
    agg = num.groupby("_k").sum()
    agg = derivadas(agg, cfg)
    extra = pd.DataFrame({"_k": censo[clave].values, "pob": num["pob"].values,
                          "comuna": censo[C["comuna"]].astype(str).values if C["comuna"] in censo else "s/i",
                          "cod_comuna": censo[C["cod_comuna"]].astype(str).str.zfill(5).values if C["cod_comuna"] in censo else "",
                          "gse_predominante": censo[C["gse_predominante"]].astype(str).values if C["gse_predominante"] in censo else "",
                          "uso_suelo": censo[C["uso_suelo"]].astype(str).values if C["uso_suelo"] in censo else ""})
    dom = extra.sort_values("pob", ascending=False).drop_duplicates("_k").set_index("_k")
    agg = agg.join(dom[["comuna", "cod_comuna", "gse_predominante", "uso_suelo"]])
    agg.index.name = clave
    return agg


def variables_personas(per, cfg, clave):
    df = per[per[clave].notna()]
    out = pd.DataFrame({"per_n": df.groupby(clave).size()})
    if "gse" in df:
        ct = pd.crosstab(df[clave], df["gse"].fillna("S/I")).reindex(columns=cfg["gse"], fill_value=0)
        out = out.join(ct.add_prefix("per_gse_"))
    if "edad" in df:
        tramo = pd.cut(df["edad"], [-1, 14, 29, 44, 64, 200], labels=["0_14", "15_29", "30_44", "45_64", "65_mas"])
        out = out.join(pd.crosstab(df[clave], tramo).add_prefix("per_edad_"))
    num = pd.DataFrame(index=df.index)
    if "sexo" in df:
        num["per_pct_mujer"] = norm_serie(df["sexo"]).str[:1].eq("f").astype(float).values
    for c, nom in (("hijos", "per_hijos_prom"), ("vehiculos", "per_vehiculos_prom"), ("bbrr", "per_bbrr_prom"),
                   ("personas_hogar", "per_personas_hogar_prom")):
        if c in df:
            num[nom] = pd.to_numeric(df[c], errors="coerce")
    if "dicom" in df:
        d = norm_serie(df["dicom"].astype(str))
        num["per_pct_dicom"] = (~d.isin(["", "0", "n", "no", "nan", "none", "false"])).astype(float).values
    if len(num.columns):
        out = out.join(num.assign(_k=df[clave].values).groupby("_k").mean())
    if "renta_hogar" in df:
        out = out.join(df.groupby(clave)["renta_hogar"].median().rename("per_renta_hogar_mediana"))
    out.index.name = clave
    return out


def variables_empresas(emp, cfg, clave):
    df = emp[emp[clave].notna()]
    g = df.groupby(clave)
    out = pd.DataFrame({"emp_n": g.size(), "trabajadores_est": g["trabajadores_est"].sum(), "emp_salud_n": g["es_salud"].sum()})
    out["trabajadores_salud"] = df[df["es_salud"]].groupby(clave)["trabajadores_est"].sum()
    return out.fillna(0)


def variables_pois(pois, cfg, clave):
    df = pois[pois[clave].notna()]
    out = pd.DataFrame(index=pd.Index(sorted(df[clave].unique()), name=clave))
    for var, rx in cfg["pois"].items():
        m = df["categoria_txt"].str.contains(rx, regex=True)
        out[var] = df[m.values].groupby(clave).size()
    out["poi_total"] = df.groupby(clave).size()
    return out.fillna(0)


def variables_bbrr(bbrr, cfg, clave):
    df = bbrr[bbrr[clave].notna()]
    out = pd.crosstab(df[clave], df["grupo_destino"]).add_prefix("bbrr_")
    out["bbrr_total"] = out.sum(axis=1)
    if "avaluo" in df:
        hab = df[df["grupo_destino"] == "habitacional"]
        out = out.join(hab.groupby(clave)["avaluo"].median().rename("bbrr_avaluo_hab_mediano"))
    return out


def variables_calles(calles, cfg, clave):
    """Km de calles y de vías principales por unidad (cada tramo cuenta en la unidad de su punto medio)."""
    S = cfg["street"]
    df = calles[calles[clave].notna()]
    jer = pd.to_numeric(df.get("jerarquia"), errors="coerce")
    tipo = norm_serie(df.get("tipo", pd.Series("", index=df.index))).str.upper()
    principal = jer.isin(S["jerarquia_principal"]).values | tipo.isin([t.upper() for t in S["tipos_principales"]]).values
    t = pd.DataFrame({"k": df[clave].values, "km": df["_largo_km"].values, "principal": principal})
    return pd.DataFrame({"calles_km": t.groupby("k")["km"].sum(), "vias_principales_km": t[t["principal"]].groupby("k")["km"].sum()}).fillna(0).rename_axis(clave)


def unir_variables(partes):
    """Une las tablas de variables (por la misma clave) y completa vacíos con 0 en las numéricas."""
    tabla = pd.concat(partes, axis=1)
    num = tabla.select_dtypes(include="number").columns
    tabla[num] = tabla[num].fillna(0)
    for c in ("comuna", "cod_comuna", "gse_predominante", "uso_suelo"):
        if c in tabla:
            tabla[c] = tabla[c].fillna("s/i")
    return tabla
