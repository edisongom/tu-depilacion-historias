# -*- coding: utf-8 -*-
"""Lectura FLEXIBLE de la data de Clínica Alemana.

Todavía no sabemos el formato exacto en que llegará la data (solo que son 5 años de ventas). Por eso este módulo:
  * acepta csv, txt, xlsx y parquet, con o sin filas de instrucciones antes del encabezado;
  * reconoce las columnas por sinónimos (config COLUMNAS_CLIENTE), sin importar tildes ni mayúsculas;
  * reconoce fechas en casi cualquier formato (2025-03, 202503, 03/2025, mar-2025, fecha completa, serial de Excel, 2025);
  * acepta tablas "anchas" (una columna por mes) y las pasa a formato largo;
  * acepta tablas agregadas (sede × mes × línea) o TRANSACCIONALES (una fila por atención, con fecha diaria); los archivos
    grandes se leen por bloques y se agregan al vuelo (decenas de millones de filas sin cargar todo en memoria);
  * reconoce la UNIDAD de los montos (pesos, miles, millones o UF) por el nombre de la columna y por su magnitud, y
    lleva todo a pesos; si no se puede saber, se detiene y la pide (UNIDAD_MONTO en config_estudio.py);
  * descarta filas de ejemplo y totales, y reporta todo lo que hizo.
"""
import difflib
import os
import re
import unicodedata

import numpy as np
import pandas as pd

from .utilidades import norm_txt, norm_serie, codificacion
from .lectura import ruta_local
from . import coordenadas

MESES = {"ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6, "jul": 7, "ago": 8, "sep": 9, "set": 9, "oct": 10, "nov": 11, "dic": 12,
         "jan": 1, "apr": 4, "aug": 8, "dec": 12}


# --------------------------------------------------------------------------------------------- LECTURA GENÉRICA
def leer_tabla(ruta, cfg, campos_esperados=None, nrows=None):
    """Lee una tabla del cliente y ubica la fila de encabezado (la que contiene más nombres de columna conocidos).
    `nrows` lee solo las primeras filas (para reconocer columnas en archivos grandes)."""
    ruta_l = ruta_local(ruta, cfg)
    ext = ruta_l.lower().rsplit(".", 1)[-1]
    if ext in ("parquet", "pq"):
        return pd.read_parquet(ruta_l) if nrows is None else pd.read_parquet(ruta_l).head(nrows)
    if ext in ("xlsx", "xlsm", "xls"):
        crudo = pd.read_excel(ruta_l, header=None, dtype=object, nrows=None if nrows is None else nrows + 20)
    else:
        cod = codificacion(ruta_l)
        with open(ruta_l, "r", encoding=cod, errors="replace") as f:
            muestra = [f.readline() for _ in range(20)]
        sep = max([",", ";", "|", "\t"], key=lambda s: sum(l.count(s) for l in muestra))
        crudo = pd.read_csv(ruta_l, sep=sep, header=None, dtype=str, encoding=cod, encoding_errors="replace",
                            on_bad_lines="skip", low_memory=False, nrows=None if nrows is None else nrows + 20)
    conocidos = {norm_txt(s) for lista in cfg["columnas_cliente"].values() for s in lista}
    mejor, fila_enc = -1, 0
    for i in range(min(15, len(crudo))):
        v = [norm_txt(x) for x in crudo.iloc[i].tolist()]
        n = sum(x in conocidos for x in v if x)
        if n > mejor:
            mejor, fila_enc = n, i
    df = crudo.iloc[fila_enc + 1:].copy()
    df.columns = [str(c).strip() if pd.notna(c) else f"col_{k}" for k, c in enumerate(crudo.iloc[fila_enc].tolist())]
    df = df.dropna(how="all")
    if fila_enc > 0:
        print(f"  {os.path.basename(ruta_l)}: se saltaron {fila_enc} filas de instrucciones antes del encabezado")
    return df.reset_index(drop=True)


def detectar_columnas(df, cfg, campos):
    """{campo lógico: columna real} usando la lista de sinónimos de config (match exacto normalizado, luego parcial)."""
    reales = {norm_txt(c): c for c in df.columns}
    out = {}
    for campo in campos:
        for sin in cfg["columnas_cliente"].get(campo, []):
            s = norm_txt(sin)
            if s in reales and reales[s] not in out.values():
                out[campo] = reales[s]
                break
        if campo not in out:
            for sin in cfg["columnas_cliente"].get(campo, []):
                s = norm_txt(sin)
                cand = [r for n, r in reales.items() if (s in n.split() or n.startswith(s)) and r not in out.values()]
                if cand:
                    out[campo] = cand[0]
                    break
    return out


def parsear_periodo(serie):
    """Convierte fechas en casi cualquier formato a texto 'AAAA-MM' (o 'AAAA' si solo viene el año).
    Cada valor DISTINTO se interpreta una sola vez (factorize): 10 millones de atenciones con fecha diaria son ~1.800
    fechas distintas en 5 años, así que el costo no depende del número de filas."""
    s = pd.Series(serie)
    codigos, unicos = pd.factorize(s.astype("object"), use_na_sentinel=True)
    valores = np.array([_periodo_uno(u) for u in unicos] + [None], dtype=object)    # el último = vacío (código −1)
    return pd.Series(valores[codigos], index=s.index, dtype=object)


def _periodo_uno(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    if isinstance(v, (pd.Timestamp, np.datetime64)) or hasattr(v, "year") and hasattr(v, "month"):
        t = pd.Timestamp(v)
        return f"{t.year:04d}-{t.month:02d}"
    if isinstance(v, (int, float, np.integer, np.floating)):
        x = float(v)
        if 1990 <= x <= 2100:
            return f"{int(x)}"
        if 199001 <= x <= 210012:
            return f"{int(x) // 100:04d}-{int(x) % 100:02d}"
        if 20000 <= x <= 80000:                       # serial de Excel
            t = pd.Timestamp("1899-12-30") + pd.Timedelta(days=x)
            return f"{t.year:04d}-{t.month:02d}"
        return None
    t = norm_txt(v)
    m = re.fullmatch(r"(\d{4}) (\d{1,2})(?: \d{1,2})?(?: \d.*)?", t)         # 2025-03, 2025/03, 2025-03-15
    if m and 1 <= int(m.group(2)) <= 12:
        return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}"
    m = re.fullmatch(r"(?:(\d{1,2}) )?(\d{1,2}) (\d{4})(?: .*)?", t)            # 03-2025, 15-03-2025
    if m and 1 <= int(m.group(2)) <= 12:
        return f"{int(m.group(3)):04d}-{int(m.group(2)):02d}"
    m = re.fullmatch(r"(\d{4})(\d{2})", t)                                        # 202503
    if m and 1 <= int(m.group(2)) <= 12:
        return f"{m.group(1)}-{m.group(2)}"
    m = re.fullmatch(r"([a-z]{3})[a-z]* (?:de )?(\d{2,4})", t)                  # mar-2025, marzo 2025, mar-25
    if m and m.group(1) in MESES:
        a = int(m.group(2)); a = a + 2000 if a < 100 else a
        return f"{a:04d}-{MESES[m.group(1)]:02d}"
    m = re.fullmatch(r"(\d{4})", t)
    if m:
        return m.group(1)
    try:
        ts = pd.to_datetime(v, dayfirst=True, errors="raise")
        return f"{ts.year:04d}-{ts.month:02d}"
    except Exception:
        return None


def ancho_a_largo(df, cfg):
    """Si la tabla trae una columna por mes (formato ancho), la pasa a formato largo (periodo, monto)."""
    per = {c: _periodo_uno(c) for c in df.columns}
    cols_per = [c for c, p in per.items() if p and len(p) == 7]
    if len(cols_per) < 6:
        return df, False
    ids = [c for c in df.columns if c not in cols_per]
    largo = df.melt(id_vars=ids, value_vars=cols_per, var_name="periodo", value_name="monto")
    largo["periodo"] = largo["periodo"].map(per)
    print(f"  tabla en formato ancho ({len(cols_per)} columnas de meses): convertida a formato largo")
    return largo, True


def _numero(serie):
    """Números escritos de cualquier forma -> float: '1.234.567', '1,234,567', '$ 1.234', '1234,5', '945,803526',
    '(1.234)' (negativo contable), '-1.234'.

    La convención de separadores se decide UNA vez para toda la columna (como el dígito verificador del RUT): si los
    valores muestran miles con punto o decimales con coma ('1.234.567', '1234,5', '945,803526') la columna es chilena;
    si muestran miles con coma o decimales con punto ('1,234,567', '0.4567') es anglosajona. Sin evidencia se asume la
    chilena. Así '945,804' en una columna en millones no se lee como 945.804 pesos por error. Las columnas ya numéricas y
    los enteros simples van por un camino rápido."""
    s = pd.Series(serie)
    if pd.api.types.is_numeric_dtype(s):
        return s.astype(float).values
    s = s.astype("object").where(s.notna(), None).astype(str).str.strip()
    out = pd.to_numeric(s.where(s.str.fullmatch(r"-?\d+")), errors="coerce").values.astype(float)
    resto = np.isnan(out) & ~s.isin(["", "None", "nan", "NaN", "-"]).values
    if resto.any():
        r = s[resto].str.replace(r"[$\s]|clp|uf", "", regex=True, case=False)
        neg = r.str.fullmatch(r"\(.*\)").fillna(False).values
        r = r.str.strip("()")
        chilena = r.str.fullmatch(r"-?\d{1,3}(?:\.\d{3})+(?:,\d+)?|-?\d+,\d{1,2}|-?\d+,\d{4,}").sum()
        anglo = r.str.fullmatch(r"-?\d{1,3}(?:,\d{3})+(?:\.\d+)?|-?\d+\.\d{1,2}|-?\d+\.\d{4,}").sum()
        if anglo > chilena:
            r = r.str.replace(",", "", regex=False)
        else:
            r = r.str.replace(".", "", regex=False).str.replace(",", ".", regex=False)
        out[resto] = pd.to_numeric(r, errors="coerce").values * np.where(neg, -1.0, 1.0)
    return out


def _filas_validas(df, col_sede):
    """Descarta filas de ejemplo, totales y vacías."""
    txt = norm_serie(df[col_sede].astype(str))
    malas = txt.str.contains(r"ejemplo|ficticio|^total|subtotal|^nan$|^$", regex=True)
    return df.loc[~malas.values]


# --------------------------------------------------------------------------------------------- VENTAS
CAMPOS_VENTAS = ["sede", "periodo", "linea", "prevision", "monto", "atenciones", "pacientes", "ticket"]
CLAVE_VENTAS = ["sede_cliente", "periodo", "linea", "prevision"]
MB_LECTURA_POR_BLOQUES = 150          # ventas en csv/txt más grandes que esto se leen por bloques y se agregan al vuelo


def _estandarizar_ventas(df, m):
    """Bloque de la tabla de ventas → columnas estándar (sede_cliente, periodo, linea, prevision, monto, atenciones,
    pacientes). Devuelve (tabla, filas con fecha no reconocida, ejemplos de esas fechas)."""
    df = _filas_validas(df, m["sede"])
    out = pd.DataFrame({"sede_cliente": df[m["sede"]].astype(str).str.strip().values,
                        "periodo": parsear_periodo(df[m["periodo"]]).values})
    out["linea"] = df[m["linea"]].astype(str).str.strip().values if "linea" in m else "total"
    out["prevision"] = df[m["prevision"]].astype(str).str.strip().values if "prevision" in m else "sin detalle"
    out["monto"] = _numero(df[m["monto"]]) if "monto" in m else np.nan
    out["atenciones"] = _numero(df[m["atenciones"]]) if "atenciones" in m else np.nan
    out["pacientes"] = _numero(df[m["pacientes"]]) if "pacientes" in m else np.nan
    if "monto" not in m and "ticket" in m:
        out["monto"] = out["atenciones"] * _numero(df[m["ticket"]])
    malas = out["periodo"].isna().values
    ejemplos = df.loc[malas, m["periodo"]].head(3).tolist() if malas.any() else []
    return out[~malas].reset_index(drop=True), int(malas.sum()), ejemplos


def agregar_ventas(v):
    """Suma las filas de una misma sede × mes × línea × previsión (montos, atenciones, pacientes) y cuenta cuántas
    filas originales había en cada una (`filas_origen`)."""
    num = [c for c in ("monto", "atenciones", "pacientes") if c in v]
    filas = v["filas_origen"] if "filas_origen" in v else pd.Series(1, index=v.index)
    g = v.assign(filas_origen=filas).groupby(CLAVE_VENTAS, sort=False, dropna=False)
    out = g[num].sum(min_count=1)
    out["filas_origen"] = g["filas_origen"].sum()
    return out.reset_index()


def _validar_columnas_ventas(m, columnas):
    if "sede" not in m or "periodo" not in m or ("monto" not in m and "atenciones" not in m):
        from .insumos import FaltanInsumos
        raise FaltanInsumos(f"❌ Ventas de la clínica: no se reconocieron las columnas mínimas (sede, periodo y monto). "
                            f"Columnas del archivo: {list(columnas)[:25]}.\n"
                            '     → Agrega el nombre real en config_estudio.py, p. ej. COLUMNAS_CLIENTE["monto"].insert(0, "NOMBRE_EXACTO").')


def leer_ventas_cliente(cfg, nrows=None):
    """Ventas del cliente estandarizadas: sede_cliente, periodo (AAAA-MM), linea, prevision, monto (EN PESOS),
    atenciones, pacientes.

    * Tabla agregada (una fila por sede × mes × línea × previsión): se lee completa.
    * Tabla transaccional grande (csv/txt > 150 MB, p. ej. una fila por atención con fecha diaria): se lee por bloques de
      2 millones de filas, solo con las columnas reconocidas, y cada bloque se agrega a sede × mes × línea × previsión.
    * La unidad de los montos se reconoce (o se pide) y todo queda en pesos (ver `unidad_monto`).
    `nrows` lee solo las primeras filas (lo usa el asistente de insumos para revisar sin cargar el archivo)."""
    ruta = cfg["rutas"].get("ventas_cliente")
    if not ruta:
        raise ValueError("Falta RUTAS['ventas_cliente'] en config_estudio.py")
    ruta_l = ruta_local(ruta, cfg)
    ext = ruta_l.lower().rsplit(".", 1)[-1]
    por_bloques = nrows is None and ext in ("csv", "txt") and os.path.getsize(ruta_l) > MB_LECTURA_POR_BLOQUES * 1e6
    malas, ejemplos = 0, []
    if not por_bloques:
        df = leer_tabla(ruta_l, cfg, nrows=nrows)
        df, ancho = ancho_a_largo(df, cfg)
        m = detectar_columnas(df, cfg, CAMPOS_VENTAS)
        _validar_columnas_ventas(m, df.columns)
        out, malas, ejemplos = _estandarizar_ventas(df, m)
        out.attrs["filas_leidas"] = len(df)
        del df
    else:
        muestra = leer_tabla(ruta_l, cfg, nrows=300)
        m = detectar_columnas(muestra, cfg, CAMPOS_VENTAS)
        _validar_columnas_ventas(m, muestra.columns)
        sep, fila_enc = _encabezado_csv(ruta_l, cfg)
        usar = set(m.values())
        partes, leidas = [], 0
        for df in pd.read_csv(ruta_l, sep=sep, skiprows=fila_enc, header=0, usecols=lambda c: c.strip() in usar, dtype=str,
                              chunksize=2_000_000, encoding=codificacion(ruta_l), encoding_errors="replace", on_bad_lines="skip"):
            df.columns = [c.strip() for c in df.columns]
            leidas += len(df)
            o, k, ej = _estandarizar_ventas(df, m)
            malas += k; ejemplos = ejemplos or ej
            partes.append(agregar_ventas(o))
        out = agregar_ventas(pd.concat(partes, ignore_index=True))
        out.attrs["filas_leidas"] = leidas
        out.attrs["granularidad"] = "transaccional"
        print(f"  archivo grande ({os.path.getsize(ruta_l) / 1e6:,.0f} MB): {leidas:,} filas leídas por bloques y agregadas a "
              f"{len(out):,} combinaciones sede × mes × línea × previsión")
    print("  columnas reconocidas en ventas:", {k: v for k, v in m.items()})
    if malas:
        print(f"  {malas:,} filas con fecha no reconocida (se descartan). Ejemplos: {ejemplos}")
    out.attrs["columnas"] = m
    if nrows is None:
        u = unidad_monto(out, m.get("monto") or m.get("ticket"), cfg)
        if u["unidad"] is None:
            from .insumos import FaltanInsumos
            raise FaltanInsumos(f"❌ Unidad de los montos de venta: {u['explicacion']}\n     → {u['que_hacer']}")
        print(f"  unidad de los montos: {u['explicacion']}")
        if u["factor"] != 1:
            out["monto"] = out["monto"] * u["factor"]
        out.attrs["unidad_monto"] = u
    return out


# --------------------------------------------------------------------------------------------- UNIDAD DE LOS MONTOS
UNIDADES_MONTO = {"pesos": 1.0, "miles": 1e3, "millones": 1e6, "uf": None}
NOMBRE_UNIDAD = {"pesos": "pesos", "miles": "miles de pesos", "millones": "millones de pesos", "uf": "UF"}
# Rangos plausibles EN PESOS para una sede de una red de salud privada (amplios a propósito: solo descartan unidades
# imposibles). Una toma de muestras chica vende ~10–30 millones al mes; una clínica grande, decenas de miles de millones.
RANGO_VENTA_SEDE_MES = (3e6, 3e11)    # de $3 millones a $300.000 millones al mes por sede
RANGO_TICKET = (2e3, 1e7)             # de $2 mil a $10 millones por atención (promedio de una sede en un mes)


def _pista_unidad(nombre):
    """Unidad que delata el nombre de la columna (monto_clp, venta_mm, venta_miles, monto_uf…) o None."""
    t = unicodedata.normalize("NFKD", str(nombre or "")).encode("ascii", "ignore").decode().lower()
    t = " " + re.sub(r"[^a-z0-9$]+", " ", t).strip() + " "          # conserva el signo $ (m$, mm$)
    for patron, u in ((r" (mm|mmclp|mm\$|millones|mill|mmpesos) ", "millones"), (r" (miles|m\$|mclp|kclp|k\$) ", "miles"),
                      (r" uf ", "uf"), (r" (clp|pesos|\$) ", "pesos")):
        if re.search(patron, t):
            return u
    return None


def unidad_monto(v, columna, cfg):
    """Unidad en que vienen los montos de venta y el factor para llevarlos a pesos.

    Orden: (1) UNIDAD_MONTO de config si no es "auto"; (2) el nombre de la columna (monto_clp → pesos, venta_mm →
    millones, venta_miles → miles, monto_uf → UF); (3) la magnitud: la venta mediana de una sede en un mes y el ticket
    mediano (monto / atenciones) deben caer en rangos plausibles en pesos. Si una sola unidad es plausible, se usa; si
    ninguna o varias lo son, `unidad` = None y el notebook se detiene y la pide (no se adivina).
    Devuelve dict: unidad, factor, explicacion, que_hacer, venta_sede_mes_mediana, ticket_mediano (en la unidad original)."""
    eleccion = (cfg.get("unidad_monto") or "auto")
    valor_uf = cfg.get("valor_uf")
    mensual = v[v["periodo"].astype(str).str.len() == 7]
    g = mensual.groupby(["sede_cliente", "periodo"])[["monto", "atenciones"]].sum(min_count=1)
    venta = g["monto"][g["monto"] > 0]
    mes = float(venta.median()) if len(venta) else np.nan
    tk = (g["monto"] / g["atenciones"].where(g["atenciones"] > 0)).replace([np.inf, -np.inf], np.nan)
    tk = float(tk[tk > 0].median()) if tk.notna().any() else np.nan
    factores = {u: (f if f is not None else (valor_uf or 40_000.0)) for u, f in UNIDADES_MONTO.items()}
    def plausible(u):
        f = factores[u]
        ok = np.isfinite(mes) and RANGO_VENTA_SEDE_MES[0] <= mes * f <= RANGO_VENTA_SEDE_MES[1]
        return bool(ok and (not np.isfinite(tk) or RANGO_TICKET[0] <= tk * f <= RANGO_TICKET[1]))
    def en_pesos(u):
        f = factores[u]
        txt = f"venta mediana de una sede ${_millones(mes * f)} al mes"
        return txt + (f", ticket mediano ${_entero(tk * f)}" if np.isfinite(tk) else "")
    lineas = "\n".join(f'       UNIDAD_MONTO = "{u}"' + " " * (10 - len(u)) + f"# {NOMBRE_UNIDAD[u]} → {en_pesos(u)}" for u in ("pesos", "miles", "millones"))
    que_hacer = ("Escribe en config_estudio.py la unidad en que viene la columna de montos:\n" + lineas
                 + '\n       UNIDAD_MONTO = "uf"        # UF (además: VALOR_UF = valor de la UF del último mes de la serie)')
    base = {"venta_sede_mes_mediana": mes, "ticket_mediano": tk, "columna": columna, "que_hacer": que_hacer}
    pista = _pista_unidad(columna)
    if eleccion != "auto":
        if eleccion not in UNIDADES_MONTO:
            return {**base, "unidad": None, "factor": None, "explicacion": f"UNIDAD_MONTO = {eleccion!r} no es válida"}
        u, origen = eleccion, "UNIDAD_MONTO en config_estudio.py"
    elif pista:
        u, origen = pista, f"el nombre de la columna '{columna}'"
    else:
        candidatas = [u for u in ("pesos", "miles", "millones") if plausible(u)]
        if len(candidatas) != 1:
            motivo = ("ninguna unidad da cifras plausibles" if not candidatas else
                      "las cifras son plausibles en " + " y en ".join(NOMBRE_UNIDAD[u] for u in candidatas))
            return {**base, "unidad": None, "factor": None,
                    "explicacion": f"no se puede saber en qué unidad viene '{columna}' ({motivo}: en la unidad original, venta "
                                   f"mediana de una sede {_entero(mes)} al mes" + (f", ticket mediano {_entero(tk, 2)}" if np.isfinite(tk) else "") + ")."}
        u, origen = candidatas[0], "la magnitud de los montos: es la única unidad con cifras plausibles"
    if u == "uf" and not valor_uf:
        return {**base, "unidad": None, "factor": None,
                "explicacion": f"los montos vienen en UF ({origen}) y falta el valor de la UF para llevarlos a pesos.",
                "que_hacer": "Escribe en config_estudio.py VALOR_UF = <valor de la UF del último mes de la serie> (p. ej. 39876.5)."}
    aviso = "" if plausible(u) else " ⚠️ Las cifras resultan poco usuales para una sede: confirma la unidad con la clínica."
    return {**base, "unidad": u, "factor": float(factores[u]), "plausible": plausible(u),
            "explicacion": f"{NOMBRE_UNIDAD[u]}, según {origen} → {en_pesos(u)}.{aviso}"}


def _millones(x):
    if not np.isfinite(x):
        return "–"
    m = x / 1e6
    txt = f"{m:,.0f}" if abs(m) >= 100 else f"{m:,.1f}" if abs(m) >= 1 else f"{m:,.3f}"
    return txt.replace(",", "X").replace(".", ",").replace("X", ".") + (" millón" if txt == "1.0" else " millones")


def _entero(x, dec=0):
    return "–" if not np.isfinite(x) else f"{x:,.{dec}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def leer_sedes_cliente(cfg):
    ruta = cfg["rutas"].get("sedes_cliente")
    if not ruta:
        return None
    df = leer_tabla(ruta, cfg)
    m = detectar_columnas(df, cfg, ["sede", "nombre", "formato", "direccion", "comuna_sede", "fecha_apertura", "fecha_cierre", "m2",
                                    "boxes", "camas", "pabellones", "prestaciones", "lat", "lon"])
    print("  columnas reconocidas en sedes:", m)
    df = _filas_validas(df, m["sede"])
    out = pd.DataFrame({k: df[v].values for k, v in m.items()})
    out = out.rename(columns={"sede": "sede_cliente", "comuna_sede": "comuna"})
    for c in ("fecha_apertura", "fecha_cierre"):
        if c in out:
            out[c] = pd.to_datetime(out[c], dayfirst=True, errors="coerce")
    for c in ("m2", "boxes", "camas", "pabellones"):
        if c in out:
            out[c] = _numero(out[c])
    if "lat" in out and "lon" in out:               # coma o punto decimal, escala, signo, intercambio
        out["lat"], out["lon"], inf = coordenadas.leer(out["lat"], out["lon"], cfg)
        out.attrs["coordenadas"] = coordenadas.REGISTRO["hoja de sedes (clínica)"] = inf
        print("  " + coordenadas.texto_informe(inf, "coordenadas de la hoja de sedes"))
    out["sede_cliente"] = out["sede_cliente"].astype(str).str.strip()
    return out.reset_index(drop=True)


def leer_maestro(cfg):
    """Maestro de sedes del levantamiento (base de puntos de la red Alemana), con las coordenadas leídas de cualquier
    forma (coma o punto decimal, escala, signo, intercambio). Los registros sin coordenada válida se informan."""
    ruta = ruta_local(cfg["rutas"]["maestro_sedes"], cfg)
    m = leer_tabla(ruta, cfg) if not ruta.lower().endswith(".csv") else pd.read_csv(ruta, dtype={"lat": object, "lon": object}, encoding="utf-8-sig")
    m.columns = [str(c).strip() for c in m.columns]
    m["lat"], m["lon"], inf = coordenadas.leer(m["lat"], m["lon"], cfg)
    m.attrs["coordenadas"] = coordenadas.REGISTRO["maestro de sedes"] = inf
    if inf["validas"] < inf["registros"] or any(inf.get(k) for k in ("escaladas", "signo_agregado", "intercambiadas", "coma_decimal", "gms")):
        print("  " + coordenadas.texto_informe(inf, "maestro de sedes"))
    return m


def _encabezado_csv(ruta_l, cfg):
    """Separador y fila de encabezado de un csv/txt (mirando las primeras 20 líneas)."""
    with open(ruta_l, "r", encoding=codificacion(ruta_l), errors="replace") as f:
        muestra = [f.readline() for _ in range(20)]
    sep = max([",", ";", "|", "\t"], key=lambda s: sum(l.count(s) for l in muestra))
    conocidos = {norm_txt(s) for lista in cfg["columnas_cliente"].values() for s in lista}
    puntajes = [sum(norm_txt(x) in conocidos for x in l.rstrip("\n").split(sep)) for l in muestra]
    return sep, int(np.argmax(puntajes))


def leer_origen(cfg, ruta=None):
    """Origen de los pacientes. Detecta el tipo: 'rut' (RUT en claro o seudonimizado), 'coordenadas' o 'zona'
    (manzana / zona censal / comuna). Devuelve (tabla estandarizada, tipo)."""
    ruta = ruta or cfg["rutas"].get("origen_pacientes")
    if not ruta:
        return None, "sin_origen"
    ruta_l = ruta_local(ruta, cfg)
    muestra = leer_tabla(ruta_l, cfg, nrows=300)
    m = detectar_columnas(muestra, cfg, ["sede", "fecha", "periodo", "linea", "prevision", "rut_hash", "rut", "dv", "lat", "lon", "zona",
                                         "pacientes", "atenciones", "monto"])
    if "rut" in m or "rut_hash" in m:
        return leer_atenciones_rut(cfg, ruta_l, m), "rut"
    df = leer_tabla(ruta_l, cfg)
    print("  columnas reconocidas en origen:", m)
    df = _filas_validas(df, m["sede"])
    out = pd.DataFrame({"sede_cliente": df[m["sede"]].astype(str).str.strip().values})
    col_per = m.get("periodo") or m.get("fecha")
    out["periodo"] = parsear_periodo(df[col_per]).values if col_per else "total"
    out["linea"] = df[m["linea"]].astype(str).values if "linea" in m else "total"
    for c in ("pacientes", "atenciones", "monto"):
        out[c] = _numero(df[m[c]]) if c in m else np.nan
    if "lat" in m and "lon" in m:
        out["lat"], out["lon"], inf = coordenadas.leer(df[m["lat"]], df[m["lon"]], cfg)
        out.attrs["coordenadas"] = inf
        print("  " + coordenadas.texto_informe(inf, "coordenadas del origen"))
        tipo = "coordenadas"
    elif "zona" in m:
        out["zona"] = df[m["zona"]].astype(str).str.strip().values
        tipo = "zona"
    else:
        raise ValueError("La tabla de origen no trae RUT, coordenadas ni zona")
    if out["monto"].isna().all():
        out["monto"] = out["atenciones"] if out["atenciones"].notna().any() else out["pacientes"]
        print("  origen sin monto: se usan atenciones (o pacientes) como peso de cada origen")
    return out, tipo


def _bloque_rut(df, m, cfg, sal, rut_min_empresa, con_dv):
    """Procesa un bloque de atenciones: estandariza columnas y reemplaza el RUT por su hash (el RUT en claro se descarta).
    `con_dv` se decide UNA vez para todo el archivo (True / False / "hash" si ya viene seudonimizado)."""
    from . import rut
    df = _filas_validas(df, m["sede"])
    out = pd.DataFrame({"sede_cliente": df[m["sede"]].astype(str).str.strip().values})
    col_per = m.get("fecha") or m.get("periodo")
    out["periodo"] = parsear_periodo(df[col_per]).values if col_per else "total"
    out["linea"] = df[m["linea"]].astype(str).str.strip().values if "linea" in m else "total"
    out["prevision"] = df[m["prevision"]].astype(str).str.strip().values if "prevision" in m else "sin detalle"
    out["monto"] = _numero(df[m["monto"]]) if "monto" in m else np.nan
    out["atenciones"] = _numero(df[m["atenciones"]]) if "atenciones" in m else 1.0
    col_rut = m.get("rut")
    if con_dv != "hash":
        canon = rut.canonico(df[col_rut], con_dv=bool(con_dv), dv=df[m["dv"]] if m.get("dv") else None)
        out["rut_valido"] = rut.es_valido(canon.values)
        out["rut_juridico"] = rut.cuerpo(canon.values) >= rut_min_empresa      # persona jurídica (empresa) según el número
        out["rut_hash"] = rut.seudonimizar(canon.values, sal, cfg)
        del canon
    else:                                                                  # ya viene seudonimizado por la clínica
        col = m.get("rut_hash") or col_rut
        out["rut_hash"] = df[col].astype(str).str.strip().str.lower().values
        out["rut_valido"] = np.nan
        out["rut_juridico"] = np.nan
    return out


def leer_atenciones_rut(cfg, ruta=None, m=None, bloque=2_000_000):
    """Atenciones con el RUT del paciente (una fila por atención o por paciente-mes), en claro o seudonimizado.
    Se lee por bloques (sirve para decenas de millones de filas) y el RUT se transforma en hash con la sal del proyecto
    (o la acordada con la clínica) apenas se lee: NUNCA queda en memoria ni en disco en claro."""
    from . import rut
    ruta_l = ruta_local(ruta or cfg["rutas"]["origen_pacientes"], cfg)
    sal = rut.sal_efectiva(cfg)
    if m is None:
        m = detectar_columnas(leer_tabla(ruta_l, cfg, nrows=300), cfg, ["sede", "fecha", "periodo", "linea", "prevision", "rut_hash", "rut",
                                                                       "dv", "atenciones", "monto"])
    m = {k: v for k, v in m.items() if k not in ("zona", "lat", "lon", "pacientes")}
    print("  columnas reconocidas en atenciones con RUT:", m)
    rmin = cfg["origen"]["rut_min_empresa"]
    # formato del RUT: se decide UNA vez para todo el archivo, con una muestra grande
    muestra = leer_tabla(ruta_l, cfg, nrows=200_000)
    col_rut = m.get("rut")
    if col_rut is None or muestra[col_rut].dropna().astype(str).str.strip().str.fullmatch(r"[0-9a-fA-F]{64}").mean() > 0.9:
        con_dv, inf = "hash", {"explicacion": "ya viene seudonimizado por la clínica"}
    elif m.get("dv"):
        con_dv, inf = True, {"explicacion": f"dígito verificador en la columna aparte '{m['dv']}'"}
    else:
        eleccion = cfg.get("rut_con_dv", "auto")
        inf = rut.detectar_dv(muestra[col_rut])
        if eleccion == "auto":
            if inf["con_dv"] is None:
                from .insumos import FaltanInsumos
                raise FaltanInsumos(f"❌ RUT de los pacientes ('{col_rut}'): {inf['explicacion']}.\n"
                                    "     → Escribe en config_estudio.py RUT_CON_DV = True (trae dígito verificador) o "
                                    "RUT_CON_DV = False (viene solo el número).")
            con_dv = inf["con_dv"]
        else:
            con_dv = bool(eleccion)
            inf["explicacion"] = f"RUT_CON_DV = {eleccion} (config) · detectado: {inf['explicacion']}"
    inf["formatos"] = rut.formatos(muestra[col_rut]) if col_rut else None
    print(f"  RUT de los pacientes: {inf['explicacion']}")
    del muestra
    partes = []
    ext = ruta_l.lower().rsplit(".", 1)[-1]
    if ext in ("csv", "txt"):
        sep, fila_enc = _encabezado_csv(ruta_l, cfg)
        usar = set(m.values())
        for df in pd.read_csv(ruta_l, sep=sep, skiprows=fila_enc, header=0, usecols=lambda c: c.strip() in usar, dtype=str,
                              chunksize=bloque, encoding=codificacion(ruta_l), encoding_errors="replace", on_bad_lines="skip"):
            df.columns = [c.strip() for c in df.columns]
            partes.append(_bloque_rut(df, m, cfg, sal, rmin, con_dv))
    else:
        partes.append(_bloque_rut(leer_tabla(ruta_l, cfg), m, cfg, sal, rmin, con_dv))
    out = pd.concat(partes, ignore_index=True)
    out.attrs["rut"] = {k: v for k, v in inf.items() if k != "formatos"}
    out.attrs["rut_formatos"] = inf["formatos"].to_dict("list") if inf.get("formatos") is not None else None
    if out["monto"].isna().all():
        out["monto"] = out["atenciones"]
        print("  sin columna de monto: cada atención pesa 1")
    inval = (1 - out["rut_valido"].astype(float).mean()) if out["rut_valido"].notna().any() else None
    print(f"  {len(out):,} atenciones · {out['rut_hash'].nunique():,} RUT distintos"
          + (f" · RUT con dígito verificador inválido: {inval:.2%}" if inval is not None else ""))
    return out


def leer_eventos(cfg):
    ruta = cfg["rutas"].get("eventos_cliente")
    if not ruta:
        return pd.DataFrame(columns=["sede_cliente", "desde", "hasta", "tipo_evento", "descripcion"])
    df = leer_tabla(ruta, cfg)
    m = detectar_columnas(df, cfg, ["sede", "desde", "hasta", "tipo_evento", "descripcion"])
    out = pd.DataFrame({k: df[v].values for k, v in m.items()}).rename(columns={"sede": "sede_cliente"})
    for c in ("desde", "hasta"):
        out[c] = parsear_periodo(out[c]) if c in out else None
    return out


def leer_sitios_propuestos(cfg):
    ruta = cfg["rutas"].get("sitios_propuestos")
    if not ruta:
        return None
    df = leer_tabla(ruta, cfg)
    m = detectar_columnas(df, cfg, ["nombre", "direccion", "comuna_sede", "lat", "lon", "formato"])
    out = pd.DataFrame({k: df[v].values for k, v in m.items()}).rename(columns={"comuna_sede": "comuna"})
    if "lat" in out and "lon" in out:
        out["lat"], out["lon"], _ = coordenadas.leer(out["lat"], out["lon"], cfg)
    return out.head(5).reset_index(drop=True)


# --------------------------------------------------------------------------------------------- SEDES
def formato_modelo(texto, cfg):
    """Formato del modelo ('clinica', 'centro_medico', 'toma_muestras') a partir de un texto libre.
    Se revisa primero toma de muestras y centro médico, para que 'Toma de muestras Clínica X' no quede como clínica."""
    t = " " + norm_txt(texto) + " "
    for clave in ("toma_muestras", "centro_medico", "clinica"):
        if any(norm_txt(p) in t for p in cfg["formatos"][clave]):
            return clave
    return None


def _similitud(a, b):
    a, b = norm_txt(a), norm_txt(b)
    ruido = {"clinica", "alemana", "centro", "medico", "de", "la", "el", "sede", "cas", "toma", "muestras", "unidad"}
    ta, tb = set(a.split()) - ruido, set(b.split()) - ruido
    jac = len(ta & tb) / max(len(ta | tb), 1)
    return max(jac, difflib.SequenceMatcher(None, a, b).ratio() * 0.9)


def emparejar_sedes(sedes_cli, maestro, cfg):
    """Empareja cada código de sede del cliente con el maestro de sedes (CAS-01, ...): primero MAPA_SEDES, luego por
    nombre y, si ambos tienen coordenadas, por distancia. Devuelve la tabla de emparejamiento con su puntaje."""
    filas = []
    mapa = cfg.get("mapa_sedes") or {}
    for _, s in sedes_cli.iterrows():
        cod = s["sede_cliente"]
        if cod in mapa:
            filas.append({"sede_cliente": cod, "id_maestro": mapa[cod], "metodo": "MAPA_SEDES (config)", "puntaje": 1.0})
            continue
        sim = maestro["nombre"].map(lambda n: _similitud(s.get("nombre", cod), n)).values
        if "direccion" in s and pd.notna(s.get("direccion")):
            sim = sim + 0.5 * maestro["direccion"].map(lambda d: _similitud(str(s["direccion"]).split(",")[0], str(d).split("/")[0])).values
        j = int(np.argmax(sim))
        filas.append({"sede_cliente": cod, "id_maestro": maestro["id"].iloc[j], "metodo": "nombre + dirección",
                      "puntaje": float(sim[j]), "nombre_cliente": s.get("nombre"), "nombre_maestro": maestro["nombre"].iloc[j]})
    t = pd.DataFrame(filas)
    t["revisar"] = t["puntaje"] < 0.45
    dup = t["id_maestro"].duplicated(keep=False)
    t.loc[dup & (t["metodo"] != "MAPA_SEDES (config)"), "revisar"] = True
    return t


def nombre_visible(sedes):
    """Nombre de cada sede para mapas, fichas e informes: el oficial del levantamiento cuando el emparejamiento es
    confiable (si no, el que manda la clínica), escribiendo la sigla 'CAS' como 'Clínica Alemana'."""
    nom = sedes["nombre"] if "nombre" in sedes else pd.Series(None, index=sedes.index, dtype=object)
    if "nombre_maestro" in sedes:
        confiable = sedes["nombre_maestro"].notna() & ~sedes.get("revisar", pd.Series(False, index=sedes.index)).fillna(True).astype(bool)
        nom = sedes["nombre_maestro"].where(confiable, nom)
    nom = nom.fillna(sedes["sede"] if "sede" in sedes else "")
    return (nom.astype(str).str.replace(r"\bCAS\b", "Clínica Alemana", regex=True).str.replace(r"\s+", " ", regex=True).str.strip())
