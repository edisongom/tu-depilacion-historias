# -*- coding: utf-8 -*-
"""GeoVentas · Clínica Alemana de Santiago.

Paquete de funciones del estudio de estimación de ventas y localización óptima. Cada módulo agrupa un tema:

    insumos         asistente de insumos: revisa decisiones, archivos, columnas y resultados previos, y pide lo que falte
    utilidades      texto, guardado de intermedios, formato de números, cálculo en paralelo según la memoria libre
    esquemas        estructura real de las bases Equifax y nombres exactos de los grafos viales
    rut             RUT en cualquier formato -> forma canónica, dígito verificador, seudonimización
    coordenadas     coordenadas en cualquier formato (coma o punto, escala, grados/min/seg, signo, lat/lon intercambiadas)
    lectura         lectura de las bases Equifax (local o gs://), filtros por área de estudio, calidad
    cliente         lectura flexible de la data de Clínica Alemana (ventas, sedes, origen, eventos)
    ventas          serie de 5 años: deflactar, atípicos, estacionalidad, crecimiento, maduración, venta madura
    geocodificacion direcciones -> coordenadas con el Maestro de Calles (BC08_STREET)
    unidades        MANZANAS del censo: filtros previos (vacías, uso excluido, áreas verdes), asignación espacial, entorno
    variables       variables territoriales por unidad (censo, personas, empresas, POIs, BBRR, calles)
    unificacion_pois unión levantamiento + POIs Equifax sin duplicados (coordenadas, nombre, dirección y tipo)
    competencia     universo de competencia (levantamiento + POIs Equifax) y su potencial exacto por manzana
    red             grafo vial con OSMnx: tiempos auto (punta/valle), a pie, transporte público e isócronas
    entorno         análisis de entorno de cada sede de la red: punta y fuera de punta, 5 a 30 min, vectorizado y en paralelo
    influencia      zonas de influencia MODELADAS sin RUT ni ventas (Huff con parámetros de referencia) y su comparación con las reales
    origen          origen de los pacientes, flujos origen-destino, áreas de influencia e indicadores por sede
    pacientes       análisis con RUT (cruce con per y emp): zonas reales, afinidad, multisede, fidelidad, convenios
    modelo          modelo de Huff calibrado (máxima verosimilitud penalizada) y validaciones
    expansion       candidatos, venta bruta/canibalizada/neta, escenarios, scoring, Top 20 y macrozonas
    mapas           mapas interactivos de manzanas (canvas + datos comprimidos, selector de indicador) en el notebook y en HTML
    graficos        gráficos estáticos (matplotlib)
    entregables     capas GIS, Excel de fichas, fichas PDF, informe ejecutivo y anexo metodológico
    verificacion    chequeos automáticos de cada fase
    metricas        indicadores clave de cada tema (ventas, mercado, pacientes, modelo, plan) con su lectura en palabras
    conclusiones    conclusiones en palabras que se adaptan a los datos (fortaleza, alerta, oportunidad, dato + qué hacer)
    simulacion      generador de bases simuladas con la estructura exacta de las bases reales
"""
from . import utilidades, esquemas, rut, coordenadas, insumos, lectura, cliente, ventas, geocodificacion, unidades, variables, unificacion_pois, competencia, red, origen, \
    pacientes, modelo, expansion, mapas, graficos, entregables, verificacion, metricas, conclusiones, entorno, influencia  # noqa: F401

__version__ = "3.6"
