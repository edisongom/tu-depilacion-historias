# -*- coding: utf-8 -*-
"""Expansión: dónde abrir y con qué formato.

  1. Candidatos: MANZANAS urbanas (o en polos laborales) que dan a una vía relevante; el sitio es el nodo de esa vía.
  2. Para cada candidato y cada formato: venta BRUTA (lo que vendería), CANIBALIZACIÓN (lo que pierden las sedes
     actuales) y venta NETA (= bruta − canibalización: lo que de verdad suma a la red), en escenarios P10/P50/P90.
  3. Métricas de mercado dentro de la isócrona del candidato (población, GSE objetivo, gasto, competencia).
  4. Scoring multicriterio (0 a 1) y viabilidad (venta neta ≥ P25 de las sedes actuales del formato).
  5. Selección secuencial del Top 20: se elige el mejor, se agrega a la red, se recalcula todo y se elige el siguiente
     (así el plan no propone 20 sitios que se canibalizan entre sí).
  6. Clínica de alta complejidad: macrozonas (2–3 alternativas), por su horizonte de inversión (FRF 2.4).
"""
import numpy as np
import pandas as pd
import geopandas as gpd
import shapely
from scipy.spatial import cKDTree

from .modelo import evaluar_sitios, agregar_sede, predecir, FORMATOS, EstadoRed, _partes, lote_columnas, T_LEJOS
from .utilidades import en_paralelo, n_nucleos

FMT_IDX = {f: k for k, f in enumerate(FORMATOS)}
FMT_NOMBRE = {"clinica": "Clínica de Alta Complejidad", "centro_medico": "Centro Médico Ambulatorio",
              "toma_muestras": "Toma de Muestras / Laboratorio"}
COMP_DE_FMT = {"clinica": ["comp_clinica_peso"], "centro_medico": ["comp_centro_medico_peso", "comp_clinica_peso"],
               "toma_muestras": ["comp_laboratorio_peso", "comp_centro_medico_peso"]}


def _ralear(xy, separacion):
    """Selección espacial "codiciosa": recorre los puntos en orden (de mayor a menor prioridad) y conserva uno solo si no
    hay otro ya conservado a menos de `separacion` metros. Usa una grilla de celdas para comparar solo con los vecinos."""
    celdas = {}
    conservar = []
    s2 = separacion ** 2
    cel = np.floor(xy / separacion).astype(np.int64)
    for k in range(len(xy)):
        cx, cy = cel[k]
        x, y = xy[k]
        libre = True
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for (qx, qy) in celdas.get((cx + dx, cy + dy), ()):
                    if (x - qx) ** 2 + (y - qy) ** 2 < s2:
                        libre = False
                        break
                if not libre:
                    break
            if not libre:
                break
        if libre:
            conservar.append(k)
            celdas.setdefault((cx, cy), []).append((x, y))
    return np.asarray(conservar, np.int64)


def generar_candidatos(ut, red, cfg):
    """MANZANAS CANDIDATAS a sede nueva. Una manzana es candidata si:
      · está en zona urbana o en un polo laboral: en su entorno (manzanas a ≤ radio_entorno_m) viven ≥ pob_entorno_min
        personas o trabajan ≥ trabajadores_entorno_min;
      · da a una vía terciaria o superior: hay un nodo de esa vía (conectado a la red) a ≤ dist_max_via_m. Ese nodo es el
        SITIO: desde ahí se miden los tiempos de viaje (una sede necesita frente a una vía relevante).
    Prioridad = demanda objetivo del entorno (gasto en salud AB/C1a/C1b) + ½ trabajadores del entorno (percentiles).
    Si varias manzanas usan el mismo nodo queda la de mayor prioridad, y entre candidatas se exige una separación
    mínima (separacion_min_m). Se conservan las `max_candidatos` de mayor prioridad.
    Devuelve un GeoDataFrame con el POLÍGONO de cada manzana candidata y las coordenadas (x, y) de su sitio."""
    from .unidades import suma_entorno
    E = cfg["expansion"]
    ent = suma_entorno(ut, ["pob", "pob_objetivo", "hog_objetivo", "gasto_salud_objetivo", "trabajadores_est", "poi_metro"],
                       E["radio_entorno_m"])
    c = ut.drop(columns=[k for k in ent.columns if k in ut]).join(ent)      # re-ejecutable: reemplaza el entorno de una corrida anterior
    urbana = (c["pob_entorno"] >= E["pob_entorno_min"]) | (c["trabajadores_est_entorno"] >= E["trabajadores_entorno_min"])
    mayor = np.where(red.en_scc & (red.rango_via >= 2))[0]
    d1, i1 = cKDTree(np.c_[red.x[mayor], red.y[mayor]]).query(np.c_[c["cx"].values, c["cy"].values])
    c["nodo"] = mayor[i1]
    c["dist_nodo_m"] = d1
    c = c[urbana.values & (d1 <= E["dist_max_via_m"])].copy()
    c["prioridad"] = c["gasto_salud_objetivo_entorno"].rank(pct=True) + 0.5 * c["trabajadores_est_entorno"].rank(pct=True)
    c = c.sort_values(["prioridad", "dist_nodo_m"], ascending=[False, True]).drop_duplicates("nodo")
    xy_sitio = np.c_[red.x[c["nodo"].values], red.y[c["nodo"].values]]
    c = c.iloc[_ralear(xy_sitio, E["separacion_min_m"])]
    c = c.head(E["max_candidatos"]).reset_index(drop=True)
    c["x"], c["y"] = red.x[c["nodo"].values], red.y[c["nodo"].values]
    c["rango_via"] = red.rango_via[c["nodo"].values]
    rv = np.array([{"motorway": 6, "trunk": 5, "primary": 4, "secondary": 3, "tertiary": 2}.get(h, 1) for h in red.highway])
    ref = pd.DataFrame({"nodo": np.r_[red.u, red.v], "via": np.r_[red.nombre, red.nombre], "r": np.r_[rv, rv]})
    ref = ref[ref["via"].str.len() > 0].sort_values("r", ascending=False).drop_duplicates("nodo").set_index("nodo")["via"]
    c["via_referencia"] = c["nodo"].map(ref).fillna("")
    ll = gpd.GeoSeries(gpd.points_from_xy(c["x"], c["y"]), crs=cfg["estudio"]["crs_metrico"]).to_crs("EPSG:4326")
    c["lat"], c["lon"] = ll.y.values, ll.x.values
    c["id_cand"] = [f"C{k:05d}" for k in range(len(c))]
    cols = ["id_cand", "ut", "comuna", "cod_comuna", "x", "y", "lat", "lon", "nodo", "dist_nodo_m", "rango_via", "via_referencia",
            "prioridad", "pob", "pob_objetivo", "densidad_hab_km2"] + list(ent.columns)
    return gpd.GeoDataFrame(c[[k for k in cols if k in c]], geometry=c.geometry.values, crs=ut.crs)


def lejos_de_sedes(cand, sedes, fmt, cfg):
    """True si el candidato está a más de la distancia mínima de una sede propia del mismo formato o superior
    (una clínica también presta servicios de centro médico y toma de muestras)."""
    dmin = cfg["expansion"]["dist_min_propia_km"][fmt] * 1000
    orden = {"clinica": 3, "centro_medico": 2, "toma_muestras": 1}
    rel = sedes[sedes["formato_modelo"].map(orden) >= orden[fmt]]
    if not len(rel):
        return np.ones(len(cand), bool)
    d, _ = cKDTree(np.c_[rel["x"], rel["y"]]).query(np.c_[cand["x"], cand["y"]])
    return d >= dmin


def metricas_isocrona(Tc, ut, minutos, compcols, mb=64):
    """Mercado dentro de la isócrona de cada candidato (unidades territoriales a ≤ `minutos`).
    Una sola multiplicación matricial por lote de candidatos (todas las variables a la vez) y memoria acotada a `mb` MB."""
    cols = {"pob_isocrona": "pob", "pob_objetivo_isocrona": "pob_objetivo", "hog_objetivo_isocrona": "hog_objetivo",
            "gasto_salud_isocrona": "gasto_salud_total", "gasto_salud_objetivo_isocrona": "gasto_salud_objetivo",
            "trabajadores_isocrona": "trabajadores_est", "oferta_contexto_isocrona": "oferta_contexto_n"}
    V = np.column_stack([ut[c].fillna(0).values if c in ut else np.zeros(len(ut)) for c in cols.values()]
                        + [ut[list(compcols)].fillna(0).values.sum(1) if compcols else np.zeros(len(ut))]).astype(np.float64)
    C = Tc.shape[1]
    V = V.astype(np.float32)
    R = np.zeros((C, V.shape[1]))
    paso = max(8, int(mb * 1e6 / (4 * max(Tc.shape[0], 1))))
    for i in range(0, C, paso):
        dentro = (np.asarray(Tc[:, i:i + paso]) <= minutos).astype(np.float32)
        R[i:i + paso] = dentro.T @ V
    out = pd.DataFrame(R[:, :-1], columns=list(cols))
    out["competencia_isocrona"] = R[:, -1]
    out["saturacion"] = out["competencia_isocrona"] / np.maximum(out["pob_objetivo_isocrona"] / 1000, 1e-6)
    return out


def _esc_bloque(thetas, d, T, fmt, z_new):
    """Venta bruta, canibalización y neta de cada sitio (columna de T) para un bloque de réplicas de θ: (réplicas, sitios, 3).
    Cada lote de columnas de T se convierte UNA vez y sirve a todas las réplicas, y las cuentas van en float32:
    5,6 veces más rápido que evaluar réplica por réplica, con diferencias relativas ~2e-5 en P10/P50/P90 (mil veces
    menores que la incertidumbre que miden los escenarios). La evaluación central (`evaluar_sitios`) sigue en float64."""
    n, C = T.shape
    fmts = np.broadcast_to(np.asarray(fmt), (C,))
    f32 = np.float32
    estados = []
    for th in thetas:
        kap, lam, a, beta, ac, pg, Dt, E, F, FT, Den, mu = _partes(th, d)
        KD = kap * Dt
        estados.append(((a[fmts] + th[-1] * z_new).astype(f32), beta[fmts].astype(f32), Den.astype(f32)[:, None],
                        KD.astype(f32), (KD * E.sum(1) / Den).astype(f32)))
    out = np.zeros((len(thetas), C, 3))
    paso = 2 * lote_columnas(n)                       # float32: el doble de columnas en la misma memoria
    for i in range(0, C, paso):
        sl = slice(i, i + paso)
        Tb = np.array(T[:, sl], dtype=f32)
        Tb[~np.isfinite(Tb)] = T_LEJOS
        En = np.empty_like(Tb)
        for r, (a_c, b_c, Den32, KD32, w32) in enumerate(estados):
            np.multiply(Tb, -b_c[sl], out=En)
            En += a_c[sl]
            np.minimum(En, 50.0, out=En)
            np.exp(En, out=En)
            En /= Den32 + En                          # cuota del sitio nuevo en cada manzana
            out[r, sl, 0] = KD32 @ En
            out[r, sl, 1] = w32 @ En
    out[:, :, 2] = out[:, :, 0] - out[:, :, 1]
    return out


def sd_sede(cfg):
    """σ (log) del error propio de una sede nueva que se suma a los escenarios (0 = solo incertidumbre de parámetros).
    Lo estima el notebook 06 con la validación "sede nueva" y el notebook 07 lo deja en cfg['expansion']['sd_log_sede']."""
    E = (cfg or {}).get("expansion", {})
    return float(E.get("sd_log_sede", 0.0)) if E.get("incluir_error_sede", True) else 0.0


def ruido_sede(vals, sd, n=25, semilla=2026):
    """Combina la incertidumbre de los parámetros con el error propio de cada sitio.
    vals: (réplicas, sitios, 3) con bruta, canibalización y neta. Cada réplica se repite `n` veces y cada sitio se
    multiplica por un factor lognormal de media 1 (σ = sd). El mismo factor escala bruta, canibalización y neta: una sede
    más atractiva de lo previsto capta más Y canibaliza más. Devuelve (réplicas·n, sitios, 3). Semilla fija: los
    escenarios son reproducibles."""
    if not sd or sd <= 0:
        return vals
    rng = np.random.default_rng(semilla)
    f = np.exp(rng.normal(-sd ** 2 / 2, sd, size=(vals.shape[0], n, vals.shape[1])))      # (R, n, S)
    return (vals[:, None, :, :] * f[..., None]).reshape(-1, vals.shape[1], vals.shape[2])


def escenarios(thetas, d, T, fmt, z_new=0.0, cfg=None):
    """P10 / P50 / P90 de venta bruta, canibalización y neta de cada sitio (columna de T).
    Combina (1) la incertidumbre de los parámetros (réplicas del bootstrap, en paralelo si son muchos sitios) y
    (2) el error propio de una sede nueva (`ruido_sede`, σ medido en la validación "sede nueva")."""
    if T.shape[1] >= 50:
        partes = [p for p in np.array_split(np.asarray(thetas), min(len(thetas), n_nucleos(cfg))) if len(p)]
        vals = np.concatenate(en_paralelo(_esc_bloque, [(p, d, T, fmt, z_new) for p in partes], cfg), axis=0)
    else:
        vals = _esc_bloque(thetas, d, T, fmt, z_new)
    vals = ruido_sede(vals, sd_sede(cfg))
    out = {}
    for k, c in enumerate(["venta_bruta", "canibalizacion", "venta_neta"]):
        for p in (10, 50, 90):
            out[f"{c}_p{p}"] = np.percentile(vals[:, :, k], p, axis=0)
    return pd.DataFrame(out)


def puntaje(df, cfg):
    """Score 0–1: promedio ponderado de percentiles (dentro del formato) de 7 criterios del FRF."""
    P = cfg["expansion"]["pesos_scoring"]
    r = lambda s, inv=False: pd.Series(s, index=df.index).rank(pct=True, ascending=not inv).fillna(0)
    acc = df["rango_via"] + 0.5 * np.minimum(df.get("poi_metro_entorno", df.get("poi_metro", 0)), 2)
    comp = pd.DataFrame({
        "s_venta_neta": r(df["venta_neta"]), "s_hogares_objetivo": r(df["hog_objetivo_isocrona"]),
        "s_gasto_potencial": r(df["gasto_salud_isocrona"]), "s_saturacion_inv": r(df["saturacion"], inv=True),
        "s_accesibilidad": r(acc), "s_canibalizacion_inv": r(df["canibalizacion"] / np.maximum(df["venta_bruta"], 1), inv=True),
        "s_poblacion_flotante": r(df["trabajadores_isocrona"])}, index=df.index)
    clave = {c: c[2:] for c in comp.columns}
    comp["score"] = sum(comp[k] * P[v] for k, v in clave.items()) / sum(P.values())
    return comp


def umbral_viabilidad(th, d, fmt, cfg):
    """Venta mensual mínima: percentil 25 de la venta PREDICHA de las sedes actuales del formato (misma vara)."""
    pred = predecir(th, d).sum(0)
    p = cfg["expansion"]["umbral_viabilidad_percentil"]
    f = FMT_IDX[fmt]
    sel = pred[d.fmt == f] if (d.fmt == f).any() else pred
    return float(np.percentile(sel, p)) if len(sel) else 0.0


def evaluar_formato(fmt, cand, Tcand, ut, sedes, th, thetas, d, cfg):
    """Evalúa todos los candidatos en un formato: venta bruta/canibalización/neta (P10/P50/P90), mercado en la
    isócrona, score y viabilidad. Los candidatos muy cerca de una sede propia quedan marcados y fuera."""
    E = cfg["expansion"]; f = FMT_IDX[fmt]
    ok = lejos_de_sedes(cand, sedes, fmt, cfg)
    c = pd.DataFrame(cand[ok].drop(columns="geometry", errors="ignore")).reset_index(drop=True)   # el polígono va aparte (mapas)
    T = Tcand[:, ok]
    ev = evaluar_sitios(th, d, T, f)
    esc = escenarios(thetas, d, T, f, cfg=cfg) if thetas is not None and len(thetas) else pd.DataFrame(index=ev.index)
    iso = metricas_isocrona(T, ut, E["isocrona_scoring_min"][fmt], [k for k in COMP_DE_FMT[fmt] if k in ut])
    out = pd.concat([c, ev, esc, iso], axis=1)
    out["formato"] = fmt
    out = pd.concat([out, puntaje(out, cfg)], axis=1)
    out["umbral_viabilidad"] = umbral_viabilidad(th, d, fmt, cfg)
    out["viable"] = out["venta_neta"] >= out["umbral_viabilidad"]
    out["col_T"] = np.where(ok)[0]
    return out


def formato_idoneo(evals):
    """Para cada candidato, el formato con mayor venta neta relativa a su umbral (índice ≥ 1 = viable)."""
    partes = []
    for fmt, ev in evals.items():
        partes.append(ev[["id_cand", "venta_neta", "umbral_viabilidad"]].assign(formato=fmt,
                      indice=lambda x: x["venta_neta"] / x["umbral_viabilidad"].replace(0, np.nan)))
    t = pd.concat(partes)
    piv = t.pivot_table(index="id_cand", columns="formato", values="indice").dropna(how="all")
    valores = piv.copy()
    piv["indice_idoneo"] = valores.max(axis=1)
    piv["formato_idoneo"] = valores.fillna(-np.inf).idxmax(axis=1)
    return piv.reset_index()


def proyeccion(venta_mensual, rampa):
    """Venta anual de los años 1, 2 y 3 según la curva de maduración, y en régimen."""
    out = {f"venta_anio_{k + 1}": venta_mensual * 12 * r for k, r in enumerate(rampa)}
    out["venta_anual_regimen"] = venta_mensual * 12
    return out


def seleccion_secuencial(evals, Tcand, d, th, thetas, cfg, rampa):
    """Top N entre todos los formatos. En cada paso: se recalcula la venta neta de los candidatos que quedan con la red
    actualizada (incluye las nuevas ya elegidas), se recalcula el score y se elige el mejor viable que cumpla el tope por
    formato y la distancia mínima a otras nuevas del mismo formato."""
    E = cfg["expansion"]
    N = E.get("max_eval_paso", 800)
    dd = d
    elegidos, filas = {k: 0 for k in evals}, []
    activos = {k: np.ones(len(v), bool) for k, v in evals.items()}
    # cota superior de la venta neta: al abrir sedes nuevas la venta neta de un candidato solo puede bajar, así que en
    # cada paso basta reevaluar exacto a los N con mayor cota (el resto no puede quedar entre los mejores)
    cota = {k: v["venta_neta"].values.astype(float).copy() for k, v in evals.items()}
    usados = set()
    # estado incremental del modelo (θ base y cada réplica del bootstrap): abrir un sitio actualiza 2 vectores, no todo el modelo
    est = EstadoRed(th, d)
    ests = [EstadoRed(t, d) for t in thetas] if thetas is not None and len(thetas) else []
    for paso in range(E["n_top"]):
        mejor = None
        for k, ev in evals.items():
            if elegidos[k] >= E["max_por_formato"][k]:
                continue
            act = np.where(activos[k] & ~ev["id_cand"].isin(usados).values)[0]
            if not len(act):
                continue
            exactos = act[np.argsort(-cota[k][act])][:N]
            nv = est.evaluar(Tcand[:, ev["col_T"].values[exactos]], FMT_IDX[k])
            cota[k][exactos] = nv["venta_neta"].values
            tmp = ev.iloc[act].copy()
            tmp["venta_neta"] = cota[k][act]                      # exacta para los evaluados, cota para el resto
            pos = pd.Series(np.arange(len(act)), index=act)
            tmp.iloc[pos[exactos].values, tmp.columns.get_indexer(["venta_bruta", "canibalizacion", "venta_neta"])] = nv.values
            tmp = tmp.drop(columns=[c for c in tmp.columns if c.startswith("s_") or c == "score"])
            tmp = pd.concat([tmp, puntaje(tmp, cfg)], axis=1)
            tmp = tmp.loc[ev.index[exactos]]                      # solo pueden elegirse los evaluados en forma exacta
            tmp = tmp[tmp["venta_neta"] >= tmp["umbral_viabilidad"]]
            if not len(tmp):
                continue
            c = tmp.loc[tmp["score"].idxmax()]
            if mejor is None or c["score"] > mejor[1]["score"]:
                mejor = (k, c)
        if mejor is None:
            break
        k, c = mejor
        tcol = Tcand[:, int(c["col_T"])]
        fila = c.to_dict()
        fila.update({"orden": paso + 1, "formato": k})
        if ests:
            vals = np.stack([e_.evaluar(tcol[:, None], FMT_IDX[k]).values[0] for e_ in ests])      # (réplicas, 3)
            vals = ruido_sede(vals[:, None, :], sd_sede(cfg), semilla=2026 + paso)[:, 0, :]           # + error propio de la sede
            for q, col in enumerate(["venta_bruta", "canibalizacion", "venta_neta"]):
                for p in (10, 50, 90):
                    fila[f"{col}_p{p}_marginal"] = float(np.percentile(vals[:, q], p))
        cs = est.canibalizacion_por_sede(tcol, FMT_IDX[k])
        top = np.argsort(-cs)[:3]
        fila["sedes_mas_canibalizadas"] = "; ".join(f"{dd.sedes[j]} ({cs[j] / max(cs.sum(), 1):.0%})" for j in top if cs[j] > 0)
        fila.update(proyeccion(c["venta_neta"], rampa))
        filas.append(fila)
        elegidos[k] += 1
        usados.add(c["id_cand"])
        dd = agregar_sede(dd, tcol, FMT_IDX[k], f"NUEVA-{paso + 1:02d}")
        est.agregar(tcol, FMT_IDX[k], f"NUEVA-{paso + 1:02d}")
        for e_ in ests:
            e_.agregar(tcol, FMT_IDX[k], f"NUEVA-{paso + 1:02d}")
        ev = evals[k]
        activos[k] &= np.hypot(ev["x"].values - c["x"], ev["y"].values - c["y"]) >= E["dist_min_entre_nuevas_km"][k] * 1000
    top = pd.DataFrame(filas)
    if len(top):
        top["id_top"] = [f"T{k:02d}" for k in top["orden"]]
        top["formato_FRF"] = top["formato"].map(FMT_NOMBRE)
    return top, dd


def macrozonas(ev_clinica, top, cfg):
    """Macrozonas de clínica de alta complejidad: SIEMPRE 2–3 alternativas (FRF 2.4).
    Primero las clínicas que entraron al plan; si son menos de `n_macrozonas`, se completan con los mejores sitios de
    clínica que no entraron (por score), separados por la distancia mínima entre clínicas nuevas. Cada macrozona es el
    área de los candidatos a ≤ radio cuya venta neta es ≥ 80% de la del sitio de referencia; `en_plan` indica si su sitio
    está en el Top y `brecha_vs_umbral` cuánto le falta (o sobra) para ser viable."""
    E = cfg["expansion"]
    if not len(ev_clinica):
        return gpd.GeoDataFrame({"macrozona": []}, geometry=[], crs=cfg["estudio"]["crs_metrico"])
    dmin = E["dist_min_entre_nuevas_km"]["clinica"] * 1000
    plan = top[top["formato"] == "clinica"] if len(top) else pd.DataFrame()
    ref = [(r, True) for _, r in plan.iterrows()]
    for _, r in ev_clinica.sort_values("score", ascending=False).iterrows():
        if len(ref) >= E["n_macrozonas"]:
            break
        if all(np.hypot(r["x"] - q["x"], r["y"] - q["y"]) >= dmin for q, _ in ref):
            ref.append((r.copy(), False))
    sel = pd.DataFrame([r for r, _ in ref])
    sel["en_plan"] = [p for _, p in ref]
    if "id_top" not in sel:
        sel["id_top"] = None
    sel.loc[~sel["en_plan"], "id_top"] = None
    filas = []
    for n, (_, s) in enumerate(sel.iterrows(), start=1):
        dist = np.hypot(ev_clinica["x"] - s["x"], ev_clinica["y"] - s["y"]) / 1000
        m = ev_clinica[(dist <= E["macrozona_radio_km"]) & (ev_clinica["venta_neta"] >= E["macrozona_frac"] * s["venta_neta"])]
        if not len(m):
            m = ev_clinica[ev_clinica["id_cand"] == s["id_cand"]]
        poly = shapely.convex_hull(shapely.MultiPoint(np.c_[m["x"], m["y"]])).buffer(500)
        com = m["comuna"].value_counts().index.tolist() if "comuna" in m else []
        filas.append({"macrozona": f"MZ-{n}", "id_top": s.get("id_top"), "en_plan": bool(s["en_plan"]), "sitio_referencia": s["id_cand"],
                      "venta_neta_referencia": s["venta_neta"], "venta_neta_p10": s.get("venta_neta_p10", np.nan),
                      "venta_neta_p90": s.get("venta_neta_p90", np.nan), "umbral_viabilidad": s["umbral_viabilidad"],
                      "brecha_vs_umbral": s["venta_neta"] / s["umbral_viabilidad"] - 1 if s["umbral_viabilidad"] else np.nan,
                      "sitios_equivalentes": len(m), "comunas": ", ".join(map(str, com[:6])),
                      "venta_neta_min": m["venta_neta"].min(), "venta_neta_max": m["venta_neta"].max(),
                      "area_km2": poly.area / 1e6, "geometry": poly})
    crs = cfg["estudio"]["crs_metrico"]
    return gpd.GeoDataFrame(filas, geometry="geometry", crs=crs) if filas else gpd.GeoDataFrame({"macrozona": []}, geometry=[], crs=crs)


def evaluar_sitios_dados(sitios, Tsit, ut, d, th, thetas, cfg, rampa):
    """Evalúa ubicaciones dadas (propuestas por la clínica o cualquier otra) en los 3 formatos y recomienda uno.
    Es la herramienta para 'evaluar ubicaciones fuera del ranking' (FRF 1.2)."""
    sitios = sitios.rename(columns={"formato": "formato_propuesto"})       # el formato que propuso la clínica se conserva aparte
    filas = []
    for fmt, f in FMT_IDX.items():
        ev = evaluar_sitios(th, d, Tsit, f)
        esc = escenarios(thetas, d, Tsit, f, cfg=cfg) if thetas is not None and len(thetas) else pd.DataFrame(index=ev.index)
        iso = metricas_isocrona(Tsit, ut, cfg["expansion"]["isocrona_scoring_min"][fmt], [k for k in COMP_DE_FMT[fmt] if k in ut])
        u = umbral_viabilidad(th, d, fmt, cfg)
        t = pd.concat([sitios.reset_index(drop=True), ev, esc, iso], axis=1).assign(formato=fmt, formato_FRF=FMT_NOMBRE[fmt], umbral_viabilidad=u)
        t["indice_viabilidad"] = t["venta_neta"] / u if u else np.nan
        filas.append(t)
    out = pd.concat(filas, ignore_index=True)
    out["viable"] = out["indice_viabilidad"] >= 1
    best = out.loc[out.groupby("id_sitio")["indice_viabilidad"].idxmax(), ["id_sitio", "formato"]].rename(columns={"formato": "formato_recomendado"})
    out = out.merge(best, on="id_sitio")
    for k, v in proyeccion(out["venta_neta"], rampa).items():
        out[k] = v
    return out


def competidores_cercanos(x, y, comp_m, n=5):
    """Los n competidores del modelo más cercanos a un punto (distancia en línea recta)."""
    c = comp_m[comp_m["en_modelo"]]
    d = np.hypot(c.geometry.x.values - x, c.geometry.y.values - y)
    idx = np.argsort(d)[:n]
    return "; ".join(f"{c['nombre'].iloc[i]} [{str(c['grupo'].iloc[i]).replace('comp_', '')}] {d[i] / 1000:.1f} km" for i in idx)


def perfil_isocrona(Tcol, ut, minutos, cfg):
    """Perfil dentro de la isócrona: población, % por GSE, hogares objetivo, gasto mensual en salud."""
    m = Tcol <= minutos
    h = ut[m]
    pob = h["pob"].sum()
    out = {"poblacion": pob, "hogares": h["hog"].sum(), "hogares_objetivo_AB_C1A_C1B": h["hog_objetivo"].sum(),
           "pct_poblacion_objetivo": h["pob_objetivo"].sum() / max(pob, 1), "gasto_salud_mensual": h["gasto_salud_total"].sum(),
           "trabajadores": h.get("trabajadores_est", pd.Series(0)).sum()}
    for g in cfg["gse"]:
        out[f"pct_{g}"] = h[f"pob_{g}"].sum() / max(pob, 1)
    return out
