# -*- coding: utf-8 -*-
"""Estructura REAL de las bases Equifax y de los grafos viales (transcrita de las bases del bucket, nov-2026).

Sirve para tres cosas:
  * la simulación genera archivos con exactamente estas columnas y en este orden;
  * el asistente de insumos compara el encabezado de cada archivo real con lo esperado y avisa si cambió algo;
  * se comprueba que cada columna que pide `config_estudio.COLUMNAS` exista en la base real.
"""
import os
import re

from .utilidades import norm_txt

GSE = ["AB", "C1A", "C1B", "C2", "C3", "D", "E"]
_CAT_GASTO = ["ALI", "ALC", "VES", "SER", "VIV", "SAL", "TRA", "COM", "REC", "EDU", "RES", "BIE"]

# gs://…/Cartografia/CENSO_2026/SD06_SOCIODEMOGRAPHIC_BLOCK_2026.gpkg · 231.036 manzanas · 153 columnas
_CENSO = (["ID_BLOCK", "COD_APD3", "PRED"]
          + [c for base in ("POB", "HOG", "VIV", "ING") for c in [base] + [f"{base}_{g}" for g in GSE]]
          + ["GASTO"] + [f"G_{c}_{g}" for c in _CAT_GASTO for g in GSE] + [f"G_{c}" for c in _CAT_GASTO]
          + ["POB_0_5", "POB_6_13", "POB_14_17", "POB_18_24", "POB_25_44", "POB_45_59", "POB_60_MAS", "H", "M",
             "REDCODE", "CASAS", "DEPARTAMEN", "TIPO_VIV", "USO_SUELO", "PXQ", "COMUNA", "PROVINCIA", "ID_PROV", "REGION",
             "ID_REG", "geometry"])

ESQUEMAS = {
    "censo": _CENSO,
    # gs://…/Cartografia/POIS/PI01_POI.gpkg · 146.345 puntos · 28 columnas
    "pois": ["COD_CNTRY", "ID_POI", "SOURCE", "ID_SOURCE", "COD_APD3", "COD_CITY", "ZIP_COD", "CAT1_DES", "CAT2_DES", "CAT3_DES",
             "CAT_ENG", "BRAND", "TRADENAME", "ADDRESS", "REFERENCE", "HOURS", "PHONE", "PHONE2", "WEB", "EMAIL", "OBS", "LON_X",
             "LAT_Y", "STATUS", "UPD_DATE", "CRE_DATE", "CHAIN", "geometry"],
    # gs://…/2026/BBRR_1_SEMESTRE_2026/MKTS_BBRR_2026_01.txt (separador |) · 9.528.541 filas · 23 columnas
    "bbrr": ["ROL", "MANZANA", "PREDIO", "COD_COMUNA", "COMUNA", "DIRECCION", "AVALUO_FISCAL", "AVALUO_EXENTO_PROPIEDAD",
             "CONTRIBUCION_SEMESTRAL", "CODIGO_DESTINO", "GLOSA_DESTINO", "TIPO_PROPIEDAD", "SUPERFICIE_TERRENO", "RADIO", "RUTID",
             "PATERNO", "MATERNO", "NOMBRES", "NOMBRE_RAZON_SOCIAL", "CIUDAD", "REGION", "LATITUD", "LONGITUD"],
    # gs://…/Cartografia/BC08_STREET.gpkg · 712.668 tramos · 33 columnas
    "street": ["COD_CNTRY", "ID_STREET", "ID_NAME", "COD_APD3", "COD_CITY", "COD_UNIQUE", "ID_BLOCK_L", "ID_BLOCK_R", "ID_NBHD_L",
               "ID_NBHD_R", "COD_APD3_L", "COD_APD3_R", "TYP_STREET", "NAM_STREET", "SYNONYM1", "SYNONYM2", "NUM_BLOCK", "COD_STREET",
               "START_LEFT", "END_LEFT", "START_RIG", "END_RIG", "START_LEF2", "END_LEF2", "START_RIG2", "END_RIG2", "DIRECTION",
               "LEVEL", "HIERARCHY", "SYMBOL", "TYPE_MAT", "LABEL", "geometry"],
    # gs://…/DATOS_CHILE/2026_BASE_PERSONAS/personas_20260825_tramos_sociedades.parquet · 17.239.671 personas · 72 columnas
    "per": ["RUTID", "NOMBRE", "PATERNO", "MATERNO", "NOMBRES", "FECHA_NACIMIENTO", "EDAD", "SEXO", "FECHA_DEFUNCION", "DEFUNCION",
            "INTERDICTO", "EST_CIVIL", "FEC_MATRIMONIO", "TIPO_NACIONALIDAD", "NACIONALIDAD", "PROFESION_OFICIO", "ISE", "RENTA_EFX",
            "CANT_PERSONAS_HH", "VEHI_CANTIDAD_HH", "VEHI_AVALUO_TOTAL_HH", "AVALUO_BBRR_TOTAL_HH", "CLEAN2_HH", "RENTA_TOTAL_HH",
            "PREDICTOR1_MIN_HH", "PREDICTOR1_PROM_HH", "PREDICTOR1_MAX_HH", "ISE_DOMINATE_HH", "VEHICULOS", "CANT_VEHICULOS",
            "TIPOVIA_PART", "CALLE_PART", "NUMERO_PART", "RESTO_DIRECCION_PART", "COMUNA_PART", "CIUDAD_PART", "REGION_PART",
            "GSE_PART", "DIRECC_VERIFICADA_PART", "LONGITUD_PART", "LATITUD_PART", "FECHA_DIRECCION_PART", "TIPO_DOMICILIO_PART",
            "COD_ACTECO", "ACTIVIDAD_PRINCIPAL", "RUTID_CONYUGE", "RUTID_PADRE", "RUTID_MADRE", "BBRR", "CANT_BBRR",
            "EVERCLEAN_12M", "EVERCLEAN_24M", "EVERCLEAN_36M", "BOLCOM", "DICOM", "ICOM", "HIJOS_0_2_ANOS", "HIJOS_3_5_ANOS",
            "HIJOS_6_13_ANOS", "HIJOS_14_17_ANOS", "HIJOS_18_24_ANOS", "HIJOS_25_ANOS_O_MAS", "CANT_HIJOS_TOTAL",
            "PARTICIP_SOCIEDADES", "TRAMO_PROPIEDADES", "TRAMO_VEHICULO", "TRAMO_HIJOS", "TRAMO_FAMILIA", "TRAMO_EDAD",
            "TRAMO_RENTA", "TRAMO_RENTA_HH", "PROFESION_LIMPIA"],
    # gs://…/2026/REZEPKA_BODEGAS/BD_EMPRESAS_ACTIVAS_3007.txt (separador |) · 787.826 empresas · 31 columnas
    "emp": ["RUTID", "RAZON_SOCIAL", "ACTIVA", "FECHA_INICIACION_ACTIVIDADES", "CODIGO_ACTIVIDAD", "ACTIVIDAD_PRINCIPAL",
            "FECHA_CONSTITUCION", "MARCA_PROPYME", "MONEDA_EXTRANJERA", "TAMANO_EMPRESAS", "RUBRO", "RUBRO_ESPECIFICO",
            "CANTIDAD_TRAB", "RANGO_TRABAJADORES", "TIPO_EMPRESA", "FACTURACION_SUB_RANGO", "ULTIMO_DOCUMENTO",
            "FECHA_ULTIMO_DOCUMENTO", "FONO_AREA_COMER", "FONO_NUMERO_COMER", "TIPOVIA_COMER", "CALLE_COMER", "NUMERO_COMER",
            "RESTO_DIRECCION_COMER", "COMUNA_COMER", "CIUDAD_COMER", "REGION_COMER", "LONGITUD_COMER", "LATITUD_COMER",
            "GSE_COMER", "COD_POSTAL_COMER"],
}

# Cómo viene el RUT en cada base (verificado en las bases reales): 10 caracteres con ceros a la izquierda en personas
# ("0216897560" = 21.689.756-0); sin ceros en empresas ("784372936" = 78.437.293-6). Ambos traen el dígito verificador.
RUT_EQUIFAX = {"per": "RUTID (texto, 10 caracteres con ceros a la izquierda, con dígito verificador)",
               "emp": "RUTID (número sin ceros a la izquierda, con dígito verificador)"}

# Grafos viales por región: carpeta prioritarias/graph (nombres EXACTOS de los archivos; código ISO 3166-2:CL + nombre)
GRAFOS_CHILE = [
    "CL-AI_aysen_del_general_carlos_ibanez_del_campo.graphml",
    "CL-AN_antofagasta.graphml",
    "CL-AP_arica_y_parinacota.graphml",
    "CL-AR_araucania.graphml",
    "CL-AT_atacama.graphml",
    "CL-BI_biobio.graphml",
    "CL-CO_coquimbo.graphml",
    "CL-LI_libertador_general_bernardo_o_higgins.graphml",
    "CL-LL_los_lagos.graphml",
    "CL-LR_los_rios.graphml",
    "CL-MA_magallanes_y_de_la_antartica_chilena.graphml",
    "CL-ML_maule.graphml",
    "CL-NB_nuble.graphml",
    "CL-RM_metropolitana_de_santiago.graphml",
    "CL-TA_tarapaca.graphml",
    "CL-VS_valparaiso.graphml",
]

_VACIAS = {"region", "de", "del", "la", "las", "los", "el", "y", "e"}


def _compacto(texto):
    """'Región Metropolitana de Santiago' -> 'metropolitanasantiago' (para comparar nombres de región con archivos)."""
    return "".join(t for t in norm_txt(texto).split() if t not in _VACIAS)


def nombre_region_de_grafo(archivo):
    """'CL-RM_metropolitana_de_santiago.graphml' -> 'metropolitana de santiago'."""
    base = os.path.basename(str(archivo))
    base = re.sub(r"\.graphml(\.gz)?$", "", base, flags=re.I)
    return base.split("_", 1)[1].replace("_", " ") if "_" in base else base


def grafo_para_region(region, disponibles=None):
    """Archivo de grafo cuyo NOMBRE corresponde a una región escrita como venga en el censo ('METROPOLITANA DE SANTIAGO',
    'Región del Biobío', 'BIO-BIO'…). Compara por nombre, no por código. None si no hay uno claramente parecido."""
    import difflib
    disponibles = list(disponibles or GRAFOS_CHILE)
    obj = _compacto(region)
    if not obj:
        return None
    puntaje = {g: difflib.SequenceMatcher(None, obj, _compacto(nombre_region_de_grafo(g))).ratio() for g in disponibles}
    for g in disponibles:                          # contención: 'metropolitanasantiago' ⊂ 'regionmetropolitanasantiago'
        c = _compacto(nombre_region_de_grafo(g))
        if c and (c in obj or obj in c):
            puntaje[g] = max(puntaje[g], 0.95)
    mejor = max(puntaje, key=puntaje.get) if puntaje else None
    return mejor if mejor and puntaje[mejor] >= 0.75 else None


def comparar(base, columnas):
    """Encabezado real vs. esperado: (faltan, nuevas). Ignora mayúsculas/espacios para no dar falsas alarmas."""
    esperado = ESQUEMAS[base]
    real = [str(c).strip() for c in columnas]
    clave = lambda c: c.upper()
    r, e = {clave(c) for c in real}, {clave(c) for c in esperado}
    faltan = [c for c in esperado if clave(c) not in r]
    nuevas = [c for c in real if clave(c) not in e]
    return faltan, nuevas


def columnas_config_fuera_de_esquema(cfg):
    """Columnas de config_estudio.COLUMNAS que no existen en la base real (error de tipeo en la configuración)."""
    from .insumos import _esperadas
    malas = []
    for base in ESQUEMAS:
        if base not in cfg["columnas"]:
            continue
        validas = set(ESQUEMAS[base])
        for logico, reales in _esperadas(cfg, base).items():
            malas += [(base, logico, r) for r in reales if r not in validas]
    return malas
