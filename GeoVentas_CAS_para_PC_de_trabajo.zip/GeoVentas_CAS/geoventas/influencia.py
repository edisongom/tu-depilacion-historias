# -*- coding: utf-8 -*-
"""Zonas de influencia MODELADAS: de dónde vendría la demanda de cada sede, SIN RUT de pacientes ni ventas.

Antes de recibir los datos de la clínica ya se puede estimar el área de influencia de cada sede con toda la data
disponible: la demanda de cada manzana (gasto en salud por GSE del censo + trabajadores de las empresas), los tiempos
reales por la red vial (hora punta y fuera de punta), la competencia ponderada por segmento (levantamiento + POIs de
Equifax) y la base de puntos de sedes Alemana (maestro del levantamiento). Se usa el MISMO modelo de Huff del notebook 06:

    cuota_ij           = A_j·e^(−β_f·t_ij) / (1 + Σ_k A_k·e^(−β·t_ik) + Σ_c w_c·A_g·e^(−β·t_ic))
    demanda captada_ij = demanda potencial_i × cuota_ij

con parámetros de REFERENCIA (config: modelo.beta_prior, modelo.pesos_gse_iniciales, influencia.atractivo_formato,
influencia.peso_trabajadores) en lugar de los calibrados. La zona de cada sede se define igual que las reales del
notebook 05 (con RUT): las manzanas más cercanas (en minutos) que reúnen el 60% de su demanda captada (zona primaria) y
hasta el 80% (secundaria). Así las preliminares se comparan directo con las reales cuando lleguen los RUT (notebook 05).

Incertidumbre: β (cuánto pesa la distancia) es el supuesto que más mueve las zonas; se recalculan con β × 0,75 (la gente
viaja más que lo supuesto) y β × 1,25 (viaja menos) para mostrar el rango.

Vectorizado y en paralelo: tiempos con Dijkstra repartido entre los núcleos (red.tiempos_a_puntos); la cuota de todas
las manzanas y sedes sale de operaciones de matrices (modelo._partes); los contornos de las zonas se dibujan en paralelo.
"""
import numpy as np
import pandas as pd
import geopandas as gpd
from scipy import sparse

from . import modelo as M
from .utilidades import en_paralelo, miles, pct, n_nucleos

NOMBRE_ZONA = {1: "primaria", 2: "secundaria"}


# --------------------------------------------------------------------------------------------- SEDES
def sedes_red(maestro, area, cfg):
    """Sedes de la base de puntos (maestro) dentro del área, con la MISMA regla del notebook 02 para decidir cuáles
    entran al modelo (fuera: estacionales, edificios de un campus que reportan con la sede principal, registros por
    verificar, formato no reconocido). Devuelve (sedes en EPSG:4326 con x, y métricos, informe)."""
    from .entorno import sitios_maestro
    s, inf = sitios_maestro(maestro, area, cfg)
    txt = pd.Series("", index=s.index)
    for c in ("formato", "estado", "tipo_registro"):
        if c in s:
            txt = txt + " " + s[c].fillna("").astype(str)
    txt = txt.str.lower()
    s["motivo_exclusion"] = ""
    for k in cfg["excluir_sedes"]:
        s.loc[txt.str.contains(k, regex=False) & (s["motivo_exclusion"] == ""), "motivo_exclusion"] = f"formato/estado contiene '{k}'"
    s.loc[s["formato_modelo"].isna() & (s["motivo_exclusion"] == ""), "motivo_exclusion"] = "formato no reconocido"
    s["en_modelo"] = s["motivo_exclusion"] == ""
    return s.to_crs("EPSG:4326"), inf


# --------------------------------------------------------------------------------------------- MODELO DE REFERENCIA
def theta_referencia(gse, cfg, beta_mult=1.0):
    """Parámetros del modelo de Huff sin calibrar (supuestos documentados en config). κ = 1: la 'demanda captada' queda
    en pesos de gasto en salud (no es venta: la escala real sale al calibrar con las ventas)."""
    Mo, I = cfg["modelo"], cfg["influencia"]
    a = np.array([I["atractivo_formato"][f] for f in M.FORMATOS], float)
    b = np.log([Mo["beta_prior"][f] * beta_mult for f in M.FORMATOS])
    p = np.log([max(Mo["pesos_gse_iniciales"].get(g, 0.1), 1e-3) for g in gse[1:]])
    # competencia: un competidor de segmento premium atrae lo mismo que una sede propia del formato equivalente
    return np.r_[0.0, np.log(I["peso_trabajadores"]), a, b, a.copy(), p, 0.0]


def datos(ut, sedes, T, pc, cfg):
    """DatosHuff sin observaciones (no hay ventas ni RUT): solo demanda, tiempos y competencia."""
    n, J = T.shape
    U = {"A": sparse.csr_matrix((0, n)), "S": np.zeros((0, J)), "mask": np.zeros((0, J), bool)}
    return M.armar_datos(ut, sedes, T, pc, U, cfg)


def captacion(th, d):
    """Demanda captada por cada sede en cada manzana (n × J), demanda potencial (n) y cuota (n × J)."""
    *_, Dt, E, F, FT, Den, mu = M._partes(th, d)
    return mu, Dt, mu / np.where(Dt[:, None] > 0, Dt[:, None], np.nan)


# --------------------------------------------------------------------------------------------- ZONAS
def _zona(t, w, cortes):
    """Zona (0 fuera, 1 primaria, 2 secundaria) de cada manzana y minutos que reúnen el 50/60/80% de `w`, ordenando por `t`."""
    z = np.zeros(len(t), np.int8)
    tiempos = np.full(3, np.nan)
    ok = np.isfinite(t) & (w > 0)
    idx = np.flatnonzero(ok)
    if not len(idx):
        return z, tiempos
    o = idx[np.argsort(t[idx], kind="stable")]
    acum = np.cumsum(w[o])
    tot = acum[-1]
    previo = (acum - w[o]) / tot
    z[o[previo < cortes[0]]] = 1
    z[o[(previo >= cortes[0]) & (previo < cortes[1])]] = 2
    for k, c in enumerate((0.5, cortes[0], cortes[1])):
        tiempos[k] = t[o[min(int(np.searchsorted(acum / tot, c)), len(o) - 1)]]
    return z, tiempos


def zonas_por_sede(mu, T, cortes):
    """Matriz Z (manzanas × sedes) con la zona de cada manzana para cada sede, y (sedes × 3) minutos t50, t60, t80."""
    n, J = mu.shape
    Z = np.zeros((n, J), np.int8)
    tiempos = np.full((J, 3), np.nan)
    for j in range(J):
        Z[:, j], tiempos[j] = _zona(T[:, j], mu[:, j], cortes)
    return Z, tiempos


def zonas_red(mu, T, cortes):
    """Zona de la RED completa: manzanas más cercanas a alguna sede que reúnen el 60% / 80% de la demanda captada por
    toda la red. También la sede que más capta en cada manzana."""
    w = mu.sum(1)
    t = np.min(np.where(np.isfinite(T), T, np.inf), axis=1)
    z, tiempos = _zona(t, w, cortes)
    dominante = np.where(w > 0, np.argmax(mu, axis=1), -1)
    return z, tiempos, t, dominante


def territorios(mu, fmt):
    """Territorio de cada sede DENTRO DE SU FORMATO: manzanas donde es la clínica (o el centro médico, o la toma de
    muestras) de la red que más captaría. Comparar entre formatos no tiene sentido (una clínica capta más que una toma de
    muestras en casi todas partes y atienden necesidades distintas). Devuelve (n × J) bool y {formato: índice dominante}."""
    n, J = mu.shape
    terr = np.zeros((n, J), bool)
    dom = {}
    for f in np.unique(fmt):
        cols = np.flatnonzero(fmt == f)
        sub = mu[:, cols]
        d = np.where(sub.sum(1) > 0, cols[np.argmax(sub, axis=1)], -1)
        dom[int(f)] = d
        for j in cols:
            terr[:, j] = d == j
    return terr, dom


def _traslape(mu, Z, recinto):
    """Parte de la demanda de la zona primaria de cada sede que también está en la zona primaria de otra sede (de otro
    recinto), y con cuál comparte más."""
    P = (Z == 1)
    J = Z.shape[1]
    tr, con, frac = np.zeros(J), [-1] * J, np.zeros(J)
    for j in range(J):
        otras = recinto != recinto[j]
        base = mu[:, j] * P[:, j]
        tot = base.sum()
        if tot <= 0 or not otras.any():
            continue
        tr[j] = (base * P[:, otras].any(1)).sum() / tot
        por = (base[:, None] * P[:, otras]).sum(0) / tot
        k = int(np.argmax(por))
        con[j], frac[j] = int(np.flatnonzero(otras)[k]), float(por[k])
    return tr, con, frac


# --------------------------------------------------------------------------------------------- ANÁLISIS COMPLETO
VARIABLES = ["pob", "pob_objetivo", "hog_objetivo", "gasto_salud_total", "gasto_salud_objetivo", "trabajadores_est", "comp_n_modelo", "area_km2"]


def analizar(ut, sedes, T, pc, cfg, cronometro=None):
    """Zonas de influencia modeladas de las sedes del modelo para cada modo. T = {modo: matriz manzanas × sedes}.
    Devuelve dict: resumen (sede × modo), red (modo), sensibilidad (sede), manzanas (por manzana, modo de referencia),
    zonas_largo (ut, sede, modo, zona) y Z, mu del modo de referencia."""
    log = cronometro or (lambda m: None)
    I = cfg["influencia"]
    cortes = tuple(I["cortes"])
    modos = [m for m in I["modos"] if m in T]
    modo_ref = "auto_punta" if "auto_punta" in modos else modos[0]
    V = np.column_stack([pd.to_numeric(ut[c], errors="coerce").fillna(0).to_numpy(float) if c in ut else np.zeros(len(ut)) for c in VARIABLES])
    nom = sedes["nombre_visible"].to_numpy() if "nombre_visible" in sedes else sedes["sede"].to_numpy()
    rec = sedes["recinto"].to_numpy() if "recinto" in sedes else np.arange(len(sedes))
    th = theta_referencia(cfg["gse"], cfg)
    filas_s, filas_r, largos, out = [], [], [], {}
    for modo in modos:
        d = datos(ut, sedes, T[modo], pc, cfg)
        mu, Dt, cuota = captacion(th, d)
        Z, tz = zonas_por_sede(mu, T[modo], cortes)
        zr, tr_red, tmin, dom = zonas_red(mu, T[modo], cortes)
        tras, con, frac = _traslape(mu, Z, rec)
        # territorio: manzanas donde la sede es la de SU FORMATO que más captaría (reparte el área entre las sedes de cada formato)
        fmt = sedes["formato_modelo"].map({f: k for k, f in enumerate(M.FORMATOS)}).to_numpy()
        terr, dom_f = territorios(mu, fmt)
        St = terr.T.astype(float) @ V
        propia = (mu * terr).sum(0) / np.where(mu.sum(0) > 0, mu.sum(0), np.nan)
        for k, nombre_z in NOMBRE_ZONA.items():          # sumas por zona: (Z == k)ᵀ · V en una multiplicación
            Sz = (Z == k).T.astype(float) @ V
            Mz = ((Z == k) * mu).sum(0)
            Dz = ((Z == k) * Dt[:, None]).sum(0)
            for j in range(len(sedes)):
                filas_s.append({"sede": sedes["sede"].iloc[j], "modo": modo, "zona": nombre_z,
                                **dict(zip(VARIABLES, Sz[j])), "demanda_captada": Mz[j], "cuota_media": Mz[j] / Dz[j] if Dz[j] > 0 else np.nan})
        for j in range(len(sedes)):
            filas_s.append({"sede": sedes["sede"].iloc[j], "modo": modo, "zona": "tiempos", "t50_min": tz[j, 0], "t60_min": tz[j, 1],
                            "t80_min": tz[j, 2], "demanda_captada_total": mu[:, j].sum(), "traslape_primaria": tras[j],
                            "traslape_con": f"{nom[con[j]]} ({pct(frac[j], 0)})" if con[j] >= 0 and frac[j] > 0 else "",
                            "demanda_en_territorio_propio": propia[j], "comunas_principales": comunas_principales(mu[:, j], ut),
                            **{f"{v}_territorio": St[j, a_] for a_, v in enumerate(VARIABLES)}})
        Sr = np.column_stack([(zr == k) for k in NOMBRE_ZONA]).T.astype(float) @ V
        for a_, (k, nombre_z) in enumerate(NOMBRE_ZONA.items()):
            filas_r.append({"modo": modo, "zona": nombre_z, **dict(zip(VARIABLES, Sr[a_])),
                            "demanda_captada": float(mu[zr == k].sum()), "t50_min": tr_red[0], "t60_min": tr_red[1], "t80_min": tr_red[2]})
        filas_r.append({"modo": modo, "zona": "toda la red", "demanda_captada": float(mu.sum()), "demanda_potencial": float(Dt.sum()),
                        "cuota_red": float(mu.sum() / Dt.sum()) if Dt.sum() > 0 else np.nan, "t80_min": tr_red[2]})
        zl = pd.DataFrame({"ut": np.repeat(ut["ut"].to_numpy(), len(sedes)), "sede": np.tile(sedes["sede"].to_numpy(), len(ut)),
                           "zona": Z.ravel()})
        largos.append(zl[zl["zona"] > 0].assign(modo=modo))
        if modo == modo_ref:
            out.update({"Z": Z, "mu": mu, "Dt": Dt, "zona_red": zr, "territorio": terr, "dominante_formato": dom_f, "min_red": tmin, "cuota": cuota})
        log(f"influencia · {modo}: t80 de la red {miles(tr_red[2], 1)} min")
    # sensibilidad a β (modo de referencia)
    sens = []
    for mult in [1.0] + list(I["sensibilidad_beta"]):
        d = datos(ut, sedes, T[modo_ref], pc, cfg)
        mu, Dt, _ = captacion(theta_referencia(cfg["gse"], cfg, mult), d)
        Z, tz = zonas_por_sede(mu, T[modo_ref], cortes)
        zr, tr_red, *_ = zonas_red(mu, T[modo_ref], cortes)
        area = (Z > 0).T.astype(float) @ ut["area_km2"].to_numpy(float)
        for j in range(len(sedes)):
            sens.append({"sede": sedes["sede"].iloc[j], "beta_x": mult, "t80_min": tz[j, 2], "superficie_km2": area[j]})
        sens.append({"sede": "RED", "beta_x": mult, "t80_min": tr_red[2], "superficie_km2": float(ut.loc[zr > 0, "area_km2"].sum())})
    resumen = _armar_resumen(pd.DataFrame(filas_s), sedes, modo_ref)
    manz = pd.DataFrame({"ut": ut["ut"].to_numpy(), "zona_red": pd.Series(out["zona_red"]).map(NOMBRE_ZONA).fillna("fuera").to_numpy(),
                         "cuota_red": np.nansum(out["cuota"], axis=1), "demanda_red": out["mu"].sum(1), "min_red": out["min_red"]})
    for k, d in out["dominante_formato"].items():             # sede de cada formato que más captaría en la manzana
        manz[f"sede_dominante_{M.FORMATOS[k]}"] = np.where(d >= 0, sedes["sede"].to_numpy()[np.maximum(d, 0)], None)
    manz["min_red"] = manz["min_red"].replace(np.inf, np.nan)
    return {"resumen": resumen, "red": pd.DataFrame(filas_r), "sensibilidad": pd.DataFrame(sens), "manzanas": manz,
            "zonas_largo": pd.concat(largos, ignore_index=True), "modo_ref": modo_ref, **out}


def _armar_resumen(f, sedes, modo_ref):
    """Una fila por sede × modo: tiempos, tamaño de cada zona y traslape."""
    t = f[f["zona"] == "tiempos"].dropna(axis=1, how="all").drop(columns="zona")
    z = f[f["zona"] != "tiempos"].dropna(axis=1, how="all")
    ancho = z.pivot_table(index=["sede", "modo"], columns="zona", values=VARIABLES + ["demanda_captada", "cuota_media"])
    ancho.columns = [f"{v}_{zona}" for v, zona in ancho.columns]
    r = t.merge(ancho.reset_index(), on=["sede", "modo"], how="left")
    cols = [c for c in ("sede", "nombre_visible", "formato_modelo", "comuna") if c in sedes]
    return sedes[cols].merge(r, on="sede", how="right")


def comunas_principales(mu_col, ut, n=3):
    s = pd.Series(mu_col, index=ut["comuna"].astype(str).to_numpy()).groupby(level=0).sum().sort_values(ascending=False)
    s = s[s > 0] / s.sum()
    return ", ".join(f"{str(c).title()} ({pct(v, 0)})" for c, v in s.head(n).items())


# --------------------------------------------------------------------------------------------- POLÍGONOS
def _contornos(trabajos, cierre_m):
    from .origen import _poligono_area
    return [_poligono_area(g, cierre_m) for g in trabajos]


def poligonos(ut, sedes, Z, zona_red, cfg, territorio=None, cierre_m=30.0):
    """Contornos de la zona primaria y secundaria de cada sede, de su territorio (donde es la sede Alemana que más capta)
    y de la red completa, en paralelo (lotes de costo parejo entre los núcleos)."""
    geoms = np.asarray(ut.geometry.values)
    tareas, claves = [], []
    for j, s in enumerate(sedes["sede"]):
        for k, nombre in NOMBRE_ZONA.items():
            sel = Z[:, j] == k
            if sel.any():
                tareas.append(geoms[sel]); claves.append((s, nombre))
        if territorio is not None and territorio[:, j].any():
            tareas.append(geoms[territorio[:, j]]); claves.append((s, "territorio"))
    for k, nombre in NOMBRE_ZONA.items():
        sel = zona_red == k
        if sel.any():
            tareas.append(geoms[sel]); claves.append(("RED", nombre))
    orden = np.argsort([-len(t) for t in tareas])                      # las más grandes primero, repartidas por turnos
    n_lotes = max(1, min(len(tareas), 2 * n_nucleos(cfg)))
    lotes = [list(orden[i::n_lotes]) for i in range(n_lotes)]
    res = en_paralelo(_contornos, [([tareas[t] for t in l], cierre_m) for l in lotes if l], cfg)
    geom = {}
    for l, r in zip([l for l in lotes if l], res):
        for t, g in zip(l, r):
            geom[t] = g
    return gpd.GeoDataFrame([{"sede": claves[t][0], "zona": claves[t][1], "geometry": geom[t]} for t in range(len(tareas))],
                            geometry="geometry", crs=ut.crs)


# --------------------------------------------------------------------------------------------- COMPARACIÓN CON LAS REALES
def comparar_con_reales(zonas_largo, flujos, ind, prelim_resumen, modo="auto_punta", col_peso="venta_mensual"):
    """Cuando llegan los RUT (notebook 05): por sede, qué parte de la venta REAL cae dentro de la zona modelada (primaria
    + secundaria, que por construcción reúne el 80% de la demanda modelada) y t80 real vs modelado."""
    z = zonas_largo[zonas_largo["modo"] == modo]
    filas = []
    for s, f in flujos.groupby("sede"):
        tot = f[col_peso].sum()
        if tot <= 0:
            continue
        en_zona = set(z.loc[z["sede"] == s, "ut"])
        prim = set(z.loc[(z["sede"] == s) & (z["zona"] == 1), "ut"])
        filas.append({"sede": s, "venta_real_en_zona_modelada": f.loc[f["ut"].isin(en_zona), col_peso].sum() / tot,
                      "venta_real_en_primaria_modelada": f.loc[f["ut"].isin(prim), col_peso].sum() / tot})
    c = pd.DataFrame(filas)
    if not len(c):
        return c
    if ind is not None and "t80_min" in ind:
        c = c.merge(ind[["sede", "t80_min"]].rename(columns={"t80_min": "t80_real_min"}), on="sede", how="left")
    p = prelim_resumen[prelim_resumen["modo"] == modo][["sede", "t80_min"]].rename(columns={"t80_min": "t80_modelado_min"})
    c = c.merge(p, on="sede", how="left")
    c["diferencia_t80_min"] = c["t80_modelado_min"] - c.get("t80_real_min", np.nan)
    return c
