# -*- coding: utf-8 -*-
"""Origen de los pacientes: de dónde vienen los clientes de cada sede, a nivel de MANZANA del censo.

La clínica puede entregar el origen de 3 formas (se detecta sola):
  rut          RUT de cada paciente (en claro o seudonimizado) -> se cruza con personas (per) y empresas (emp);
               ver módulo `pacientes` (es la forma recomendada: zonas de influencia reales)
  zona         código INE de manzana o zona censal, o comuna (grupos con < 5 pacientes sumados a la comuna)
  coordenadas  lat/lon del domicilio
Todo termina en flujos unidad × sede (venta mensual en régimen) y en las UNIDADES DE CALIBRACIÓN del modelo.
"""
import numpy as np
import pandas as pd
import geopandas as gpd
import shapely
from scipy import sparse

from .utilidades import norm_txt
from .unidades import unidad_de_manzanas, asignar_a_unidades


# --------------------------------------------------------------------------------------------- ZONAS
def tabla_manzanas(censo, ut, cfg):
    """Manzanas con su unidad, códigos (ID_BLOCK, REDCODE, comuna) y peso de demanda (gasto en salud × afinidad GSE inicial)."""
    C = cfg["columnas"]["censo"]
    cat = cfg["censo"]["categoria_gasto_salud"]
    w0 = cfg["modelo"]["pesos_gse_iniciales"]
    gasto = sum(pd.to_numeric(censo[C["gasto_cat_gse"].format(cat=cat, gse=g)], errors="coerce").fillna(0) * w0.get(g, 0.1) for g in cfg["gse"])
    t = pd.DataFrame({"id_block": censo[C["id"]].astype(str).values,
                      "cod_ine": censo[C["cod_ine"]].astype(str).str.replace(r"\D", "", regex=True).values if C["cod_ine"] in censo else "",
                      "cod_comuna": censo[C["cod_comuna"]].astype(str).str.zfill(5).values,
                      "comuna": censo[C["comuna"]].map(norm_txt).values, "ut": unidad_de_manzanas(censo, ut, cfg), "peso": gasto.values + 1e-6})
    return t[t["ut"].notna()].reset_index(drop=True)


def resolver_zonas(zonas, mz):
    """Traduce cada código de zona a un conjunto de manzanas. Niveles, en orden de prueba:
         manzana  (REDCODE o ID_BLOCK exacto) · zona censal / distrito (prefijo de REDCODE) · comuna (código o nombre)."""
    por_ine = mz.groupby("cod_ine").indices
    por_blk = mz.groupby("id_block").indices
    por_com_cod = mz.groupby("cod_comuna").indices
    por_com_nom = mz.groupby("comuna").indices
    ine = mz["cod_ine"].astype(str)
    por_prefijo = {}                                   # {largo: {prefijo: índices}}: búsqueda de zona censal / distrito vectorizada
    filas = []
    for z in pd.unique(pd.Series(zonas).astype(str)):
        dig = "".join(ch for ch in z if ch.isdigit())
        nom = norm_txt(z)
        if dig and dig in por_ine:
            filas.append((z, "manzana", por_ine[dig]))
        elif z.strip() in por_blk:
            filas.append((z, "manzana", por_blk[z.strip()]))
        elif dig and len(dig) >= 7 and len(dig) == len(z.strip()):
            if len(dig) not in por_prefijo:
                por_prefijo[len(dig)] = ine.str[:len(dig)].groupby(ine.str[:len(dig)].values).indices
            idx = por_prefijo[len(dig)].get(dig, np.array([], int))
            filas.append((z, "zona censal" if len(idx) else "sin resolver", idx))
        elif dig and len(dig) <= 5 and dig.zfill(5) in por_com_cod and len(dig) == len(z.strip()):
            filas.append((z, "comuna", por_com_cod[dig.zfill(5)]))
        elif nom in por_com_nom:
            filas.append((z, "comuna", por_com_nom[nom]))
        else:
            filas.append((z, "sin resolver", np.array([], int)))
    return pd.DataFrame(filas, columns=["zona", "nivel", "idx_manzanas"])


def flujos_desde_zonas(orig, mz, cfg):
    """Flujos unidad × sede a partir de zonas (DESCRIPTIVO: para mapas e indicadores). Las zonas que agrupan varias
    manzanas se reparten según su demanda (reparto dasimétrico). La calibración NO usa este reparto: usa
    `unidades_desde_zonas`, que es exacta."""
    res = resolver_zonas(orig["zona"], mz)
    niv = dict(zip(res["zona"], res["nivel"]))
    o = orig.copy()
    o["nivel"] = o["zona"].astype(str).map(niv)
    resumen = o.groupby("nivel")["monto"].agg(["sum", "size"]).rename(columns={"sum": "monto", "size": "filas"})
    resumen["% monto"] = resumen["monto"] / resumen["monto"].sum()
    g = o.groupby(["zona", "sede", "nivel"], as_index=False)["monto"].sum()
    g["zona"] = g["zona"].astype(str)
    r = res[res["idx_manzanas"].map(len) > 0]
    idx = np.concatenate(r["idx_manzanas"].values) if len(r) else np.array([], int)
    L = pd.DataFrame({"zona": np.repeat(r["zona"].values, r["idx_manzanas"].map(len).values), "ut": mz["ut"].values[idx], "w": mz["peso"].values[idx]})
    L["share"] = L["w"] / L.groupby("zona")["w"].transform("sum")
    L = L.groupby(["zona", "ut"], as_index=False)["share"].sum()
    f = g.merge(L, on="zona", how="inner")
    f["monto"] = f["monto"] * f["share"]
    f = f.groupby(["ut", "sede", "nivel"], as_index=False)["monto"].sum()
    return f, resumen.reset_index()


def flujos_desde_coordenadas(orig, ut, cfg):
    g = gpd.GeoDataFrame(orig, geometry=gpd.points_from_xy(orig["lon"], orig["lat"]), crs="EPSG:4326")
    o = orig.copy()
    o["ut"] = asignar_a_unidades(g, ut, cfg)
    o["nivel"] = np.where(o["ut"].notna(), "coordenadas", "sin resolver")
    resumen = o.groupby("nivel")["monto"].agg(["sum", "size"]).rename(columns={"sum": "monto", "size": "filas"})
    resumen["% monto"] = resumen["monto"] / resumen["monto"].sum()
    f = o[o["ut"].notna()].groupby(["ut", "sede", "nivel"], as_index=False)["monto"].sum()
    return f, resumen.reset_index()


def escalar_flujos(f, venta_madura, ut):
    """Lleva los flujos (de cualquier periodo) a VENTA MENSUAL EN RÉGIMEN de cada sede:
         flujo_ij (CLP/mes) = venta_madura_j × monto_ij / Σ_i monto_ij
    Así la distribución espacial viene del origen y el nivel viene de la serie de 5 años."""
    vm = venta_madura.set_index("sede")["venta_mensual_madura"]
    f = f[f["ut"].isin(set(ut["ut"])) & f["sede"].isin(vm.index)].copy()
    tot = f.groupby("sede")["monto"].transform("sum")
    f["venta_mensual"] = f["monto"] / tot * f["sede"].map(vm)
    return f


# --------------------------------------------------------------------------------------------- UNIDADES DE CALIBRACIÓN
def unidades_desde_zonas(orig, mz, ut, sedes_modelo, venta_madura):
    """Unidades de calibración EXACTAS para origen agregado por zonas.
    Cada zona fina reportada (manzana o zona censal) es una unidad: el modelo predice la suma de sus unidades territoriales
    (cada una pondera según la fracción de su demanda que cae en la zona; con manzanas esa fracción es 1).
    Los grupos chicos que la clínica sumó a la comuna forman, para cada sede, una unidad "resto de la comuna" con las
    manzanas de esa comuna que NO aparecen reportadas para esa sede: así no se traslapan y la regla de anonimato no sesga."""
    sid = list(sedes_modelo["sede"]); J = len(sid); n = len(ut)
    pos_ut = pd.Series(np.arange(n), index=ut["ut"].values)
    mz = mz[mz["ut"].isin(pos_ut.index)].reset_index(drop=True)
    i_ut = pos_ut[mz["ut"]].values
    W = np.bincount(i_ut, weights=mz["peso"].values, minlength=n)
    frac = mz["peso"].values / np.maximum(W[i_ut], 1e-12)
    o = orig[orig["sede"].isin(sid)].copy()
    o["zona"] = o["zona"].astype(str)
    res = resolver_zonas(o["zona"], mz)
    niv = dict(zip(res["zona"], res["nivel"])); idxs = dict(zip(res["zona"], res["idx_manzanas"]))
    o["nivel"] = o["zona"].map(niv)
    g = o[o["nivel"] != "sin resolver"].groupby(["zona", "sede", "nivel"], as_index=False)["monto"].sum()
    finas = g[g["nivel"].isin(["manzana", "zona censal"])]
    zf = sorted(finas["zona"].unique(), key=lambda z: (niv[z] == "manzana", z))
    pos_z = {z: k for k, z in enumerate(zf)}
    zona_de = np.full(len(mz), -1)
    for z in zf:
        zona_de[idxs[z]] = pos_z[z]
    ok = zona_de >= 0
    A_f = sparse.csr_matrix((frac[ok], (zona_de[ok], i_ut[ok])), shape=(len(zf), n))
    tot = g.groupby("sede")["monto"].sum()
    vm = venta_madura.set_index("sede")["venta_mensual_madura"]
    S_f = np.zeros((len(zf), J)); M_f = np.zeros((len(zf), J), bool)
    fz = finas.assign(fila=finas["zona"].map(pos_z), j=finas["sede"].map({s: k for k, s in enumerate(sid)}))
    fz["S"] = fz["sede"].map(vm).fillna(0) * fz["monto"] / fz["sede"].map(tot)
    np.add.at(S_f, (fz["fila"].values, fz["j"].values), fz["S"].values)
    M_f[fz["fila"].values, fz["j"].values] = True
    com_mz = mz["cod_comuna"].values
    com_rows = g[g["nivel"] == "comuna"].copy()
    com_rows["cod_comuna"] = com_rows["zona"].map(lambda z: pd.Series(com_mz[idxs[z]]).mode().iloc[0] if len(idxs[z]) else None)
    monto_com = com_rows.groupby(["sede", "cod_comuna"])["monto"].sum()
    comunas = np.unique(com_mz)
    filas, cols, vals, S_r, M_r, nombres_r = [], [], [], [], [], []
    k = 0
    for j, s in enumerate(sid):
        no_rep = ~np.isin(zona_de, fz.loc[fz["sede"] == s, "fila"].unique())
        for c in comunas:
            sel = no_rep & (com_mz == c)
            if not sel.any():
                continue
            filas.append(np.full(sel.sum(), k)); cols.append(i_ut[sel]); vals.append(frac[sel])
            fila_S = np.zeros(J); fila_M = np.zeros(J, bool)
            if s in tot.index:
                fila_S[j] = vm.get(s, 0) * monto_com.get((s, c), 0.0) / tot[s]
                fila_M[j] = True
            S_r.append(fila_S); M_r.append(fila_M); nombres_r.append(f"resto comuna {c} · {s}")
            k += 1
    A_r = sparse.csr_matrix((np.concatenate(vals), (np.concatenate(filas), np.concatenate(cols))), shape=(k, n)) if k else sparse.csr_matrix((0, n))
    A = sparse.vstack([A_f, A_r]).tocsr()
    S = np.vstack([S_f, np.array(S_r).reshape(-1, J)]); mask = np.vstack([M_f, np.array(M_r, bool).reshape(-1, J)])
    nombres = [f"zona {z}" for z in zf] + nombres_r
    return _agregar_total({"A": A, "S": S, "mask": mask, "unidades": nombres, "sedes": sid, "nivel": "zona",
                           "sedes_con_origen": sorted(set(tot.index)), "n_zonas_finas": len(zf), "n_restos_comuna": k}, vm, n)


def _agregar_total(U, vm, n, todas=False):
    """Agrega la unidad 'TOTAL_SEDE' (todas las unidades territoriales) para las sedes sin datos de origen."""
    sid = U["sedes"]; J = len(sid)
    sin = [j for j, s in enumerate(sid) if todas or s not in set(U["sedes_con_origen"])]
    if sin:
        U["A"] = sparse.vstack([U["A"], sparse.csr_matrix(np.ones((1, n)))]).tocsr()
        fila = np.zeros((1, J)); fila[0, sin] = pd.Series(vm).reindex([sid[j] for j in sin]).fillna(0).values
        U["S"] = np.vstack([U["S"], fila])
        U["mask"] = np.vstack([U["mask"], np.isin(np.arange(J), sin)[None, :]])
        U["unidades"] = list(U["unidades"]) + ["TOTAL_SEDE"]
    return U


def elegir_nivel(resumen, cfg, tipo=None):
    """'auto': rut o coordenadas -> 'unidad' (cada manzana es una observación); zonas -> 'zona' (exacto);
    sin origen -> 'total'. Se puede forzar 'comuna' en la configuración."""
    O = cfg["origen"]
    if O["nivel_calibracion"] != "auto":
        return O["nivel_calibracion"], None
    if resumen is None or len(resumen) == 0 or tipo in (None, "sin_origen"):
        return "total", 0.0
    r = resumen.set_index("nivel")["monto"]
    fino = float(r[[k for k in r.index if k not in ("comuna", "sin resolver", "sin cruce", "empresa", "persona sin dirección verificada")]].sum()
                 / max(r.sum(), 1))
    return ("zona" if tipo == "zona" else "unidad"), fino


def unidades_calibracion(nivel, ut, sedes_modelo, flujos=None, venta_madura=None):
    """Unidades de observación del modelo para nivel 'unidad' (cada manzana), 'comuna' o 'total'.
         A    matriz dispersa (observaciones × unidades territoriales)
         S    venta mensual observada (observaciones × sedes)
         mask qué pares entran a la verosimilitud"""
    n = len(ut)
    sid = list(sedes_modelo["sede"]); J = len(sid)
    vm = venta_madura.set_index("sede")["venta_mensual_madura"]
    con_origen = set(flujos["sede"]) if flujos is not None and len(flujos) else set()
    if nivel == "unidad" and con_origen:
        S = flujos.pivot_table(index="ut", columns="sede", values="venta_mensual", aggfunc="sum").reindex(index=ut["ut"], columns=sid).fillna(0).values
        A = sparse.identity(n, format="csr"); nombres = list(ut["ut"])
    elif nivel == "comuna" and con_origen:
        com = ut["cod_comuna"].astype(str).values
        u = sorted(set(com)); k = {c: i for i, c in enumerate(u)}
        A = sparse.csr_matrix((np.ones(n), ([k[c] for c in com], np.arange(n))), shape=(len(u), n))
        fl = flujos.assign(cod_comuna=flujos["ut"].map(pd.Series(com, index=ut["ut"].values)))
        S = fl.pivot_table(index="cod_comuna", columns="sede", values="venta_mensual", aggfunc="sum").reindex(index=u, columns=sid).fillna(0).values
        nombres = u
    else:
        A = sparse.csr_matrix((0, n)); S = np.zeros((0, J)); nombres = []
    mask = np.zeros(S.shape, bool)
    for j, s in enumerate(sid):
        if s in con_origen:
            mask[:, j] = True
    U = {"A": A.tocsr(), "S": S, "mask": mask, "unidades": nombres, "sedes": sid, "nivel": nivel,
         "sedes_con_origen": sorted(con_origen)}
    return _agregar_total(U, vm, n, todas=(nivel == "total"))


# --------------------------------------------------------------------------------------------- DIAGNÓSTICO
def indicadores_sede(flujos, T, ut, sedes_modelo, venta_madura, bandas=(0, 5, 10, 15, 20, 30, 45, 999)):
    """Por sede: minutos que reúnen el 50/60/80% de la venta (t50, t60, t80), % de la venta por banda de minutos,
    unidades de origen y penetración (venta / gasto en salud de la población a ≤ t80)."""
    pos = pd.Series(np.arange(len(ut)), index=ut["ut"].values)
    filas = []
    for j, s in enumerate(sedes_modelo["sede"]):
        f = flujos[flujos["sede"] == s]
        fila = {"sede": s}
        if len(f):
            t = T[pos.reindex(f["ut"]).values.astype(int), j]
            w = f["venta_mensual"].values
            ok = np.isfinite(t)
            o = np.argsort(t[ok]); tt = t[ok][o]; cw = np.cumsum(w[ok][o]) / max(w.sum(), 1e-9)
            for p in (50, 60, 80):
                fila[f"t{p}_min"] = float(tt[min(np.searchsorted(cw, p / 100), len(tt) - 1)]) if len(tt) else np.nan
            for lo, hi in zip(bandas[:-1], bandas[1:]):
                m = ok & (t >= lo) & (t < hi)
                fila[f"% venta {lo}-{hi if hi < 999 else '+'} min"] = float(w[m].sum() / max(w.sum(), 1e-9))
            fila["% venta fuera del horizonte"] = float(w[~ok].sum() / max(w.sum(), 1e-9))
            fila["unidades_origen"] = int((w > 0).sum())
            dentro = np.isfinite(T[:, j]) & (T[:, j] <= fila["t80_min"])
            fila["gasto_salud_a_t80"] = float(ut.loc[dentro, "gasto_salud_total"].sum())
            fila["pob_objetivo_a_t80"] = float(ut.loc[dentro, "pob_objetivo"].sum())
        filas.append(fila)
    out = pd.DataFrame(filas).merge(venta_madura[["sede", "venta_mensual_madura"]], on="sede", how="left")
    if "gasto_salud_a_t80" in out:
        out["penetracion_gasto_t80"] = 0.8 * out["venta_mensual_madura"] / out["gasto_salud_a_t80"].replace(0, np.nan)
    return out


def _poligono_area(geoms, cierre_m=30.0):
    """Contorno de un conjunto de manzanas: unión con un 'cierre' morfológico que tapa las calles entre manzanas."""
    g = np.asarray(geoms)
    if not len(g):
        return None
    return shapely.union_all(shapely.buffer(g, cierre_m, quad_segs=2)).buffer(-cierre_m * 0.8, quad_segs=2)


def areas_influencia(flujos, T, ut, sedes_modelo, cfg, cortes=(0.6, 0.8), col_peso="venta_mensual"):
    """Área primaria (unidades más cercanas que suman el 60% de la venta) y secundaria (60–80%), por sede, como polígonos."""
    pos = pd.Series(np.arange(len(ut)), index=ut["ut"].values)
    geo = ut.set_index("ut").geometry
    pob = ut.set_index("ut")["pob"]
    filas = []
    for j, s in enumerate(sedes_modelo["sede"]):
        f = flujos[flujos["sede"] == s].copy()
        if not len(f):
            continue
        f["t"] = T[pos.reindex(f["ut"]).values.astype(int), j]
        f = f[np.isfinite(f["t"])].sort_values("t")
        previo = (f[col_peso].cumsum() - f[col_peso]) / f[col_peso].sum()
        for nombre, (lo, hi) in {"primaria": (0.0, cortes[0]), "secundaria": (cortes[0], cortes[1])}.items():
            sel = f[(previo >= lo) & (previo < hi)]
            if len(sel):
                filas.append({"sede": s, "area": f"{nombre} ({int(lo * 100)}–{int(hi * 100)}% de la venta)",
                              "minutos_max": float(sel["t"].max()), "unidades": len(sel), "venta_mensual": float(sel[col_peso].sum()),
                              "pacientes": float(sel["pacientes"].sum()) if "pacientes" in sel else np.nan,
                              "pob": float(pob.loc[sel["ut"]].sum()), "geometry": _poligono_area(geo.loc[sel["ut"]].values)})
    return gpd.GeoDataFrame(filas, geometry="geometry", crs=cfg["estudio"]["crs_metrico"])


def matriz_od_comunas(flujos, ut, sedes_modelo):
    """Origen-destino por comuna: % de la venta de cada sede que viene de cada comuna, y % del total de la red."""
    com = ut.set_index("ut")["comuna"]
    f = flujos.assign(comuna=flujos["ut"].map(com))
    m = f.pivot_table(index="comuna", columns="sede", values="venta_mensual", aggfunc="sum", fill_value=0)
    m = m.reindex(columns=[s for s in sedes_modelo["sede"] if s in m.columns])
    pct = m / m.sum(axis=0)
    pct["% del total de la red"] = m.sum(axis=1) / m.values.sum()
    return pct.sort_values("% del total de la red", ascending=False)


def perfil_ecologico(flujos, ut, cfg):
    """Perfil GSE de la demanda de cada sede cuando NO hay RUT: composición GSE de las unidades de origen ponderada por la venta."""
    G = cfg["gse"]
    comp = ut.set_index("ut")[[f"pob_{g}" for g in G]]
    comp = comp.div(comp.sum(axis=1).replace(0, np.nan), axis=0).fillna(0)
    f = flujos.join(comp, on="ut")
    out = f.groupby("sede").apply(lambda d: pd.Series({g: np.average(d[f"pob_{g}"], weights=d["venta_mensual"]) for g in G}))
    return out.add_prefix("% ").assign(fuente="composición de las unidades de origen (aproximado)")
