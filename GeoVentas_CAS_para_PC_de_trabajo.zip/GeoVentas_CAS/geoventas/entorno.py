# -*- coding: utf-8 -*-
"""Análisis de ENTORNO de cada sede de la red Alemana (base de puntos del levantamiento: RUTAS["maestro_sedes"]).

Para cada sede y cada modo (auto fuera de punta y en hora punta; se pueden agregar a pie y transporte público) y cada
corte de minutos (5, 10, 15, 20, 30), mide qué hay en la zona desde la que se llega a la sede por las calles reales:

  Personas        población, hogares, segmento objetivo (AB, C1a, C1b), mezcla de GSE, niños y adultos mayores, densidad
  Poder de compra gasto mensual en salud (total y del segmento), renta media del hogar, avalúo medio de la vivienda
  Actividad       trabajadores, empresas (y de salud), trabajadores por habitante
  Generadores     estaciones de metro, paraderos, malls, supermercados, educación, oficinas, restaurantes, gimnasios,
  de flujo        lugares de salud (POIs de Equifax), y propiedades por destino (viviendas, comercio, oficinas, salud)
  Competencia     clínicas, centros médicos y laboratorios del modelo, competidores por 10.000 personas del segmento,
                  oferta de contexto (dental, kine, farmacias), los 5 competidores más cercanos en minutos
  Red propia      otras sedes de la red a pocos minutos y TRASLAPE: qué parte de su segmento objetivo está también a
                  esos minutos de otra sede (riesgo de canibalización)
  Congestión      cuánto público objetivo pierde la sede en hora punta frente a fuera de punta, y en cuántos minutos
                  llega a una meta de personas del segmento en cada hora
  Tipo de entorno residencial de alto ingreso, polo laboral, comercial, urbano denso, baja densidad (reglas a la vista)

Cómo se calcula (vectorizado y en paralelo):
  1. Tiempos manzana → sede en cada modo con Dijkstra sobre la red (red.tiempos_a_puntos: los destinos se reparten
     entre los núcleos). Una matriz T (manzanas × sedes) por modo.
  2. Todas las variables de cada manzana en una matriz V (manzanas × variables). Para cada corte m:
     sumas = (T ≤ m)ᵀ · V  →  (sedes × variables) en una sola multiplicación de matrices.
  3. Las isócronas (polígonos) se dibujan en paralelo con red.isocronas_sitios, solo para mostrarlas en el mapa: los
     indicadores salen de las manzanas alcanzadas, que es lo mismo que usa el modelo.
"""
import numpy as np
import pandas as pd
import geopandas as gpd
from scipy.spatial import cKDTree

from . import red as RED
from .unidades import IndiceManzanas
from .utilidades import miles, pct


def _cant(n, singular, plural):
    return f"{miles(n)} {singular if n == 1 else plural}"


def _min(t):
    """'menos de 1 min', '4 min'."""
    return "menos de 1 min" if t < 1 else f"{miles(t, 0)} min"

NOMBRE_MODO = {"auto_valle": "Auto, fuera de punta", "auto_punta": "Auto, hora punta", "pie": "Caminando", "tp": "Transporte público"}
NOMBRE_FORMATO = {"clinica": "clínica", "centro_medico": "centro médico", "toma_muestras": "toma de muestras"}
POIS = {"poi_metro": "estaciones de metro", "poi_paradero": "paraderos y terminales", "poi_mall": "malls y centros comerciales",
        "poi_supermercado": "supermercados", "poi_educacion": "establecimientos educacionales", "poi_oficinas": "oficinas, bancos y notarías",
        "poi_restaurant": "restaurantes y cafés", "poi_gimnasio": "gimnasios", "poi_salud": "lugares de salud (POIs)"}
BBRR = {"bbrr_habitacional": "viviendas", "bbrr_comercio": "locales comerciales", "bbrr_oficina": "oficinas (propiedades)", "bbrr_salud": "propiedades de salud"}
EDADES_MENORES = ["pob_0_5", "pob_6_13", "pob_14_17"]


# --------------------------------------------------------------------------------------------- SEDES
def sitios_maestro(maestro, area, cfg):
    """Sedes del maestro (base de puntos del levantamiento) dentro del área de estudio, en CRS métrico.
    Devuelve (sitios, informe) con las que no tienen coordenada válida o quedan fuera del área (otra región)."""
    from .cliente import formato_modelo
    E = cfg["entorno"]
    m = maestro.copy()
    if "tipo_registro" in m and E.get("registros"):
        m = m[m["tipo_registro"].isin(E["registros"])]
    ok = np.isfinite(pd.to_numeric(m["lat"], errors="coerce")) & np.isfinite(pd.to_numeric(m["lon"], errors="coerce"))
    inf = {"en_maestro": len(m), "sin_coordenadas": m.loc[~ok, "nombre"].astype(str).tolist()}
    m = m[ok]
    g = gpd.GeoDataFrame(m, geometry=gpd.points_from_xy(m["lon"].astype(float), m["lat"].astype(float)), crs="EPSG:4326")
    dentro = g.within(area.to_crs("EPSG:4326").geometry.iloc[0]).to_numpy()
    inf["fuera_del_area"] = g.loc[~dentro, "nombre"].astype(str).tolist()
    if "region" in g:
        inf["fuera_por_region"] = g.loc[~dentro, "region"].astype(str).value_counts().to_dict()
    g = g[dentro].to_crs(cfg["estudio"]["crs_metrico"]).reset_index(drop=True)
    g["x"], g["y"] = g.geometry.x.to_numpy(), g.geometry.y.to_numpy()
    g["sede"] = g["id"].astype(str)
    g["formato_modelo"] = g["formato"].map(lambda t: formato_modelo(t, cfg)) if "formato" in g else None
    g["nombre_visible"] = g["nombre"].astype(str).str.replace(r"\bCAS\b", "Clínica Alemana", regex=True)
    # puntos a menos de `misma_sede_m` son el mismo recinto (p. ej. dos edificios del campus Vitacura)
    pares = cKDTree(np.c_[g["x"], g["y"]]).query_pairs(E["misma_sede_m"], output_type="ndarray") if len(g) > 1 else np.zeros((0, 2), int)
    grupo = np.arange(len(g))
    for a, b in sorted(map(tuple, pares)):
        grupo[grupo == grupo[b]] = grupo[a]
    g["recinto"] = grupo
    inf["analizadas"] = len(g)
    return g, inf


# --------------------------------------------------------------------------------------------- VARIABLES POR MANZANA
def variables_manzana(ut, comp, cfg):
    """Matriz V (manzanas × variables) que se suma dentro de cada zona, y la manzana de cada competidor del modelo."""
    n = len(ut)
    V = {}
    def col(c):
        return pd.to_numeric(ut[c], errors="coerce").fillna(0).to_numpy(float) if c in ut else None
    base = ["pob", "hog", "pob_objetivo", "hog_objetivo", "gasto_salud_total", "gasto_salud_objetivo", "trabajadores_est", "emp_n",
            "emp_salud_n", "area_km2", "calles_km", "vias_principales_km", "oferta_contexto_n", "pob_60_mas"] + EDADES_MENORES \
        + [f"pob_{g}" for g in cfg["gse"]] + list(POIS) + list(BBRR)
    for c in base:
        v = col(c)
        if v is not None:
            V[c] = v
    hog = V.get("hog", np.zeros(n))
    for fuente, peso, num, den in (("per_renta_hogar_mediana", hog, "_renta_x_hog", "_hog_con_renta"),
                                   ("bbrr_avaluo_hab_mediano", V.get("bbrr_habitacional", np.zeros(n)), "_avaluo_x_viv", "_viv_con_avaluo")):
        if fuente in ut:
            r = pd.to_numeric(ut[fuente], errors="coerce").to_numpy(float)
            ok = np.isfinite(r) & (peso > 0)
            V[num], V[den] = np.where(ok, r * peso, 0.0), np.where(ok, peso, 0.0)
    pos_c = np.full(0, -1)
    c = comp[comp["en_modelo"].astype(bool)].copy() if comp is not None and "en_modelo" in comp else None
    if c is not None and len(c):
        idx = IndiceManzanas(ut, np.arange(n), cfg["filtro_manzanas"].get("dist_max_actividad_m", 300)).asignar(c)
        pos_c = np.array([-1 if v is None else int(v) for v in idx])
        for grupo, nombre in (("comp_clinica", "comp_n_clinica"), ("comp_centro_medico", "comp_n_centro_medico"),
                              ("comp_laboratorio", "comp_n_laboratorio")):
            sel = (c["grupo"].to_numpy() == grupo) & (pos_c >= 0)
            V[nombre] = np.bincount(pos_c[sel], minlength=n).astype(float)
    return pd.DataFrame(V), c, pos_c


# --------------------------------------------------------------------------------------------- AGREGACIÓN VECTORIZADA
def agregar(T, V, minutos):
    """Sumas de cada variable en la zona de cada sede: (cortes × sedes × variables) = (T ≤ m)ᵀ · V para cada corte."""
    Vm = np.ascontiguousarray(V, dtype=np.float64)
    out = np.empty((len(minutos), T.shape[1], Vm.shape[1]))
    for a, m in enumerate(minutos):
        out[a] = (T <= m).T.astype(np.float64) @ Vm
    return out


def _div(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return np.where(b > 0, a / np.where(b > 0, b, 1), np.nan)


def derivar(S, cfg):
    """Indicadores legibles a partir de las sumas (una fila por sede × modo × minutos)."""
    g = lambda c: S[c] if c in S else pd.Series(0.0, index=S.index)
    o = pd.DataFrame(index=S.index)
    o["poblacion"] = g("pob"); o["hogares"] = g("hog")
    o["pob_objetivo"] = g("pob_objetivo"); o["pct_objetivo"] = _div(g("pob_objetivo"), g("pob"))
    for k in cfg["gse"]:
        if f"pob_{k}" in S:
            o[f"pct_gse_{k}"] = _div(S[f"pob_{k}"], g("pob"))
    o["pct_menores_18"] = _div(sum(g(c) for c in EDADES_MENORES), g("pob"))
    o["pct_60_mas"] = _div(g("pob_60_mas"), g("pob"))
    o["superficie_km2"] = g("area_km2"); o["densidad_hab_km2"] = _div(g("pob"), g("area_km2"))
    o["gasto_salud_mes"] = g("gasto_salud_total"); o["gasto_salud_objetivo_mes"] = g("gasto_salud_objetivo")
    o["gasto_salud_por_persona"] = _div(g("gasto_salud_total"), g("pob"))
    if "_renta_x_hog" in S:
        o["renta_media_hogar"] = _div(S["_renta_x_hog"], S["_hog_con_renta"])
    if "_avaluo_x_viv" in S:
        o["avaluo_medio_vivienda"] = _div(S["_avaluo_x_viv"], S["_viv_con_avaluo"])
    o["trabajadores"] = g("trabajadores_est"); o["trabajadores_por_habitante"] = _div(g("trabajadores_est"), g("pob"))
    o["empresas"] = g("emp_n"); o["empresas_salud"] = g("emp_salud_n")
    for c in list(POIS) + list(BBRR):
        if c in S:
            o[c] = S[c]
    o["comercio_por_10mil_hab"] = _div(sum(g(c) for c in ("poi_mall", "poi_supermercado", "poi_restaurant")) * 1e4, g("pob"))
    for c, nombre in (("comp_n_clinica", "comp_clinicas"), ("comp_n_centro_medico", "comp_centros_medicos"), ("comp_n_laboratorio", "comp_laboratorios")):
        o[nombre] = g(c)
    o["comp_total"] = o[["comp_clinicas", "comp_centros_medicos", "comp_laboratorios"]].sum(1)
    o["comp_por_10mil_objetivo"] = _div(o["comp_total"] * 1e4, g("pob_objetivo"))
    o["oferta_contexto"] = g("oferta_contexto_n")
    o["calles_km"] = g("calles_km"); o["vias_principales_km"] = g("vias_principales_km")
    return o


def minutos_para_meta(T, w, meta):
    """Minutos que necesita cada sede para reunir `meta` (p. ej. personas del segmento objetivo) en su zona. NaN si no
    la alcanza dentro del horizonte calculado."""
    w = np.asarray(w, float)
    out = np.full(T.shape[1], np.nan)
    for j in range(T.shape[1]):
        t = T[:, j]
        ok = np.isfinite(t)
        o = np.argsort(t[ok])
        acum = np.cumsum(w[ok][o])
        k = np.searchsorted(acum, meta)
        if k < len(o):
            out[j] = float(t[ok][o][k])
    return out


# --------------------------------------------------------------------------------------------- ANÁLISIS COMPLETO
def analizar(rd, ut, sitios, comp, cfg, nodos_ut=None, cronometro=None):
    """Análisis de entorno de `sitios` (sedes del maestro). Devuelve dict con:
         detalle   una fila por sede × modo × minutos con todos los indicadores
         resumen   una fila por sede: tipo de entorno, indicadores clave a los minutos de referencia, congestión,
                   traslape con otras sedes, competidores más cercanos y un texto en palabras
         T         {modo: matriz manzanas × sedes} (minutos)"""
    log = cronometro or (lambda m: None)
    E = cfg["entorno"]
    modos, minutos = list(E["modos"]), sorted(E["minutos"])
    ref, ref_tipo = E["minutos_referencia"], E["minutos_tipologia"]
    modo_ref = "auto_punta" if "auto_punta" in modos else modos[0]
    V, comp_m, pos_c = variables_manzana(ut, comp, cfg)
    xy = sitios[["x", "y"]].to_numpy(float)
    T = {}
    for modo in modos:                       # Dijkstra en paralelo (destinos repartidos entre los núcleos)
        T[modo] = RED.tiempos_a_puntos(rd, ut, xy, modo, cfg, horizonte_min=max(minutos), nodos_ut=nodos_ut)
        log(f"entorno · tiempos {modo}: {T[modo].shape[0]:,} manzanas × {T[modo].shape[1]} sedes")
    filas = []
    for modo in modos:                       # (T ≤ m)ᵀ · V para todos los cortes y sedes
        A = agregar(T[modo], V.to_numpy(), minutos)
        for a, m in enumerate(minutos):
            S = pd.DataFrame(A[a], columns=V.columns)
            S.insert(0, "minutos", m); S.insert(0, "modo", modo); S.insert(0, "sede", sitios["sede"].to_numpy())
            filas.append(S)
    S = pd.concat(filas, ignore_index=True)
    det = pd.concat([S[["sede", "modo", "minutos"]], derivar(S, cfg)], axis=1)
    obj = V["pob_objetivo"].to_numpy() if "pob_objetivo" in V else np.zeros(len(ut))
    rec = sitios["recinto"].to_numpy()
    tras = {}
    for modo in modos:                       # traslape con OTRAS sedes (otro recinto) en cada corte
        for m in minutos:
            W = T[modo] <= m
            base = obj[:, None] * W                                   # segmento objetivo de cada sede
            otra = np.column_stack([W[:, rec != rec[j]].any(1) for j in range(W.shape[1])])
            tras.update({(s, modo, m): v for s, v in zip(sitios["sede"], _div((base * otra).sum(0), base.sum(0)))})
    det["traslape_red"] = [tras.get(k, np.nan) for k in zip(det["sede"], det["modo"], det["minutos"])]
    det = det.merge(sitios[["sede", "nombre_visible", "formato_modelo"]], on="sede", how="left")
    res = _resumen(det, sitios, T, V, comp_m, pos_c, ut, cfg, modo_ref, ref, ref_tipo)
    return {"detalle": det, "resumen": res, "T": T, "modo_ref": modo_ref}


def _tipologia(r, p75_comercio):
    """Tipo de entorno (reglas a la vista) con los indicadores a `minutos_tipologia` en hora punta."""
    rasgos = []
    baja = r["poblacion"] < 20_000 and r["trabajadores"] < 20_000
    if baja:
        rasgos.append("baja densidad / periférico")
    if r["trabajadores_por_habitante"] >= 1.0 and not baja:
        rasgos.append("polo laboral")
    if r["pct_objetivo"] >= 0.40:
        rasgos.append("residencial de alto ingreso" if not baja else "de alto ingreso")
    if not baja and np.isfinite(p75_comercio) and r["comercio_por_10mil_hab"] >= p75_comercio:
        rasgos.append("comercial")
    if r["densidad_hab_km2"] >= 10_000:
        rasgos.append("urbano denso")
    if not rasgos:
        rasgos.append("residencial mixto")
    return " y ".join(rasgos[:2]).capitalize()


def _resumen(det, sitios, T, V, comp_m, pos_c, ut, cfg, modo_ref, ref, ref_tipo):
    E = cfg["entorno"]
    clave = lambda modo, m: det[(det["modo"] == modo) & (det["minutos"] == m)].set_index("sede")
    R = clave(modo_ref, ref)
    tipo = clave(modo_ref, ref_tipo)
    p75 = tipo["comercio_por_10mil_hab"].quantile(0.75) if len(tipo) else np.nan
    res = sitios[["sede", "nombre_visible", "formato_modelo", "recinto"] + [c for c in ("comuna", "estado", "lat", "lon") if c in sitios]].copy()
    res["tipo_entorno"] = res["sede"].map({s: _tipologia(r, p75) for s, r in tipo.iterrows()})
    for c in ("poblacion", "pob_objetivo", "pct_objetivo", "gasto_salud_objetivo_mes", "renta_media_hogar", "trabajadores", "empresas",
              "poi_metro", "poi_mall", "comp_clinicas", "comp_centros_medicos", "comp_laboratorios", "comp_total", "comp_por_10mil_objetivo"):
        if c in R:
            res[f"{c}_{ref}min"] = res["sede"].map(R[c])
    if "auto_valle" in T and modo_ref == "auto_punta":
        Vv = clave("auto_valle", ref)
        res[f"pob_objetivo_{ref}min_valle"] = res["sede"].map(Vv["pob_objetivo"])
        res["perdida_punta_objetivo"] = 1 - res[f"pob_objetivo_{ref}min"] / res[f"pob_objetivo_{ref}min_valle"]
        res["perdida_punta_superficie"] = 1 - res["sede"].map(R["superficie_km2"]) / res["sede"].map(Vv["superficie_km2"])
    obj = V["pob_objetivo"].to_numpy() if "pob_objetivo" in V else np.zeros(len(ut))
    meta = E["personas_objetivo_meta"]
    for modo in T:
        res[f"minutos_meta_{modo}"] = minutos_para_meta(T[modo], obj, meta)
    # índice frente a la mediana de las sedes del mismo formato (100 = como una sede típica de su formato)
    med = res.groupby("formato_modelo")[f"pob_objetivo_{ref}min"].transform("median")
    res["indice_objetivo_vs_formato"] = 100 * res[f"pob_objetivo_{ref}min"] / med.where(med > 0)
    # traslape con OTRAS sedes de la red (otro recinto) a `minutos_traslape` en el modo de referencia
    mt = E.get("minutos_traslape", ref)
    W = T[modo_ref] <= mt
    rec = res["recinto"].to_numpy()
    tras, con, cerca = [], [], []
    nombres = res["nombre_visible"].to_numpy()
    pos_s = IndiceManzanas(ut, np.arange(len(ut)), 300).asignar(gpd.GeoDataFrame(sitios[["sede"]], geometry=sitios.geometry, crs=sitios.crs))
    pos_s = np.array([-1 if v is None else int(v) for v in pos_s])
    for j in range(W.shape[1]):
        otras = rec != rec[j]
        base = obj * W[:, j]
        tot = base.sum()
        if otras.any() and tot > 0:
            tras.append(float((base * W[:, otras].any(1)).sum() / tot))
            por_otra = (base[:, None] * W[:, otras]).sum(0) / tot
            k = int(np.argmax(por_otra))
            con.append(f"{nombres[otras][k]} ({pct(por_otra[k], 0)})" if por_otra[k] > 0 else "")
        else:
            tras.append(0.0); con.append("")
        t_otras = [(nombres[k], T[modo_ref][pos_s[k], j]) for k in range(len(nombres)) if otras[k] and pos_s[k] >= 0]
        cerca.append(", ".join(f"{n} ({_min(t)})" for n, t in sorted(t_otras, key=lambda z: z[1]) if t <= ref))
    res["traslape_red"] = tras
    res["traslape_principal_con"] = con
    res["sedes_red_cerca"] = cerca
    # competidores más cercanos (en minutos, hora punta)
    if comp_m is not None and len(pos_c):
        ok = pos_c >= 0
        nom_c = comp_m["nombre"].astype(str).to_numpy()[ok]
        tip_c = comp_m["formato_FRF"].astype(str).to_numpy()[ok] if "formato_FRF" in comp_m else np.full(ok.sum(), "")
        Tc = T[modo_ref][pos_c[ok]]
        lista, primero, primero_min = [], [], []
        for j in range(Tc.shape[1]):
            o = np.argsort(Tc[:, j])[:5]
            o = o[np.isfinite(Tc[o, j])]
            lista.append("; ".join(f"{nom_c[i]} · {tip_c[i]} · {_min(Tc[i, j])}" for i in o))
            primero.append(nom_c[o[0]] if len(o) else ""); primero_min.append(float(Tc[o[0], j]) if len(o) else np.nan)
        res["competidores_mas_cercanos"] = lista
        res["competidor_mas_cercano"] = primero
        res["min_competidor_mas_cercano"] = primero_min
    res["texto"] = [_texto(r, ref, ref_tipo, modo_ref, E) for _, r in res.iterrows()]
    return res


def _texto(r, ref, ref_tipo, modo_ref, E):
    """Resumen en palabras del entorno de una sede (cambia según sus cifras)."""
    partes = [f"Entorno {str(r['tipo_entorno']).lower()}."]
    hora = "en hora punta" if modo_ref == "auto_punta" else NOMBRE_MODO.get(modo_ref, modo_ref).lower()
    po = r.get(f"pob_objetivo_{ref}min")
    if pd.notna(po):
        t = f"En {ref} min en auto {hora} llegan {miles(po)} personas del segmento objetivo ({pct(r.get(f'pct_objetivo_{ref}min'), 0)} de la población de su zona)"
        idx = r.get("indice_objetivo_vs_formato")
        if pd.notna(idx) and r.get("formato_modelo") in NOMBRE_FORMATO:
            t += (f", {miles(idx / 100, 1)} veces lo de una sede típica de su formato" if idx >= 150 else
                  f", solo el {miles(idx, 0)}% de lo de una sede típica de su formato" if idx <= 66 else
                  ", similar a una sede típica de su formato")
        partes.append(t + ".")
    if pd.notna(r.get("perdida_punta_objetivo")):
        p = r["perdida_punta_objetivo"]
        partes.append(f"Fuera de punta llegan {miles(r.get(f'pob_objetivo_{ref}min_valle'))}: " +
                      (f"la congestión le quita {pct(p, 0)}." if p >= 0.05 else "la congestión casi no la afecta."))
    gen = []
    for c, sing, plur in (("poi_metro", "estación de metro", "estaciones de metro"), ("poi_mall", "mall o centro comercial", "malls y centros comerciales")):
        v = r.get(f"{c}_{ref}min")
        if pd.notna(v) and v > 0:
            gen.append(_cant(v, sing, plur))
    if gen:
        partes.append(f"En esa zona hay {' y '.join(gen)}.")
    if pd.notna(r.get(f"comp_total_{ref}min")):
        partes.append(f"Competencia en la zona: {_cant(r.get(f'comp_clinicas_{ref}min'), 'clínica', 'clínicas')}, "
                      f"{_cant(r.get(f'comp_centros_medicos_{ref}min'), 'centro médico', 'centros médicos')} "
                      f"y {_cant(r.get(f'comp_laboratorios_{ref}min'), 'laboratorio', 'laboratorios')}" +
                      (f"; el más cercano es {r['competidor_mas_cercano']} ({_min(r['min_competidor_mas_cercano'])})." if r.get("competidor_mas_cercano") else "."))
    mt = E.get("minutos_traslape", ref)
    if r.get("traslape_red", 0) > 0:
        partes.append(f"En su zona inmediata ({mt} min) comparte {pct(r['traslape_red'], 0)} del segmento objetivo con otras sedes de la red"
                      + (f", sobre todo con {r['traslape_principal_con']}." if r.get("traslape_principal_con") else "."))
    else:
        partes.append(f"En su zona inmediata ({mt} min) no se cruza con otras sedes de la red.")
    return " ".join(partes)


def poligonos(rd, sitios, det, cfg, iso_previas=None, cronometro=None):
    """Isócronas (polígonos) de cada sede en los modos y minutos del entorno, en paralelo. Reutiliza las que ya se
    dibujaron (iso_previas: mismas sedes, modos y minutos) y dibuja solo las que faltan. Trae los indicadores de `det`."""
    E = cfg["entorno"]
    piezas, faltan = [], []
    previas = iso_previas if iso_previas is not None and len(iso_previas) else None
    for modo in E["modos"]:
        for s in sitios["sede"]:
            if previas is not None:
                p = previas[(previas["id"] == s) & (previas["modo"] == modo) & (previas["minutos"].isin(E["minutos"]))]
                if p["minutos"].nunique() == len(E["minutos"]):
                    piezas.append(p[["id", "modo", "minutos", "geometry", "area_km2"]])
                    continue
            faltan.append((modo, s))
    for modo in E["modos"]:
        ids = [s for m, s in faltan if m == modo]
        if ids:
            sub = sitios[sitios["sede"].isin(ids)][["sede", "x", "y"]].rename(columns={"sede": "id"})
            piezas.append(RED.isocronas_sitios(rd, sub, cfg, [modo], cronometro=cronometro, minutos=E["minutos"]))
    iso = gpd.GeoDataFrame(pd.concat(piezas, ignore_index=True), geometry="geometry", crs=cfg["estudio"]["crs_metrico"])
    iso = iso.rename(columns={"id": "sede"}).merge(det, on=["sede", "modo", "minutos"], how="left")
    return iso


# --------------------------------------------------------------------------------------------- TABLAS PARA ENTREGAR
NOMBRES_COLUMNAS = {
    "poblacion": "Población", "hogares": "Hogares", "pob_objetivo": "Segmento objetivo (AB, C1a, C1b)", "pct_objetivo": "% segmento objetivo",
    "pct_menores_18": "% menores de 18", "pct_60_mas": "% 60 años o más", "superficie_km2": "Superficie (km²)", "densidad_hab_km2": "Densidad (hab/km²)",
    "gasto_salud_mes": "Gasto en salud al mes ($)", "gasto_salud_objetivo_mes": "Gasto en salud del segmento al mes ($)",
    "gasto_salud_por_persona": "Gasto en salud por persona al mes ($)", "renta_media_hogar": "Renta media del hogar ($)",
    "avaluo_medio_vivienda": "Avalúo medio de la vivienda ($)", "trabajadores": "Trabajadores", "trabajadores_por_habitante": "Trabajadores por habitante",
    "empresas": "Empresas", "empresas_salud": "Empresas de salud", "comercio_por_10mil_hab": "Comercio por 10.000 hab.",
    "comp_clinicas": "Clínicas de la competencia", "comp_centros_medicos": "Centros médicos de la competencia",
    "comp_laboratorios": "Laboratorios de la competencia", "comp_total": "Competidores (total)",
    "comp_por_10mil_objetivo": "Competidores por 10.000 del segmento", "oferta_contexto": "Otra oferta de salud (dental, kine, farmacias…)",
    "calles_km": "Calles (km)", "vias_principales_km": "Vías principales (km)",
    **{k: v[0].upper() + v[1:] for k, v in POIS.items()}, **{k: v[0].upper() + v[1:] for k, v in BBRR.items()},
}


def tabla_detalle(det):
    """Detalle legible: una fila por sede × modo × minutos."""
    t = det.copy()
    t["modo"] = t["modo"].map(NOMBRE_MODO).fillna(t["modo"])
    t = t.rename(columns={"nombre_visible": "sede (nombre)", "formato_modelo": "formato", **NOMBRES_COLUMNAS})
    t["formato"] = t["formato"].map(NOMBRE_FORMATO).fillna(t["formato"])
    return t.rename(columns={"sede": "código", "minutos": "minutos (zona)"})


def tabla_resumen(res, ref):
    t = res.drop(columns=[c for c in ("recinto",) if c in res]).copy()
    t["formato_modelo"] = t["formato_modelo"].map(NOMBRE_FORMATO).fillna(t["formato_modelo"])
    ren = {"sede": "código", "nombre_visible": "sede", "formato_modelo": "formato", "tipo_entorno": "tipo de entorno",
           "perdida_punta_objetivo": f"segmento que se pierde en punta ({ref} min)", "perdida_punta_superficie": f"superficie que se pierde en punta ({ref} min)",
           "indice_objetivo_vs_formato": "índice segmento vs sede típica del formato (100 = igual)", "traslape_red": "traslape con otras sedes (zona inmediata)",
           "traslape_principal_con": "traslape principal con", "sedes_red_cerca": f"sedes de la red a ≤ {ref} min",
           "competidores_mas_cercanos": "5 competidores más cercanos (min, punta)", "competidor_mas_cercano": "competidor más cercano",
           "min_competidor_mas_cercano": "minutos al competidor más cercano", "texto": "resumen en palabras"}
    for c in list(t.columns):
        for base, nombre in NOMBRES_COLUMNAS.items():
            if c == f"{base}_{ref}min":
                ren[c] = f"{nombre} a {ref} min (punta)"
            elif c == f"{base}_{ref}min_valle":
                ren[c] = f"{nombre} a {ref} min (fuera de punta)"
        if c.startswith("minutos_meta_"):
            ren[c] = f"minutos para reunir la meta del segmento · {NOMBRE_MODO.get(c[13:], c[13:]).lower()}"
    return t.rename(columns=ren)
