# -*- coding: utf-8 -*-
"""Asistente de insumos: antes de calcular, cada notebook revisa que tenga TODO lo que necesita.

Nada se supone en silencio. Para cada notebook se revisan:
  * las DECISIONES que solo el equipo puede tomar (modo, región, cómo viene el RUT de los pacientes);
  * los ARCHIVOS de entrada (existen, se pueden abrir) y sus COLUMNAS (solo el encabezado: no se lee la base completa);
  * los RESULTADOS de los notebooks anteriores;
  * la coherencia de los parámetros y la memoria disponible.

Si falta algo obligatorio, el notebook se detiene en la primera celda con una lista de qué falta, por qué importa y la
línea exacta que hay que escribir en `config_estudio.py`. Lo opcional que no viene se informa con su consecuencia.

Uso (primera celda de cada notebook):           cfg = config_estudio.obtener_config(); insumos.exigir(cfg, "02")
Revisión completa de todo el estudio (terminal): python revisar_insumos.py
"""
import difflib
import glob
import hashlib
import html
import json
import os
import re
from dataclasses import dataclass

from . import esquemas
from .utilidades import norm_txt, memoria_libre_gb

# --------------------------------------------------------------------------------------------- ESTADOS
OK, AVISO, NO_VIENE, FALTA = "ok", "aviso", "no_viene", "falta"
ICONO = {OK: "✅", AVISO: "⚠️", NO_VIENE: "➖", FALTA: "❌"}
ETIQUETA = {OK: "Listo", AVISO: "Revisar", NO_VIENE: "No viene (opcional)", FALTA: "Falta"}

OBLIGATORIO, RECOMENDADO, DESEABLE, OPCIONAL = "obligatorio", "recomendado", "deseable", "opcional"

TITULOS = {"00": "Simulación de datos", "01": "Ingesta y calidad", "02": "Ventas históricas y sedes",
           "03": "Territorio y competencia", "04": "Red vial e isócronas", "04b": "Zonas de influencia preliminares (sin datos de la clínica)", "05": "Origen-destino y áreas de influencia",
           "06": "Modelo de ventas", "07": "Expansión, scoring y ranking", "08": "Entregables"}

# --------------------------------------------------------------------------------------------- QUÉ NECESITA CADA NOTEBOOK
# Archivos de entrada (clave de RUTAS): (nivel, qué es, qué pasa si no viene)
ENTRADAS = {
    "00": [("maestro_sedes", OBLIGATORIO, "Maestro de sedes (levantamiento propio)", ""),
           ("competencia", OBLIGATORIO, "Universo de competencia (levantamiento propio)", "")],
    "01": [("censo", OBLIGATORIO, "Censo por manzana (SD06)", ""),
           ("per", OBLIGATORIO, "Base de personas", ""),
           ("emp", OBLIGATORIO, "Base de empresas", ""),
           ("bbrr", OBLIGATORIO, "Bienes raíces (BBRR)", ""),
           ("pois", OBLIGATORIO, "Puntos de interés (PI01)", ""),
           ("street", OBLIGATORIO, "Maestro de calles (BC08)", "")],
    "02": [("ventas_cliente", OBLIGATORIO, "Ventas de la clínica por sede y mes", ""),
           ("sedes_cliente", RECOMENDADO, "Hoja de sedes de la clínica",
            "habrá que emparejar a mano los códigos de sede (MAPA_SEDES) y, sobre todo, falta el TAMAÑO de cada sede (m²): "
            "el modelo no puede separar el efecto del tamaño y lo confunde con la distancia. En la simulación el error "
            "\"sede nueva\" se triplica (de 10–18% a 44–54%)"),
           ("eventos_cliente", OPCIONAL, "Eventos (aperturas, cierres, obras, convenios)",
            "los quiebres de las series se detectan solo con estadística, sin explicación de negocio"),
           ("ipc", OPCIONAL, "Serie IPC mensual del INE", "se deflacta con el IPC anual aproximado de config_estudio.py"),
           ("maestro_sedes", OBLIGATORIO, "Maestro de sedes (levantamiento propio)", "")],
    "03": [("competencia", OBLIGATORIO, "Universo de competencia (levantamiento propio)", ""),
           ("areas_verdes", OPCIONAL, "Capa de áreas verdes y parques", "los parques se detectan solo por USO_SUELO del censo")],
    "04": [("gtfs", OPCIONAL, "GTFS de transporte público",
            "el transporte público se aproxima con caminata + buses sobre vías principales (sin metro programado)")],
    "05": [("origen_pacientes", DESEABLE, "Origen de los pacientes (RUT, zona o coordenadas)",
            "el modelo se calibra solo con la venta total de cada sede: la caída con el tiempo de viaje sale de los valores "
            "de referencia y las áreas de influencia son modeladas, no observadas")],
    "07": [("sitios_propuestos", OPCIONAL, "Sitios propuestos por la clínica", "solo se evalúan las manzanas candidatas")],
    "04b": [("maestro_sedes", OBLIGATORIO, "Maestro de sedes (base de puntos del levantamiento)", "")],
}

# Resultados previos que cada notebook carga sí o sí (los opcionales se revisan dentro del notebook)
PRODUCIDO_POR = {
    **dict.fromkeys(["censo.parquet", "area_estudio.gpkg", "per.parquet", "emp.parquet", "bbrr.parquet", "pois.parquet",
                     "calles.parquet"], "01"),
    **dict.fromkeys(["sedes_estudio.parquet", "venta_madura.csv", "curva_maduracion.json", "mix_lineas_formato.csv",
                     "crecimiento.csv", "metricas_ventas.json"], "02"),
    **dict.fromkeys(["unidades.parquet", "personas_ut.parquet", "empresas_ut.parquet", "competencia.parquet"], "03"),
    **dict.fromkeys(["red.pkl", "T_sedes_auto_punta.npy", "potencial_competencia.pkl", "candidatos.parquet", "T_cand.npy",
                     "isocronas_sedes.gpkg", "entorno_sedes.csv", "entorno_sedes_detalle.csv", "isocronas_entorno.gpkg",
                     "metricas_entorno.json"], "04"),
    **dict.fromkeys(["influencia_preliminar_sedes.csv", "influencia_preliminar_red.csv", "influencia_preliminar_manzanas.parquet",
                     "influencia_preliminar_zonas.parquet", "influencia_preliminar.gpkg", "metricas_influencia.json"], "04b"),
    **dict.fromkeys(["unidades_calib.pkl", "metricas_pacientes.json"], "05"),
    **dict.fromkeys(["modelo.pkl", "parametros.csv", "validacion_sede_nueva.csv", "metricas_modelo.json"], "06"),
    **dict.fromkeys(["top20.parquet", "fichas_extras.json", "metricas_plan.json"], "07"),
}
_BASES_01 = ["censo.parquet", "area_estudio.gpkg", "per.parquet", "emp.parquet", "bbrr.parquet", "pois.parquet", "calles.parquet"]
NECESITA = {
    "02": ["censo.parquet", "calles.parquet", "area_estudio.gpkg"],
    "03": _BASES_01,                          # sin datos de la clínica, las sedes de los mapas salen del maestro
    "04b": ["unidades.parquet", "competencia.parquet", "area_estudio.gpkg"],
    "04": ["area_estudio.gpkg", "unidades.parquet", "competencia.parquet", "sedes_estudio.parquet"],
    "05": ["censo.parquet", "unidades.parquet", "sedes_estudio.parquet", "venta_madura.csv", "T_sedes_auto_punta.npy",
           "isocronas_sedes.gpkg", "competencia.parquet"],
    "06": ["unidades.parquet", "sedes_estudio.parquet", "venta_madura.csv", "T_sedes_auto_punta.npy",
           "potencial_competencia.pkl", "unidades_calib.pkl"],
    "07": ["censo.parquet", "calles.parquet", "unidades.parquet", "competencia.parquet", "sedes_estudio.parquet",
           "curva_maduracion.json", "mix_lineas_formato.csv", "red.pkl", "candidatos.parquet", "T_cand.npy", "modelo.pkl"],
    "08": ["unidades.parquet", "competencia.parquet", "sedes_estudio.parquet", "venta_madura.csv", "crecimiento.csv",
           "curva_maduracion.json", "candidatos.parquet", "isocronas_sedes.gpkg", "modelo.pkl", "parametros.csv",
           "validacion_sede_nueva.csv", "top20.parquet", "fichas_extras.json", "metricas_ventas.json", "metricas_pacientes.json",
           "metricas_modelo.json", "metricas_plan.json", "entorno_sedes.csv", "entorno_sedes_detalle.csv", "isocronas_entorno.gpkg",
           "metricas_entorno.json"],
}

# Columnas Equifax sin las cuales el estudio no puede seguir (el resto: se sigue sin ellas, con aviso)
CRITICAS = {"censo": ["id", "id_region", "pob", "hog", "comuna", "pob_gse", "hog_gse", "gasto_cat_gse"],
            "per": ["lat", "lon"], "emp": ["lat", "lon"], "bbrr": ["lat", "lon", "destino"], "pois": ["cat1"],
            "street": ["nombre"]}

# Columnas mínimas de cada archivo de la clínica: lista de grupos; en cada grupo basta UNA de las alternativas
CAMPOS_CLIENTE = {
    "ventas_cliente": ([["sede"], ["periodo"], ["monto", "atenciones"]], ["linea", "prevision", "pacientes"]),
    "sedes_cliente": ([["sede"]], ["nombre", "direccion", "formato", "fecha_apertura", "fecha_cierre", "m2", "lat", "lon"]),
    "origen_pacientes": ([["sede"], ["rut", "rut_hash", "zona", "lat+lon"]], ["fecha", "periodo", "monto", "atenciones", "linea"]),
    "eventos_cliente": ([["sede"], ["desde"]], ["hasta", "tipo_evento", "descripcion"]),
    "sitios_propuestos": ([["direccion", "lat+lon"]], ["nombre", "comuna_sede", "formato"]),
}

RUT_OPCIONES = ("en_claro", "seudonimizado", "sin_rut")


@dataclass
class Item:
    grupo: str
    nombre: str
    estado: str
    detalle: str = ""
    que_hacer: str = ""


class FaltanInsumos(RuntimeError):
    """Se lanza cuando falta algo obligatorio. En Jupyter se muestra solo el mensaje (sin la traza de Python)."""

    def __init__(self, texto):
        super().__init__(texto)
        self.texto = texto

    def _render_traceback_(self):          # IPython usa este método en vez de imprimir la traza completa
        return self.texto.split("\n")


# --------------------------------------------------------------------------------------------- AYUDAS
def _cfg_txt(cfg):
    """Nombre del diccionario de rutas que hay que editar según el modo."""
    return "RUTAS_SIMULACION" if cfg["modo"] == "simulacion" else "RUTAS_REALES"


def _n(x, dec=1):
    """Número con formato chileno: 1.234,5"""
    return f"{x:,.{dec}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _gb(b):
    return f"{_n(b / 1e9)} GB" if b >= 1e9 else f"{_n(b / 1e6, 0)} MB" if b >= 1e6 else f"{_n(max(b / 1e3, 1), 0)} KB"


def ruta_cache(ruta, cfg):
    """Ruta local donde queda (o quedará) un archivo gs:// al descargarlo."""
    return os.path.join(cfg["carpetas"]["cache"], re.sub(r"[^A-Za-z0-9._-]", "_", str(ruta)[5:]))


def _ubicar(ruta, cfg):
    """(ruta local o None, existe: True/False/None si no se pudo verificar, tamaño en bytes o None, nota)."""
    r = str(ruta)
    if not r.startswith("gs://"):
        if os.path.exists(r):
            return r, True, (os.path.getsize(r) if os.path.isfile(r) else None), ""
        return None, False, None, ""
    cache = ruta_cache(r, cfg)
    if os.path.exists(cache) and os.path.getsize(cache) > 0:
        return cache, True, os.path.getsize(cache), "ya descargado en cache_gcs/"
    nota = "en el bucket (se descarga la primera vez que se lee)"
    try:
        import fsspec
        fs = fsspec.filesystem("gs")
        return (None, True, fs.info(r).get("size"), nota) if fs.exists(r) else (None, False, None, "")
    except Exception as e1:                                           # sin gcsfs: se prueba con google-cloud-storage
        try:
            from google.cloud import storage
            bucket, _, nombre = r[5:].partition("/")
            blob = storage.Client().bucket(bucket).get_blob(nombre)
            return (None, True, blob.size, nota) if blob is not None else (None, False, None, "")
        except Exception as e2:
            err = e2 if isinstance(e1, ImportError) else e1
            return None, None, None, (f"no se pudo consultar el bucket desde este equipo ({type(err).__name__}: {str(err)[:100]}); "
                                      "en el PC de trabajo se lee con gcsfs o google-cloud-storage")


def _encabezado(ruta, local, cfg):
    """Columnas de un archivo leyendo SOLO el encabezado. None si no se puede sin descargarlo entero (gpkg en gs://)."""
    r = local or str(ruta)
    ext = r.lower().rsplit(".", 1)[-1]
    if ext in ("parquet", "pq"):
        import pyarrow.parquet as pq
        if local:
            return list(pq.read_schema(local).names)
        import fsspec
        with fsspec.open(r, "rb") as f:
            return list(pq.read_schema(f).names)
    if ext in ("gpkg", "shp", "geojson", "fgb"):
        if not local:
            return None
        import pyogrio
        return list(pyogrio.read_info(local)["fields"]) + ["geometry"]
    if local:
        from .utilidades import codificacion
        f = open(local, "r", encoding=codificacion(local), errors="replace")
    else:
        import fsspec
        f = fsspec.open(r, "rt", encoding="utf-8-sig", errors="replace").open()
    with f:
        cab = f.readline().rstrip("\r\n")
    sep = cfg.get("separador_txt", "|")
    if cab.count(sep) == 0:
        sep = max([",", ";", "|", "\t"], key=cab.count)
    return [c.strip().strip('"') for c in cab.split(sep)]


# Raíces que delatan el contenido de una columna aunque tenga otro nombre (para sugerir la correcta)
PISTAS = {"lat": ("LAT",), "lon": ("LON", "LNG"), "id": ("RUT", "ID"), "comuna": ("COMUNA", "COM"), "region": ("REG",),
          "id_region": ("REG", "ID_REG"), "pob": ("POB",), "hog": ("HOG",), "destino": ("DEST",), "nombre": ("NOM", "NAM"),
          "sede": ("SEDE", "CENTRO", "SUC"), "periodo": ("MES", "PERIOD", "FECHA"), "monto": ("MONTO", "VENTA", "VALOR")}


def _parecidas(nombre, disponibles, logico=None, n=3):
    """Columnas del archivo más parecidas a la que se busca (parecido de texto + raíces típicas del campo)."""
    objetivo = nombre.upper()
    pistas = PISTAS.get(logico, ())

    def puntaje(c):
        cu = c.upper()
        p = difflib.SequenceMatcher(None, objetivo, cu).ratio()
        if any(t.startswith(h) for t in re.split(r"[_\s]+", cu) for h in pistas):
            p += 0.5
        if cu[:3] == objetivo[:3]:
            p += 0.2
        return p

    orden = sorted(disponibles, key=puntaje, reverse=True)
    return [c for c in orden[:n] if puntaje(c) >= 0.55]


def _esperadas(cfg, base):
    """{nombre lógico: [columnas reales]} de una base Equifax (expande los patrones por GSE)."""
    mapa, out = cfg["columnas"][base], {}
    for k, v in mapa.items():
        if isinstance(v, list):
            out[k] = list(v)
        elif "{gse}" in v and "{cat}" in v:
            out[k] = [v.format(cat=cfg["censo"]["categoria_gasto_salud"], gse=g) for g in cfg["gse"]]
        elif "{gse}" in v:
            out[k] = [v.format(gse=g) for g in cfg["gse"]]
        elif "{cat}" in v:
            out[k] = [v.format(cat=c) for c in cfg["censo"]["categorias_gasto"]]
        else:
            out[k] = [v]
    return out


def _criticas(cfg, base):
    c = list(CRITICAS.get(base, []))
    if base in ("per", "emp") and cfg.get("rut_pacientes") in ("en_claro", "seudonimizado"):
        c.append("id")                                    # el RUT permite ubicar a los pacientes en su manzana
    return c


# --------------------------------------------------------------------------------------------- REVISIONES
def _decisiones(cfg, nb):
    items = []
    modo = cfg["modo"]
    if modo not in ("real", "simulacion"):
        return [Item("Decisiones", "Modo", FALTA, f"MODO = {modo!r} no es válido",
                     'En config_estudio.py: MODO = "real" (bases Equifax y datos de la clínica) o "simulacion".')]
    items.append(Item("Decisiones", "Modo", OK, "simulación: datos de prueba generados por el notebook 00" if modo == "simulacion"
                      else "real: bases Equifax del bucket y datos de Clínica Alemana"))
    E = cfg["estudio"]
    regs = E.get("id_regiones") or []
    if not regs or not all(isinstance(r, int) and 1 <= r <= 16 for r in regs):
        items.append(Item("Decisiones", "Región del estudio", FALTA, f"id_regiones = {regs!r}",
                          'En config_estudio.py → PARAMETROS["estudio"]["id_regiones"] = [13]  (ID_REG del censo; 13 = Metropolitana).'))
    else:
        items.append(Item("Decisiones", "Región del estudio", OK,
                          f"ID_REG {', '.join(map(str, regs))} (filtro del censo)" + (f" · recorte {E['bbox']}" if E.get("bbox") else "")))
    if nb in ("01", "05", None):
        items.append(_decision_rut(cfg))
    perfil = cfg.get("perfil", "completo")
    if perfil != "completo" and nb in ("04", "06", "07", None):
        items.append(Item("Decisiones", "Perfil de cómputo", AVISO, f"perfil {perfil!r}: menos bootstrap, candidatos y validaciones",
                          'Sirve para revisar rápido; para la entrega final usa PERFIL = "completo" en config_estudio.py.'))
    return items


def _decision_rut(cfg):
    d = cfg.get("rut_pacientes")
    opciones = ('Escribe en config_estudio.py una de estas líneas:\n'
                '  RUT_PACIENTES = "en_claro"       # la clínica manda el RUT tal cual (se seudonimiza al leerlo; nunca se guarda)\n'
                '  RUT_PACIENTES = "seudonimizado"  # la clínica manda sha256(SAL + RUT) → define la variable de entorno GEOVENTAS_SAL_RUT\n'
                '  RUT_PACIENTES = "sin_rut"        # el origen vendrá por zona/comuna o no vendrá (la ingesta es más rápida)')
    if d is None:
        return Item("Decisiones", "Cómo viene el RUT de los pacientes", FALTA,
                    "Define si la clínica enviará RUT, y cómo. Se necesita desde la ingesta: personas y empresas se "
                    "seudonimizan con la misma sal que los pacientes para poder cruzarlos.", opciones)
    if d not in RUT_OPCIONES:
        return Item("Decisiones", "Cómo viene el RUT de los pacientes", FALTA, f"RUT_PACIENTES = {d!r} no es válido", opciones)
    if d == "seudonimizado" and not cfg.get("sal_rut"):
        return Item("Decisiones", "Cómo viene el RUT de los pacientes", FALTA,
                    "La clínica seudonimiza el RUT, pero falta la SAL que usó (sin ella no se puede cruzar con personas ni empresas).",
                    "Define la variable de entorno GEOVENTAS_SAL_RUT con la sal acordada antes de abrir Jupyter "
                    "(en Windows: setx GEOVENTAS_SAL_RUT \"...\"). No la escribas en config_estudio.py ni en los notebooks.")
    txt = {"en_claro": "RUT en claro: se seudonimiza al leerlo con la sal secreta del proyecto (trabajo/.sal_proyecto)",
           "seudonimizado": "RUT seudonimizado por la clínica: se usa la sal acordada (variable GEOVENTAS_SAL_RUT)",
           "sin_rut": "sin RUT: no se leen ni seudonimizan RUT de personas y empresas"}[d]
    if cfg["modo"] == "simulacion":
        txt = "simulación: RUT en claro con sal de prueba"
    return Item("Decisiones", "Cómo viene el RUT de los pacientes", OK, txt)


def _archivo(cfg, clave, nivel, que, sin_dato, descargar):
    """Revisa un archivo de entrada: configurado, existe, se puede abrir. Devuelve (Item, ruta local o None)."""
    ruta = cfg["rutas"].get(clave)
    grupo = ("Bases Equifax" if clave in cfg["columnas"] else "Datos de la clínica" if clave in CAMPOS_CLIENTE
             else "Insumos del estudio")
    destino = f'{_cfg_txt(cfg)}["{clave}"]'
    if not ruta:
        if nivel == OBLIGATORIO:
            return Item(grupo, que, FALTA, "No está configurado.",
                        f'En config_estudio.py → {destino} = "gs://…/archivo.xlsx" (o ruta local; csv, txt, xlsx o parquet).'), None
        estado = AVISO if nivel in (RECOMENDADO, DESEABLE) else NO_VIENE
        return Item(grupo, que, estado, f"No viene ({nivel}). Consecuencia: {sin_dato}.",
                    f"Si llega, configúralo en {destino}." if estado == AVISO else ""), None
    local, existe, tam, nota = _ubicar(ruta, cfg)
    if existe is False:
        carpeta = os.path.dirname(str(ruta))
        vecinos = sorted(os.path.basename(p) for p in glob.glob(os.path.join(carpeta, "*")))[:8] if os.path.isdir(carpeta) else []
        return Item(grupo, que, FALTA, f"No existe: {ruta}" + (f" · en esa carpeta hay: {', '.join(vecinos)}" if vecinos else ""),
                    f"Corrige la ruta en {destino}" + (" o corre el notebook 00 (genera los datos simulados)." if cfg["modo"] == "simulacion" else ".")), None
    if existe is None:
        return Item(grupo, que, AVISO, nota, "Se leerá en el notebook; si falla ahí, revisa la ruta y las credenciales de GCS."), None
    if local is None and descargar and str(ruta).startswith("gs://"):
        from .lectura import ruta_local
        local = ruta_local(ruta, cfg)
        nota = "descargado a cache_gcs/"
    det = f"{os.path.basename(str(ruta))}" + (f" · {_gb(tam)}" if tam else "") + (f" · {nota}" if nota else "")
    return Item(grupo, que, OK, det), local or (None if str(ruta).startswith("gs://") else str(ruta))


def _columnas_equifax(cfg, base, ruta_local_):
    ruta = cfg["rutas"][base]
    try:
        cols = _encabezado(ruta, ruta_local_, cfg)
    except Exception as e:
        return Item("Bases Equifax", f"Columnas de {base}", FALTA, f"No se pudo leer el encabezado: {type(e).__name__}: {e}",
                    "Revisa que el archivo no esté dañado y que el formato coincida con su extensión.")
    if cols is None:
        return Item("Bases Equifax", f"Columnas de {base}", OK, "se revisan al descargar (primera lectura del notebook 01)")
    disp = set(cols)
    faltan_crit, faltan_otras = [], []
    criticas = _criticas(cfg, base)
    for logico, reales in _esperadas(cfg, base).items():
        no = [r for r in reales if r not in disp]
        if not no:
            continue
        (faltan_crit if logico in criticas else faltan_otras).append((logico, no))
    if faltan_crit:
        lineas = []
        for logico, no in faltan_crit:
            sug = _parecidas(no[0], cols, logico)
            patron = cfg["columnas"][base][logico]
            lineas.append(f'COLUMNAS["{base}"]["{logico}"] = "{sug[0] if sug and isinstance(patron, str) and "{" not in patron else patron}"'
                          f'   # hoy busca {", ".join(no[:3])}{"…" if len(no) > 3 else ""}'
                          + (f" · parecidas en el archivo: {', '.join(sug)}" if sug else ""))
        return Item("Bases Equifax", f"Columnas de {base}", FALTA,
                    f"{len(cols)} columnas en el archivo; faltan las imprescindibles: "
                    + ", ".join(f"{l} ({', '.join(n[:2])})" for l, n in faltan_crit),
                    "En config_estudio.py → COLUMNAS, escribe el nombre real (revisa la sugerencia):\n  " + "\n  ".join(lineas))
    if faltan_otras:
        return Item("Bases Equifax", f"Columnas de {base}", AVISO,
                    f"{len(cols)} columnas; no están (se sigue sin ellas): "
                    + ", ".join(f"{l} ({', '.join(n[:2])}{'…' if len(n) > 2 else ''})" for l, n in faltan_otras),
                    f'Si existen con otro nombre, corrígelas en COLUMNAS["{base}"] de config_estudio.py.')
    no_estan, nuevas = esquemas.comparar(base, cols) if base in esquemas.ESQUEMAS else ([], [])
    if no_estan or nuevas:
        return Item("Bases Equifax", f"Columnas de {base}", AVISO,
                    f"{len(cols)} columnas; están todas las que usa el estudio, pero la base cambió respecto de la versión "
                    f"revisada ({len(esquemas.ESQUEMAS[base])} columnas)"
                    + (f" · ya no vienen: {', '.join(no_estan[:6])}{'…' if len(no_estan) > 6 else ''}" if no_estan else "")
                    + (f" · nuevas: {', '.join(nuevas[:6])}{'…' if len(nuevas) > 6 else ''}" if nuevas else ""),
                    "No afecta al estudio (no usa esas columnas). Si una columna nueva reemplaza a una que sí se usa, "
                    f'corrígela en COLUMNAS["{base}"].')
    return Item("Bases Equifax", f"Columnas de {base}", OK,
                f"{len(cols)} columnas, idénticas a la versión revisada; están todas las que usa el estudio")


def _columnas_cliente(cfg, clave, ruta_local_):
    """Reconoce las columnas de un archivo de la clínica y pide explícitamente las que falten."""
    from . import cliente
    que = dict((k, q) for e in ENTRADAS.values() for k, _, q, _ in e).get(clave, clave)
    try:
        df = cliente.leer_tabla(ruta_local_, cfg, nrows=300)
        if clave == "ventas_cliente":
            df, _ = cliente.ancho_a_largo(df, cfg)
    except Exception as e:
        return Item("Datos de la clínica", f"Columnas · {que}", FALTA, f"No se pudo abrir: {type(e).__name__}: {e}",
                    "Revisa el formato (csv, txt, xlsx o parquet) y que no esté protegido con contraseña.")
    minimos, utiles = CAMPOS_CLIENTE[clave]
    campos = sorted({c for g in minimos for alt in g for c in alt.split("+")} | set(utiles))
    m = cliente.detectar_columnas(df, cfg, campos)
    tiene = lambda alt: all(c in m for c in alt.split("+"))
    faltan = [g for g in minimos if not any(tiene(a) for a in g)]
    parcial = [c for c, real in m.items() if norm_txt(real) not in {norm_txt(s) for s in cfg["columnas_cliente"].get(c, [])}]
    reconocidas = " · ".join(f"{c} ← '{r}'" + (" (parcial)" if c in parcial else "") for c, r in sorted(m.items()))
    cols = [str(c) for c in df.columns]
    if faltan:
        lineas = []
        for g in faltan:
            campo = g[0].split("+")[0]
            sug = _parecidas(cfg["columnas_cliente"].get(campo, [campo])[0], cols, campo, 1)
            lineas.append(f'COLUMNAS_CLIENTE["{campo}"].insert(0, "{sug[0] if sug else "NOMBRE_EXACTO_DE_LA_COLUMNA"}")'
                          + (f"   # o una de: {', '.join(g[1:])}" if len(g) > 1 else ""))
        return Item("Datos de la clínica", f"Columnas · {que}", FALTA,
                    f"No se reconoce: {', '.join(' o '.join(g) for g in faltan)}. Columnas del archivo: {', '.join(cols[:25])}"
                    + ("…" if len(cols) > 25 else "") + (f". Reconocidas: {reconocidas}" if m else ""),
                    "Agrega al final de la sección COLUMNAS DEL CLIENTE de config_estudio.py (con el nombre real):\n  " + "\n  ".join(lineas))
    cap = cfg["modelo"].get("capacidad", "m2")
    if clave == "sedes_cliente" and cap not in m:
        return Item("Datos de la clínica", f"Columnas · {que}", AVISO,
                    f"Reconocidas: {reconocidas}. Falta el tamaño de cada sede ('{cap}'): el modelo no podrá separar el efecto "
                    "del tamaño y lo confundirá con la distancia (en la simulación el error \"sede nueva\" se triplica (de 10–18% a 44–54%)).",
                    f'Pide a la clínica los m² (o boxes) de cada sede. Si la columna existe con otro nombre: '
                    f'COLUMNAS_CLIENTE["{cap}"].insert(0, "NOMBRE_EXACTO") en config_estudio.py.')
    if parcial:
        return Item("Datos de la clínica", f"Columnas · {que}", AVISO, f"Reconocidas: {reconocidas}",
                    "Las marcadas (parcial) se tomaron por parecido: confirma que son las correctas o fija el nombre exacto con "
                    'COLUMNAS_CLIENTE["campo"].insert(0, "nombre exacto") en config_estudio.py.')
    return Item("Datos de la clínica", f"Columnas · {que}", OK, f"Reconocidas: {reconocidas}")


def _unidad_monto(cfg, ruta_local_):
    """Unidad de los montos de venta (pesos, miles, millones, UF), con una muestra de 200 mil filas."""
    import contextlib, io
    from . import cliente
    try:
        c2 = {**cfg, "rutas": {**cfg["rutas"], "ventas_cliente": ruta_local_}}
        with contextlib.redirect_stdout(io.StringIO()):
            v = cliente.leer_ventas_cliente(c2, nrows=200_000)
        m = v.attrs.get("columnas", {})
        u = cliente.unidad_monto(v, m.get("monto") or m.get("ticket"), cfg)
    except Exception as e:                         # las columnas ya se revisaron aparte; aquí solo se informa
        return Item("Datos de la clínica", "Unidad de los montos de venta", AVISO, f"No se pudo revisar: {type(e).__name__}: {e}",
                    "Se revisará al leer las ventas en el notebook 02.")
    if u["unidad"] is None:
        return Item("Datos de la clínica", "Unidad de los montos de venta", FALTA, u["explicacion"], u["que_hacer"])
    if not u.get("plausible", True):
        return Item("Datos de la clínica", "Unidad de los montos de venta", AVISO, u["explicacion"],
                    "Si la unidad no es esa, fíjala en config_estudio.py: UNIDAD_MONTO = \"pesos\" | \"miles\" | \"millones\" | \"uf\".")
    return Item("Datos de la clínica", "Unidad de los montos de venta", OK, u["explicacion"])


def _coherencia_rut(cfg, ruta_local_):
    """El archivo de origen debe calzar con la decisión RUT_PACIENTES."""
    from . import cliente
    d = cfg.get("rut_pacientes")
    try:
        df = cliente.leer_tabla(ruta_local_, cfg, nrows=300)
    except Exception:
        return None
    m = cliente.detectar_columnas(df, cfg, ["rut", "rut_hash", "dv", "zona", "lat", "lon"])
    col = m.get("rut") or m.get("rut_hash")
    if col is None:
        if d in ("en_claro", "seudonimizado"):
            return Item("Decisiones", "RUT en el archivo de origen", FALTA,
                        f'RUT_PACIENTES = "{d}", pero el archivo de origen no trae una columna de RUT reconocible.',
                        'Si el origen viene por zona o coordenadas: RUT_PACIENTES = "sin_rut". Si sí trae RUT con otro nombre: '
                        'COLUMNAS_CLIENTE["rut"].insert(0, "NOMBRE_DE_LA_COLUMNA").')
        return None
    es_hash = df[col].dropna().astype(str).str.strip().str.fullmatch(r"[0-9a-fA-F]{64}").mean() > 0.9
    if not es_hash and d == "en_claro":
        dv = _rut_dv_pacientes(cfg, df, m, col)
        if dv is not None:
            return dv
    if d == "sin_rut":
        return Item("Decisiones", "RUT en el archivo de origen", FALTA,
                    f"El archivo trae RUT ('{col}'), pero RUT_PACIENTES = \"sin_rut\": la ingesta no preparó el cruce.",
                    f'Cambia a RUT_PACIENTES = "{"seudonimizado" if es_hash else "en_claro"}" y vuelve a correr desde el notebook 01.')
    if es_hash and d == "en_claro":
        return Item("Decisiones", "RUT en el archivo de origen", FALTA,
                    f"El archivo trae RUT ya seudonimizados (64 caracteres hexadecimales en '{col}').",
                    'Cambia a RUT_PACIENTES = "seudonimizado", define GEOVENTAS_SAL_RUT con la sal de la clínica y vuelve a correr desde el 01.')
    if not es_hash and d == "seudonimizado":
        return Item("Decisiones", "RUT en el archivo de origen", FALTA,
                    f"RUT_PACIENTES = \"seudonimizado\", pero '{col}' trae RUT en claro.",
                    'Cambia a RUT_PACIENTES = "en_claro" y vuelve a correr desde el notebook 01.')
    detalle = "seudonimizado" if es_hash else "en claro"
    if not es_hash:
        from . import rut
        inf = {"explicacion": "dígito verificador en la columna '" + m["dv"] + "'"} if m.get("dv") else rut.detectar_dv(df[col])
        eleccion = cfg.get("rut_con_dv", "auto")
        detalle += " · " + (inf["explicacion"] if eleccion == "auto" or m.get("dv")
                            else f"se usa RUT_CON_DV = {eleccion} (config); los RUT con guion o K conservan su dígito verificador")
    return Item("Decisiones", "RUT en el archivo de origen", OK, f"columna '{col}' · {detalle}")


def _rut_dv_pacientes(cfg, df, m, col):
    """¿El RUT de los pacientes trae dígito verificador? Se mira en las primeras filas del archivo; si es ambiguo y
    RUT_CON_DV = "auto", se pide la decisión."""
    from . import rut
    if m.get("dv"):
        return None
    eleccion = cfg.get("rut_con_dv", "auto")
    inf = rut.detectar_dv(df[col])
    fmts = rut.formatos(df[col])
    txt = " · ".join(f"{r['formato']} {r['%']:.0f}%" for _, r in fmts.head(4).iterrows())
    if eleccion == "auto" and inf["con_dv"] is None:
        return Item("Decisiones", "RUT de los pacientes: dígito verificador", FALTA,
                    f"Columna '{col}': {inf['explicacion']}. Formatos: {txt}.",
                    "Escribe en config_estudio.py una de estas líneas:\n"
                    "  RUT_CON_DV = True    # el último carácter es el dígito verificador (19027025-4, 190270254)\n"
                    "  RUT_CON_DV = False   # viene solo el número, sin dígito verificador (19027025)")
    if eleccion != "auto" and inf["con_dv"] is not None and bool(eleccion) != inf["con_dv"]:
        return Item("Decisiones", "RUT de los pacientes: dígito verificador", AVISO,
                    f"RUT_CON_DV = {eleccion}, pero la columna '{col}' parece decir lo contrario: {inf['explicacion']}.",
                    "Revisa con la clínica; si los datos tienen razón, cambia RUT_CON_DV (o usa \"auto\").")
    return None


def _rut_equifax(cfg, base, local):
    """RUTID de personas o empresas: se revisa el formato en una muestra (sin cargar la base) para que cruce con los pacientes."""
    from . import rut
    if not local or cfg.get("rut_pacientes") not in ("en_claro", "seudonimizado"):
        return None
    col = cfg["columnas"][base]["id"]
    try:
        if local.lower().endswith((".parquet", ".pq")):
            import pyarrow.parquet as pq
            muestra = next(pq.ParquetFile(local).iter_batches(batch_size=50_000, columns=[col])).to_pandas()[col]
        else:
            import pandas as pd
            sep = cfg.get("separador_txt", "|")
            muestra = pd.read_csv(local, sep=sep, usecols=[col], nrows=50_000, dtype=str, encoding_errors="replace")[col]
    except Exception as e:
        return Item("Bases Equifax", f"RUT de {base}", AVISO, f"No se pudo revisar la columna {col}: {type(e).__name__}: {e}")
    inf = rut.detectar_dv(muestra)
    if inf["con_dv"] is None:
        return Item("Bases Equifax", f"RUT de {base}", AVISO, f"{col}: {inf['explicacion']}",
                    "Se leerá asumiendo que trae dígito verificador (formato habitual de Equifax). Si el cruce con los "
                    "pacientes sale bajo en el notebook 05, revisa esta columna.")
    return Item("Bases Equifax", f"RUT de {base}", OK, f"{col}: {inf['explicacion']}")


def huella_sal(cfg):
    """Huella corta (no reversible) de la sal en uso: permite detectar si personas/empresas se seudonimizaron con otra."""
    from .rut import sal_efectiva
    return hashlib.sha256(("huella:" + sal_efectiva(cfg)).encode()).hexdigest()[:12]


def registrar_huella_sal(cfg):
    """La ingesta (notebook 01) deja anotado con qué sal seudonimizó personas y empresas."""
    if cfg.get("rut_pacientes") == "sin_rut":
        return
    with open(os.path.join(cfg["carpetas"]["trabajo"], "huella_sal.json"), "w", encoding="utf-8") as f:
        json.dump({"huella": huella_sal(cfg), "rut_pacientes": cfg.get("rut_pacientes")}, f)


def _coherencia_sal(cfg):
    if cfg.get("rut_pacientes") in (None, "sin_rut") or not cfg["rutas"].get("origen_pacientes"):
        return None
    ruta = os.path.join(cfg["carpetas"]["trabajo"], "huella_sal.json")
    if not os.path.exists(ruta):
        return Item("Resultados previos", "Seudonimización de personas y empresas", FALTA,
                    "La ingesta no dejó registro de la sal usada (o se corrió con RUT_PACIENTES = \"sin_rut\").",
                    "Vuelve a correr el notebook 01 con la decisión de RUT actual.")
    reg = json.load(open(ruta, encoding="utf-8"))
    if reg.get("huella") != huella_sal(cfg):
        return Item("Resultados previos", "Seudonimización de personas y empresas", FALTA,
                    "Personas y empresas se seudonimizaron con OTRA sal: los RUT de los pacientes no cruzarían.",
                    "Vuelve a correr los notebooks 01 y 03 (la sal o la decisión de RUT cambió desde la ingesta).")
    return Item("Resultados previos", "Seudonimización de personas y empresas", OK, "misma sal que la ingesta")


def _regiones_censo(cfg):
    """Nombres de región del censo ya leído (columna REGION), si la ingesta ya se corrió."""
    from .utilidades import ruta_trabajo
    ruta = ruta_trabajo(cfg, "censo.parquet")
    col = cfg["columnas"]["censo"]["region"]
    if not os.path.exists(ruta):
        return []
    try:
        import pyarrow.parquet as pq
        t = pq.read_table(ruta, columns=[col]).column(0).to_pandas()
        return [r for r in t.dropna().astype(str).unique() if r.strip()]
    except Exception:
        return []


def _grafo(cfg, nb):
    from .red import buscar_grafos, archivos_grafo, grafos_disponibles
    carpeta = cfg["rutas"].get("grafos")
    destino = f'{_cfg_txt(cfg)}["grafos"]'
    if not carpeta or not os.path.isdir(carpeta):
        return [Item("Insumos del estudio", "Grafo vial", FALTA, f"No existe la carpeta de grafos: {carpeta}",
                     f"En config_estudio.py → {destino} = ruta completa de la carpeta con los .graphml "
                     "(la que en Jupyter se ve como prioritarias/graph).")]
    disponibles = grafos_disponibles(carpeta)
    regiones = _regiones_censo(cfg)
    sugeridos = sorted({g for g in (esquemas.grafo_para_region(r, disponibles) for r in regiones) if g})
    linea = "GRAFOS_VIALES = [" + ", ".join(f'"{g}"' for g in (sugeridos or ["NOMBRE_EXACTO.graphml"])) + "]"
    if not archivos_grafo(cfg):
        return [Item("Decisiones", "Grafo vial", FALTA,
                     "No se eligió qué grafo usar. En la carpeta hay: " + (", ".join(disponibles) or "ningún .graphml"),
                     "Escribe en config_estudio.py el nombre exacto del archivo (uno por región del estudio):\n  " + linea
                     + (f"   # según las regiones del censo: {', '.join(regiones)}" if sugeridos else ""))]
    try:
        rutas = buscar_grafos(cfg)
    except FileNotFoundError as e:
        return [Item("Decisiones", "Grafo vial", FALTA, f"{e}. En la carpeta hay: {', '.join(disponibles) or 'ningún .graphml'}",
                     "Corrige el nombre en config_estudio.py:\n  " + linea)]
    tam = sum(os.path.getsize(r) for r in rutas)
    items = [Item("Insumos del estudio", "Grafo vial", OK, " + ".join(os.path.basename(r) for r in rutas) + f" · {_gb(tam)}")]
    elegidos = {os.path.basename(r).replace(".gz", "") for r in rutas}
    sin_grafo = [r for r in regiones if (esquemas.grafo_para_region(r, disponibles) or "") not in elegidos]
    if sin_grafo:
        faltan = sorted({esquemas.grafo_para_region(r, disponibles) or f"(no reconozco la región '{r}')" for r in sin_grafo})
        items.append(Item("Decisiones", "Cobertura del grafo vial", FALTA,
                          f"El área de estudio incluye manzanas de {', '.join(sin_grafo)}, pero no se cargará su grafo: esas "
                          f"manzanas quedarían lejos de la red y con tiempos de viaje falsos. Falta: {', '.join(faltan)}",
                          "Agrega el grafo en config_estudio.py:\n  " + linea))
    elif regiones:
        items.append(Item("Decisiones", "Cobertura del grafo vial", OK, f"el grafo cubre las regiones del censo: {', '.join(regiones)}"))
    if nb in ("00", "04"):
        necesita = tam * 16 / 1e9                     # medido: GraphML de 238 MB -> 3,65 GB en memoria con osmnx
        libre = memoria_libre_gb()
        if libre is not None and libre < necesita * 1.15:
            items.append(Item("Equipo", "Memoria para cargar el grafo", AVISO,
                              f"El grafo ocupa ~{_n(necesita)} GB al cargarlo y hay {_n(libre)} GB libres.",
                              "Cierra programas pesados (navegadores con muchas pestañas, SQL Server, Oracle) antes de seguir; "
                              "el notebook libera el grafo apenas arma la red compacta."))
        else:
            items.append(Item("Equipo", "Memoria para cargar el grafo", OK,
                              f"~{_n(necesita)} GB al cargarlo · {_n(libre)} GB libres" if libre is not None else f"~{_n(necesita)} GB al cargarlo"))
    return items


def _previos(cfg, nb):
    from .utilidades import ruta_trabajo
    items, faltan = [], []
    lista = list(NECESITA.get(nb, []))
    if nb == "05" and cfg.get("rut_pacientes") != "sin_rut" and cfg["rutas"].get("origen_pacientes"):
        lista += ["personas_ut.parquet", "empresas_ut.parquet"]
    for f in lista:
        if not os.path.exists(ruta_trabajo(cfg, f)):
            faltan.append(f)
    if faltan:
        por_nb = {}
        for f in faltan:
            por_nb.setdefault(PRODUCIDO_POR.get(f, "?"), []).append(f)
        primero = min(por_nb)
        items.append(Item("Resultados previos", "Resultados de notebooks anteriores", FALTA,
                          " · ".join(f"notebook {k} ({TITULOS.get(k, '')}): {', '.join(v)}" for k, v in sorted(por_nb.items())),
                          (f"Corre los notebooks {' y '.join(sorted(por_nb))} (el 02 no hace falta: necesita las ventas de la clínica)." if nb == "04b"
                           else f"Corre primero el notebook {primero} · {TITULOS.get(primero, '')} (y los siguientes, en orden).")))
    elif lista:
        items.append(Item("Resultados previos", "Resultados de notebooks anteriores", OK,
                          f"{len(lista)} archivos de {', '.join(sorted({PRODUCIDO_POR[f] for f in lista}))} en {os.path.basename(cfg['carpetas']['trabajo'])}/"))
    return items


def _parametros(cfg, nb):
    """Errores de configuración que harían fallar o sesgar el estudio a mitad de camino."""
    items = []
    P = cfg
    malos = []
    if not set(P["gse_objetivo"]) <= set(P["gse"]):
        malos.append(("gse_objetivo", f'{sorted(set(P["gse_objetivo"]) - set(P["gse"]))} no están en GSE', 'PARAMETROS["gse_objetivo"] ⊂ GSE'))
    if P["censo"]["unidad_gasto"] not in ("mensual_total", "anual_total", "mensual_por_hogar", "mensual_por_persona"):
        malos.append(("unidad_gasto", P["censo"]["unidad_gasto"], '"mensual_total", "anual_total", "mensual_por_hogar" o "mensual_por_persona"'))
    from .red import MODOS
    if P["modelo"]["hora"] not in MODOS:
        malos.append(("modelo.hora", P["modelo"]["hora"], " / ".join(MODOS)))
    if set(P["red"]["isocronas_min"]) - set(MODOS):
        malos.append(("red.isocronas_min", sorted(set(P["red"]["isocronas_min"]) - set(MODOS)), " / ".join(MODOS)))
    s = sum(P["expansion"]["pesos_scoring"].values())
    if abs(s - 1) > 0.01:
        malos.append(("expansion.pesos_scoring", f"suman {s:.2f}", "que sumen 1,00"))
    try:
        import pyproj
        pyproj.CRS.from_user_input(P["estudio"]["crs_metrico"])
    except Exception:
        malos.append(("estudio.crs_metrico", P["estudio"]["crs_metrico"], "un CRS métrico válido, p. ej. EPSG:32719"))
    for nombre, valor, esperado in malos:
        items.append(Item("Parámetros", nombre, FALTA, f"valor actual: {valor}", f"En config_estudio.py → PARAMETROS: {esperado}."))
    mx = max(max(v) for v in P["red"]["isocronas_min"].values())
    if P["red"]["horizonte_min"] < mx:
        items.append(Item("Parámetros", "red.horizonte_min", AVISO, f"{P['red']['horizonte_min']} min < isócrona más larga ({mx} min)",
                          "Las isócronas más largas quedarán cortadas en el horizonte: súbelo o acorta las isócronas."))
    if not items and nb in (None, "01"):
        items.append(Item("Parámetros", "Coherencia de parámetros", OK, "sin contradicciones"))
    return items


# --------------------------------------------------------------------------------------------- API
def revisar(cfg, notebook=None, descargar=False):
    """Lista de revisiones (Item) para un notebook ('01'…'08') o para TODO el estudio (notebook=None).
    `descargar=True` baja a la caché local los archivos gs:// que se necesitan para revisar sus columnas."""
    nbs = [notebook] if notebook else ["01", "02", "03", "04", "04b", "05", "06", "07", "08"]
    items = _decisiones(cfg, notebook) + _parametros(cfg, notebook)
    if notebook is None:
        items += _avance(cfg)
    for nb in nbs:
        if notebook:
            items += _previos(cfg, nb)
        for clave, nivel, que, sin_dato in ENTRADAS.get(nb, []):
            it, local = _archivo(cfg, clave, nivel, que, sin_dato, descargar)
            items.append(it)
            if it.estado != OK:
                continue
            if clave in cfg["columnas"]:
                items.append(_columnas_equifax(cfg, clave, local))
                if clave in ("per", "emp") and nb == "01":
                    r = _rut_equifax(cfg, clave, local)
                    if r:
                        items.append(r)
            elif clave in CAMPOS_CLIENTE:
                if local:
                    items.append(_columnas_cliente(cfg, clave, local))
                    if clave == "origen_pacientes":
                        c = _coherencia_rut(cfg, local)
                        if c:
                            items.append(c)
                    if clave == "ventas_cliente" and items[-1].estado != FALTA:
                        items.append(_unidad_monto(cfg, local))
                else:
                    items.append(Item("Datos de la clínica", f"Columnas · {que}", OK, "se reconocen al leerlo en el notebook"))
        if nb in ("00", "04", "04b"):
            items += _grafo(cfg, nb)
        if nb == "05" and cfg["modo"] == "real":
            c = _coherencia_sal(cfg)
            if c:
                items.append(c)
    if notebook is None:
        items = _sin_duplicados(items)
    return items


def _avance(cfg):
    """Qué notebooks ya se corrieron (según sus resultados en la carpeta de trabajo)."""
    import datetime as dt
    from .utilidades import ruta_trabajo
    items = []
    for nb in ["01", "02", "03", "04", "05", "06", "07"]:
        fs = [ruta_trabajo(cfg, f) for f, p in PRODUCIDO_POR.items() if p == nb]
        hay = [f for f in fs if os.path.exists(f)]
        if len(hay) == len(fs):
            t = dt.datetime.fromtimestamp(max(os.path.getmtime(f) for f in hay)).strftime("%d-%m-%Y %H:%M")
            items.append(Item("Avance", f"Notebook {nb} · {TITULOS[nb]}", OK, f"resultados del {t}"))
        else:
            items.append(Item("Avance", f"Notebook {nb} · {TITULOS[nb]}", NO_VIENE,
                              "aún no se corre" if not hay else f"incompleto: faltan {len(fs) - len(hay)} de {len(fs)} resultados"))
    return items


def _sin_duplicados(items):
    vistos, out = set(), []
    for it in items:
        k = (it.grupo, it.nombre)
        if k not in vistos:
            vistos.add(k)
            out.append(it)
    return out


def resumen(items):
    n = {e: sum(i.estado == e for i in items) for e in (OK, AVISO, NO_VIENE, FALTA)}
    return n


def como_texto(items, titulo, detiene=True):
    n = resumen(items)
    faltas = [i for i in items if i.estado == FALTA]
    cola = " — el notebook se detiene aquí" if detiene else ""
    cab = (f"❌ {titulo}: {'FALTA 1 COSA' if len(faltas) == 1 else f'FALTAN {len(faltas)} COSAS'}{cola}"
           if faltas else f"✅ {titulo}: todo listo" + (f" ({n[AVISO]} para revisar)" if n[AVISO] else ""))
    out = [cab, "=" * min(len(cab), 110)]
    orden = faltas + [i for i in items if i.estado == AVISO] + [i for i in items if i.estado in (OK, NO_VIENE)]
    for k, i in enumerate(orden, 1):
        out.append(f"{ICONO[i.estado]} [{i.grupo}] {i.nombre}: {i.detalle}")
        if i.que_hacer and i.estado in (FALTA, AVISO):
            out += ["     → " + l for l in i.que_hacer.split("\n")]
    return "\n".join(out)


def como_html(items, titulo):
    n = resumen(items)
    faltas = n[FALTA]
    color = {OK: "#1b7f4b", AVISO: "#a15c00", NO_VIENE: "#6b7280", FALTA: "#b42318"}
    fondo = {OK: "#e8f5ee", AVISO: "#fff4e0", NO_VIENE: "#f1f2f4", FALTA: "#fdecea"}
    if faltas:
        cab = ("Falta 1 cosa" if faltas == 1 else f"Faltan {faltas} cosas") + ": el notebook se detiene aquí hasta completarlas"
        cc = FALTA
    else:
        cab = "Todo listo para correr" + (f" · {n[AVISO]} {'punto' if n[AVISO] == 1 else 'puntos'} para revisar" if n[AVISO] else "")
        cc = AVISO if n[AVISO] else OK
    orden = sorted(items, key=lambda i: [FALTA, AVISO, NO_VIENE, OK].index(i.estado))
    filas = []
    for i in orden:
        qh = html.escape(i.que_hacer).replace("\n", "<br>") if i.estado in (FALTA, AVISO) and i.que_hacer else ""
        filas.append(
            f'<tr><td style="white-space:nowrap;padding:6px 8px"><span style="background:{fondo[i.estado]};color:{color[i.estado]};'
            f'border-radius:10px;padding:2px 8px;font-weight:600;font-size:12px">{ICONO[i.estado]} {ETIQUETA[i.estado]}</span></td>'
            f'<td style="padding:6px 8px;color:#6b7280;font-size:12px">{html.escape(i.grupo)}</td>'
            f'<td style="padding:6px 8px;font-weight:600">{html.escape(i.nombre)}</td>'
            f'<td style="padding:6px 8px">{html.escape(i.detalle)}'
            + (f'<div style="margin-top:4px;font-family:Consolas,monospace;font-size:12px;background:#f6f8fa;color:#111827;'
               f'border-left:3px solid {color[i.estado]};padding:4px 8px">{qh}</div>' if qh else "") + "</td></tr>")
    return (f'<div style="font-family:Segoe UI,Arial,sans-serif;font-size:13px;color:#111827;background:#ffffff;'
            f'border:1px solid #e5e7eb;border-radius:10px;padding:12px 14px;max-width:1100px">'
            f'<div style="font-size:15px;font-weight:700;margin-bottom:2px">{html.escape(titulo)}</div>'
            f'<div style="color:{color[cc]};font-weight:600;margin-bottom:8px">{ICONO[cc]} {html.escape(cab)}</div>'
            f'<table style="border-collapse:collapse;width:100%;text-align:left">'
            f'<tr style="border-bottom:1px solid #e5e7eb;color:#6b7280;font-size:12px"><th style="padding:4px 8px">Estado</th>'
            f'<th style="padding:4px 8px">Tipo</th><th style="padding:4px 8px">Insumo</th><th style="padding:4px 8px">Detalle y qué hacer</th></tr>'
            + "".join(filas) + "</table></div>")


def _en_jupyter():
    try:
        from IPython import get_ipython
        ip = get_ipython()
        return ip is not None and "IPKernelApp" in ip.config
    except Exception:
        return False


def mostrar(items, titulo):
    if _en_jupyter():
        from IPython.display import HTML, display
        display(HTML(como_html(items, titulo)))
    else:
        print(como_texto(items, titulo))


def detener_si_falta(items, titulo):
    """Muestra la revisión y, si hay algo obligatorio pendiente, detiene el notebook con instrucciones claras."""
    mostrar(items, titulo)
    if any(i.estado == FALTA for i in items):
        raise FaltanInsumos(como_texto([i for i in items if i.estado == FALTA], titulo))
    return items


def exigir(cfg, notebook):
    """Primera celda de cada notebook: revisa lo que necesita y se detiene si falta algo obligatorio."""
    nb = str(notebook).split("_")[0]          # "02", "04b"…
    items = revisar(cfg, nb, descargar=True)
    return detener_si_falta(items, f"Insumos del notebook {nb} · {TITULOS.get(nb, '')}")


# --------------------------------------------------------------------------------------------- REVISIONES DENTRO DE LOS NOTEBOOKS
def verificar_unidad_gasto(dg, cfg):
    """La unidad del gasto del censo (config) debe calzar con lo que muestran los datos (gasto en salud por hogar)."""
    u = cfg["censo"]["unidad_gasto"]
    if not u.endswith("_total"):
        return Item("Decisiones", "Unidad del gasto del censo", OK, f"{u} (configurada; no aplica la prueba por hogar)")
    tot, hog = dg["gasto salud total"].sum(), dg["hogares"].sum()
    if not hog or not tot:
        return Item("Decisiones", "Unidad del gasto del censo", AVISO, "No se pudo calcular el gasto por hogar.",
                    "Revisa las columnas HOG_{gse} y G_SAL_{gse} del censo.")
    por_hogar = tot / hog
    mensual = por_hogar if u == "mensual_total" else por_hogar / 12
    det = f"gasto en salud por hogar ≈ ${_n(por_hogar, 0)} " + ("al mes" if u == "mensual_total" else "al año")
    if u == "mensual_total" and mensual > 1_500_000:
        return Item("Decisiones", "Unidad del gasto del censo", FALTA, det + ": parece un total ANUAL, no mensual.",
                    'Si el gasto del censo es anual: PARAMETROS["censo"]["unidad_gasto"] = "anual_total" en config_estudio.py.')
    if u == "anual_total" and mensual < 20_000:
        return Item("Decisiones", "Unidad del gasto del censo", FALTA, det + ": parece un total MENSUAL, no anual.",
                    'Si el gasto del censo es mensual: PARAMETROS["censo"]["unidad_gasto"] = "mensual_total" en config_estudio.py.')
    return Item("Decisiones", "Unidad del gasto del censo", OK, det + " · coherente con la unidad configurada")


def verificar_emparejamiento(emp, cfg, maestro=None, puntaje_sugerible=0.25):
    """Sedes de la clínica que no se pudieron asociar con seguridad a una sede del levantamiento.
    Se sugiere la mejor coincidencia solo si tiene algún parecido real (puntaje ≥ `puntaje_sugerible`); si no, queda
    "CAS-??" y se listan las sedes del levantamiento para elegir (nunca se propone un emparejamiento sin base)."""
    dudosas = emp[emp["revisar"]]
    if dudosas.empty:
        return Item("Datos de la clínica", "Emparejamiento de sedes", OK, f"{len(emp)} sedes de la clínica asociadas al levantamiento")
    sugerido = ", ".join(f'"{r.sede_cliente}": "{r.id_maestro if r.puntaje >= puntaje_sugerible else "CAS-??"}"'
                         for r in dudosas.itertuples())
    det = (f"{len(dudosas)} de {len(emp)} sedes con emparejamiento dudoso: "
           + "; ".join(f"{r.sede_cliente} → " + (f"{r.id_maestro} ({getattr(r, 'nombre_maestro', '') or ''}, puntaje {r.puntaje:.2f})"
                                                if r.puntaje >= puntaje_sugerible else "sin coincidencia por nombre ni dirección")
                       for r in dudosas.itertuples()))
    qh = ("Confirma o completa en config_estudio.py (código de la clínica → id del levantamiento):\n"
          f"  MAPA_SEDES = {{{sugerido}}}")
    if maestro is not None and {"id", "nombre"} <= set(maestro.columns):
        qh += "\nSedes del levantamiento: " + " · ".join(f"{i} {n}" for i, n in zip(maestro["id"], maestro["nombre"]))
    return Item("Datos de la clínica", "Emparejamiento de sedes", FALTA if cfg["modo"] == "real" else AVISO, det, qh)


if __name__ == "__main__":
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import config_estudio
    c = config_estudio.obtener_config()
    print(como_texto(revisar(c), f"Revisión completa del estudio (modo {c['modo']})", detiene=False))
