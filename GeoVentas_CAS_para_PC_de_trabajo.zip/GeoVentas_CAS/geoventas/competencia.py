# -*- coding: utf-8 -*-
"""Universo de competencia para el modelo.

Fuentes (en orden de prioridad):
  1. Levantamiento propio (pois_salud_nacional.csv, 23.788 lugares: DEIS, SIS, OSM, Farmanet, Overture, webs oficiales).
  2. POIs de salud de Equifax (PI01_POI) que NO estén ya en el levantamiento. El cruce se hace por coordenadas, nombre,
     dirección y tipo (ver unificacion_pois): un mismo lugar queda una sola vez aunque cada fuente lo escriba distinto.

Cada competidor se clasifica en un GRUPO del modelo según su formato:
  comp_clinica (clínicas de alta y mediana complejidad), comp_centro_medico, comp_laboratorio (toma de muestras/lab.).
Y se pondera por su segmento (Premium 1,0 … Público 0,2): un centro médico premium compite más con CAS que un SAPU.
El resto de la oferta (dental, kine, farmacias…) queda como CONTEXTO: se cuenta en las isócronas pero no entra al modelo.
"""
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
import geopandas as gpd
from scipy.spatial import cKDTree

from .utilidades import norm_serie, Cronometro, en_paralelo, n_nucleos
from . import unificacion_pois as UP

# tipo de lugar (familia) -> cómo entra un POI NUEVO de Equifax al universo (los del levantamiento traen lo suyo)
FORMATO_FAMILIA = {"hospital": "Clínica (mediana o baja complejidad)", "medica": "Centro Médico Ambulatorio",
                   "laboratorio": "Toma de Muestras / Laboratorio"}
CATEGORIA_FAMILIA = {"hospital": "Clínica / hospital", "medica": "Centro médico / consulta", "laboratorio": "Laboratorio / toma de muestras",
                     "dental": "Dental", "farmacia": "Farmacia", "optica": "Óptica", "kine": "Kinesiología / rehabilitación",
                     "eleam": "Residencia adulto mayor (ELEAM)", "insumos": "Insumos médicos / ortopedia", "ambulancia": "Ambulancias",
                     "salud_otro": "Otro (salud)"}


def leer_universo(cfg):
    """Universo de competencia del levantamiento, con las coordenadas leídas de cualquier forma (coordenadas.leer)."""
    from . import coordenadas
    u = pd.read_csv(cfg["rutas"]["competencia"], low_memory=False, encoding="utf-8-sig", dtype={"lat": object, "lon": object})
    u["lat"], u["lon"], inf = coordenadas.leer(u["lat"], u["lon"], cfg)
    u = u[np.isfinite(u["lat"]) & np.isfinite(u["lon"])]
    g = gpd.GeoDataFrame(u, geometry=gpd.points_from_xy(u["lon"], u["lat"]), crs="EPSG:4326")
    g.attrs["coordenadas"] = coordenadas.REGISTRO["competencia (levantamiento)"] = inf
    return g


def pois_salud_equifax(pois, cfg):
    """POIs de salud de PI01 (CAT1|CAT2|CAT3 cumple `incluir` y no `excluir`: fuera veterinarias), con su tipo de lugar y,
    si son clínicas, centros médicos o laboratorios, su formato del estudio."""
    E = cfg["competencia"]["pois_equifax"]
    cat = pois["categoria_txt"].astype(str)
    p = pois[(cat.str.contains(E["incluir"], regex=True) & ~cat.str.contains(E["excluir"], regex=True)).values].copy()
    nombre = p["nombre"] if "nombre" in p else pd.Series("", index=p.index)
    por_categoria = UP.familias(p["categoria_txt"].astype(str), E["familias"])      # "Centros Medicos" -> medica
    por_nombre = UP.familias(norm_serie(nombre), E["familias"])                       # si la categoría es solo "Salud"
    p["familia"] = np.where(por_categoria == "salud_otro", por_nombre, por_categoria)
    publico = norm_serie(nombre).str.contains(E["publico"], regex=True).values & np.isin(p["familia"], ["hospital", "medica"])
    p["formato_FRF"] = p["familia"].map(FORMATO_FAMILIA).fillna("No comparable con los formatos del estudio")
    p["tipo_competencia"] = np.where(publico, "Contexto: oferta pública",
                                     np.where(p["familia"].isin(list(FORMATO_FAMILIA)), "Indirecta",
                                              np.where(p["familia"].eq("farmacia"), "Contexto: retail de salud",
                                                       "Contexto: especializado o profesional")))
    p["segmento_estimado"] = np.where(publico, "Público", "s/i")
    p["categoria"] = np.where(publico, "Atención primaria y otros públicos", p["familia"].map(CATEGORIA_FAMILIA).values)
    p["nombre"] = nombre.where(nombre.notna() & nombre.astype(str).str.strip().ne(""), p.get("cat3", p.get("cat2", ""))).values
    p["fuentes"] = "Equifax PI01"
    p["id_universo"] = "PI01-" + p["id"].astype(str) if "id" in p else [f"PI01-{i}" for i in range(len(p))]
    return p.reset_index(drop=True)


def construir_competencia(cfg, area, pois=None, unificar=True):
    """Universo de competencia del área de estudio: el levantamiento completo + los POIs de salud de Equifax que no
    estaban (un registro por lugar). Devuelve (universo, unificación); la unificación es None si no hay POIs de Equifax.
    unificar=False agrega todos los POIs dados tal cual (solo para la "verdad" de la simulación, que ya sabe cuáles son nuevos)."""
    K = cfg["competencia"]
    crs = cfg["estudio"]["crs_metrico"]
    zona = area.to_crs(crs).buffer(K["unificacion"]["buffer_borde_m"]).to_crs("EPSG:4326").iloc[0]
    u_todo = leer_universo(cfg)
    u_todo = u_todo[u_todo.within(zona)].copy()            # también lo que está justo fuera del borde, para el cruce
    u_todo["fuente_universo"] = "levantamiento 19/20-11-2026"
    unif = None
    if pois is not None and len(pois):
        pe = pois_salud_equifax(pois, cfg)
        pe = pe[pe.within(area.geometry.iloc[0])].reset_index(drop=True)
        if unificar:
            unif = UP.unificar(u_todo, pe, cfg)
            nuevos = unif.nuevos.copy()
            u_todo["n_registros_equifax"] = u_todo["id_universo"].map(unif.por_levantamiento).fillna(0).astype(int)
        else:
            nuevos = pe.assign(n_registros_equifax=1)
        nuevos["fuente_universo"] = "Equifax PI01 (no estaba en el levantamiento)"
        cols = ["id_universo", "nombre", "marca", "direccion", "formato_FRF", "tipo_competencia", "segmento_estimado", "categoria",
                "familia", "fuentes", "fuente_universo", "n_registros_equifax", "geometry"]
        u_todo = pd.concat([u_todo, nuevos[[c for c in cols if c in nuevos]]], ignore_index=True)
    u = gpd.GeoDataFrame(u_todo, geometry="geometry", crs="EPSG:4326")
    u = u[u.within(area.geometry.iloc[0])].copy()
    u["lat"], u["lon"] = u.geometry.y, u.geometry.x
    # grupo del modelo
    u["grupo"] = None
    for grupo, formatos in K["grupos"].items():
        u.loc[u["formato_FRF"].isin(formatos) & u["grupo"].isna(), "grupo"] = grupo
    marca = norm_serie(u.get("marca", pd.Series("", index=u.index)).astype(str) + " " + u["nombre"].astype(str))
    propia = marca.str.contains("|".join(K["excluir_marcas"])) | u["tipo_competencia"].astype(str).str.startswith("Red propia")
    u["es_red_propia"] = propia.values
    relevante = u["tipo_competencia"].isin(K["tipos_relevantes"]) & u["grupo"].notna() & ~u["es_red_propia"]
    u["en_modelo"] = relevante.values
    u["peso_segmento"] = u["segmento_estimado"].map(K["peso_segmento"]).fillna(0.5)
    return u.reset_index(drop=True), unif


def variables_competencia(comp, ut, cfg):
    """Columnas por manzana: peso de competencia de cada grupo y conteo de oferta de contexto (dental, kine, farmacia…).
    Cada punto se asigna a la manzana cuyo punto interior está más cerca (todos los competidores cuentan una vez)."""
    crs = cfg["estudio"]["crs_metrico"]
    c = comp.to_crs(crs)
    _, j = cKDTree(np.c_[ut["cx"].values, ut["cy"].values]).query(np.c_[c.geometry.x.values, c.geometry.y.values])
    c = c.assign(ut=ut["ut"].values[j])
    m = c[c["en_modelo"]]
    out = m.pivot_table(index="ut", columns="grupo", values="peso_segmento", aggfunc="sum").add_suffix("_peso")
    out["comp_n_modelo"] = m.groupby("ut").size()
    ctx = c[~c["en_modelo"] & ~c["es_red_propia"]]
    out = out.join(ctx.groupby("ut").size().rename("oferta_contexto_n"), how="outer")
    return out.fillna(0)


# --------------------------------------------------------------------------------------------- POTENCIAL DE COMPETENCIA
# En el modelo, la competencia del grupo k frente a la manzana i es  F_ik = e^{a_k} · S_ik(β),  con
#     S_ik(β) = Σ_{c ∈ k} w_c · e^{−β · t_ic}       (w_c = peso de segmento, t_ic = minutos manzana → competidor)
# y β = la caída por minuto del formato equivalente (se estima). Calcular esa suma en cada iteración del ajuste exigiría
# guardar decenas de millones de pares manzana-competidor. En vez de eso, S se calcula UNA vez, con los tiempos exactos
# de cada manzana, en una grilla de β, y durante el ajuste se interpola log S en función de log β con un polinomio de
# Hermite cúbico que usa también la derivada exacta en cada nodo. Con 48 valores de β el error relativo es < 1e-4 en la suma y < 1e-3 en su derivada (medido), y la
# derivada que necesita el gradiente es la del mismo polinomio: el ajuste es consistente.
GRUPOS = ["comp_clinica", "comp_centro_medico", "comp_laboratorio"]


@dataclass
class PotencialCompetencia:
    u: np.ndarray                 # (nb,) log β de la grilla
    L: np.ndarray                 # (n, 3, nb) float32: log S_ik(β_b)
    D: np.ndarray                 # (n, 3, nb) float32: d log S / d log β en cada nodo
    cero: np.ndarray              # (n, 3) bool: la manzana no alcanza ningún competidor del grupo dentro del horizonte
    resumen: dict = field(default_factory=dict)

    @property
    def n(self):
        return self.L.shape[0]

    def subconjunto(self, filas):
        """Potencial de un subconjunto de manzanas (mismo orden que `filas`)."""
        return PotencialCompetencia(self.u, self.L[filas], self.D[filas], self.cero[filas], dict(self.resumen))


def _hermite(u, uu):
    """Coeficientes de Hermite (valor y derivada respecto de u) del punto uu en la grilla u.
    Fuera de la grilla: extrapolación lineal con la pendiente del extremo (continua y con derivada continua)."""
    nb = len(u)
    if uu <= u[0] or uu >= u[-1]:
        j = 0 if uu <= u[0] else nb - 1
        return "lineal", j, uu - u[j], None
    j = int(np.clip(np.searchsorted(u, uu) - 1, 0, nb - 2))
    h = u[j + 1] - u[j]
    t = (uu - u[j]) / h
    val = (2 * t ** 3 - 3 * t ** 2 + 1, (t ** 3 - 2 * t ** 2 + t) * h, -2 * t ** 3 + 3 * t ** 2, (t ** 3 - t ** 2) * h)
    der = ((6 * t ** 2 - 6 * t) / h, 3 * t ** 2 - 4 * t + 1, (-6 * t ** 2 + 6 * t) / h, 3 * t ** 2 - 2 * t)
    return "hermite", j, val, der


def evaluar_potencial(pc, beta_grupo):
    """S_ik(β_k) y ST_ik = Σ w·t·e^{−β t} = −dS/dβ para cada manzana i y grupo k (β_k = caída del formato equivalente).
    Devuelve (S, ST), ambos (n, 3). Costo O(n): solo combina 4 columnas de la grilla por grupo."""
    n = pc.n
    S = np.zeros((n, 3))
    ST = np.zeros((n, 3))
    for k in range(3):
        b = float(beta_grupo[k])
        tipo, j, a, d = _hermite(pc.u, np.log(max(b, 1e-12)))
        Lk, Dk = pc.L[:, k, :], pc.D[:, k, :]
        if tipo == "lineal":
            Lu = Dk[:, j].astype(float)
            L = Lk[:, j].astype(float) + Lu * a
        else:
            L0, L1 = Lk[:, j].astype(float), Lk[:, j + 1].astype(float)
            D0, D1 = Dk[:, j].astype(float), Dk[:, j + 1].astype(float)
            L = a[0] * L0 + a[1] * D0 + a[2] * L1 + a[3] * D1
            Lu = d[0] * L0 + d[1] * D0 + d[2] * L1 + d[3] * D1
        Sk = np.where(pc.cero[:, k], 0.0, np.exp(np.minimum(L, 300.0)))
        S[:, k] = Sk
        ST[:, k] = -Sk * Lu / b                      # −S'(β) = −S · (dL/du) / β
    return S, ST


def _acumular(S, S1, T, w, g, beta):
    """Suma la contribución de un lote de competidores a S y S1 (in situ). T: (n, m) minutos con ∞ fuera del horizonte.
    Las exponenciales se calculan en float32 (el doble de rápido; error relativo ~1e-7) y se acumulan en float64."""
    ok = np.isfinite(T)
    Tz = np.where(ok, T, 0.0).astype(np.float32)
    for k in range(3):
        cols = np.flatnonzero(g == k)
        if not len(cols):
            continue
        Tk = np.ascontiguousarray(Tz[:, cols])
        Wk = (ok[:, cols] * w[cols]).astype(np.float32)                  # peso 0 fuera del horizonte
        E = np.empty_like(Tk)
        for b in range(len(beta)):
            np.multiply(Tk, np.float32(-beta[b]), out=E)
            np.exp(E, out=E)
            E *= Wk                                                       # (n, m): w·e^(−βt)
            S[:, k, b] += E.sum(1, dtype=np.float64)
            S1[:, k, b] += np.einsum("ij,ij->i", E, Tk, dtype=np.float64)
    return ok.sum(0)


def _potencial_bloque(M, nodos, acceso_comp, nodos_ut, acceso_ut, w, g, beta, horizonte_min, lote, ids):
    """Trabajo de UN proceso: tiempos de todas las manzanas a un bloque de competidores (Dijkstra hacia cada uno) y su
    suma en la grilla de β. Devuelve sumas PARCIALES (se combinan sumándolas): la matriz manzanas × competidores nunca
    viaja entre procesos."""
    from scipy.sparse import csgraph
    S = np.zeros((len(nodos_ut), 3, len(beta)))
    S1 = np.zeros_like(S)
    alc = np.zeros(len(nodos), np.int64)
    for i0 in range(0, len(nodos), lote):
        sl = slice(i0, i0 + lote)
        D = csgraph.dijkstra(M, directed=True, indices=nodos[sl], limit=60 * horizonte_min)[:, nodos_ut]
        T = (D.T / 60).astype(np.float32)
        del D
        T += acceso_ut[:, None] + acceso_comp[sl][None, :]
        T[T > horizonte_min] = np.inf
        alc[sl] = _acumular(S, S1, T, w[sl], g[sl], beta)
    return S, S1, {"ids": ids, "alcanzables": alc}


def _sumar_parciales(a, b):
    a[0][:] += b[0]
    a[1][:] += b[1]
    a[2]["ids"] = np.r_[a[2]["ids"], b[2]["ids"]]
    a[2]["alcanzables"] = np.r_[a[2]["alcanzables"], b[2]["alcanzables"]]
    return a


def potencial_competencia(comp, ut, red, cfg, modo="auto_punta", nodos_ut=None, cronometro=None):
    """Potencial de competencia EXACTO por manzana: tiempos de cada manzana (desde su nodo de red) a cada competidor del
    modelo (desde su propio nodo, con el tramo de acceso en ambos extremos), resumidos en la grilla de β.
    En paralelo: cada proceso toma un bloque de competidores, calcula sus tiempos por lotes y su suma parcial en la
    grilla; las sumas parciales se combinan a medida que llegan. La matriz manzanas × competidores nunca existe entera."""
    from .red import preparar_unidades, nodo_cercano, velocidad_acceso
    log = cronometro or Cronometro()
    K = cfg["competencia"]
    c = comp[comp["en_modelo"]].to_crs(cfg["estudio"]["crs_metrico"])
    xy = np.c_[c.geometry.x.values, c.geometry.y.values]
    w = c["peso_segmento"].values.astype(float)
    g = c["grupo"].map({k: i for i, k in enumerate(GRUPOS)}).values.astype(int)
    nb = int(K.get("n_grilla_beta", 48))
    u = np.linspace(np.log(K.get("beta_min", 0.004)), np.log(K.get("beta_max", 1.5)), nb)
    beta = np.exp(u)
    nh, dh = nodos_ut if nodos_ut is not None else preparar_unidades(red, ut)
    nd, dd = nodo_cercano(red, xy[:, 0], xy[:, 1])
    vel = velocidad_acceso(cfg, modo)
    acc_ut = (dh / 1000 / vel * 60).astype(np.float32)                 # tramo manzana -> red y red -> competidor (min)
    acc_c = (dd / 1000 / vel * 60).astype(np.float32)
    lote = int(K.get("lote_competidores", 200))
    bloques = [b for b in np.array_split(np.arange(len(c)), max(1, min(len(c) // 20, n_nucleos(cfg)))) if len(b)]
    S, S1, info = en_paralelo(_potencial_bloque, [(red.M[modo], nd[b], acc_c[b], nh, acc_ut, w[b], g[b], beta,
                                                  cfg["red"]["horizonte_min"], lote, b) for b in bloques],
                              cfg, combinar=_sumar_parciales)
    alcanzables = np.zeros(len(c), np.int64)
    alcanzables[info["ids"]] = info["alcanzables"]
    log(f"  potencial de competencia: {len(c):,} competidores en {len(bloques)} bloques paralelos")
    cero = S[:, :, 0] <= 0
    Ss = np.where(S > 0, S, 1.0)
    L = np.where(cero[:, :, None], 0.0, np.log(Ss))
    D = np.where(cero[:, :, None], 0.0, -beta[None, None, :] * S1 / Ss)
    resumen = {"competidores": int(len(c)), "por_grupo": {GRUPOS[k]: int((g == k).sum()) for k in range(3)},
               "competidores_sin_manzanas_alcanzables": int((alcanzables == 0).sum()),
               "manzanas_sin_competencia_alcanzable": {GRUPOS[k]: int(cero[:, k].sum()) for k in range(3)},
               "grilla_beta": {"min": float(beta[0]), "max": float(beta[-1]), "valores": nb}, "modo": modo}
    return PotencialCompetencia(u, L.astype(np.float32), D.astype(np.float32), cero, resumen)


def verificar_potencial(pc, comp, ut, red, cfg, n_muestra=400, modo="auto_punta", nodos_ut=None, semilla=7):
    """Compara el potencial interpolado con el cálculo directo en una muestra de manzanas y valores de β al azar.
    Devuelve el error relativo máximo de S y de Σw·t·e^{−βt} (deben ser < 1e-3)."""
    from .red import tiempos_a_puntos, preparar_unidades
    rng = np.random.default_rng(semilla)
    filas = np.sort(rng.choice(len(ut), size=min(n_muestra, len(ut)), replace=False))
    nodos_ut = nodos_ut if nodos_ut is not None else preparar_unidades(red, ut)
    sub = (nodos_ut[0][filas], nodos_ut[1][filas])
    c = comp[comp["en_modelo"]].to_crs(cfg["estudio"]["crs_metrico"])
    T = tiempos_a_puntos(red, ut.iloc[filas], np.c_[c.geometry.x.values, c.geometry.y.values], modo, cfg, nodos_ut=sub)
    ok = np.isfinite(T)
    Tz = np.where(ok, T, 0.0).astype(float)
    w = c["peso_segmento"].values.astype(float)
    g = c["grupo"].map({k: i for i, k in enumerate(GRUPOS)}).values
    ps = pc.subconjunto(filas)
    e_s = e_t = 0.0
    for _ in range(12):
        betas = np.exp(rng.uniform(np.log(0.02), np.log(0.5), 3))
        Si, STi = evaluar_potencial(ps, betas)
        for k in range(3):
            E = np.exp(-betas[k] * Tz[:, g == k]) * ok[:, g == k] * w[g == k]
            S, ST = E.sum(1), (E * Tz[:, g == k]).sum(1)
            m = S > 1e-12
            if m.any():
                e_s = max(e_s, float(np.max(np.abs(Si[m, k] / S[m] - 1))))
                e_t = max(e_t, float(np.max(np.abs(STi[m, k] / ST[m] - 1))))
    return {"manzanas": int(len(filas)), "error_rel_max_S": e_s, "error_rel_max_ST": e_t}
