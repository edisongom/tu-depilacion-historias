# -*- coding: utf-8 -*-
"""Modelo de estimación de ventas: interacción espacial tipo Huff con competencia.

En palabras: cada MANZANA tiene un "presupuesto" de gasto en salud (más alto en los GSE altos). Ese gasto se reparte
entre las sedes de Clínica Alemana, la competencia y "no ir a ninguna" (el 1 del denominador), según qué tan
atractiva es cada alternativa y cuánto se demora uno en llegar. La venta de una sede es la suma de lo que capta en
todas las manzanas.

  venta_ij = κ · Dt_i · A_j·e^{−β_f(j)·t_ij} / (1 + Σ_k A_k·e^{−β_f(k)·t_ik} + Σ_c w_c·A_g(c)·e^{−β_f(g(c))·t_ic})
  Dt_i     = Σ_g gasto_salud_ig · p_g  +  λ · trabajadores_i · gasto_per_cápita
             (p_g = peso de afinidad del GSE g, con p_AB = 1; λ = peso de la demanda flotante)

Parámetros (17): κ (escala), λ, atractivo A por formato (3), caída por minuto β por formato (3), atractivo de cada
grupo de competencia (3) y pesos GSE (6). Se estiman por máxima verosimilitud cuasi-Poisson penalizada (priors suaves)
con gradiente analítico. Las observaciones son UNIDADES (manzanas, zonas censales, comunas o el total de una sede): la
venta esperada de una unidad es la suma de la venta esperada de sus manzanas (matriz A). Así el mismo modelo sirve con
origen por RUT (cada manzana es una observación), por zona, por comuna o sin origen.
La competencia entra por su "potencial" exacto por manzana (ver competencia.potencial_competencia), interpolado en β.
"""
from dataclasses import dataclass, field, replace

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.optimize import minimize

from .utilidades import en_paralelo
from .competencia import PotencialCompetencia, evaluar_potencial

FORMATOS = ["clinica", "centro_medico", "toma_muestras"]
GRUPOS_COMP = ["comp_clinica", "comp_centro_medico", "comp_laboratorio"]
FMT_DE_GRUPO = np.array([0, 1, 2])          # la competencia de cada grupo decae con el β del formato equivalente
T_LEJOS = 1e3


def nombres_parametros(gse):
    return (["log_kappa", "log_lambda"] + [f"a_{f}" for f in FORMATOS] + [f"log_beta_{f}" for f in FORMATOS]
            + [f"a_{g}" for g in GRUPOS_COMP] + [f"log_peso_{g}" for g in gse[1:]] + ["gamma_capacidad"])


@dataclass
class DatosHuff:
    G: np.ndarray            # (n, nG) gasto mensual en salud por GSE en cada manzana
    W: np.ndarray            # (n,) trabajadores × gasto per cápita (base de la demanda flotante)
    T: np.ndarray            # (n, J) minutos a las sedes propias
    fmt: np.ndarray          # (J,) índice de formato de cada sede
    pc: PotencialCompetencia # potencial de competencia exacto por manzana y grupo (grilla en β)
    A: sparse.csr_matrix     # (U, n) unidades de observación
    S: np.ndarray            # (U, J) venta mensual observada por unidad y sede
    mask: np.ndarray         # (U, J) pares que entran a la verosimilitud
    w: np.ndarray = None     # (U,) pesos (bootstrap / validación cruzada)
    sedes: list = field(default_factory=list)
    gse: list = field(default_factory=list)
    phi: float = None        # dispersión cuasi-Poisson (en pesos): la estima `ajustar` en una primera pasada (None = aún no)
    z: np.ndarray = None     # (J,) capacidad relativa de cada sede: log(m² / mediana de su formato); 0 = tamaño típico

    def __post_init__(self):
        self.T = np.where(np.isfinite(self.T), self.T, T_LEJOS).astype(float)
        if self.pc is not None and self.pc.n != self.T.shape[0]:
            raise ValueError(f"El potencial de competencia tiene {self.pc.n:,} manzanas y los tiempos {self.T.shape[0]:,}: "
                             "vuelve a correr el notebook 04.")
        if self.w is None:
            self.w = np.ones(self.S.shape[0])
        # pares unidad-sede sin ninguna manzana dentro del horizonte de viaje: no se modelan (el modelo predice 0 ahí)
        alcanzable = (self.A @ (self.T < T_LEJOS).astype(float)) > 0
        self.mask = np.asarray(self.mask, bool) & alcanzable
        if self.z is None:
            self.z = np.zeros(self.T.shape[1])

    @property
    def n_par(self):
        return 12 + self.G.shape[1] - 1


def theta_inicial(d, cfg):
    M = cfg["modelo"]
    p0 = np.log([max(M["pesos_gse_iniciales"].get(g, 0.1), 1e-3) for g in d.gse[1:]])
    Dt = d.G @ np.r_[1.0, np.exp(p0)] + 0.3 * d.W
    tot_obs = (d.S * d.mask).sum(0)
    k0 = np.log(max(tot_obs.sum(), 1e-300) / max(Dt.sum() * 0.25, 1e-300)) if tot_obs.sum() > 0 else 0.0
    b0 = np.log([M["beta_prior"][f] for f in FORMATOS])
    return np.r_[k0, np.log(0.3), 0.0, 0.0, 0.0, b0, 0.0, 0.0, 0.0, p0, 0.0]


def sd_prior(d, cfg, nivel):
    sd = np.r_[10.0, np.full(10, cfg["modelo"]["prior_sd"]), np.full(len(d.gse) - 1, 0.7), 0.5]
    if np.allclose(d.z, 0):                    # sin datos de capacidad: γ queda fijo en 0
        sd[-1] = 1e-3
    if nivel == "total":                       # sin origen: β y pesos GSE vienen casi solo de los priors
        sd[5:8] = 0.25; sd[11:-1] = 0.3
    for f in range(3):
        if not (d.fmt == f).any():             # formato sin sedes propias: atractivo no identificable con datos propios
            sd[2 + f] = 0.3; sd[5 + f] = 0.25
    return sd


def _partes(th, d):
    th = np.clip(th, -40, 40)                     # protege contra desbordes durante la búsqueda del optimizador
    kap, lam = np.exp(th[0]), np.exp(th[1]); a = th[2:5]; beta = np.exp(th[5:8]); ac = th[8:11]
    pg = np.r_[1.0, np.exp(th[11:-1])]
    Dt = d.G @ pg + lam * d.W + 1e-9
    E = np.exp(np.minimum((a[d.fmt] + th[-1] * d.z)[None, :] - beta[d.fmt][None, :] * d.T, 50.0))
    if d.pc is not None:
        Sc, STc = evaluar_potencial(d.pc, beta[FMT_DE_GRUPO])     # (n, 3): Σ w·e^{−βt} y Σ w·t·e^{−βt} por grupo
        ea = np.exp(np.minimum(ac, 50.0))[None, :]
        F, FT = Sc * ea, STc * ea                                 # competencia de cada grupo y su derivada (para el gradiente)
    else:
        F = FT = np.zeros((d.T.shape[0], 3))
    Den = 1.0 + E.sum(1) + F.sum(1)
    mu = kap * Dt[:, None] * E / Den[:, None]
    return kap, lam, a, beta, ac, pg, Dt, E, F, FT, Den, mu


def _segunda_diferencia(m):
    D = np.zeros((max(m - 2, 0), m))
    for k in range(m - 2):
        D[k, k:k + 3] = [1.0, -2.0, 1.0]
    return D


def logver(th, d, th0, sd, tau_gse=0.25):
    """Log-verosimilitud cuasi-Poisson penalizada sobre las unidades y su gradiente analítico."""
    kap, lam, a, beta, ac, pg, Dt, E, F, FT, Den, mu = _partes(th, d)
    muU = d.A @ mu
    wm = d.w[:, None] * d.mask / _phi(d)            # cuasi-verosimilitud: los datos pesan según su dispersión real
    ll = (wm * (np.where(d.S > 0, d.S * np.log(np.maximum(muU, 1e-300)), 0.0) - muU)).sum()
    RU = wm * (d.S / np.maximum(muU, 1e-300) - 1.0)
    P = (d.A.T @ RU) * mu                        # (n, J)
    Pi = P.sum(1)
    g = np.zeros(len(th))
    g[0] = P.sum()
    g[1] = (Pi * lam * d.W / Dt).sum()
    for f in range(3):
        jf = d.fmt == f
        q = E[:, jf].sum(1) / Den
        g[2 + f] = P[:, jf].sum() - (Pi * q).sum()
        cf = FMT_DE_GRUPO == f                                  # grupos de competencia que decaen con el β de este formato
        r = ((E[:, jf] * d.T[:, jf]).sum(1) + FT[:, cf].sum(1)) / Den
        g[5 + f] = beta[f] * (-(P[:, jf] * d.T[:, jf]).sum() + (Pi * r).sum())
    for k in range(3):
        s_ = F[:, k] / Den
        g[8 + k] = -(Pi * s_).sum()
    for k in range(1, len(pg)):
        g[10 + k] = (Pi * d.G[:, k] * pg[k] / Dt).sum()
    g[-1] = (P * d.z[None, :]).sum() - (Pi * (E @ d.z) / Den).sum()          # γ (capacidad)
    ll -= 0.5 * (((th - th0) / sd) ** 2).sum()
    g -= (th - th0) / sd ** 2
    # suavidad de la curva de pesos GSE (AB=0, C1A, …, E en log): penaliza la segunda diferencia. Los GSE vecinos viven
    # juntos (columnas casi colineales); sin esto los pesos individuales "zigzaguean" aunque su efecto conjunto esté bien.
    l = np.r_[0.0, th[11:-1]]
    D2 = _segunda_diferencia(len(l))
    r = D2 @ l
    ll -= 0.5 * (r ** 2).sum() / tau_gse ** 2
    g[11:-1] -= (D2.T @ r)[1:] / tau_gse ** 2
    return ll, g


def _phi(d):
    return 1.0 if d.phi is None else d.phi


def dispersion(th, d):
    """φ de Pearson: Σ (observado − esperado)² / esperado / (grados de libertad). Mide cuánto más variable es la venta
    observada que un Poisson; con φ la verosimilitud y los priors quedan en la escala correcta.

    φ tiene la MISMA unidad que la venta: si las ventas se multiplican por k, φ también, y la cuasi-verosimilitud
    (Σ y·log μ − μ) / φ no cambia. Por eso el ajuste da los mismos β, pesos y λ con ventas en pesos, en miles o en
    millones, y con una red que vende 20 veces más o 20 veces menos (solo cambia κ). No se pone un piso de 1 (eso
    rompería esa invariancia con montos chicos)."""
    mu = d.A @ predecir(th, d)
    m = d.mask & (mu > 0)
    return float(max(np.sum((d.S[m] - mu[m]) ** 2 / mu[m]) / max(m.sum() - len(th), 1), 1e-300))


def ajustar(d, cfg, nivel="unidad", th_ini=None, maxiter=1500):
    """Estimación MAP (cuasi-verosimilitud penalizada). Devuelve (theta, resultado del optimizador).
    Si la dispersión φ aún no se estimó (d.phi is None), se ajusta una vez, se estima φ, se guarda en d.phi y se reajusta.
    Las recalibraciones posteriores (validación, bootstrap) reutilizan ese φ."""
    if d.phi is None and (d.S * d.mask).sum() > 0:
        # 1ª pasada: φ provisional = una millonésima de la venta media observada. Es proporcional a la escala (la 1ª
        # pasada tampoco depende de la unidad) y tan chico que los datos dominan a los priors: φ se estima con los
        # residuos de un ajuste guiado por los datos, aunque haya pocas observaciones (p. ej. 11 sedes sin origen).
        y = d.S[d.mask & (d.S > 0)]
        d.phi = 1e-6 * float(np.mean(y)) if len(y) else 1.0
        th1, _ = _ajustar(d, cfg, nivel, th_ini, maxiter)
        d.phi = dispersion(th1, d)
        th_ini = th1
    th, res = _ajustar(d, cfg, nivel, th_ini, maxiter)
    res.phi = _phi(d)
    return th, res


def solo_lo_que_aporta(d):
    """Copia de los datos con SOLO las unidades que entran a la verosimilitud (peso > 0 y algún par observado) y sus
    manzanas. Las demás no aportan ni a la verosimilitud ni al gradiente (la cuota de una manzana depende solo de sus
    propios tiempos), así que el ajuste es idéntico y cada evaluación es proporcionalmente más rápida (en el
    bootstrap ~37% de las unidades tiene peso 0)."""
    activas = (d.w > 0) & d.mask.any(1)
    A = d.A[activas]
    filas = np.flatnonzero(A.getnnz(0) > 0)
    if activas.all() and len(filas) == d.T.shape[0]:
        return d
    return replace(d, G=d.G[filas], W=d.W[filas], T=d.T[filas], pc=None if d.pc is None else d.pc.subconjunto(filas),
                   A=A[:, filas], S=d.S[activas], mask=d.mask[activas], w=d.w[activas])


def _ajustar(d, cfg, nivel, th_ini, maxiter):
    th0 = theta_inicial(d, cfg)
    sd = sd_prior(d, cfg, nivel)
    escala = _escala(d)
    d = solo_lo_que_aporta(d)

    def fobj(th):
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            ll, g = logver(th, d, th0, sd)
        if not np.isfinite(ll):
            return 1e30, np.zeros_like(th)
        return -ll / escala, -g / escala
    res = minimize(fobj, th0 if th_ini is None else th_ini, jac=True, method="L-BFGS-B",
                   options={"maxiter": maxiter, "gtol": 1e-7, "ftol": 1e-14, "maxcor": 30})
    # criterio de convergencia práctico: gradiente (escalado) casi nulo, aunque el optimizador se detenga por iteraciones
    res.convergio = bool(res.success or np.max(np.abs(res.jac)) < 1e-5)
    return res.x, res


def _escala(d):
    """Normalizador de la función objetivo (≈ número de "observaciones efectivas"): deja la verosimilitud en O(1) para
    que las tolerancias del optimizador signifiquen lo mismo con cualquier escala de ventas."""
    tot = float((d.S * d.mask).sum()) / _phi(d)
    return tot if tot > 0 else 1.0


def predecir(th, d):
    """Venta mensual esperada por manzana y sede (n × J)."""
    return _partes(th, d)[-1]


def lote_columnas(n_filas, lote=None, mb=32):
    """Cuántas columnas (sitios) procesar a la vez para que cada matriz temporal (n_filas × lote, float64) ocupe ≤ `mb` MB.
    Con ≈ 50 mil manzanas son ≈ 80 columnas por lote. Así la memoria no depende del número de sitios
    ni de cuántos procesos corran en paralelo."""
    auto = max(8, int(mb * 1e6 / (8 * max(n_filas, 1))))
    return min(lote, auto) if lote else auto


def _tiempos_lote(T, sl):
    """Columnas `sl` de una matriz de tiempos (float16/32/64, memmap o no) en float64, con ∞ / NaN → T_LEJOS.
    Se convierte solo el lote: nunca se copia la matriz completa."""
    Tb = np.array(T[:, sl], dtype=np.float64)
    Tb[~np.isfinite(Tb)] = T_LEJOS
    return Tb


def evaluar_sitios(th, d, Tnew, fmt_new, lote=None, z_new=0.0):
    """Para cada sitio nuevo (columna de Tnew): venta bruta, venta que pierden las sedes actuales (canibalización) y neta.
    Recorre los sitios por lotes de memoria acotada (`lote_columnas`)."""
    kap, lam, a, beta, ac, pg, Dt, E, F, FT, Den, mu = _partes(th, d)
    C = Tnew.shape[1]
    fmt_new = np.broadcast_to(np.asarray(fmt_new), (C,))
    sumE = E.sum(1)
    KD = kap * Dt
    w_canib = KD * sumE / Den        # pérdida de las sedes actuales: Σ KD·ΣE·(1/Den − 1/(Den+En)) = Σ (KD·ΣE/Den)·En/(Den+En)
    bruta, canib = np.zeros(C), np.zeros(C)
    paso = lote_columnas(Tnew.shape[0], lote)
    for i in range(0, C, paso):
        sl = slice(i, i + paso)
        En = np.exp(np.minimum((a[fmt_new[sl]] + th[-1] * z_new)[None, :] - beta[fmt_new[sl]][None, :] * _tiempos_lote(Tnew, sl), 50.0))
        cuota = En / (Den[:, None] + En)      # participación del sitio nuevo en cada manzana
        bruta[sl] = KD @ cuota
        canib[sl] = w_canib @ cuota           # sin restar sumas grandes: exacto en punto flotante
    return pd.DataFrame({"venta_bruta": bruta, "canibalizacion": canib, "venta_neta": bruta - canib})


def canibalizacion_por_sede(th, d, tnew, fmt_new, z_new=0.0):
    """Pérdida de venta mensual de cada sede actual si se abre un sitio (tiempos tnew, formato fmt_new)."""
    kap, lam, a, beta, ac, pg, Dt, E, F, FT, Den, mu = _partes(th, d)
    En = np.exp(a[fmt_new] + th[-1] * z_new - beta[fmt_new] * np.where(np.isfinite(tnew), tnew, T_LEJOS))
    return (mu - kap * Dt[:, None] * E / (Den + En)[:, None]).sum(0)


def agregar_sede(d, tnew, fmt_new, nombre):
    """Copia de los datos con una sede propia más (para la selección secuencial del Top 20)."""
    U = d.S.shape[0]
    return replace(d, T=np.c_[d.T, tnew], fmt=np.r_[d.fmt, fmt_new], z=np.r_[d.z, 0.0], S=np.c_[d.S, np.zeros(U)],
                   mask=np.c_[d.mask, np.zeros(U, bool)], sedes=list(d.sedes) + [nombre])


def quitar_sede(d, j):
    k = np.arange(d.T.shape[1]) != j
    return replace(d, T=d.T[:, k], fmt=d.fmt[k], z=d.z[k], S=d.S[:, k], mask=d.mask[:, k], sedes=[s for i, s in enumerate(d.sedes) if i != j])


def tabla_parametros(th, d, banda=None):
    nombres = nombres_parametros(d.gse)
    t = pd.DataFrame({"parametro": nombres, "valor": th})
    t["valor_natural"] = [np.exp(v) if n.startswith(("log_", "a_")) else v for n, v in zip(nombres, th)]
    interp = (["escala de captura κ", "peso de la demanda flotante λ (trabajadores)"]
              + [f"atractivo de una sede propia: {f}" for f in FORMATOS]
              + [f"caída por minuto β ({f})" for f in FORMATOS]
              + [f"atractivo de la competencia: {g}" for g in GRUPOS_COMP]
              + [f"peso de afinidad GSE {g} (AB = 1)" for g in d.gse[1:]]
              + ["efecto del tamaño de la sede γ (atractivo × (m²/m² típico)^γ)"])
    t["interpretacion"] = interp
    for f in range(3):
        b = np.exp(th[5 + f])
        t.loc[5 + f, "interpretacion"] += f" → el atractivo cae a la mitad cada {np.log(2) / b:.1f} min"
    if banda is not None:
        t["p10"], t["p90"] = banda
        for c in ("p10", "p90"):
            t[c + "_natural"] = [np.exp(v) if n.startswith(("log_", "a_")) else v for n, v in zip(nombres, t[c])]
    return t


def pesos_gse(th, d):
    return dict(zip(d.gse, np.r_[1.0, np.exp(th[11:-1])]))


# --------------------------------------------------------------------------------------------- VALIDACIÓN
def metricas_ajuste(th, d):
    mu = predecir(th, d)
    muU = d.A @ mu
    m = d.mask
    y, p = d.S[m], muU[m]
    dev = lambda yy, mm: 2 * np.sum(np.where(yy > 0, yy * np.log(np.maximum(yy, 1e-300) / np.maximum(mm, 1e-300)), 0) - (yy - mm))
    d2 = 1 - dev(y, p) / dev(y, np.full_like(y, y.mean())) if len(y) > 1 else np.nan
    tot_o = (d.S * d.mask).sum(0); tot_p = (muU * d.mask).sum(0)
    return {"unidades_observadas": int(m.any(1).sum()), "desvio_explicado_unidades": float(d2),
            "correlacion_unidades": float(np.corrcoef(y, p)[0, 1]) if len(y) > 2 else np.nan,
            "error_abs_medio_sede_pct": float(np.mean(np.abs(tot_p - tot_o) / np.where(tot_o > 0, tot_o, np.nan))),
            "venta_observada_total": float(tot_o.sum()), "venta_predicha_total": float(tot_p.sum())}


def ajuste_por_sede(th, d, venta_madura):
    mu = predecir(th, d)
    vm = venta_madura.set_index("sede")["venta_mensual_madura"]
    t = pd.DataFrame({"sede": d.sedes, "formato": [FORMATOS[f] for f in d.fmt],
                      "venta_observada": vm.reindex(d.sedes).values, "venta_predicha": mu.sum(0)})
    t["error_pct"] = t["venta_predicha"] / t["venta_observada"] - 1
    return t


def validar_sede_fuera(d, cfg, th_full, nivel, venta_madura):
    """Validación 'sede nueva' (FRF Hito 2.1): se saca cada sede del modelo, se recalibra con las demás y se predice
    su venta como si fuera una apertura. Es la prueba más parecida al uso real del modelo."""
    vm = venta_madura.set_index("sede")["venta_mensual_madura"]
    preds = en_paralelo(_sede_fuera, [(d, cfg, th_full, nivel, j) for j in range(len(d.sedes))], cfg)   # una sede por núcleo
    mu_full = predecir(th_full, d).sum(0)
    v = pd.DataFrame({"sede": d.sedes, "formato": [FORMATOS[f] for f in d.fmt], "venta_observada": vm.reindex(d.sedes).values,
                      "venta_predicha_como_nueva": preds, "venta_predicha_con_todas": mu_full})
    v["error_pct"] = v["venta_predicha_como_nueva"] / v["venta_observada"] - 1
    return v


def sd_error_sede(val, piso=0.10, techo=0.60):
    """Error propio de una sede nueva (σ en escala log), medido con la validación "sede nueva".

    Por qué hace falta: el bootstrap remuestrea manzanas y mide cuánto se mueven los PARÁMETROS, pero no captura que cada
    sede tiene un atractivo propio no observado (estacionamiento, equipo médico, convenios, visibilidad) que la hace vender
    más o menos que lo predicho. La validación "sede nueva" mide justamente ese error en sedes reales. Se usa la raíz del
    error cuadrático medio de log(predicha / observada) (incluye el sesgo), con un piso de 10% (con pocas sedes la
    estimación es inestable) y un techo de 60%."""
    r = np.log(val["venta_predicha_como_nueva"].astype(float) / val["venta_observada"].astype(float))
    r = r[np.isfinite(r)]
    if not len(r):
        return piso
    return float(np.clip(np.sqrt(np.mean(r ** 2)), piso, techo))


def _sede_fuera(d, cfg, th_full, nivel, j):
    dj = quitar_sede(d, j)
    th_j, _ = ajustar(dj, cfg, nivel, th_ini=th_full, maxiter=250)
    return float(evaluar_sitios(th_j, dj, d.T[:, [j]], d.fmt[j], z_new=d.z[j])["venta_bruta"].iloc[0])


def _ajuste_pesado(d, cfg, nivel, th, w, maxiter):
    th_b, _ = ajustar(replace(d, w=w), cfg, nivel, th_ini=th, maxiter=maxiter)
    return th_b


def incertidumbre(d, cfg, th, nivel, B=None, semilla=1):
    """Muestras de parámetros para escenarios P10/P50/P90.
    Con ≥ 30 unidades: bootstrap de unidades de origen (remuestreo con reemplazo y recalibración).
    Con pocas unidades (sin origen): aproximación de Laplace (normal con la curvatura de la verosimilitud) × dispersión."""
    B = B or cfg["modelo"]["n_bootstrap"]
    rng = np.random.default_rng(semilla)
    U = d.S.shape[0]
    usadas = np.where(d.mask.any(1))[0]
    if len(usadas) >= 30:
        pesos = []
        for b in range(B):
            w = np.zeros(U)
            w[usadas] = rng.multinomial(len(usadas), np.full(len(usadas), 1 / len(usadas)))
            pesos.append(w)
        thetas = en_paralelo(_ajuste_pesado, [(d, cfg, nivel, th, w, 200) for w in pesos], cfg)   # réplicas en paralelo
        return np.array(thetas), "bootstrap de unidades de origen"
    th0 = theta_inicial(d, cfg); sd = sd_prior(d, cfg, nivel)
    eps = 1e-4
    H = np.zeros((len(th), len(th)))
    for k in range(len(th)):
        e = np.zeros(len(th)); e[k] = eps
        H[:, k] = -(logver(th + e, d, th0, sd)[1] - logver(th - e, d, th0, sd)[1]) / (2 * eps)
    H = (H + H.T) / 2
    mu = d.A @ predecir(th, d)
    m = d.mask
    ok = m & (mu > 0)
    phi = max(float(np.sum((d.S[ok] - mu[ok]) ** 2 / mu[ok]) / max(ok.sum() - len(th), 1)), 1e-300)
    cov = np.linalg.pinv(H) * (phi if d.phi is None else 1.0)    # si φ ya está en la verosimilitud no se aplica dos veces
    return rng.multivariate_normal(th, cov, size=B, method="eigh"), "aproximación de Laplace × dispersión"


def coordenadas_unidades(d, ut):
    """Centro de cada unidad de observación (promedio de sus manzanas ponderado por demanda) para armar bloques espaciales."""
    peso = d.G.sum(1) + 1e-9
    A = d.A.multiply(peso[None, :]).tocsr()
    s = np.asarray(A.sum(1)).ravel() + 1e-12
    return np.c_[A @ ut["cx"].values / s, A @ ut["cy"].values / s]


def cv_espacial(d, cfg, th, nivel, coords, n_bloques=None, semilla=1):
    """Validación cruzada espacial: se esconden bloques de unidades vecinas, se recalibra y se predicen.
    Mide si el modelo predice bien zonas que no vio (más exigente que el ajuste en muestra)."""
    from sklearn.cluster import KMeans
    usadas = np.where(d.mask.any(1) & (np.asarray(d.A.sum(1)).ravel() < d.A.shape[1]))[0]
    k = min(n_bloques or cfg["modelo"]["n_bloques_cv"], max(2, len(usadas) // 5))
    if len(usadas) < 10:
        return None
    grupos = np.full(d.S.shape[0], -1)
    grupos[usadas] = KMeans(k, n_init=5, random_state=semilla).fit_predict(coords[usadas])
    pred = np.full(d.S.shape, np.nan)
    pesos = []
    for gk in range(k):
        w = d.w.copy(); w[grupos == gk] = 0.0
        pesos.append(w)
    ths = en_paralelo(_ajuste_pesado, [(d, cfg, nivel, th, w, 250) for w in pesos], cfg)        # un bloque por núcleo
    for gk, th_g in enumerate(ths):
        te = grupos == gk
        pred[te] = (d.A @ predecir(th_g, d))[te]
    m = d.mask & (grupos >= 0)[:, None]
    y, p = (d.S * m).sum(1)[usadas], np.nansum(np.where(m, pred, 0), 1)[usadas]
    dev = lambda yy, mm: 2 * np.sum(np.where(yy > 0, yy * np.log(np.maximum(yy, 1e-300) / np.maximum(mm, 1e-300)), 0) - (yy - mm))
    return {"bloques": k, "desvio_explicado_cv": float(1 - dev(y, p) / dev(y, np.full_like(y, y.mean()))),
            "correlacion_cv": float(np.corrcoef(y, p)[0, 1]), "y": y, "pred": p, "grupos": grupos[usadas]}


def benchmark_ml(X, y, coords, n_bloques=8, semilla=1):
    """Comparación con un modelo de machine learning (gradient boosting Poisson) con la MISMA validación espacial.
    Si el ML gana por mucho, al Huff le falta alguna variable; si empatan, el Huff (interpretable) es suficiente."""
    from sklearn.cluster import KMeans
    from sklearn.ensemble import HistGradientBoostingRegressor
    from sklearn.model_selection import GroupKFold
    from sklearn.inspection import permutation_importance
    grupos = KMeans(n_bloques, n_init=5, random_state=semilla).fit_predict(coords)
    pred = np.zeros(len(y))
    for tr, te in GroupKFold(n_bloques).split(X, y, grupos):
        m = HistGradientBoostingRegressor(loss="poisson", max_iter=300, learning_rate=0.05, random_state=semilla).fit(X.iloc[tr], y[tr])
        pred[te] = m.predict(X.iloc[te])
    m = HistGradientBoostingRegressor(loss="poisson", max_iter=300, learning_rate=0.05, random_state=semilla).fit(X, y)
    imp = permutation_importance(m, X, y, n_repeats=3, random_state=semilla)
    dev = lambda yy, mm: 2 * np.sum(np.where(yy > 0, yy * np.log(np.maximum(yy, 1e-300) / np.maximum(mm, 1e-300)), 0) - (yy - mm))
    return {"desvio_explicado_cv": float(1 - dev(y, pred) / dev(y, np.full_like(y, y.mean()))), "pred": pred,
            "importancia": pd.DataFrame({"variable": X.columns, "importancia": imp.importances_mean}).sort_values("importancia", ascending=False)}


def decaimiento_observado(d, nivel, ancho=2.5, max_min=40):
    """Curva empírica (solo con origen por manzana): venta observada por peso de demanda según minutos a la sede."""
    if nivel != "unidad":
        return pd.DataFrame()
    filas = []
    D = d.G.sum(1)
    for k, f in enumerate(FORMATOS):
        js = np.where(d.fmt == k)[0]
        if not len(js):
            continue
        t = d.T[:, js].ravel(); s = d.S[:d.T.shape[0], js].ravel(); Dr = np.repeat(D, len(js))
        ok = t < max_min
        g = pd.DataFrame({"b": np.floor(t[ok] / ancho), "s": s[ok], "D": Dr[ok], "t": t[ok]}).groupby("b").agg(s=("s", "sum"), D=("D", "sum"), t_medio=("t", "mean"))
        g["indice"] = (g["s"] / g["D"]) / max((g["s"] / g["D"]).iloc[0], 1e-12)
        filas.append(g.assign(formato=f).reset_index(drop=True))
    return pd.concat(filas, ignore_index=True) if filas else pd.DataFrame()


def chequeo_gradiente(th, d, cfg, nivel, eps=1e-6, semilla=0):
    """Compara el gradiente analítico con diferencias finitas centradas, en un punto un poco desplazado del óptimo
    (en el óptimo el gradiente es ~0 y el error relativo no es informativo). Devuelve el error relativo máximo,
    normalizado por la escala del gradiente: debe ser < 1e-4."""
    rng = np.random.default_rng(semilla)
    th0 = theta_inicial(d, cfg); sd = sd_prior(d, cfg, nivel)
    x = th + rng.normal(0, 0.05, len(th))
    escala = _escala(d)
    f = lambda t: logver(t, d, th0, sd)[0] / escala
    g = logver(x, d, th0, sd)[1] / escala
    num = np.array([(f(x + eps * e) - f(x - eps * e)) / (2 * eps) for e in np.eye(len(x))])
    return float(np.max(np.abs(g - num)) / max(np.max(np.abs(num)), 1e-12))


class EstadoRed:
    """Estado del modelo para un juego de parámetros θ: permite evaluar sitios nuevos y "abrirlos" sin recalcular todo.
    Abrir una sede solo suma un término al denominador de cada manzana, así que basta actualizar dos vectores (O(n))."""

    def __init__(self, th, d):
        kap, lam, a, beta, ac, pg, Dt, E, F, FT, Den, mu = _partes(th, d)
        self.kap, self.a, self.beta, self.gam = kap, a, beta, float(np.clip(th[-1], -40, 40))
        self.KD = kap * Dt                       # κ·D_i
        self.E = E.copy()                        # (n, J) atractivo descontado de cada sede
        self.sumE = E.sum(1)
        self.Den = Den.copy()
        self.sedes = list(d.sedes)

    def _En(self, T, fmt, z_new):
        Tn = _tiempos_lote(T, slice(None))
        fmt = np.broadcast_to(np.asarray(fmt), (Tn.shape[1],))
        return np.exp(np.minimum((self.a[fmt] + self.gam * z_new)[None, :] - self.beta[fmt][None, :] * Tn, 50.0))

    def evaluar(self, T, fmt, z_new=0.0, lote=None):
        """Venta bruta, canibalización y neta (mensual) de cada sitio (columnas de T) frente a la red actual.
        Por lotes de memoria acotada (`lote_columnas`)."""
        C = T.shape[1]
        bruta, canib = np.zeros(C), np.zeros(C)
        w_canib = self.KD * self.sumE / self.Den
        fmts = np.broadcast_to(np.asarray(fmt), (C,))
        paso = lote_columnas(T.shape[0], lote)
        for i in range(0, C, paso):
            En = self._En(T[:, i:i + paso], fmts[i:i + paso], z_new)
            cuota = En / (self.Den[:, None] + En)
            bruta[i:i + paso] = self.KD @ cuota
            canib[i:i + paso] = w_canib @ cuota
        return pd.DataFrame({"venta_bruta": bruta, "canibalizacion": canib, "venta_neta": bruta - canib})

    def canibalizacion_por_sede(self, t, fmt, z_new=0.0):
        En = self._En(t[:, None], fmt, z_new)[:, 0]
        return ((self.KD / self.Den)[:, None] * self.E - (self.KD / (self.Den + En))[:, None] * self.E).sum(0)

    def agregar(self, t, fmt, nombre, z_new=0.0):
        En = self._En(t[:, None], fmt, z_new)[:, 0]
        self.E = np.c_[self.E, En]; self.sumE = self.sumE + En; self.Den = self.Den + En
        self.sedes.append(nombre)


# --------------------------------------------------------------------------------------------- ARMADO DE DATOS
def capacidad_relativa(sedes, col="m2"):
    """z_j = log(capacidad_j / mediana de su formato). 0 = tamaño típico del formato (y para sedes sin dato)."""
    cap = pd.to_numeric(sedes[col], errors="coerce") if col in sedes else pd.Series(np.nan, index=sedes.index)
    med = cap.groupby(sedes["formato_modelo"]).transform("median")
    return np.nan_to_num(np.log(cap / med).values, nan=0.0, posinf=0.0, neginf=0.0)


def armar_datos(ut, sedes, T, pc, U, cfg):
    """Ensambla los datos del modelo (una fila por manzana) con los resultados de los notebooks 03, 04 y 05.
    pc = potencial de competencia por manzana (notebook 04)."""
    G = ut[[f"gasto_salud_{g}" for g in cfg["gse"]]].values.astype(float)
    gpc = ut["gasto_salud_total"].sum() / max(ut["pob"].sum(), 1)          # gasto mensual en salud por persona del área
    W = ut["trabajadores_est"].values.astype(float) * gpc if "trabajadores_est" in ut else np.zeros(len(ut))
    fmt = sedes["formato_modelo"].map({f: k for k, f in enumerate(FORMATOS)}).values.astype(int)
    z = capacidad_relativa(sedes, cfg["modelo"].get("capacidad", "m2"))
    return DatosHuff(G=G, W=W, T=T, fmt=fmt, pc=pc, A=U["A"], S=U["S"], mask=U["mask"], sedes=list(sedes["sede"]),
                     gse=list(cfg["gse"]), z=z)
