# -*- coding: utf-8 -*-
"""Análisis de la serie histórica de ventas (5 años) del cliente.

Pasos (en este orden en el notebook 02):
  1. limpiar      tabla agregada o transaccional, duplicados, negativos (notas de crédito), meses faltantes
  2. deflactar    pesos nominales -> pesos reales del último mes (IPC)
  3. panel        sede × mes, con meses faltantes explícitos
  4. atípicos     estacionalidad común + tendencia robusta + residuo MAD; quiebres de nivel; eventos informados
  5. maduración   curva de rampa estimada con las sedes que abrieron dentro de la ventana
  6. venta madura venta mensual en régimen de cada sede (la que calibra el modelo espacial)
"""
import numpy as np
import pandas as pd
from scipy.optimize import least_squares

from .utilidades import norm_txt


# --------------------------------------------------------------------------------------------- 1. LIMPIEZA
CLAVE = ["sede", "periodo", "linea", "prevision"]


def granularidad(v, granularidad_lectura=None):
    """'agregada' (≈ una fila por sede × mes × línea × previsión) o 'transaccional' (varias filas por combinación:
    una por atención, por día o por prestación). Importa para los duplicados: en una tabla agregada dos filas idénticas
    son un error de carga; en una transaccional pueden ser dos atenciones distintas del mismo valor."""
    if granularidad_lectura == "transaccional":
        return "transaccional", 1.0
    clave = [c for c in CLAVE if c in v]
    distintas = v.drop_duplicates()
    repetidas = float(distintas.duplicated(subset=clave, keep=False).mean()) if len(distintas) else 0.0
    return ("transaccional" if repetidas > 0.05 else "agregada"), repetidas


def limpiar_ventas(v, granularidad_lectura=None):
    """Duplicados según la granularidad de la tabla, notas de crédito, ceros y filas sin mes. Una tabla transaccional
    se agrega a sede × mes × línea × previsión (todo lo que sigue trabaja con sumas). Devuelve (tabla limpia, reporte)."""
    rep = []
    n0 = len(v)
    tipo, repetidas = granularidad(v, granularidad_lectura)
    filas_origen = int(v.attrs.get("filas_leidas", n0)) if granularidad_lectura == "transaccional" else n0
    rep.append({"chequeo": f"Tipo de tabla: {tipo}" + (f" ({repetidas:.0%} de las combinaciones sede × mes × línea × previsión "
                                                     "tiene varias filas)" if tipo == "transaccional" and repetidas < 1 else ""),
                "filas": filas_origen, "monto": float(v["monto"].sum())})
    dup = v.duplicated(keep="first")
    if tipo == "agregada":
        rep.append({"chequeo": "Filas duplicadas exactas (eliminadas: en una tabla agregada son errores de carga)", "filas": int(dup.sum()),
                    "monto": float(v.loc[dup, "monto"].sum())})
        v = v.loc[~dup].copy()
    else:
        rep.append({"chequeo": "Filas idénticas (se CONSERVAN: en una tabla transaccional pueden ser atenciones distintas)",
                    "filas": int(dup.sum()), "monto": float(v.loc[dup, "monto"].sum())})
    neg = v["monto"] < 0
    rep.append({"chequeo": "Montos negativos (notas de crédito; se mantienen y netean)", "filas": int(neg.sum()),
                "monto": float(v.loc[neg, "monto"].sum())})
    rep.append({"chequeo": "Montos vacíos", "filas": int(v["monto"].isna().sum()), "monto": 0.0})
    rep.append({"chequeo": "Montos en cero", "filas": int((v["monto"] == 0).sum()), "monto": 0.0})
    anual = v["periodo"].astype(str).str.len() == 4
    rep.append({"chequeo": "Filas con solo año (sin mes)", "filas": int(anual.sum()), "monto": float(v.loc[anual, "monto"].sum())})
    if tipo == "transaccional" and v.groupby([c for c in CLAVE if c in v], sort=False).size().max() > 1:
        num = [c for c in ("monto", "atenciones", "pacientes") if c in v]
        claves = [c for c in v.columns if c not in num + ["filas_origen"]]
        g = v.assign(filas_origen=v.get("filas_origen", 1)).groupby(claves, sort=False, dropna=False)
        v = g[num].sum(min_count=1).join(g["filas_origen"].sum()).reset_index()
        rep.append({"chequeo": "Agregada a sede × mes × línea × previsión", "filas": len(v), "monto": float(v["monto"].sum())})
    rep.append({"chequeo": "Filas finales", "filas": len(v), "monto": float(v["monto"].sum())})
    print(f"  limpieza ({tipo}): {filas_origen:,} -> {len(v):,} filas")
    out = v.reset_index(drop=True)
    out.attrs["granularidad"] = tipo
    return out, pd.DataFrame(rep)


# --------------------------------------------------------------------------------------------- 2. IPC
def serie_ipc(cfg, periodos):
    """Índice de precios mensual (base = último periodo = 1). Usa la serie del INE si se entregó (RUTAS['ipc']);
    si no, una aproximación con la inflación anual de config (marcada como supuesto)."""
    periodos = sorted(set(p for p in periodos if isinstance(p, str) and len(p) == 7))
    ruta = cfg["rutas"].get("ipc")
    if ruta:
        t = pd.read_csv(ruta)
        t.columns = [norm_txt(c) for c in t.columns]
        from .cliente import parsear_periodo
        t["periodo"] = parsear_periodo(t.iloc[:, 0])
        idx = t.set_index("periodo").iloc[:, -1].astype(float)
        fuente = "INE (archivo entregado)"
    else:
        tasas = cfg["ventas"]["ipc_anual_aprox"]
        rng = pd.period_range(min(periodos), max(periodos), freq="M")
        val, nivel = [], 1.0
        for p in rng:
            r = tasas.get(p.year, list(tasas.values())[-1])
            nivel *= (1 + r) ** (1 / 12)
            val.append(nivel)
        idx = pd.Series(val, index=[str(p) for p in rng])
        fuente = "aproximación con inflación anual (reemplazar por la serie oficial del INE)"
    base = cfg["ventas"].get("anio_base_precios") or max(periodos)
    idx = idx / idx.get(base, idx.iloc[-1])
    out = pd.DataFrame({"periodo": idx.index, "ipc": idx.values})
    out.attrs["fuente"] = fuente
    return out


def deflactar(v, ipc, ya_real=False):
    """Agrega monto_real = monto / ipc (pesos del periodo base). Filas solo con año usan el IPC promedio del año.
    `ya_real=True` (montos en UF, que ya se reajustan con la inflación): monto_real = monto."""
    m = ipc.set_index("periodo")["ipc"]
    anual = m.groupby(m.index.str[:4]).mean()
    per = v["periodo"].astype(str)
    f = per.map(m).fillna(per.str[:4].map(anual))           # vectorizado: sirve igual con millones de filas
    v = v.copy()
    v["ipc"] = 1.0 if ya_real else f.values
    v["monto_real"] = v["monto"] / v["ipc"]
    return v


# --------------------------------------------------------------------------------------------- 3. PANEL
def panel_mensual(v, col="monto_real"):
    """Panel sede × mes con todos los meses entre el primero y el último de la serie (los faltantes quedan en NaN)."""
    v = v[v["periodo"].astype(str).str.len() == 7]
    g = v.groupby(["sede", "periodo"]).agg(monto=("monto", "sum"), monto_real=("monto_real", "sum"),
                                           atenciones=("atenciones", "sum"), pacientes=("pacientes", "sum")).reset_index()
    todos = pd.period_range(g["periodo"].min(), g["periodo"].max(), freq="M").astype(str)
    filas = []
    for s, d in g.groupby("sede"):
        d = d.set_index("periodo").reindex(todos)
        d["sede"] = s
        primero = d[col].first_valid_index()
        d["antes_de_abrir"] = d.index < primero
        filas.append(d.reset_index().rename(columns={"index": "periodo"}))
    p = pd.concat(filas, ignore_index=True)
    p["faltante"] = p[col].isna() & ~p["antes_de_abrir"]
    p["mes"] = p["periodo"].str[5:7].astype(int)
    p["anio"] = p["periodo"].str[:4].astype(int)
    return p


# --------------------------------------------------------------------------------------------- 4. ATÍPICOS
def indice_estacional(panel, col="monto_real", excluir=None):
    """Índice estacional común (promedio = 1): mediana, por mes calendario, de la venta / media móvil centrada de 12 meses."""
    filas = []
    for s, d in panel.groupby("sede"):
        y = d.set_index("periodo")[col].astype(float)
        if excluir is not None:
            y = y.where(~excluir.loc[d.index].values)
        mm = y.rolling(12, center=True, min_periods=10).mean()
        filas.append(pd.DataFrame({"mes": d["mes"].values, "r": (y / mm).values}))
    r = pd.concat(filas).dropna()
    r = r[np.isfinite(r["r"]) & (r["r"] > 0)]
    ind = r.groupby("mes")["r"].median().reindex(range(1, 13)).fillna(1.0)
    return ind / ind.mean()


def _mediana(x):
    """Mediana de los valores finitos; NaN si no hay ninguno (sin la advertencia "All-NaN slice" de numpy)."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    return float(np.median(x)) if len(x) else np.nan


def detectar_atipicos(panel, cfg, eventos=None, col="monto_real"):
    """Marca meses atípicos por sede:
      * residuo robusto: log(venta desestacionalizada) − mediana móvil de 7 meses, en unidades MAD; |z| > umbral
      * quiebre de nivel: mediana de los 6 meses siguientes vs 6 anteriores difiere ≥ umbral_quiebre
      * eventos informados por el cliente (aperturas, cierres, obras, convenios)
    Devuelve el panel con columnas estacional, desest, z, atipico, quiebre, evento, motivo."""
    V = cfg["ventas"]
    p = panel.copy()
    est = indice_estacional(p, col)
    p["estacional"] = p["mes"].map(est).values
    p["desest"] = p[col] / p["estacional"]
    p["z"] = np.nan; p["atipico"] = False; p["quiebre"] = False; p["evento"] = ""; p["motivo"] = ""
    for s, d in p.groupby("sede"):
        y = np.log(d["desest"].where(d["desest"] > 0))
        tend = y.rolling(7, center=True, min_periods=3).median()
        r = y - tend
        med = _mediana(r)
        mad = 1.4826 * _mediana(np.abs(r - med))
        z = (r - med) / max(mad, 0.02) if np.isfinite(mad) else r * np.nan
        p.loc[d.index, "z"] = z.values
        at = (z.abs() > V["umbral_atipico_z"]).values
        p.loc[d.index[at], "atipico"] = True
        p.loc[d.index[at], "motivo"] = np.where(z.values[at] > 0, "pico", "caída")
        des = d["desest"].values.astype(float).copy()
        des[at | (d["evento"].values != "")] = np.nan          # los meses atípicos o con eventos no cuentan para el nivel
        validos = np.where(np.isfinite(des) & (des > 0))[0]
        primero = int(validos[0]) if len(validos) else 0
        inicio = primero + 24 if primero > 0 else 6               # sede nueva: no se buscan quiebres en sus 2 primeros años (rampa)
        umbral = np.log(1 + V["umbral_quiebre"])
        for k in range(max(6, inicio), len(des) - 6):
            a6, b6 = _mediana(des[k - 6:k]), _mediana(des[k:k + 6])
            if not (np.isfinite(a6) and np.isfinite(b6) and a6 > 0):
                continue
            ruido = 1.4826 * _mediana(np.abs(np.diff(np.log(des[max(0, k - 12):k + 12])))) / np.sqrt(2)
            salto6 = np.log(b6 / a6)
            # persistencia: el cambio se mantiene comparando años completos (12 meses antes vs 12 después)
            a12, b12 = _mediana(des[max(0, k - 12):k]), _mediana(des[k:k + 12])
            salto12 = np.log(b12 / a12) if a12 > 0 and np.isfinite(b12) else salto6
            if abs(salto6) >= max(umbral, 4 * ruido / np.sqrt(6)) and np.sign(salto12) == np.sign(salto6) and abs(salto12) >= 0.75 * umbral:
                p.loc[d.index[k], "quiebre"] = True
    # un quiebre se reporta una vez (el mes de mayor cambio de cada racha)
    for s, d in p[p["quiebre"]].groupby("sede"):
        grupos = (d.index.to_series().diff() != 1).cumsum()
        for _, gg in d.groupby(grupos.values):
            keep = gg.index[len(gg) // 2]
            p.loc[gg.index.difference([keep]), "quiebre"] = False
    if eventos is not None and len(eventos):
        for _, e in eventos.iterrows():
            if "sede" not in e or pd.isna(e.get("desde")):
                continue
            hasta = e.get("hasta") if pd.notna(e.get("hasta")) else e["desde"]
            m = (p["sede"] == e["sede"]) & (p["periodo"] >= str(e["desde"])) & (p["periodo"] <= str(hasta))
            p.loc[m, "evento"] = f"{e.get('tipo_evento', '')}: {e.get('descripcion', '')}"
    p.loc[p["faltante"], "motivo"] = "mes faltante"
    p.attrs["indice_estacional"] = {int(k): float(v) for k, v in est.items()}   # dict (no Series) para que pandas pueda copiar attrs
    return p


# --------------------------------------------------------------------------------------------- 5. MADURACIÓN
def edad_sedes(panel, sedes_cli=None):
    """Mes de apertura de cada sede: fecha_apertura del cliente si existe; si no, primer mes con venta.
    Una sede que ya vendía en el primer mes de la serie se considera abierta antes de la ventana."""
    inicio = panel["periodo"].min()
    prim = panel[panel["monto_real"] > 0].groupby("sede")["periodo"].min()
    out = pd.DataFrame({"primer_mes_venta": prim})
    out["apertura_en_ventana"] = out["primer_mes_venta"] > inicio
    if sedes_cli is not None and "fecha_apertura" in sedes_cli and "sede" in sedes_cli:
        fa = sedes_cli.dropna(subset=["sede"]).set_index("sede")["fecha_apertura"]
        fa = fa[~fa.index.duplicated()]
        fa = pd.to_datetime(fa, errors="coerce").dt.strftime("%Y-%m")
        out["fecha_apertura_cliente"] = fa.reindex(out.index)
        dentro = out["fecha_apertura_cliente"].notna() & (out["fecha_apertura_cliente"] >= inicio)
        out.loc[dentro, "primer_mes_venta"] = out.loc[dentro, "fecha_apertura_cliente"]
        out.loc[dentro, "apertura_en_ventana"] = True
    return out


def curva_maduracion(panel, edades, cfg, min_meses=24):
    """Curva de rampa común:  venta(m) = L_s · (1 − (1 − r0) · e^(−m/τ)),  m = meses desde la apertura.
    Se estima con las sedes que abrieron dentro de la ventana y tienen ≥ `min_meses` de historia (L_s propio de cada
    sede, r0 y τ comunes). Devuelve dict con r0, tau, rampa anual (años 1-3 en % del régimen) y la tabla usada."""
    abiertas = edades[edades["apertura_en_ventana"]].index
    datos = []
    for s in abiertas:
        d = panel[(panel["sede"] == s) & (panel["periodo"] >= edades.loc[s, "primer_mes_venta"])].copy()
        d = d[~d["atipico"] & ~d["faltante"] & (d["evento"] == "") & d["desest"].notna()]
        if len(d) < min_meses:
            continue
        p0 = pd.Period(edades.loc[s, "primer_mes_venta"], "M")
        d["m"] = [(pd.Period(x, "M") - p0).n + 0.5 for x in d["periodo"]]
        datos.append(d.assign(sede=s))
    defecto = cfg["ventas"]["rampa_por_defecto"]
    if not datos:
        return {"r0": None, "tau": None, "rampa_anual": defecto, "fuente": "supuesto (no hay aperturas con historia suficiente)",
                "sedes": [], "tabla": pd.DataFrame()}
    D = pd.concat(datos, ignore_index=True)
    sedes = list(D["sede"].unique())
    idx = D["sede"].map({s: k for k, s in enumerate(sedes)}).values
    y, m = D["desest"].values, D["m"].values

    def res(par):
        r0 = 1 / (1 + np.exp(-par[0])); tau = np.exp(par[1]); L = np.exp(par[2:])
        pred = L[idx] * (1 - (1 - r0) * np.exp(-m / tau))
        return (y - pred) / pred
    L0 = [np.log(D[D["sede"] == s]["desest"].tail(6).median()) for s in sedes]
    sol = least_squares(res, np.r_[0.0, np.log(8.0), L0])
    r0 = 1 / (1 + np.exp(-sol.x[0])); tau = float(np.exp(sol.x[1]))
    f = lambda mm: 1 - (1 - r0) * np.exp(-np.asarray(mm) / tau)
    rampa = [float(f(np.arange(12 * a, 12 * (a + 1)) + 0.5).mean()) for a in range(3)]
    D["L"] = np.exp(sol.x[2:])[idx]
    D["indice"] = D["desest"] / D["L"]
    D["curva"] = f(D["m"])
    return {"r0": float(r0), "tau": tau, "rampa_anual": rampa, "fuente": f"estimada con {len(sedes)} apertura(s): {', '.join(sedes)}",
            "sedes": sedes, "tabla": D[["sede", "periodo", "m", "desest", "L", "indice", "curva"]]}


def factor_rampa(meses, curva):
    """Fracción del régimen alcanzada a los `meses` desde la apertura según la curva estimada (1 si no hay curva)."""
    if curva.get("r0") is None:
        a = np.minimum(np.floor(np.asarray(meses, float) / 12).astype(int), 2)
        return np.array(curva["rampa_anual"])[a] if np.ndim(meses) else curva["rampa_anual"][int(a)]
    return 1 - (1 - curva["r0"]) * np.exp(-np.asarray(meses, float) / curva["tau"])


# --------------------------------------------------------------------------------------------- 6. VENTA MADURA
def venta_madura(panel, edades, curva, cfg, col="desest"):
    """Venta mensual en régimen de cada sede (pesos reales):
      promedio de la venta desestacionalizada de los últimos `meses_calibracion` meses, sin meses atípicos, faltantes
      ni con eventos; los meses de una sede en maduración se dividen por el factor de rampa (se llevan a régimen)."""
    V = cfg["ventas"]
    fin = panel["periodo"].max()
    ini = str(pd.Period(fin, "M") - (V["meses_calibracion"] - 1))
    filas = []
    for s, d in panel.groupby("sede"):
        dd = d[(d["periodo"] >= ini) & ~d["antes_de_abrir"]]
        ok = dd[~dd["atipico"] & ~dd["faltante"] & (dd["evento"] == "") & dd[col].notna() & (dd[col] > 0)]
        p0 = pd.Period(edades.loc[s, "primer_mes_venta"], "M") if s in edades.index else pd.Period(panel["periodo"].min(), "M")
        meses = np.array([(pd.Period(x, "M") - p0).n + 0.5 for x in ok["periodo"]])
        en_ventana = bool(edades.loc[s, "apertura_en_ventana"]) if s in edades.index else False
        fac = factor_rampa(meses, curva) if en_ventana else np.ones(len(ok))
        vm = float(np.mean(ok[col].values / fac)) if len(ok) else np.nan
        edad = (pd.Period(fin, "M") - p0).n + 1
        filas.append({"sede": s, "venta_mensual_madura": vm, "venta_mensual_observada": float(ok[col].mean()) if len(ok) else np.nan,
                      "meses_usados": len(ok), "meses_excluidos": int(len(dd) - len(ok)), "edad_meses": edad if en_ventana else None,
                      "en_maduracion": bool(en_ventana and edad < V["meses_madurez"]),
                      "ajuste_maduracion": float(vm / ok[col].mean()) if len(ok) and ok[col].mean() > 0 else np.nan,
                      "cv_mensual": float(ok[col].std() / ok[col].mean()) if len(ok) > 1 else np.nan,
                      "atenciones_mensuales": float(d.loc[ok.index, "atenciones"].mean()) if len(ok) else np.nan})
    out = pd.DataFrame(filas)
    out["ticket_promedio"] = out["venta_mensual_observada"] / out["atenciones_mensuales"]
    out.attrs["ventana"] = (ini, fin)
    return out


# --------------------------------------------------------------------------------------------- RESÚMENES
def crecimiento(panel, col="monto_real"):
    """Venta real anual por sede y de la red, variación anual y crecimiento compuesto de los últimos 3 años completos."""
    p = panel[panel["periodo"].str.len() == 7]
    n_mes = p.groupby("anio")["periodo"].nunique()
    completos = n_mes[n_mes == 12].index
    a = p[p["anio"].isin(completos)].pivot_table(index="sede", columns="anio", values=col, aggfunc="sum")
    a.loc["TOTAL RED"] = a.sum()
    var = a.pct_change(axis=1)
    out = a.copy()
    for c in var.columns[1:]:
        out[f"var_{c}"] = var[c]
    if len(completos) >= 4:
        y0, y1 = completos[-4], completos[-1]
        out["cagr_3a"] = (a[y1] / a[y0]) ** (1 / 3) - 1
    return out.reset_index()


def mix(v, col, valor="monto_real"):
    """Participación de cada categoría (línea o previsión) en la venta de cada sede y del total."""
    t = v.pivot_table(index="sede", columns=col, values=valor, aggfunc="sum", fill_value=0)
    t.loc["TOTAL RED"] = t.sum()
    return t.div(t.sum(axis=1), axis=0)


def ticket_por_linea(v):
    g = v.groupby(["sede", "linea"]).agg(monto_real=("monto_real", "sum"), atenciones=("atenciones", "sum"))
    g["ticket_real"] = g["monto_real"] / g["atenciones"].replace(0, np.nan)
    return g.reset_index()


def mix_lineas_por_formato(v, sedes):
    """Mezcla de líneas de servicio típica de cada formato (para desglosar la venta estimada de un sitio nuevo)."""
    f = v.merge(sedes[["sede", "formato_modelo"]], on="sede", how="inner")
    t = f.pivot_table(index="formato_modelo", columns="linea", values="monto_real", aggfunc="sum", fill_value=0)
    return t.div(t.sum(axis=1), axis=0)
