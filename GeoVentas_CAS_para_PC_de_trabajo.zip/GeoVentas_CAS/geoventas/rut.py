# -*- coding: utf-8 -*-
"""RUT chilenos: cualquier forma de escribirlo -> UNA forma canónica, validación y seudonimización.

FORMA CANÓNICA (la única que se seudonimiza y se cruza): cuerpo + dígito verificador, solo dígitos y K mayúscula, sin
puntos, guion, espacios ni ceros a la izquierda.

    '0190270254' · '190270254' · '19027025-4' · '19.027.025-4' · ' 19027025 - 4 ' · 190270254 (número) ·
    190270254.0 y '190270254.0' (número leído como decimal) · '1,90270254E+08' (Excel)            -> '190270254'
    '12.345.678-k' · '12345678K'                                                                  -> '12345678K'
    Columna con SOLO el cuerpo (sin dígito verificador): '19027025' · '19.027.025' · 19027025       -> '190270254'
      (aun así, un valor con guion o terminado en K trae su dígito verificador y se respeta: '19027025-4')
    Cuerpo y dígito verificador en dos columnas ('19027025' y '4')                                  -> '190270254'

Así el RUT de un paciente cruza con el RUTID de personas ('0216897560') y de empresas ('784372936') aunque cada fuente
lo escriba distinto. Si la clínica seudonimiza por su cuenta, debe aplicar sha256(SAL + forma canónica).

¿Trae o no dígito verificador? Se detecta en la columna completa (no fila a fila): si el último carácter es el dígito
verificador, más del 80% de los RUT lo cumple (los mal digitados son pocos); si la columna trae solo el cuerpo, solo
~9% "calza" por azar (1 de 11). Entre medio la columna es ambigua y se pide la decisión explícita (RUT_CON_DV).
"""
import hashlib
import os

import numpy as np
import pandas as pd

from .utilidades import en_paralelo, n_nucleos

_PESOS = np.array([4, 3, 2, 7, 6, 5, 4, 3, 2], dtype=np.int64)        # 2,3,4,5,6,7 cíclico desde la derecha (9 dígitos)

FORMATOS = {   # nombre del formato -> expresión sobre el texto original (en orden: gana el primero que calza)
    "vacío": r"\s*",
    "con puntos y guion (12.345.678-9)": r"\s*\d{1,3}(\.\d{3})+\s*-\s*[\dK]\s*",
    "con guion (12345678-9)": r"\s*\d+\s*-\s*[\dK]\s*",
    "decimal de Excel (123456789.0)": r"\s*\d+[.,]0+\s*",
    "notación científica de Excel (1,23E+08)": r"\s*\d+([.,]\d+)?E\+?\d+\s*",
    "con ceros a la izquierda (0123456789)": r"\s*0\d+[\dK]\s*",
    "solo dígitos, termina en K (12345678K)": r"\s*\d+K\s*",
    "solo dígitos (123456789)": r"\s*\d+\s*",
    "solo puntos, sin guion (12.345.678)": r"\s*\d{1,3}(\.\d{3})+\s*",
}


# --------------------------------------------------------------------------------------------- FORMA CANÓNICA
def _texto(serie):
    """Cualquier columna (texto, entero, decimal, objeto mixto de Excel) -> texto en mayúsculas, sin espacios extremos.
    Los números se escriben como enteros (190270254.0 -> '190270254'); los vacíos quedan como ''."""
    s = pd.Series(serie, copy=False)
    if pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s):
        v = pd.to_numeric(s, errors="coerce").to_numpy(dtype=float)
        ok = np.isfinite(v)
        out = np.full(len(v), "", dtype=object)
        out[ok] = np.round(v[ok]).astype(np.int64).astype(str)
        return pd.Series(out, index=s.index, dtype=object)
    t = s.astype(object).where(s.notna(), "")
    if pd.api.types.infer_dtype(t, skipna=True) not in ("string", "empty"):   # Excel mezcla números y texto en una columna
        es_num = t.map(lambda x: isinstance(x, (int, float, np.integer, np.floating)) and not isinstance(x, bool))
        if es_num.any():
            t = t.copy()
            t[es_num] = _texto(pd.to_numeric(t[es_num], errors="coerce")).values
    t = t.astype(str).str.strip().str.upper()
    return t.where(~t.isin(["NAN", "NONE", "NULL", "<NA>", "NAT"]), "")


def canonico(serie, con_dv=True, dv=None):
    """Forma canónica (cuerpo + dígito verificador) de cada RUT. '' si no se puede leer.
    con_dv=False: la columna trae solo el cuerpo y el dígito verificador se calcula. `dv`: columna aparte con el dígito."""
    t = _texto(serie)
    t = t.str.replace(r"^(\d+)[.,]0+$", r"\1", regex=True)                             # 190270254.0 / 190270254,0
    sci = t.str.fullmatch(r"\d+(?:[.,]\d+)?E\+?\d+")
    if sci.any():                                                                     # 1,90270254E+08
        v = pd.to_numeric(t[sci].str.replace(",", ".", regex=False), errors="coerce")
        t = t.copy()
        t[sci] = [f"{x:.0f}" if np.isfinite(x) else "" for x in v]
    t = t.str.replace(r"[^0-9K]", "", regex=True).str.lstrip("0")
    if dv is None and con_dv:
        return t
    cuerpo_ = t.where(t.str.fullmatch(r"\d{1,9}"), "")
    if dv is not None:                                                                # dígito verificador en otra columna
        d = pd.Series(_texto(dv).str.replace(r"[^0-9K]", "", regex=True).str[-1:].values, index=t.index)
        return (cuerpo_ + d).where((cuerpo_ != "") & (d != ""), "")
    original = _texto(serie)
    explicito = original.str.contains("-", regex=False) | original.str.endswith("K")   # trae su DV aunque la columna no
    return (cuerpo_ + pd.Series(digito_verificador(cuerpo_.values), index=t.index)).where(~explicito, t)


def digito_verificador(cuerpos):
    """Dígito verificador (módulo 11) de cada cuerpo, vectorizado. '' si el cuerpo no es un número de 1 a 9 dígitos."""
    s = pd.Series(np.asarray(cuerpos, dtype=object)).astype(str)
    ok = s.str.fullmatch(r"\d{1,9}").to_numpy(dtype=bool)
    if not len(s):
        return np.array([], dtype=object)
    c9 = s.where(ok, "0").str.zfill(9)
    d = (np.frombuffer("".join(c9).encode("ascii"), dtype=np.uint8).reshape(-1, 9).astype(np.int64) - 48)
    r = 11 - (d @ _PESOS) % 11
    dv = np.where(r == 11, "0", np.where(r == 10, "K", r.astype(str)))
    return np.where(ok, dv, "").astype(object)


def es_valido(canonicos):
    """True si el RUT canónico tiene forma válida y su dígito verificador calza (detecta mal digitados o inventados)."""
    s = pd.Series(np.asarray(canonicos, dtype=object)).astype(str)
    ok = s.str.fullmatch(r"\d{1,9}[0-9K]").to_numpy(dtype=bool)
    if not ok.any():
        return ok
    dv = digito_verificador(s.str[:-1].where(ok, "").values)
    return ok & (dv == s.str[-1].values)


def cuerpo(canonicos):
    """Número del RUT sin dígito verificador (float; NaN si no es válido). Sirve para separar personas de empresas."""
    return pd.to_numeric(pd.Series(np.asarray(canonicos, dtype=object)).astype(str).str[:-1], errors="coerce").to_numpy()


# --------------------------------------------------------------------------------------------- DIAGNÓSTICO DE UNA COLUMNA
def formatos(serie, muestra=200_000, semilla=0):
    """Cuántos RUT vienen en cada formato (sin mostrar ningún RUT). Tabla: formato, n, %."""
    s = _texto(_muestra(serie, muestra, semilla))
    tipo = pd.Series("otro (revisar)", index=s.index)
    pendiente = pd.Series(True, index=s.index)
    for nombre, rx in FORMATOS.items():
        m = pendiente & s.str.fullmatch(rx)
        tipo[m] = nombre
        pendiente &= ~m
    t = tipo.value_counts().rename_axis("formato").reset_index(name="n")
    t["%"] = (100 * t["n"] / max(len(s), 1)).round(1)
    return t


def _pct(x):
    """0.668 -> '66,8%' (formato chileno)."""
    return f"{100 * x:.1f}%".replace(".", ",")


def _muestra(serie, n, semilla):
    s = pd.Series(serie, copy=False)
    return s.sample(n, random_state=semilla) if len(s) > n else s


def detectar_dv(serie, muestra=200_000, semilla=0):
    """¿La columna trae el dígito verificador al final? Devuelve un dict:
        con_dv         True (lo trae) · False (solo el cuerpo) · None (ambiguo: hay que decidirlo explícitamente)
        pct_valido     % de RUT cuyo último carácter es un dígito verificador correcto
        pct_guion_k    % con guion o terminados en K (formas que solo existen CON dígito verificador)
        largo_mediano  largo mediano de la forma canónica (persona con DV: 9; solo cuerpo: 8)
        n              RUT no vacíos revisados
        explicacion    frase para el informe"""
    s = _texto(_muestra(serie, muestra, semilla))
    s = s[s != ""]
    n = int(len(s))
    if n == 0:
        return {"con_dv": None, "pct_valido": np.nan, "pct_guion_k": np.nan, "largo_mediano": np.nan, "n": 0,
                "explicacion": "la columna no trae RUT (está vacía)"}
    c = canonico(s, con_dv=True)
    p = float(es_valido(c.values).mean())
    gk = float((s.str.contains("-", regex=False) | s.str.endswith("K")).mean())
    largo = float(c.str.len().median())
    if p >= 0.80:
        decision, txt = True, f"trae dígito verificador ({_pct(p)} de los RUT lo cumple)"
    elif p <= 0.25 and gk <= 0.01 and largo <= 8:
        decision, txt = False, (f"trae SOLO el cuerpo, sin dígito verificador (solo {_pct(p)} 'calza' por azar y el largo "
                                f"típico es {largo:.0f} dígitos): el dígito verificador se calcula")
    else:
        decision, txt = None, (f"no se puede saber si trae dígito verificador: lo cumple el {_pct(p)} (con dígito "
                               f"verificador sería más de 80%; sin él, ~9%) · {_pct(gk)} con guion o K · largo típico {largo:.0f}")
    return {"con_dv": decision, "pct_valido": round(100 * p, 2), "pct_guion_k": round(100 * gk, 2), "largo_mediano": largo,
            "n": n, "explicacion": txt}


def preparar(serie, con_dv="auto", dv=None, nombre="RUT"):
    """Forma canónica de toda una columna, decidiendo UNA vez para la columna si trae dígito verificador.
    con_dv: "auto" | True | False. Devuelve (Serie canónica, informe). Con "auto" ambiguo lanza ValueError con la
    instrucción exacta (quien llama decide si detener el notebook o seguir con lo conocido)."""
    if dv is not None:
        return canonico(serie, dv=dv), {"con_dv": True, "explicacion": f"{nombre}: dígito verificador en una columna aparte"}
    inf = detectar_dv(serie) if con_dv == "auto" else {"con_dv": bool(con_dv), "explicacion": "fijado en config_estudio.py"}
    if inf["con_dv"] is None:
        raise ValueError(f"{nombre}: {inf['explicacion']}. Fija en config_estudio.py RUT_CON_DV = True (el último carácter es "
                         "el dígito verificador) o RUT_CON_DV = False (viene solo el número).")
    return canonico(serie, con_dv=inf["con_dv"]), inf


# --------------------------------------------------------------------------------------------- SEUDONIMIZACIÓN
def _hash_bloque(canonicos, sal):
    return [hashlib.sha256((sal + r).encode()).hexdigest() if r else "" for r in canonicos]


def seudonimizar(canonicos, sal, cfg=None):
    """sha256(sal + RUT canónico) para millones de RUT, repartido en todos los núcleos. '' -> '' (sin RUT)."""
    c = np.asarray(canonicos, dtype=object)
    if len(c) < 200_000:
        return _hash_bloque(c, sal)
    partes = np.array_split(c, n_nucleos(cfg) * 2)
    return [h for p in en_paralelo(_hash_bloque, [(p, sal) for p in partes], cfg) for h in p]


def sal_efectiva(cfg):
    """Sal para seudonimizar RUT. Prioridad: (1) la acordada con la clínica (variable de entorno GEOVENTAS_SAL_RUT o
    cfg['sal_rut']); (2) una sal secreta del proyecto, creada al azar la primera vez y guardada en trabajo/.sal_proyecto.
    Con (2) la clínica puede mandar RUT en claro: se seudonimizan al leerlos y nunca se guardan en claro.
    Con RUT_PACIENTES = "seudonimizado" la sal de la clínica es obligatoria (sin ella los RUT no cruzarían)."""
    if cfg.get("sal_rut"):
        return cfg["sal_rut"]
    if cfg.get("rut_pacientes") == "seudonimizado":
        raise ValueError("RUT_PACIENTES = 'seudonimizado' exige la sal de la clínica en la variable de entorno GEOVENTAS_SAL_RUT")
    ruta = os.path.join(cfg["carpetas"]["trabajo"], ".sal_proyecto")
    if not os.path.exists(ruta):
        with open(ruta, "w") as f:
            f.write(os.urandom(16).hex())
    return open(ruta).read().strip()
