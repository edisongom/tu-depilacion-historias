# -*- coding: utf-8 -*-
"""Unidad de análisis del estudio: la MANZANA del censo (polígono de SD06_SOCIODEMOGRAPHIC_BLOCK).

  1. Cada persona, empresa, POI, propiedad y tramo de calle se asigna a su manzana con un índice espacial (STRtree):
     primero la manzana que lo contiene; si cae en la calle (fuera de toda manzana), la más cercana dentro de una
     distancia máxima (60 m personas y calles; 300 m empresas, POIs y propiedades, que pueden ser predios grandes).
  2. Se DESCARTAN de antemano las manzanas que no aportan demanda (cada descarte queda registrado con su motivo):
       · sin población, sin trabajadores y sin POIs (vacías);
       · uso de suelo excluido (área verde, parque, plaza, cementerio, sitio eriazo…) y sin población;
       · ≥ 80% de su superficie cubierta por áreas verdes (si se entrega esa capa) y ≤ 10 habitantes.
     Lo que estaba dentro de una manzana descartada (p. ej. un kiosco en un parque) se reasigna a la manzana válida más
     cercana: nada se pierde.
  3. Se arma la tabla de manzanas útiles (una fila por manzana, columna 'ut' = ID_BLOCK) con todas las variables.

Todo el estudio (demanda, tiempos, modelo, candidatos, mapas y entregables) trabaja sobre estos polígonos.
"""
import numpy as np
import pandas as pd
import geopandas as gpd
import shapely
from scipy import sparse
from scipy.spatial import cKDTree

from . import variables as V
from .utilidades import norm_txt, norm_serie, Cronometro


# --------------------------------------------------------------------------------------------- ASIGNACIÓN ESPACIAL
class IndiceManzanas:
    """Índice espacial de polígonos (manzanas) para asignar puntos a su manzana de forma vectorizada."""

    def __init__(self, poligonos_m, ids, max_dist_m=60.0):
        self.geoms = np.asarray(poligonos_m.geometry.values)
        self.arbol = shapely.STRtree(self.geoms)
        self.ids = np.asarray(ids, dtype=object)
        self.max_dist = max_dist_m
        self.crs = poligonos_m.crs

    def posiciones(self, x, y):
        """Posición (0..n-1) de la manzana de cada punto; -1 si no hay ninguna a ≤ max_dist."""
        x = np.asarray(x, float)
        y = np.asarray(y, float)
        res = np.full(len(x), -1, np.int64)
        ok = np.where(np.isfinite(x) & np.isfinite(y))[0]
        if not len(ok):
            return res
        pts = shapely.points(x[ok], y[ok])
        ip, ig = self.arbol.query(pts, predicate="within")
        res[ok[ip]] = ig
        sin = ok[res[ok] < 0]
        if len(sin) and self.max_dist > 0:
            par = self.arbol.query_nearest(shapely.points(x[sin], y[sin]), max_distance=self.max_dist, all_matches=False)
            res[sin[par[0]]] = par[1]
        return res

    def asignar(self, gdf, max_dist_m=None):
        """Id de la manzana de cada punto (o línea: su punto medio) de un GeoDataFrame; None si no hay ninguna cerca."""
        previo = self.max_dist
        if max_dist_m is not None:
            self.max_dist = max_dist_m
        try:
            return self._asignar(gdf)
        finally:
            self.max_dist = previo

    def _asignar(self, gdf):
        g = gdf.to_crs(self.crs)
        if len(g) and not (g.geom_type == "Point").all():
            es_linea = g.geom_type.str.contains("Line").all()
            g = g.set_geometry(g.geometry.interpolate(0.5, normalized=True) if es_linea else g.geometry.representative_point())
        pos = self.posiciones(g.geometry.x.values, g.geometry.y.values)
        out = np.full(len(g), None, dtype=object)
        out[pos >= 0] = self.ids[pos[pos >= 0]]
        return out


def pct_area_verde(manzanas_m, verdes):
    """Fracción de la superficie de cada manzana cubierta por la capa de áreas verdes (vectorizado con STRtree)."""
    v = verdes.to_crs(manzanas_m.crs).explode(index_parts=False)
    v = v[v.geometry.notna() & ~v.geometry.is_empty]
    vg = np.asarray(v.geometry.make_valid().values)
    mg = np.asarray(manzanas_m.geometry.values)
    if not len(vg):
        return np.zeros(len(mg))
    im, iv = shapely.STRtree(vg).query(mg, predicate="intersects")
    inter = shapely.area(shapely.intersection(mg[im], vg[iv]))
    suma = np.bincount(im, weights=inter, minlength=len(mg))
    return np.clip(suma / np.maximum(shapely.area(mg), 1e-9), 0, 1)


# --------------------------------------------------------------------------------------------- FILTROS
def motivos_descarte(m, cfg, trabajadores, n_pois, pct_verde=None):
    """Motivo de descarte de cada manzana ('' = se conserva). Reglas en cfg['filtro_manzanas']."""
    F = cfg["filtro_manzanas"]
    C = cfg["columnas"]["censo"]
    pob = pd.to_numeric(m[C["pob"]], errors="coerce").fillna(0).values
    motivo = np.full(len(m), "", dtype=object)
    if C["uso_suelo"] in m and F.get("usos_excluir"):
        uso = norm_serie(m[C["uso_suelo"]]).values
        patron = "|".join(norm_txt(u) for u in F["usos_excluir"])
        excl = pd.Series(uso).str.contains(patron, regex=True).values & (pob <= F["pob_max_uso_excluido"])
        motivo[excl] = "uso de suelo excluido (" + pd.Series(uso)[excl].astype(str) + ")"
    if pct_verde is not None:
        verde = (pct_verde >= F["area_verde_min_pct"]) & (pob <= F["pob_max_area_verde"]) & (motivo == "")
        motivo[verde] = [f"área verde ({p:.0%} de la manzana)" for p in pct_verde[verde]]
    if F.get("descartar_vacias", True):
        vac = (pob <= 0) & (np.asarray(trabajadores) <= 0) & (np.asarray(n_pois) <= 0) & (motivo == "")
        motivo[vac] = "sin población ni actividad"
    return motivo


# --------------------------------------------------------------------------------------------- CONSTRUCCIÓN
def construir_unidades(censo, cfg, per=None, emp=None, pois=None, bbrr=None, calles=None, areas_verdes=None, cronometro=None):
    """Tabla de manzanas útiles (GeoDataFrame en CRS métrico, columna 'ut' = ID_BLOCK) y tabla de descartes.
    Devuelve (ut, descartes, per, emp): per y emp con la columna 'ut' de su manzana (para cruzar RUT después)."""
    log = cronometro or Cronometro()
    crs = cfg["estudio"]["crs_metrico"]
    C = cfg["columnas"]["censo"]
    F = cfg["filtro_manzanas"]
    m = censo.to_crs(crs).reset_index(drop=True)
    ids = m[C["id"]].astype(str).values
    if pd.Series(ids).duplicated().any():                       # ids repetidos: se hacen únicos
        ids = (pd.Series(ids) + "_" + pd.Series(ids).groupby(ids).cumcount().astype(str)).str.replace("_0$", "", regex=True).values
        log("  AVISO: había ID_BLOCK repetidos; se les agregó un sufijo _1, _2…")
    m["ut"] = ids
    idx_todas = IndiceManzanas(m, ids, F["dist_max_punto_manzana_m"])
    bases = {"per": per, "emp": emp, "pois": pois, "bbrr": bbrr, "calles": calles}
    dist = {"per": F["dist_max_punto_manzana_m"], "calles": F["dist_max_punto_manzana_m"]}
    dist_act = F.get("dist_max_actividad_m", F["dist_max_punto_manzana_m"])
    for k, b in bases.items():
        if b is not None and len(b):
            b = b.copy()
            b["ut"] = idx_todas.asignar(b, dist.get(k, dist_act))
            bases[k] = b
            log(f"  {k}: {pd.Series(b['ut']).notna().mean():.1%} asignado a una manzana")
    trab = bases["emp"].groupby("ut")["trabajadores_est"].sum().reindex(ids).fillna(0).values if bases["emp"] is not None else np.zeros(len(m))
    npois = bases["pois"].groupby("ut").size().reindex(ids).fillna(0).values if bases["pois"] is not None else np.zeros(len(m))
    pv = pct_area_verde(m, areas_verdes) if areas_verdes is not None and len(areas_verdes) else None
    motivo = motivos_descarte(m, cfg, trab, npois, pv)
    keep = motivo == ""
    descartes = pd.DataFrame({"ut": ids, "comuna": m[C["comuna"]].astype(str).values if C["comuna"] in m else "",
                              "poblacion": pd.to_numeric(m[C["pob"]], errors="coerce").fillna(0).values, "trabajadores": trab, "pois": npois,
                              "uso_suelo": m[C["uso_suelo"]].astype(str).values if C["uso_suelo"] in m else "",
                              "pct_area_verde": pv if pv is not None else np.nan, "area_m2": m.area.values, "motivo": motivo})[~keep]
    descartes = gpd.GeoDataFrame(descartes, geometry=m.geometry.values[~keep], crs=crs)
    log(f"manzanas: {len(m):,} · descartadas {int((~keep).sum()):,} ({(~keep).mean():.1%}) · quedan {int(keep.sum()):,}")
    # lo que cayó en una manzana descartada se reasigna a la manzana válida más cercana
    mk = m[keep].reset_index(drop=True)
    idx_ok = IndiceManzanas(mk, mk["ut"].values, F["dist_max_punto_manzana_m"])
    validos = set(mk["ut"])
    for k, b in bases.items():
        if b is not None and len(b):
            mal = ~pd.Series(b["ut"]).isin(validos).values & pd.Series(b["ut"]).notna().values
            if mal.any():
                b.loc[b.index[mal], "ut"] = idx_ok.asignar(b[mal], dist.get(k, dist_act))
    if bases["calles"] is not None and len(bases["calles"]):
        bases["calles"]["_largo_km"] = bases["calles"].to_crs(crs).length.values / 1000
    partes = [V.variables_censo(mk, cfg, "ut")]
    for k, f in (("per", V.variables_personas), ("emp", V.variables_empresas), ("pois", V.variables_pois),
                 ("bbrr", V.variables_bbrr), ("calles", V.variables_calles)):
        if bases[k] is not None:
            partes.append(f(bases[k], cfg, "ut"))
    tabla = V.unir_variables(partes)
    tabla = tabla.loc[tabla.index.isin(validos)]
    ut = gpd.GeoDataFrame(tabla.reindex(mk["ut"].values), geometry=mk.geometry.values, crs=crs)
    ut.index.name = "ut"
    ut = ut.reset_index()
    rp = ut.geometry.representative_point()
    ut["cx"], ut["cy"] = rp.x.values, rp.y.values
    ut["area_km2"] = ut.area.values / 1e6
    ut = _completar(ut, cfg)
    return ut, descartes, bases["per"], bases["emp"]


def _completar(ut, cfg):
    ut["densidad_hab_km2"] = (ut["pob"] / ut["area_km2"].replace(0, np.nan)).fillna(0)
    ll = gpd.GeoSeries(gpd.points_from_xy(ut["cx"], ut["cy"]), crs=cfg["estudio"]["crs_metrico"]).to_crs("EPSG:4326")
    ut["lat"], ut["lon"] = ll.y.values, ll.x.values
    for c in ("comuna", "cod_comuna", "gse_predominante", "uso_suelo"):
        if c in ut:
            ut[c] = ut[c].fillna("s/i")
    return ut


# --------------------------------------------------------------------------------------------- ENTORNO DE CADA MANZANA
def suma_entorno(ut, columnas, radio_m=600.0, lote=4000):
    """Suma de cada variable en las manzanas cuyo punto interior está a ≤ radio_m (incluida la propia).
    Sirve para describir el "barrio" de una manzana (población objetivo, trabajadores, metro cercano) sin agregarla a
    una grilla. Vectorizado con un KD-tree y matrices dispersas, por lotes para acotar la memoria."""
    xy = np.c_[ut["cx"].values, ut["cy"].values]
    arbol = cKDTree(xy)
    Vv = np.column_stack([ut[c].fillna(0).values.astype(float) if c in ut else np.zeros(len(ut)) for c in columnas])
    out = np.zeros_like(Vv)
    for i0 in range(0, len(ut), lote):
        vec = arbol.query_ball_point(xy[i0:i0 + lote], r=radio_m, workers=-1)
        largos = np.fromiter((len(v) for v in vec), np.int64, len(vec))
        cols = np.concatenate([np.asarray(v, np.int64) for v in vec]) if largos.sum() else np.zeros(0, np.int64)
        filas = np.repeat(np.arange(len(vec)), largos)
        M = sparse.csr_matrix((np.ones(len(cols)), (filas, cols)), shape=(len(vec), len(ut)))
        out[i0:i0 + lote] = M @ Vv
    return pd.DataFrame(out, columns=[f"{c}_entorno" for c in columnas], index=ut.index)


def unidad_de_manzanas(censo, ut, cfg):
    """Id de la manzana útil de cada manzana del censo (None si fue descartada)."""
    ids = censo[cfg["columnas"]["censo"]["id"]].astype(str)
    return ids.where(ids.isin(set(ut["ut"])), None).values


def asignar_a_unidades(gdf, ut, cfg):
    """Manzana útil de cada punto (orígenes con coordenadas): la que lo contiene o la más cercana a ≤ 60 m."""
    return IndiceManzanas(ut, ut["ut"].values, cfg["filtro_manzanas"]["dist_max_punto_manzana_m"]).asignar(gdf)
