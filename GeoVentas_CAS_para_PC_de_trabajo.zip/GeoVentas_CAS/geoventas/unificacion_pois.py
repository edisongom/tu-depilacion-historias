# -*- coding: utf-8 -*-
"""Unificación de los lugares de salud: levantamiento propio (PRIORIDAD) + POIs de Equifax (PI01), sin duplicados.

El mismo lugar aparece en las dos fuentes con coordenadas algo distintas (decenas o cientos de metros, por cómo se
geocodificó) y con nombres distintos pero parecidos:
    "Centro Médico Integramédica Plaza Egaña"  ≈  "INTEGRAMEDICA EGAÑA"
    "Clínica Santa María"                      ≈  "CLINICA SANTA MARIA SPA"
    "Laboratorio Bionet Providencia"           ≈  "Lab. Bionet - Providencia"
y Equifax trae además duplicados propios (el mismo lugar desde dos fuentes). Se deja UN registro por lugar: el del
levantamiento si existe; si no, el registro de Equifax más completo.

Cómo se decide, para cada par de lugares a ≤ `radio_max_m`:
  1. NOMBRE. Se normaliza (sin tildes, mayúsculas ni signos; se expanden abreviaturas: C.M., Ctro., Lab., Dr., Sta.…;
     se quitan SpA, Ltda., S.A., Inversiones). Se miden tres parecidos de 0 a 1 con trigramas de letras (tolera errores
     de tipeo y palabras en otro orden):
       · el nombre completo;
       · solo las palabras DISTINTIVAS (sin "centro", "médico", "clínica", "laboratorio", "sucursal"…);
       · contención: el nombre corto está dentro del largo ("Plaza Egaña" dentro de "Integramédica Plaza Egaña").
     Se comparan todos los alias (nombre, otros nombres y marca del levantamiento; nombre, marca y cadena de Equifax) y
     vale el par de alias que mejor calza.
  2. DIRECCIÓN. Misma calle (parecida) y mismo número = fuerte indicio de que es el mismo lugar.
  3. TIPO. Farmacia, dental, óptica, laboratorio, centro médico, clínica… Tipos incompatibles NUNCA se unen (una farmacia
     al lado de un centro médico no es un duplicado). Tipos afines (centro médico ↔ laboratorio) exigen más.
  4. DISTANCIA. Mientras más lejos, más parecido debe ser el nombre: el mínimo sube de `nombre_min_cerca` (a ≤ cerca_m)
     a `nombre_min_lejos` (a radio_max_m). Con la misma dirección baja `bonus_misma_direccion`.
  5. CADENAS Y TOPÓNIMOS. Si lo que calza es un nombre que en el levantamiento aparece en ≥ `cadena_lugares_min` lugares
     del mismo tipo ("Cruz Verde", "Integramédica", "Dental Vitacura"), solo se une a ≤ `cadena_max_m` o con la misma
     dirección: dos sucursales de una cadena a 300 m son dos lugares.
  6. NOMBRES GENÉRICOS ("Centro Médico", "Laboratorio Clínico"): solo se unen casi en el mismo punto y con el mismo tipo.
Cada POI de Equifax se une con su MEJOR candidato del levantamiento o queda como nuevo; los nuevos se deduplican entre
sí con la misma regla. Los pares que quedaron cerca del umbral se listan para revisión manual.
"""
import difflib
import re
from dataclasses import dataclass
from functools import lru_cache

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.sparse.csgraph import connected_components
from scipy.spatial import cKDTree

from .geocodificacion import separar_direccion
from .utilidades import norm_txt, norm_serie

# --------------------------------------------------------------------------------------------- NOMBRES
_ABREVIATURAS = [(re.compile(r), t) for r, t in [
    (r"\bc\s?m\b", "centro medico"), (r"\bctro\b", "centro"), (r"\bcent\b", "centro"), (r"\bmed\b", "medico"),
    (r"\bmedic\b", "medico"), (r"\blabs?\b", "laboratorio"), (r"\bclin\b", "clinica"), (r"\bhosp\b", "hospital"),
    (r"\bdr\b", "doctor"), (r"\bdra\b", "doctora"), (r"\bsta\b", "santa"), (r"\bsto\b", "santo"), (r"\bgral\b", "general"),
    (r"\bavda?\b", "avenida"), (r"\btm\b", "toma muestras"), (r"\bfcias?\b", "farmacia"), (r"\bfarm\b", "farmacia"),
    (r"\bpolic\b", "policlinico"), (r"\bkine\b", "kinesiologia"), (r"\bodont\b", "odontologia"), (r"\bsuc\b", "sucursal"),
    (r"\bu\b", "universidad"), (r"\buniv\b", "universidad"), (r"\bint\b", "integral")]]
_LEGALES = re.compile(r"\b(s p a|spa|ltda|limitada|s a|eirl|e i r l|y cia|cia|compania|sociedad|soc|inversiones)\b")
_VACIAS = {"de", "del", "la", "las", "el", "los", "y", "e", "en", "a", "al", "por", "para", "con", "su", "sus", "n", "no", "nro",
           "num", "numero"}
GENERICAS = {
    "centro", "centros", "medico", "medica", "medicos", "medicas", "clinica", "clinicas", "clinico", "hospital", "laboratorio",
    "laboratorios", "toma", "tomas", "muestras", "muestra", "consulta", "consultas", "consultorio", "salud", "sucursal", "sede",
    "servicio", "servicios", "atencion", "integral", "policlinico", "especialidades", "especialidad", "dental", "dentales",
    "odontologia", "odontologica", "odontologico", "farmacia", "farmacias", "kinesiologia", "rehabilitacion", "optica", "opticas",
    "red", "grupo", "institucion", "instituto", "unidad", "doctor", "doctora", "examenes", "imagenes", "diagnostico",
    "urgencia", "ambulatorio", "ambulatoria", "privado", "privada", "nuevo", "nueva", "medicina", "familiar", "edificio", "torre",
    "oficina", "local", "piso", "avenida", "calle", "familiar", "cesfam", "cecosf", "sapu", "sar", "sur", "posta", "rural",
    "primaria", "comunitario", "comunitaria", "sala", "externa", "medicas", "odontologicos", "dentista", "dentistas"}


def normalizar_nombre(texto):
    """'Ctro. Médico Integramédica - Plaza Egaña SpA' -> 'centro medico integramedica plaza egana'."""
    t = norm_txt(texto)
    for rx, rep in _ABREVIATURAS:
        t = rx.sub(rep, t)
    t = _LEGALES.sub(" ", t)
    return " ".join(w for w in t.split() if w not in _VACIAS)


def distintivo(nombre_normalizado):
    """Solo las palabras que distinguen un lugar: 'centro medico integramedica plaza egana' -> 'integramedica plaza egana'."""
    return " ".join(w for w in nombre_normalizado.split() if w not in GENERICAS)


# --------------------------------------------------------------------------------------------- TIPOS
def familias(texto, reglas):
    """Tipo de cada lugar (farmacia, dental, laboratorio, clínica…) según la primera regla que calza; 'salud_otro' si ninguna."""
    t = norm_serie(texto)
    out = pd.Series("salud_otro", index=t.index, dtype=object)
    libre = pd.Series(True, index=t.index)
    for fam, rx in reglas:
        m = libre & t.str.contains(rx, regex=True)
        out[m] = fam
        libre &= ~m
    return out.values


_AFINES = {frozenset(p) for p in [("hospital", "medica"), ("medica", "laboratorio"), ("hospital", "laboratorio"), ("medica", "kine"),
                                  ("hospital", "kine"), ("medica", "dental")]}          # "Centro Médico y Dental"


def compatibilidad(fa, fb):
    """1 = mismo tipo · 0,5 = afines (o uno sin tipo conocido) · 0 = incompatibles (nunca se unen). Vectorizado."""
    k = pd.Series(np.asarray(fa, dtype=object)) + "|" + pd.Series(np.asarray(fb, dtype=object))
    valor = {}
    for clave in pd.unique(k):
        a, b = clave.split("|")
        valor[clave] = 1.0 if a == b else 0.5 if (frozenset((a, b)) in _AFINES or "salud_otro" in (a, b)) else 0.0
    return k.map(valor).to_numpy(dtype=float)


# --------------------------------------------------------------------------------------------- TRIGRAMAS
class _Vocabulario:
    def __init__(self):
        self.ids = {}

    def matriz(self, textos):
        """Matriz binaria (n × V) con los trigramas de letras de cada texto (con espacio en los bordes)."""
        filas, cols = [], []
        for i, t in enumerate(textos):
            if not t:
                continue
            s = f" {t} "
            for g in {s[k:k + 3] for k in range(len(s) - 2)}:
                filas.append(i)
                cols.append(self.ids.setdefault(g, len(self.ids)))
        return filas, cols, len(textos)

    @staticmethod
    def csr(trip, n_cols):
        filas, cols, n = trip
        return sparse.csr_matrix((np.ones(len(filas), np.float32), (filas, cols)), shape=(n, n_cols))


def _interseccion(XA, XB, ia, ib, lote=300_000):
    """Trigramas en común de cada par (fila ia de XA, fila ib de XB), por lotes para acotar la memoria."""
    out = np.zeros(len(ia), np.float32)
    for k in range(0, len(ia), lote):
        a, b = XA[ia[k:k + lote]], XB[ib[k:k + lote]]
        out[k:k + lote] = np.asarray(a.multiply(b).sum(axis=1)).ravel()
    return out


def _jaccard(XA, XB, ia, ib):
    inter = _interseccion(XA, XB, ia, ib)
    na, nb = np.asarray(XA.getnnz(axis=1))[ia], np.asarray(XB.getnnz(axis=1))[ib]
    return np.where(na + nb > 0, inter / np.maximum(na + nb - inter, 1), 0.0), inter, na, nb


# --------------------------------------------------------------------------------------------- LUGARES
@dataclass
class _Lugares:
    """Lugares de una fuente, listos para comparar: coordenadas, tipo, dirección y alias normalizados."""
    x: np.ndarray
    y: np.ndarray
    familia: np.ndarray
    calle: np.ndarray
    numero: np.ndarray
    alias: pd.DataFrame          # dueno, norm, dist, n_tokens, largo_dist, n_lugares
    tokens: np.ndarray = None    # palabras distintivas de cada lugar (todas sus variantes de nombre juntas)

    def __post_init__(self):
        if self.tokens is None:
            t = self.alias.groupby("dueno")["dist"].agg(lambda v: frozenset(w for w in " ".join(v).split() if len(w) > 1))
            self.tokens = t.reindex(range(len(self.x))).map(lambda v: v if isinstance(v, frozenset) else frozenset()).to_numpy()


def _alias(df, columnas):
    partes = []
    for c in columnas:
        if c not in df.columns:
            continue
        s = df[c].astype(object).where(df[c].notna(), "").astype(str).str.split(r"\s*/\s*|;|\|")
        partes.append(pd.DataFrame({"dueno": np.arange(len(df)), "texto": s.values}).explode("texto"))
    al = pd.concat(partes, ignore_index=True)
    al["texto"] = al["texto"].fillna("").astype(str)
    cache = {t: normalizar_nombre(t) for t in pd.unique(al["texto"])}
    al["norm"] = al["texto"].map(cache)
    al = al[al["norm"] != ""].drop_duplicates(["dueno", "norm"]).reset_index(drop=True)
    al["dist"] = al["norm"].map(distintivo)
    al["n_tokens"] = al["dist"].str.split().str.len().fillna(0).astype(int)
    al["largo_dist"] = al["dist"].str.len()
    return al.drop(columns="texto")


def _lugares(df, columnas_alias, familia, crs):
    g = df.to_crs(crs)
    dirs = [separar_direccion(v) for v in (df["direccion"] if "direccion" in df else pd.Series([None] * len(df)))]
    return _Lugares(x=g.geometry.x.to_numpy(), y=g.geometry.y.to_numpy(), familia=np.asarray(familia, dtype=object),
                    calle=np.array([d[0] or "" for d in dirs], dtype=object),
                    numero=np.array([d[1] if d[1] is not None else np.nan for d in dirs], dtype=float),
                    alias=_alias(df, columnas_alias))


def _contar_lugares(ref, otros):
    """Para cada alias: cuántos lugares DISTINTOS del levantamiento (del mismo tipo) contienen todas sus palabras
    distintivas. Un nombre en muchos lugares es de cadena ("Cruz Verde") o un topónimo ("Vitacura")."""
    indice = {}
    for d, toks, fam in zip(ref.alias["dueno"].values, ref.alias["dist"].str.split().values, ref.familia[ref.alias["dueno"].values]):
        for t in toks:
            indice.setdefault((fam, t), set()).add(d)
            indice.setdefault(("*", t), set()).add(d)
    for L in otros:
        fams = L.familia[L.alias["dueno"].values]
        n = []
        for toks, fam in zip(L.alias["dist"].str.split().values, fams):
            clave = "*" if fam == "salud_otro" else fam
            conj = [indice.get((clave, t)) for t in toks]
            n.append(0 if not conj or any(c is None for c in conj) else len(set.intersection(*conj)))
        L.alias["n_lugares"] = np.array(n, dtype=int)


# --------------------------------------------------------------------------------------------- EVALUACIÓN DE PARES
def _trigramas_txt(t):
    t = f" {t} "
    return {t[k:k + 3] for k in range(len(t) - 2)}


def _parecido_txt(a, b):
    ga, gb = _trigramas_txt(a), _trigramas_txt(b)
    return len(ga & gb) / max(len(ga | gb), 1)


@lru_cache(maxsize=200_000)
def _misma_palabra(a, b):
    """Misma palabra salvo un error de tipeo ("alemnaa" = "alemana", "palza" = "plaza", "mockeberg" = "monckeberg")."""
    return a == b or (min(len(a), len(b)) >= 4 and difflib.SequenceMatcher(None, a, b).ratio() >= 0.75)


def _partes_distintas(tok_a, tok_b):
    """Dos nombres que comparten palabras pero cada uno tiene además una parte PROPIA y distinta ("Cruz Verde Los Leones"
    vs "Cruz Verde Providencia", "Farmacia Popular El Golf" vs "Farmacia Popular La Pincoya"): son dos lugares.
    Las palabras con errores de tipeo ("Alemnaa" ≈ "Alemana") cuentan como compartidas."""
    resto_a = {x for x in tok_a if not any(_misma_palabra(x, y) for y in tok_b)}
    resto_b = {y for y in tok_b if not any(_misma_palabra(x, y) for x in tok_a)}
    if not resto_a or not resto_b:
        return False
    return _parecido_txt(" ".join(sorted(resto_a)), " ".join(sorted(resto_b))) < 0.3


def _evaluar(A, B, ia, ib, d, P, M):
    """Evalúa pares de lugares (ia de A, ib de B, a distancia d). Devuelve una fila por par con el MEJOR par de alias:
    parecido de nombre, umbral exigido, si es duplicado, el motivo y un puntaje para elegir entre candidatos."""
    pares = pd.DataFrame({"p": np.arange(len(ia)), "ia": ia, "ib": ib, "d": d})
    if not len(pares):
        return pares.assign(s=[], umbral=[], dup=[], margen=[], misma_dir=[], compat=[], motivo=[], orden=[])
    aa = A.alias.reset_index().rename(columns={"index": "ra", "dueno": "ia"})[["ra", "ia"]]
    ab = B.alias.reset_index().rename(columns={"index": "rb", "dueno": "ib"})[["rb", "ib"]]
    m = pares.merge(aa, on="ia").merge(ab, on="ib")
    ra, rb = m["ra"].to_numpy(), m["rb"].to_numpy()
    j_full, *_ = _jaccard(M["A_full"], M["B_full"], ra, rb)
    j_dist, inter_d, na_d, nb_d = _jaccard(M["A_dist"], M["B_dist"], ra, rb)
    largo_min = np.minimum(A.alias["largo_dist"].to_numpy()[ra], B.alias["largo_dist"].to_numpy()[rb])
    contencion = np.where(largo_min >= 4, inter_d / np.maximum(np.minimum(na_d, nb_d), 1), 0.0)
    contencion = np.where(contencion >= 0.85, contencion, 0.0)            # contención casi exacta (sin errores de tipeo)
    ta, tb = A.alias["n_tokens"].to_numpy()[ra], B.alias["n_tokens"].to_numpy()[rb]
    generico = (ta == 0) | (tb == 0)
    # Con palabras distintivas en ambos lados, el nombre completo solo ayuda si las distintivas también se parecen
    # ("Clínica Dental Pizarro" y "Clínica Dental Sense" comparten "clínica dental", pero no son el mismo lugar).
    s = np.where(generico, j_full, np.maximum.reduce([j_dist, 0.95 * contencion, np.minimum(j_full, j_dist + 0.25)]))
    via_contencion = ~generico & (0.95 * contencion >= s - 1e-9) & (contencion > j_dist)
    la, lb = A.alias["n_lugares"].to_numpy()[ra], B.alias["n_lugares"].to_numpy()[rb]
    n_explica = np.where(ta < tb, la, np.where(tb < ta, lb, np.maximum(la, lb)))
    cadena = ~generico & (n_explica >= P["cadena_lugares_min"])
    # atributos del par de lugares (no del alias)
    pia, pib, dd = m["ia"].to_numpy(), m["ib"].to_numpy(), m["d"].to_numpy()
    compat = compatibilidad(A.familia[pia], B.familia[pib])
    na_, nb_ = A.numero[pia], B.numero[pib]
    misma_dir = np.isfinite(na_) & (na_ == nb_)
    if misma_dir.any():
        k = np.where(misma_dir)[0]
        calles_a = pd.Series(A.calle[pia[k]]); calles_b = pd.Series(B.calle[pib[k]])
        vc = _Vocabulario()
        ta_, tb_ = vc.matriz(calles_a.tolist()), vc.matriz(calles_b.tolist())
        Xa, Xb = _Vocabulario.csr(ta_, len(vc.ids)), _Vocabulario.csr(tb_, len(vc.ids))
        jc, *_ = _jaccard(Xa, Xb, np.arange(len(k)), np.arange(len(k)))
        misma_dir[k] = (jc >= 0.75) & (calles_a.str.len().values > 0)
    avance = np.clip((dd - P["cerca_m"]) / max(P["radio_max_m"] - P["cerca_m"], 1), 0, 1)
    umbral = (P["nombre_min_cerca"] + (P["nombre_min_lejos"] - P["nombre_min_cerca"]) * avance
              - P["bonus_misma_direccion"] * misma_dir + P["castigo_tipo_afin"] * (compat == 0.5))
    umbral = np.where(generico, P["generico_nombre_min"], umbral)
    cadena_lejos = cadena & ~misma_dir & (dd > P["cadena_max_m"])
    generico_lejos = generico & ~misma_dir & (dd > P["generico_max_m"])
    afin_debil = (compat == 0.5) & (j_full < 0.5)
    pasa = (compat > 0) & (s >= umbral) & ~cadena_lejos & ~generico_lejos & ~(generico & (compat < 1)) & ~afin_debil
    # nombres con partes propias distintas (otra sucursal u otro lugar): se revisa solo en los pares que pasarían
    sucursales = np.zeros(len(m), bool)
    revisar = np.where(pasa & ~generico)[0]
    if len(revisar):
        cache = {}
        for k in revisar:
            clave = (pia[k], pib[k])
            if clave not in cache:
                cache[clave] = _partes_distintas(A.tokens[pia[k]], B.tokens[pib[k]])
            sucursales[k] = cache[clave]
    dup = pasa & ~sucursales
    motivo = np.select(
        [dup & misma_dir, dup & generico, dup & via_contencion, dup,
         compat == 0, sucursales, cadena_lejos & (s >= umbral), generico_lejos & (s >= umbral), afin_debil & (s >= umbral)],
        ["misma dirección y nombre parecido", "nombre genérico casi en el mismo punto", "un nombre contiene al otro",
         "nombre parecido a corta distancia", "tipos incompatibles", "cada nombre tiene una parte propia distinta (otra sucursal u otro lugar)",
         f"nombre de cadena o topónimo y a más de {P['cadena_max_m']:.0f} m", f"nombre genérico y a más de {P['generico_max_m']:.0f} m",
         "tipos afines pero nombre completo poco parecido"],
        "nombre poco parecido para la distancia")
    # puntaje para elegir el mejor candidato: primero el nombre (y el nombre completo como desempate), luego dirección,
    # tipo y cercanía. No se usa el margen sobre el umbral: la rebaja por misma dirección haría ganar a un vecino.
    orden = s + 0.1 * j_full + 0.03 * misma_dir + 0.03 * (compat == 1) - 0.0002 * dd
    m = m.assign(s=s, umbral=umbral, dup=dup, margen=s - umbral, misma_dir=misma_dir, compat=compat, motivo=motivo, orden=orden,
                 comparados=B.alias["norm"].to_numpy()[rb] + "  ≈  " + A.alias["norm"].to_numpy()[ra])
    return m.sort_values(["dup", "orden"], ascending=False).drop_duplicates("p").sort_values("p").reset_index(drop=True)


def _subconjunto(L, X, idx):
    """Lugares `idx` de L, renumerados 0..n-1, y las filas de sus alias en las matrices de trigramas X."""
    nuevo = np.full(len(L.x), -1)
    nuevo[idx] = np.arange(len(idx))
    duenos = L.alias["dueno"].to_numpy()
    filas = np.where(nuevo[duenos] >= 0)[0]
    al = L.alias.iloc[filas].assign(dueno=nuevo[duenos[filas]]).reset_index(drop=True)
    return (_Lugares(L.x[idx], L.y[idx], L.familia[idx], L.calle[idx], L.numero[idx], al, L.tokens[idx]),
            {k: m[filas] for k, m in X.items()})


def _pares_cercanos(xa, ya, xb, yb, radio):
    if not len(xa) or not len(xb):
        return np.zeros(0, int), np.zeros(0, int), np.zeros(0)
    vec = cKDTree(np.c_[xa, ya]).query_ball_point(np.c_[xb, yb], r=radio)
    lens = np.fromiter(map(len, vec), dtype=int, count=len(vec))
    ib = np.repeat(np.arange(len(vec)), lens)
    ia = np.fromiter((j for v in vec for j in v), dtype=int, count=int(lens.sum()))
    return ia, ib, np.hypot(xa[ia] - xb[ib], ya[ia] - yb[ib])


# --------------------------------------------------------------------------------------------- API
@dataclass
class Unificacion:
    decisiones: pd.DataFrame       # una fila por POI de salud de Equifax: qué se hizo y por qué
    revisar: pd.DataFrame          # casos cerca del umbral, para revisión manual
    resumen: pd.DataFrame          # cuántos se unieron, por qué regla, cuántos quedaron nuevos
    nuevos: pd.DataFrame           # POIs de Equifax que se agregan (uno por lugar), con cuántos registros representan
    por_levantamiento: pd.Series   # id_universo -> cuántos registros de Equifax se unieron a ese lugar


def unificar(lev, eq, cfg):
    """lev: levantamiento (GeoDataFrame; prioridad). eq: POIs de salud de Equifax (salida de pois_salud_equifax).
    Devuelve Unificacion. Ningún registro del levantamiento se elimina ni se cambia."""
    P = cfg["competencia"]["unificacion"]
    reglas = cfg["competencia"]["pois_equifax"]["familias"]
    crs = cfg["estudio"]["crs_metrico"]
    lev = lev.reset_index(drop=True)
    eq = eq.reset_index(drop=True)
    texto_lev = lev.get("categoria", pd.Series("", index=lev.index)).astype(str) + " " + lev.get("formato_FRF", "").astype(str)
    A = _lugares(lev, ["nombre", "otros_nombres", "marca"], familias(texto_lev, reglas), crs)
    B = _lugares(eq, ["nombre", "marca", "cadena"], eq["familia"].values, crs)
    _contar_lugares(A, [A, B])
    voc = _Vocabulario()
    trip = {k: voc.matriz(L.alias[c].tolist()) for k, L, c in [("A_full", A, "norm"), ("A_dist", A, "dist"),
                                                                  ("B_full", B, "norm"), ("B_dist", B, "dist")]}
    M = {k: _Vocabulario.csr(t, len(voc.ids)) for k, t in trip.items()}

    # 1) cada POI de Equifax contra el levantamiento: se queda con su mejor candidato que cumpla la regla
    ia, ib, d = _pares_cercanos(A.x, A.y, B.x, B.y, P["radio_max_m"])
    ev = _evaluar(A, B, ia, ib, d, P, M)
    mejor = ev.sort_values(["dup", "orden"], ascending=False).drop_duplicates("ib")
    unido = mejor[mejor["dup"]].set_index("ib")
    dec = pd.DataFrame({"id_poi": eq["id"].values, "nombre_equifax": eq["nombre"].values, "tipo_equifax": eq["familia"].values,
                        "categoria_equifax": eq["categoria_txt"].values})
    dec["decision"] = "nuevo"
    dec["motivo"] = f"sin lugar del levantamiento a ≤ {P['radio_max_m']:.0f} m que calce"
    i_u = unido.index.to_numpy()
    dec.loc[i_u, "decision"] = "duplicado del levantamiento"
    dec.loc[i_u, "motivo"] = unido["motivo"].values
    dec["id_universo"] = None
    dec.loc[i_u, "id_universo"] = lev["id_universo"].values[unido["ia"].values]
    dec["nombre_levantamiento"] = None
    dec.loc[i_u, "nombre_levantamiento"] = lev["nombre"].values[unido["ia"].values]
    for c_out, c_ev in (("distancia_m", "d"), ("parecido_nombre", "s"), ("parecido_minimo", "umbral")):
        dec[c_out] = np.nan
        dec.loc[i_u, c_out] = unido[c_ev].values
    dec["misma_direccion"] = False
    dec.loc[i_u, "misma_direccion"] = unido["misma_dir"].values
    dec["nombres_comparados"] = None                     # el par de nombres (o alias: otro nombre, marca) que calzó
    dec.loc[i_u, "nombres_comparados"] = unido["comparados"].values

    # casos dudosos (no unidos, pero cerca del umbral): para revisión manual
    duda = mejor[~mejor["dup"] & (mejor["compat"] > 0) & ((mejor["margen"] >= -P["margen_revision"])
                                                        | (mejor["misma_dir"] & (mejor["compat"] == 1)))]
    revisar = pd.DataFrame({"id_poi": eq["id"].values[duda["ib"].values], "nombre_equifax": eq["nombre"].values[duda["ib"].values],
                            "id_universo": lev["id_universo"].values[duda["ia"].values],
                            "nombre_levantamiento": lev["nombre"].values[duda["ia"].values],
                            "distancia_m": duda["d"].round(0).values, "parecido_nombre": duda["s"].round(2).values,
                            "parecido_minimo": duda["umbral"].round(2).values, "nombres_comparados": duda["comparados"].values,
                            "por_que_no_se_unio": np.where(duda["misma_dir"] & (duda["margen"] < -P["margen_revision"]),
                                                           "misma dirección y tipo, pero nombre distinto (¿razón social?)",
                                                           duda["motivo"].values),
                            "se_decidio": "nuevo (no se unió)"})
    # los dudosos que sí se unieron con poco margen también se listan
    justos = unido[unido["margen"] < P["margen_revision"] / 2]
    if len(justos):
        revisar = pd.concat([revisar, pd.DataFrame({
            "id_poi": eq["id"].values[justos.index.to_numpy()], "nombre_equifax": eq["nombre"].values[justos.index.to_numpy()],
            "id_universo": lev["id_universo"].values[justos["ia"].values], "nombre_levantamiento": lev["nombre"].values[justos["ia"].values],
            "distancia_m": justos["d"].round(0).values, "parecido_nombre": justos["s"].round(2).values,
            "parecido_minimo": justos["umbral"].round(2).values, "nombres_comparados": justos["comparados"].values,
            "por_que_no_se_unio": "", "se_decidio": "duplicado (justo sobre el umbral)"})],
            ignore_index=True)

    # 2) los que quedaron nuevos se deduplican entre sí (Equifax trae el mismo lugar desde varias fuentes)
    libres = np.where(dec["decision"].values == "nuevo")[0]
    grupo = np.arange(len(eq))
    if len(libres) > 1:
        sub, X = _subconjunto(B, {"full": M["B_full"], "dist": M["B_dist"]}, libres)
        Msub = {"A_full": X["full"], "A_dist": X["dist"], "B_full": X["full"], "B_dist": X["dist"]}
        pares = cKDTree(np.c_[sub.x, sub.y]).query_pairs(P["radio_max_m"], output_type="ndarray")
        if len(pares):
            i, j = pares[:, 0], pares[:, 1]
            ev2 = _evaluar(sub, sub, i, j, np.hypot(sub.x[i] - sub.x[j], sub.y[i] - sub.y[j]), P, Msub)
            e = ev2[ev2["dup"]]
            if len(e):
                G = sparse.coo_matrix((np.ones(len(e)), (e["ia"], e["ib"])), shape=(len(libres), len(libres)))
                _, comp = connected_components(G, directed=False)
                orden = pd.DataFrame({"comp": comp, "puntaje": _completitud(eq.iloc[libres]), "local": np.arange(len(libres))})
                mejor_local = orden.sort_values("puntaje", ascending=False).drop_duplicates("comp").set_index("comp")["local"]
                grupo[libres] = libres[mejor_local.reindex(comp).to_numpy()]
    rep = grupo[libres]
    internos = libres[rep != libres]
    dec.loc[internos, "decision"] = "duplicado dentro de Equifax"
    dec.loc[internos, "motivo"] = "mismo lugar que otro POI de Equifax (" + eq["nombre"].astype(str).values[rep[rep != libres]] + ")"
    dec["id_poi_representante"] = np.where(dec["decision"] == "duplicado del levantamiento", None, eq["id"].values[grupo])
    nuevos = eq.iloc[np.unique(rep)].copy() if len(libres) else eq.iloc[:0].copy()
    nuevos["n_registros_equifax"] = pd.Series(rep).value_counts().reindex(nuevos.index).fillna(1).astype(int).values

    por_lev = dec[dec["decision"] == "duplicado del levantamiento"].groupby("id_universo").size()
    resumen = (dec.groupby("decision").size().rename("POIs de Equifax").to_frame()
               .join(dec[dec["decision"] == "duplicado del levantamiento"].groupby("decision")["motivo"]
                     .agg(lambda s: " · ".join(f"{k}: {v}" for k, v in s.value_counts().items())).rename("cómo se decidió")))
    resumen.loc["Total"] = [len(dec), ""]
    return Unificacion(decisiones=dec, revisar=revisar.sort_values("parecido_nombre", ascending=False).reset_index(drop=True),
                       resumen=resumen, nuevos=nuevos, por_levantamiento=por_lev)


def _completitud(df):
    """Qué registro de Equifax representa a un grupo de duplicados: el más completo y el más reciente."""
    p = sum(df[c].notna().astype(int).values * w for c, w in (("nombre", 4), ("marca", 2), ("direccion", 2)) if c in df)
    if "actualizado" in df:
        f = pd.to_datetime(df["actualizado"], errors="coerce")
        p = p + (f.rank(pct=True).fillna(0).values if f.notna().any() else 0)
    return np.asarray(p, dtype=float)
