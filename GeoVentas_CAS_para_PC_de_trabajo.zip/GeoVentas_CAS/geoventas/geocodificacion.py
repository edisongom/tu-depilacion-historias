# -*- coding: utf-8 -*-
"""Geocodificación de direcciones con el Maestro de Calles (BC08_STREET).

Cómo funciona (igual que un geocodificador de calles clásico):
  1. Se separa la dirección en calle + número + comuna ("Av. Vitacura 5951, Vitacura").
  2. Se normaliza el nombre de la calle (sin tildes, sin "Avenida/Av./Calle/Pasaje").
  3. Se buscan los tramos de esa calle en esa comuna (COD_APD3). Si no hay coincidencia exacta, se usa la más parecida.
  4. Se elige el tramo cuyo rango de numeración (START/END izquierda o derecha) contiene el número
     y se interpola la posición a lo largo del tramo.
El resultado trae una columna `calidad` para saber cuánto confiar en cada punto.
"""
import difflib
import re

import numpy as np
import pandas as pd

from .utilidades import norm_txt

TIPOS_VIA = r"^(avenida|avda|av|calle|cl|pasaje|psje|pje|camino|cam|autopista|aut|carretera|carr|costanera|diagonal|paseo|ruta|general|gral)\s+"


def normalizar_calle(nombre):
    t = norm_txt(nombre)
    for _ in range(2):
        t = re.sub(TIPOS_VIA, "", t)
    return t.strip()


def separar_direccion(texto):
    """'Av. Vitacura 5951 / Av. Manquehue Norte 1410, Vitacura' -> ('vitacura', 5951, 'vitacura')."""
    if texto is None or (isinstance(texto, float) and np.isnan(texto)):
        return None, None, None
    partes = [p.strip() for p in re.split(r"[,]", str(texto)) if p.strip()]
    principal = re.split(r"\s/\s|;", partes[0])[0]
    comuna = norm_txt(partes[-1]) if len(partes) > 1 else None
    m = re.search(r"^(.*?)(?:\s+n[°ºo.]*)?\s*(\d{1,6})\b", principal, flags=re.I)
    if not m:
        return normalizar_calle(principal), None, comuna
    return normalizar_calle(m.group(1)), int(m.group(2)), comuna


class Geocodificador:
    """Índice de calles para geocodificar muchas direcciones rápido.

    calles: GeoDataFrame del Maestro de Calles ya renombrado (nombre, cod_comuna, ini_izq, fin_izq, ini_der, fin_der).
    comunas: tabla con 'comuna' (nombre) y 'cod_comuna' (COD_APD3) para traducir nombres a códigos."""

    def __init__(self, calles, comunas=None):
        c = calles.to_crs("EPSG:4326").reset_index(drop=True)
        self.calles = c
        nombres = c["nombre"].map(normalizar_calle)
        self.nombre = nombres.values
        self.cod = c["cod_comuna"].astype(str).str.zfill(5).values if "cod_comuna" in c else np.array([""] * len(c))
        self.indice = pd.Series(np.arange(len(c))).groupby(nombres.values).apply(list).to_dict()
        for s in ("sinonimo1", "sinonimo2"):
            if s in c:
                for i, v in zip(range(len(c)), c[s].map(normalizar_calle).values):
                    if v:
                        self.indice.setdefault(v, []).append(i)
        self.rangos = np.c_[pd.to_numeric(c.get("ini_izq"), errors="coerce"), pd.to_numeric(c.get("fin_izq"), errors="coerce"),
                            pd.to_numeric(c.get("ini_der"), errors="coerce"), pd.to_numeric(c.get("fin_der"), errors="coerce")]
        self.comuna_a_cod = {}
        if comunas is not None:
            self.comuna_a_cod = {norm_txt(n): str(k).zfill(5) for n, k in zip(comunas["comuna"], comunas["cod_comuna"])}
        self.nombres_por_cod = pd.Series(self.nombre).groupby(self.cod).apply(lambda s: sorted(set(s))).to_dict()

    def _candidatos(self, calle, cod):
        filas = self.indice.get(calle, [])
        if cod:
            en = [i for i in filas if self.cod[i] == cod]
            if en:
                return en, "exacta"
        if filas:
            return filas, "exacta (otra comuna)" if cod else "exacta"
        universo = self.nombres_por_cod.get(cod, []) if cod else list(self.indice.keys())
        parecida = difflib.get_close_matches(calle, universo, n=1, cutoff=0.82)
        if parecida:
            filas = [i for i in self.indice[parecida[0]] if not cod or self.cod[i] == cod]
            return filas, f"nombre parecido ('{parecida[0]}')"
        return [], "calle no encontrada"

    def geocodificar(self, direccion, comuna=None):
        calle, num, com = separar_direccion(direccion)
        com = norm_txt(comuna) if comuna else com
        cod = self.comuna_a_cod.get(com) if com else None
        if not calle:
            return {"lat": np.nan, "lon": np.nan, "calidad": "sin dirección"}
        filas, como = self._candidatos(calle, cod)
        if not filas:
            return {"lat": np.nan, "lon": np.nan, "calidad": como, "calle_buscada": calle, "numero": num}
        if num is None:
            g = self.calles.geometry.iloc[filas].union_all().centroid
            return {"lat": g.y, "lon": g.x, "calidad": f"{como} · sin número (centro de la calle)", "calle_buscada": calle}
        mejor, gap = None, np.inf
        for i in filas:
            for a, b in ((0, 1), (2, 3)):
                ini, fin = self.rangos[i, a], self.rangos[i, b]
                if not (np.isfinite(ini) and np.isfinite(fin)):
                    continue
                lo, hi = min(ini, fin), max(ini, fin)
                d = 0 if lo <= num <= hi else min(abs(num - lo), abs(num - hi))
                if d < gap:
                    frac = 0.5 if hi == lo else (np.clip(num, lo, hi) - ini) / (fin - ini)
                    mejor, gap = (i, float(np.clip(frac, 0, 1))), d
        if mejor is None:
            g = self.calles.geometry.iloc[filas].union_all().centroid
            return {"lat": g.y, "lon": g.x, "calidad": f"{como} · tramos sin numeración", "calle_buscada": calle, "numero": num}
        i, frac = mejor
        p = self.calles.geometry.iloc[i].interpolate(frac, normalized=True)
        cal = "interpolada en rango" if gap == 0 else ("número cercano (≤ 200)" if gap <= 200 else f"número lejano (a {gap:.0f})")
        return {"lat": p.y, "lon": p.x, "calidad": f"{como} · {cal}", "calle_buscada": calle, "numero": num,
                "calle_encontrada": self.calles["nombre"].iloc[i], "cod_comuna": self.cod[i]}

    def geocodificar_tabla(self, df, col_dir="direccion", col_comuna=None):
        res = [self.geocodificar(d, df[col_comuna].iloc[k] if col_comuna and col_comuna in df else None)
               for k, d in enumerate(df[col_dir].values)]
        return pd.concat([df.reset_index(drop=True), pd.DataFrame(res).add_prefix("geo_")], axis=1)


def comparar_coordenadas(df, lat1, lon1, lat2, lon2):
    """Distancia en metros entre dos pares de coordenadas (p. ej. geocodificada vs maestro)."""
    R = 6371000.0
    p1, p2 = np.radians(df[lat1].astype(float)), np.radians(df[lat2].astype(float))
    dl = np.radians(df[lon2].astype(float) - df[lon1].astype(float))
    dp = p2 - p1
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))
