# -*- coding: utf-8 -*-
"""Coordenadas escritas de cualquier forma → grados decimales WGS84, con controles para Chile.

Las coordenadas llegan de muchas fuentes (bases Equifax en parquet y txt, Excel de la clínica, el maestro de sedes,
el universo de competencia) y cada una las escribe a su manera. Este módulo las lee todas igual, vectorizado:

  Escritura                                   Ejemplo                       Resultado
  decimal con punto                           -33.4372                      -33.4372
  decimal con COMA (Excel en español)         -33,4372 · " -33,4372 "       -33.4372
  signo menos tipográfico                     −33.4372 · –33,4372           -33.4372
  número sin separador decimal (escalado)     -334372000 · -3,34372E+08     -33.4372 (la potencia de 10 que lo deja en rango)
  separadores de miles de Excel               -33.437.200 · -70,573,016     -33.4372 · -70.573016
  grados, minutos y segundos                  33°26'14,5"S · 33 26 14.5 S   -33.4374
  grados y minutos decimales                  33°26.24'S                    -33.4373
  signo omitido                               33.4372 (en Chile)            -33.4372
  latitud y longitud intercambiadas (fila)    lat -70.57, lon -33.39        se intercambian
  vacío, 0, texto, fuera de Chile             "", 0, "s/i", -3.34           NaN (se cuentan en el informe)

Por qué es seguro corregir escala, signo e intercambio en Chile: la latitud está entre −56,6 y −17,4 y la longitud entre
−109,6 y −66,3 (con Isla de Pascua). En escala logarítmica esos rangos no se tocan: un número cabe, a lo más, en UNA
de las dos coordenadas y con UNA sola potencia de 10. Por eso cada corrección es única (no hay que adivinar).
Los límites se pueden cambiar en PARAMETROS["estudio"]["limites_coordenadas"] (otro país o un área más chica).
"""
import re

import numpy as np
import pandas as pd

LIMITES_CHILE = {"lat": (-56.6, -17.4), "lon": (-109.6, -66.3)}
REGISTRO = {}          # último informe de lectura por base (lo muestra la tabla de calidad del notebook 01)
_MENOS = {"−": "-", "–": "-", "—": "-", "‒": "-"}
_SIMPLE = re.compile(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?")
_DMS = re.compile(r"""^\s*([NSEOW])?\s*([-+]?\d+(?:[.,]\d+)?)\s*(?:°|º|d|:|\s)?\s*(?:(\d+(?:[.,]\d+)?)\s*(?:'|′|m|:|\s)?\s*)?"""
                  r"""(?:(\d+(?:[.,]\d+)?)\s*(?:"|″|''|s)?\s*)?([NSEOW])?\s*$""", re.IGNORECASE)


def limites(cfg=None):
    """Límites válidos de latitud y longitud (config o Chile)."""
    lim = ((cfg or {}).get("estudio") or {}).get("limites_coordenadas")
    return lim or LIMITES_CHILE


# --------------------------------------------------------------------------------------------- TEXTO → NÚMERO
def a_numero(serie):
    """Coordenadas como texto o número → float (sin corregir escala ni signo; eso lo hace `normalizar`).
    Devuelve (valores, informe) con cuántos venían con coma decimal, con separadores de miles o en grados/minutos/segundos."""
    s = pd.Series(serie)
    inf = {"coma_decimal": 0, "separador_miles": 0, "gms": 0}
    if pd.api.types.is_numeric_dtype(s):
        return np.array(s, dtype=float), inf
    t = s.astype("object").where(s.notna(), None).astype(str).str.strip()
    for k, v in _MENOS.items():
        t = t.str.replace(k, v, regex=False)
    out = np.array(pd.to_numeric(t.where(t.str.fullmatch(_SIMPLE.pattern)), errors="coerce"), dtype=float)   # copia escribible
    resto = np.isnan(out) & ~t.str.lower().isin(["", "none", "nan", "nat", "-", "s/i", "sin dato", "null"]).to_numpy()
    if not resto.any():
        return out, inf
    r = t[resto].str.replace(r"\s+", " ", regex=True)
    vals = np.full(len(r), np.nan)
    # (1) un solo separador → es el decimal ("-33,4372", "-3,34E+08"); (2) varios iguales → miles de Excel; (3) ambos → el último es el decimal
    compacto = r.str.replace(" ", "", regex=False)
    n_coma, n_punto = compacto.str.count(","), compacto.str.count(r"\.")
    numerico = compacto.str.fullmatch(r"[-+]?[\d.,]+(?:[eE][-+]?\d+)?").to_numpy()
    una_coma = numerico & (n_coma == 1).to_numpy() & (n_punto == 0).to_numpy()
    miles = numerico & (((n_coma >= 2) & (n_punto == 0)) | ((n_punto >= 2) & (n_coma == 0))).to_numpy()
    ambos = numerico & ((n_coma >= 1) & (n_punto >= 1)).to_numpy()
    if una_coma.any():
        vals[una_coma] = pd.to_numeric(compacto[una_coma].str.replace(",", ".", regex=False), errors="coerce")
        inf["coma_decimal"] = int(np.isfinite(vals[una_coma]).sum())
    if miles.any():
        vals[miles] = pd.to_numeric(compacto[miles].str.replace(r"[.,]", "", regex=True), errors="coerce")
        inf["separador_miles"] = int(np.isfinite(vals[miles]).sum())
    if ambos.any():
        c = compacto[ambos]
        ultimo_coma = c.str.rfind(",") > c.str.rfind(".")
        c = pd.Series(np.where(ultimo_coma, c.str.replace(".", "", regex=False).str.replace(",", ".", regex=False),
                               c.str.replace(",", "", regex=False)), index=c.index)
        vals[ambos] = pd.to_numeric(c, errors="coerce")
        inf["separador_miles"] += int(np.isfinite(vals[ambos]).sum())
    # (4) grados, minutos y segundos (con hemisferio S/W/O → negativo)
    pend = ~np.isfinite(vals)
    if pend.any():
        m = r[pend].str.extract(_DMS.pattern, flags=re.IGNORECASE)
        g = pd.to_numeric(m[1].str.replace(",", "."), errors="coerce")
        mi = pd.to_numeric(m[2].str.replace(",", "."), errors="coerce").fillna(0)
        se = pd.to_numeric(m[3].str.replace(",", "."), errors="coerce").fillna(0)
        hem = m[0].fillna(m[4]).fillna("").str.upper()
        ok = g.notna() & (mi < 60) & (se < 60) & (m[2].notna() | hem.ne(""))
        v = (g.abs() + mi / 60 + se / 3600) * np.where((g < 0) | hem.isin(["S", "W", "O"]), -1, 1)
        idx = np.flatnonzero(pend)
        vals[idx[ok.to_numpy()]] = v[ok].to_numpy()
        inf["gms"] = int(ok.sum())
    out[resto] = vals
    return out, inf


# --------------------------------------------------------------------------------------------- ESCALA, SIGNO, INTERCAMBIO
def _en_rango(v, lo, hi, max_k=12):
    """Para cada valor, la versión que cae en [lo, hi] dividiendo por 10^k (k = 0…max_k) y/o cambiando el signo.
    Devuelve (valor ajustado o NaN, k usado, signo cambiado). La solución es única si el rango cubre menos de un orden de magnitud."""
    v = np.asarray(v, float)
    out = np.full(len(v), np.nan)
    k_us = np.full(len(v), -1, np.int8)
    giro = np.zeros(len(v), bool)
    pend = np.isfinite(v) & (v != 0)
    for k in range(max_k + 1):
        if not pend.any():
            break
        c = v / 10.0 ** k
        for signo in (1.0, -1.0):
            ok = pend & (signo * c >= lo) & (signo * c <= hi)
            out[ok], k_us[ok], giro[ok] = signo * c[ok], k, signo < 0
            pend &= ~ok
    return out, k_us, giro


def normalizar(lat, lon, lim=None):
    """Latitud y longitud (float) → coordenadas válidas para el área: corrige escala, signo omitido e intercambio por
    fila; lo que no tiene arreglo queda NaN. Devuelve (lat, lon, informe)."""
    lim = lim or LIMITES_CHILE
    (la0, la1), (lo0, lo1) = lim["lat"], lim["lon"]
    a_lat, k1, g1 = _en_rango(lat, la0, la1)
    a_lon, k2, g2 = _en_rango(lon, lo0, lo1)
    directo = np.isfinite(a_lat) & np.isfinite(a_lon)
    b_lat, k3, g3 = _en_rango(lon, la0, la1)             # ¿vienen intercambiadas?
    b_lon, k4, g4 = _en_rango(lat, lo0, lo1)
    cruzado = ~directo & np.isfinite(b_lat) & np.isfinite(b_lon)
    lat_f = np.where(directo, a_lat, np.where(cruzado, b_lat, np.nan))
    lon_f = np.where(directo, a_lon, np.where(cruzado, b_lon, np.nan))
    kx = np.where(directo, np.maximum(k1, k2), np.where(cruzado, np.maximum(k3, k4), -1))
    gx = np.where(directo, g1 | g2, np.where(cruzado, g3 | g4, False))
    vac = ~(np.isfinite(np.asarray(lat, float)) & np.isfinite(np.asarray(lon, float)))
    inf = {"registros": int(len(lat_f)), "validas": int(np.isfinite(lat_f).sum()), "escaladas": int(((kx > 0) & np.isfinite(lat_f)).sum()),
           "signo_agregado": int((gx & np.isfinite(lat_f)).sum()), "intercambiadas": int(cruzado.sum()), "vacias": int(vac.sum()),
           "fuera_de_rango": int((~vac & ~np.isfinite(lat_f)).sum())}
    return lat_f, lon_f, inf


def leer(lat, lon, cfg=None, lim=None):
    """Texto o números de latitud y longitud → (lat, lon, informe) listos para usar. Vectorizado: sirve igual para
    20 sedes o para millones de personas (se llama por bloques)."""
    la, i1 = a_numero(lat)
    lo, i2 = a_numero(lon)
    lat_f, lon_f, inf = normalizar(la, lo, lim or limites(cfg))
    for k in i1:
        inf[k] = i1[k] + i2[k]
    return lat_f, lon_f, inf


def sumar_informes(informes):
    total = {}
    for i in informes:
        for k, v in i.items():
            total[k] = total.get(k, 0) + v
    return total


def texto_informe(inf, base=""):
    """'empresas: 98.765 de 100.000 coordenadas válidas · 40.112 con coma decimal · 12 intercambiadas · 3 fuera de Chile'."""
    if not inf:
        return ""
    from .utilidades import miles
    partes = [f"{miles(inf.get('validas', 0))} de {miles(inf.get('registros', 0))} coordenadas válidas"]
    for k, t in (("coma_decimal", "con coma decimal"), ("separador_miles", "con separadores de miles"), ("gms", "en grados/minutos/segundos"),
                 ("escaladas", "sin punto decimal (se reescalaron)"), ("signo_agregado", "sin el signo menos (se agregó)"),
                 ("intercambiadas", "con latitud y longitud intercambiadas"), ("vacias", "vacías"),
                 ("fuera_de_rango", "fuera del país (se descartan)")):
        if inf.get(k):
            partes.append(f"{miles(inf[k])} {t}")
    return (f"{base}: " if base else "") + " · ".join(partes)


def puntos(df, col_lat, col_lon, cfg=None, nombre=""):
    """GeoDataFrame (EPSG:4326) a partir de un DataFrame con columnas de latitud y longitud escritas de cualquier forma.
    Reemplaza las columnas por los valores leídos y deja el informe en .attrs['coordenadas']."""
    import geopandas as gpd
    lat, lon, inf = leer(df[col_lat], df[col_lon], cfg)
    d = df.copy()
    d[col_lat], d[col_lon] = lat, lon
    g = gpd.GeoDataFrame(d, geometry=gpd.points_from_xy(lon, lat), crs="EPSG:4326")
    g.attrs["coordenadas"] = inf
    if nombre and (inf["validas"] < inf["registros"] or any(inf.get(k) for k in ("escaladas", "signo_agregado", "intercambiadas", "gms", "separador_miles"))):
        print("  " + texto_informe(inf, nombre))
    return g
