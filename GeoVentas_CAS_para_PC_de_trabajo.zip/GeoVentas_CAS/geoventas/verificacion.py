# -*- coding: utf-8 -*-
"""Chequeos automáticos. Cada notebook termina con una tabla de verificaciones ✅ / ❌ que se guarda en
trabajo/verificaciones_<fase>.csv. Si algo sale ❌, el detalle dice qué revisar."""
import os

import pandas as pd


class Chequeos:
    def __init__(self, fase):
        self.fase = fase
        self.filas = []

    def __call__(self, nombre, ok, detalle=""):
        self.filas.append({"fase": self.fase, "chequeo": nombre, "resultado": "✅" if bool(ok) else "❌", "detalle": str(detalle)})
        return bool(ok)

    def tabla(self):
        return pd.DataFrame(self.filas)

    def guardar(self, cfg):
        t = self.tabla()
        t.to_csv(os.path.join(cfg["carpetas"]["trabajo"], f"verificaciones_{self.fase}.csv"), index=False, encoding="utf-8-sig")
        n_ok = (t["resultado"] == "✅").sum()
        print(f"{self.fase}: {n_ok} de {len(t)} verificaciones OK")
        return t


def resumen_todas(cfg):
    """Une las verificaciones de todos los notebooks."""
    carp = cfg["carpetas"]["trabajo"]
    partes = [pd.read_csv(os.path.join(carp, f), encoding="utf-8-sig") for f in sorted(os.listdir(carp)) if f.startswith("verificaciones_")]
    return pd.concat(partes, ignore_index=True) if partes else pd.DataFrame()
