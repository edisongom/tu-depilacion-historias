# -*- coding: utf-8 -*-
"""Conclusiones en palabras que se ADAPTAN a los datos.

Cada regla mira uno o más indicadores de `geoventas/metricas.py` y escribe la conclusión que corresponde a SU valor:
el mismo código dice "la red crece con fuerza" o "la venta cae en términos reales", "modelo confiable" o "usar solo como
orden relativo", "canibalización baja" o "alta", según lo que muestren los datos. Si un indicador no existe (p. ej. no
hay origen de pacientes o la serie es corta), su conclusión no aparece o se reemplaza por la advertencia que
corresponde. Los umbrales están escritos en cada regla para que se puedan leer y discutir.

Cada conclusión trae: tema, tipo (fortaleza ✅ · alerta ⚠️ · oportunidad 💡 · dato ℹ️), titular, detalle con las cifras
y "qué hacer".
"""
import html
from dataclasses import dataclass

import numpy as np
import pandas as pd

from .metricas import MESES, NOMBRE_FORMATO, TEMAS, con_signo, formatear, pesos, _finito
from .utilidades import miles, pct

FORTALEZA, ALERTA, OPORTUNIDAD, DATO = "fortaleza", "alerta", "oportunidad", "dato"
ICONO = {FORTALEZA: "✅", ALERTA: "⚠️", OPORTUNIDAD: "💡", DATO: "ℹ️"}
SIMBOLO_PDF = {FORTALEZA: "✓", ALERTA: "!", OPORTUNIDAD: "→", DATO: "•"}
ETIQUETA = {FORTALEZA: "Fortaleza", ALERTA: "Alerta", OPORTUNIDAD: "Oportunidad", DATO: "Dato"}
COLOR = {FORTALEZA: "#2e7d32", ALERTA: "#c62828", OPORTUNIDAD: "#1565c0", DATO: "#607d8b"}
TITULO_TEMA = {"Ventas": "Ventas de la red", "Mercado": "Mercado y cobertura", "Entorno": "Entorno de las sedes",
               "Influencia": "Zonas de influencia modeladas (preliminares)", "Pacientes": "Pacientes y áreas de influencia",
               "Modelo": "Confiabilidad del modelo", "Plan": "Plan de expansión"}


@dataclass
class Conclusion:
    tema: str
    tipo: str
    titular: str
    detalle: str = ""
    que_hacer: str = ""

    def __post_init__(self):                       # frases que empiezan con mayúscula aunque vengan de una "lectura"
        self.detalle = (self.detalle or "").strip()
        if self.detalle:
            self.detalle = self.detalle[0].upper() + self.detalle[1:]


class _Indicadores:
    """Acceso cómodo a las métricas: I("clave") devuelve el valor (o None si no existe o no es finito)."""

    def __init__(self, metricas):
        self.m = {x.clave: x for x in metricas}

    def __call__(self, clave):
        x = self.m.get(clave)
        if x is None:
            return None
        return x.valor if isinstance(x.valor, str) or _finito(x.valor) else None

    def lectura(self, clave):
        x = self.m.get(clave)
        return x.lectura if x else ""

    def texto(self, clave):
        x = self.m.get(clave)
        return formatear(x.valor, x.formato) if x else "–"


def _n(k, singular, plural):
    """'1 mes', '3 meses'."""
    return f"{miles(k)} {singular if k == 1 else plural}"


def _frase(*partes):
    return " ".join(p.strip() for p in partes if p and p.strip())


# --------------------------------------------------------------------------------------------- REGLAS POR TEMA
def _ventas(I, C):
    n, var = I("n_meses"), I("var_real_12m")
    if n is not None and var is None:
        C.append(Conclusion("Ventas", ALERTA, f"La serie de ventas tiene {n} meses: no alcanza para medir el crecimiento anual",
                            "Con menos de 24 meses no se puede comparar un año contra el anterior, y la estacionalidad y la curva de "
                            "maduración se apoyan más en supuestos.", "Pedir a la clínica la serie completa de 5 años."))
    elif var is not None:
        if var >= 0.08:
            tipo, tit = FORTALEZA, f"La red crece con fuerza: {con_signo(var)} real en los últimos 12 meses"
        elif var >= 0.02:
            tipo, tit = FORTALEZA, f"La red crece {con_signo(var)} real en los últimos 12 meses"
        elif var > -0.02:
            tipo, tit = DATO, f"La venta está estable en términos reales ({con_signo(var)} en 12 meses)"
        else:
            tipo, tit = ALERTA, f"La venta cae {pct(-var)} real en los últimos 12 meses"
        partes = []
        rc = I("var_real_12m_red_constante")
        if rc is not None and abs(rc - var) >= 0.02:
            partes.append(f"A red constante (solo las sedes abiertas los 24 meses) la variación es {con_signo(rc)}: "
                          + ("las aperturas explican parte del crecimiento." if var > rc else "los cierres o las sedes nuevas aún chicas restan."))
        at, tk = I("var_atenciones_12m"), I("var_ticket_real_12m")
        if at is not None and tk is not None:
            fuente = (("más atenciones" if at > 0 else "menos atenciones") if abs(at) >= abs(tk)
                      else ("un ticket real más alto (precio o mezcla de prestaciones)" if tk > 0 else "un ticket real más bajo"))
            partes.append(f"Las atenciones variaron {con_signo(at)} y el ticket real {con_signo(tk)}: el cambio viene sobre todo de {fuente}.")
        if I("sede_mas_crece"):
            partes.append(f"La sede que más aporta es {I('sede_mas_crece')} ({I.lectura('sede_mas_crece')})"
                          + (f"; la que más resta, {I('sede_mas_cae')} ({I.lectura('sede_mas_cae')})." if I("sede_mas_cae") else "."))
        elif I("sede_mas_cae"):
            partes.append(f"La sede que más resta es {I('sede_mas_cae')} ({I.lectura('sede_mas_cae')}).")
        if I("cagr_3a") is not None:
            partes.append(f"En 3 años completos, el crecimiento real compuesto es {con_signo(I('cagr_3a'))} al año.")
        accion = {FORTALEZA: "Revisar la capacidad (boxes, horarios, agenda) de las sedes que más crecen antes de que se saturen.",
                  DATO: "El crecimiento tendrá que venir de zonas nuevas: el plan de expansión cuantifica dónde.",
                  ALERTA: f"Revisar con la clínica qué pasó en {I('sede_mas_cae') or 'las sedes que caen'} (convenios, competencia nueva, obras, cambios de horario)."}[tipo]
        C.append(Conclusion("Ventas", tipo, tit, " ".join(partes), accion))

    s1 = I("participacion_sede_principal")
    if s1 is not None:
        nombre, efectivas = I("sede_principal"), I("sedes_efectivas")
        txt_ef = f" Equivale a una red de {miles(efectivas, 1)} sedes de igual tamaño." if efectivas is not None else ""
        if s1 >= 0.5:
            C.append(Conclusion("Ventas", ALERTA, f"La red depende de {nombre}: {pct(s1)} de la venta",
                                "Cualquier problema en esa sede (obras, competencia, término de un convenio) pega fuerte en el total." + txt_ef,
                                "Diversificar: las ubicaciones del plan reducen esta dependencia."))
        elif (I("participacion_top3") or 0) >= 0.7:
            C.append(Conclusion("Ventas", DATO, f"Tres sedes concentran {pct(I('participacion_top3'))} de la venta (la principal, {nombre}, {pct(s1)})", txt_ef.strip()))
        else:
            C.append(Conclusion("Ventas", FORTALEZA, f"La venta está repartida entre sedes: la principal, {nombre}, tiene {pct(s1)}", txt_ef.strip()))

    amp = I("estacionalidad_amplitud")
    if amp is not None:
        alto, bajo = I("mes_alto"), I("mes_bajo")
        if amp >= 0.20:
            C.append(Conclusion("Ventas", DATO, f"Estacionalidad marcada: {alto} vende {I.lectura('mes_alto')} sobre un mes promedio y {bajo} {I.lectura('mes_bajo')}",
                                f"La diferencia entre el mes más fuerte y el más débil es {pct(amp, 0)}.",
                                "Planificar dotación, campañas y vacaciones del equipo según estos meses; comparar siempre contra el mismo mes del año anterior."))
        elif amp < 0.08:
            C.append(Conclusion("Ventas", DATO, "La venta casi no tiene estacionalidad",
                                f"El mes más fuerte ({alto}) y el más débil ({bajo}) difieren solo {pct(amp, 0)}."))
        else:
            C.append(Conclusion("Ventas", DATO, f"Estacionalidad moderada: {alto} es el mes más fuerte ({I.lectura('mes_alto')}) y {bajo} el más débil ({I.lectura('mes_bajo')})"))

    lin, prev = I("linea_principal"), I("prevision_principal")
    sl, sp = I("participacion_linea_principal"), I("participacion_prevision_principal")
    txt_lin = (f"La línea más grande es {lin} ({pct(sl)})" + (f", seguida de {I('linea_segunda')} ({I.lectura('linea_segunda')})." if I("linea_segunda") else ".")) if lin else ""
    txt_prev = (f"En previsión, {prev} ({pct(sp)})" + (f" y luego {I('prevision_segunda')} ({I.lectura('prevision_segunda')})." if I("prevision_segunda") else ".")) if prev else ""
    if prev and sp >= 0.6:
        C.append(Conclusion("Ventas", ALERTA, f"{pct(sp)} de la venta viene de pacientes {prev}", txt_lin,
                            f"Alta exposición a {prev}: un cambio en sus convenios o aranceles impacta directo en la venta. Seguir de cerca esa relación."))
    elif lin and sl >= 0.5:
        C.append(Conclusion("Ventas", ALERTA, f"{pct(sl)} de la venta viene de una sola línea: {lin}", txt_prev,
                            f"Una caída en {lin} (equipo médico, competencia, convenios) pega fuerte en el total."))
    elif lin or prev:
        C.append(Conclusion("Ventas", DATO, "Mezcla de la venta diversificada" if lin and sl < 0.35 else "Mezcla de la venta",
                            _frase(txt_lin, txt_prev)))

    r = I("brecha_productividad")
    if r is not None and r >= 1.8:
        C.append(Conclusion("Ventas", OPORTUNIDAD, f"{I('productividad_mejor')} vende {miles(r, 1)} veces más por m² que {I('productividad_peor')}",
                            f"Ambas son sedes de tipo {I.lectura('productividad_peor')}: la diferencia no se explica por el formato.",
                            f"Revisar en {I('productividad_peor')}: horarios, especialidades, convenios o una superficie mayor a la que su demanda necesita."))

    at, fal, q = I("pct_meses_atipicos"), I("meses_faltantes") or 0, I("quiebres") or 0
    if at is not None:
        if at > 0.03 or fal > 0:
            k_at = int(I.lectura("pct_meses_atipicos").split(" de ")[0] or 0)
            C.append(Conclusion("Ventas", ALERTA, f"Datos de ventas con {_n(k_at, 'mes atípico', 'meses atípicos')} y {_n(fal, 'mes', 'meses')} sin dato",
                                "No se borraron: se excluyeron del cálculo de la venta madura que calibra el modelo.",
                                "Confirmar con la clínica esos meses (notebook 02, sección 4): un error de carga se corrige; un evento real se agrega a la hoja de eventos."))
        else:
            C.append(Conclusion("Ventas", FORTALEZA, "Series de ventas consistentes",
                                f"Solo {pct(at)} de los meses es atípico y no hay meses sin dato."))
    if I("quiebre_comun"):
        C.append(Conclusion("Ventas", DATO, f"Cambio de nivel común a la red en {I('quiebre_comun')}: {I.lectura('quiebre_comun')}",
                            "Cuando muchas sedes cambian de nivel a la vez, la causa suele ser común: precios o aranceles, un cambio en el registro "
                            "de la venta o un shock externo. No afecta la venta madura si ocurrió antes de los últimos 24 meses.",
                            "Confirmar la causa con la clínica; si es un cambio de registro, conviene corregir la serie anterior."))
        if I("quiebres_propios"):
            C.append(Conclusion("Ventas", DATO, f"Además, {_n(I('quiebres_propios'), 'cambio de nivel propio', 'cambios de nivel propios')} de una sede",
                                I.lectura("quiebres_propios") + ".",
                                "Conversar su causa con la clínica (convenios, obras, aperturas cercanas) y registrarlos como eventos."))
    elif q:
        C.append(Conclusion("Ventas", DATO, f"{_n(q, 'cambio de nivel', 'cambios de nivel')} en la serie", I.lectura("quiebres") + ".",
                            "Conversar su causa con la clínica (convenios, obras, aperturas cercanas) y, si corresponde, registrarlos como eventos."))
    if I("sedes_en_maduracion"):
        C.append(Conclusion("Ventas", DATO, f"{_n(I('sedes_en_maduracion'), 'sede aún en maduración', 'sedes aún en maduración')}: {I.lectura('sedes_en_maduracion')}",
                            "Su venta se llevó a régimen con la curva de maduración antes de calibrar el modelo."))


def _mercado(I, C):
    cuota, cuota_obj = I("cuota_gasto_salud"), I("cuota_gasto_objetivo")
    if cuota is not None:
        if cuota > 0.6 or cuota < 0.001:
            C.append(Conclusion("Mercado", ALERTA, f"La venta de la red equivale al {pct(cuota)} del gasto en salud del área: cifra fuera de rango",
                                "Lo normal para una red privada es entre 0,1% y 60%. Una cifra así suele ser un problema de unidades.",
                                "Revisar la unidad de los montos (UNIDAD_MONTO en config_estudio.py) y la del gasto del censo (PARAMETROS['censo']['unidad_gasto'])."))
        else:
            C.append(Conclusion("Mercado", DATO, f"La venta de la red equivale al {pct(cuota)} del gasto en salud del área"
                                + (f" ({pct(cuota_obj)} del gasto del segmento objetivo)" if cuota_obj is not None else ""),
                                I.lectura("cuota_gasto_salud") + "."))
    bre, cob = I("brecha_pct"), I("cobertura_objetivo_15min")
    if bre is not None:
        if bre >= 0.10:
            C.append(Conclusion("Mercado", OPORTUNIDAD, f"{miles(I('brecha_poblacion_objetivo'))} personas del segmento objetivo viven lejos de la red ({pct(bre)})",
                                f"Están en zonas con mucha demanda a más de 15 minutos en auto de un centro médico o clínica de la red, sobre todo en {I('brecha_comunas') or 'la periferia'}.",
                                "Es el primer lugar donde buscar sitios; el plan de expansión los ordena por venta neta."))
        elif bre >= 0.03:
            C.append(Conclusion("Mercado", OPORTUNIDAD, f"Hay brechas de cobertura acotadas: {pct(bre)} del segmento objetivo ({I('brecha_comunas') or ''})",
                                "Pocas zonas con mucha demanda quedan a más de 15 minutos de la red."))
        else:
            C.append(Conclusion("Mercado", FORTALEZA, f"La red ya cubre casi todo el segmento objetivo (brecha de {pct(bre)})",
                                f"{pct(cob)} del segmento vive a ≤ 15 min de un centro médico o clínica de la red." if cob is not None else "",
                                "Crecer exigirá ganar participación donde ya hay sedes (formatos de cercanía) más que cubrir zonas nuevas."))
    if I("competidores") is not None:
        d10 = I("competidores_por_10mil_objetivo")
        C.append(Conclusion("Mercado", DATO, f"{miles(I('competidores'))} competidores en el modelo"
                            + (f" ({miles(d10, 1)} por cada 10.000 personas del segmento objetivo)" if d10 is not None else ""),
                            I.lectura("competidores") + "."))


def _entorno(I, C):
    n = I("sedes_entorno")
    if n is None:
        return
    p, pmax = I("perdida_punta_mediana"), I("perdida_punta_maxima")
    if p is not None:
        det = f"A la más afectada, {I('sede_mas_congestion')}, la hora punta le quita {pct(pmax, 0)}." if I("sede_mas_congestion") else ""
        if p >= 0.25:
            C.append(Conclusion("Entorno", ALERTA, f"La hora punta le quita a las sedes {pct(p, 0)} de su público objetivo a 15 minutos (mediana)", det,
                                "Ofrecer y comunicar horarios fuera de punta (temprano, tarde, sábado) y, para sedes nuevas, preferir accesos que no "
                                "dependan de las vías más congestionadas."))
        else:
            C.append(Conclusion("Entorno", DATO, f"La hora punta le quita a las sedes {pct(p, 0)} de su público objetivo a 15 minutos (mediana)", det))
    if I("sede_mayor_alcance"):
        C.append(Conclusion("Entorno", DATO, f"El entorno más amplio es el de {I('sede_mayor_alcance')} ({I.lectura('sede_mayor_alcance')} del segmento objetivo a 15 min en punta)",
                            f"El más acotado, {I('sede_menor_alcance')} ({I.lectura('sede_menor_alcance')}). La mediana de la red es {miles(I('alcance_objetivo_mediana'))}."
                            if I("sede_menor_alcance") else ""))
    tmax, nalto = I("traslape_maximo"), I("sedes_traslape_alto")
    if tmax is not None:
        if nalto:
            C.append(Conclusion("Entorno", ALERTA, f"{_n(nalto, 'sede comparte', 'sedes comparten')} más de la mitad de su zona inmediata con otras sedes de la red",
                                f"{I.lectura('sedes_traslape_alto')}. La que más es {I('sede_mayor_traslape')}: {I.lectura('sede_mayor_traslape')}.",
                                "Coordinar la oferta entre esas sedes (especialidades, horarios) y no abrir otra sede en esas zonas."))
        else:
            C.append(Conclusion("Entorno", FORTALEZA, f"En su zona inmediata las sedes se pisan poco: el traslape máximo es {pct(tmax, 0)}",
                                f"Mediana de la red: {pct(I('traslape_mediano'), 0)} del público objetivo de la zona inmediata compartido con otra sede."))
    if I("sede_mas_competencia"):
        C.append(Conclusion("Entorno", DATO, f"{I('sede_mas_competencia')} es la sede con más competencia cerca ({I.lectura('sede_mas_competencia')} a 15 min)",
                            f"Mediana de la red: {miles(I('competidores_entorno_mediana'))} competidores a 15 min."))
    if I("tipos_entorno"):
        C.append(Conclusion("Entorno", DATO, f"Tipos de entorno de las sedes: {I('tipos_entorno')}",
                            (f"{I('sedes_con_metro')} de {n} sedes tienen estaciones de metro a 15 min." if I("sedes_con_metro") is not None else "")))
    if I("sedes_fuera_area"):
        C.append(Conclusion("Entorno", DATO, f"{_n(I('sedes_fuera_area'), 'sede del maestro queda', 'sedes del maestro quedan')} fuera del área de estudio",
                            I.lectura("sedes_fuera_area") + ".",
                            "Para analizarlas, agregar su región en PARAMETROS['estudio']['id_regiones'] y su grafo en GRAFOS_VIALES."))


def _influencia(I, C):
    if I("sedes_influencia") is None:
        return
    rango = I("t80_red_rango")
    C.append(Conclusion("Influencia", ALERTA, "Zonas preliminares: modeladas con toda la data disponible, sin RUT ni ventas de la clínica",
                        _frase("Usan supuestos de referencia (cuánto pesa la distancia, atractivo por formato, peso de los trabajadores y de cada GSE).",
                               f"Si la gente viaja más o menos de lo supuesto, el t80 de la red va de {rango}." if rango else "",
                               f"El t80 de una sede se mueve típicamente {miles(I('t80_rango_mediano'), 1)} min." if I("t80_rango_mediano") is not None else ""),
                        "Usarlas para planificar desde ya; validarlas con los RUT (el notebook 05 las compara solo) y recalibrar con las ventas (notebook 06)."))
    t, tv = I("t80_red_punta"), I("t80_red_valle")
    if t is not None:
        C.append(Conclusion("Influencia", DATO, f"La red captaría el 80% de su demanda desde hasta {miles(t, 0)} minutos en hora punta"
                            + (f" ({miles(tv, 0)} fuera de punta)" if tv is not None else ""),
                            _frase(f"En esa zona viven {miles(I('pob_objetivo_zona_red'))} personas del segmento objetivo ({I.lectura('pob_objetivo_zona_red')})."
                                   if I("pob_objetivo_zona_red") is not None else "",
                                   f"Fuera de punta la zona crece {pct(I('crecimiento_zona_valle'), 0)}." if I("crecimiento_zona_valle") is not None else "")))
    alc = {f: I(f"t80_inf_{f}") for f in NOMBRE_FORMATO}
    if any(v is not None for v in alc.values()):
        plural = {"clinica": "las clínicas", "centro_medico": "los centros médicos", "toma_muestras": "las tomas de muestras"}
        C.append(Conclusion("Influencia", DATO, "Alcance por formato: el 80% de la demanda llega desde " +
                            "; ".join(f"{miles(v, 0)} min en {plural[f]}" for f, v in alc.items() if v is not None),
                            f"La sede de mayor alcance es {I('sede_mayor_alcance_inf')} ({I.lectura('sede_mayor_alcance_inf')}); la más local, "
                            f"{I('sede_menor_alcance_inf')} ({I.lectura('sede_menor_alcance_inf')}).",
                            "Usar estos radios para no abrir sedes nuevas dentro del alcance de una actual del mismo formato."))
    pm, pmed = I("propia_minima"), I("propia_mediana")
    if pm is not None:
        if pm < 0.4:
            C.append(Conclusion("Influencia", ALERTA, f"{I('sede_menos_propia')} comparte la mayor parte de su demanda con otras sedes de su mismo formato",
                                f"{I.lectura('sede_menos_propia')[0].upper() + I.lectura('sede_menos_propia')[1:]}. En la mediana de la red, {pct(pmed, 0)} de la demanda de una sede viene de su territorio propio.",
                                "Las sedes cercanas del mismo formato compiten por el mismo público: coordinar su oferta y no sumar otra sede de ese formato en la zona."))
        else:
            C.append(Conclusion("Influencia", FORTALEZA, f"Cada sede tiene un territorio propio claro: al menos {pct(pm, 0)} de su demanda viene de él",
                                f"Mediana de la red: {pct(pmed, 0)}."))


def _pacientes(I, C):
    if I("tipo_origen") == "no se entregó":
        C.append(Conclusion("Pacientes", ALERTA, "Sin origen de los pacientes",
                            "El modelo se calibró solo con la venta total de cada sede: la caída con la distancia y los pesos por GSE vienen "
                            "casi solo de los supuestos.", "Pedir a la clínica las atenciones con RUT (o al menos la venta por comuna o zona)."))
        return
    cruce = I("cruce_rut")
    if cruce is not None:
        if cruce < 0.7:
            C.append(Conclusion("Pacientes", ALERTA, f"Solo el {pct(cruce)} de la venta se pudo ubicar con el RUT",
                                "Con menos de 70% la calibración pierde precisión y puede sesgarse hacia los pacientes que sí cruzan.",
                                "Revisar con la clínica el formato del RUT y, si viene seudonimizado, la sal usada."))
        else:
            C.append(Conclusion("Pacientes", FORTALEZA, f"El {pct(cruce)} de la venta se ubicó en el domicilio o la empresa del paciente",
                                f"{miles(I('pacientes_unicos'))} pacientes distintos" + (f", {miles(I('atenciones_por_paciente'), 1)} atenciones por paciente." if I("atenciones_por_paciente") else ".")))
    t = {f: I(f"t80_{f}") for f in NOMBRE_FORMATO}
    if any(v is not None for v in t.values()):
        plural = {"clinica": "las clínicas", "centro_medico": "los centros médicos", "toma_muestras": "las tomas de muestras"}
        partes = [f"{miles(v, 0)} min en {plural[f]}" for f, v in t.items() if v is not None]
        C.append(Conclusion("Pacientes", DATO, "Alcance: el 80% de la venta viene de manzanas a menos de " + "; ".join(partes),
                            (f"{pct(I('venta_15min'))} de la venta viene de manzanas a ≤ 15 min de su sede. " if I("venta_15min") is not None else "")
                            + (f"La sede más local es {I('sede_mas_local')} ({I.lectura('sede_mas_local')}); la que atrae de más lejos, {I('sede_mas_regional')} ({I.lectura('sede_mas_regional')})."
                               if I("sede_mas_local") else ""),
                            "Usar estos radios al buscar sitios: una toma de muestras compite en el barrio; una clínica, en media ciudad."))
    ez = I("venta_en_zona_preliminar")
    if ez is not None:
        C.append(Conclusion("Pacientes", FORTALEZA if ez >= 0.65 else DATO if ez >= 0.5 else ALERTA,
                            f"Las zonas preliminares (sin RUT) contenían el {pct(ez, 0)} de la venta real de cada sede (mediana)",
                            "Por construcción, una zona perfecta contendría el 80%. " +
                            ("Los supuestos de referencia eran razonables." if ez >= 0.65 else "Los supuestos de referencia se alejan de lo real: usar las zonas reales."),
                            "" if ez >= 0.65 else "Revisar sobre todo cuánto pesa la distancia (β) en el notebook 06."))
    ms = I("pct_multisede")
    if ms is not None:
        C.append(Conclusion("Pacientes", DATO if ms < 0.15 else ALERTA,
                            f"{pct(ms)} de los pacientes usa 2 o más sedes" + (": hay sustitución entre sedes" if ms >= 0.15 else ""),
                            "Es la canibalización observada: muestra cuánto se reparten los pacientes entre sedes cercanas.",
                            "Al abrir cerca de una sede con mucho traslape, esperar más canibalización (el modelo ya la descuenta en la venta neta)." if ms >= 0.15 else ""))
    ret = I("retencion_anual")
    if ret is not None:
        una = I("pct_una_atencion")
        C.append(Conclusion("Pacientes", FORTALEZA if ret >= 0.5 else ALERTA, f"{pct(ret, 0)} de los pacientes vuelve al año siguiente",
                            f"{pct(una, 0)} se atendió una sola vez en el periodo." if una is not None else "",
                            "" if ret >= 0.5 else "Revisar la experiencia y el seguimiento de pacientes nuevos: la mayoría no vuelve."))
    if I("afinidad_gse_max"):
        C.append(Conclusion("Pacientes", DATO, f"El GSE {I('afinidad_gse_max')} es el más afín a la red: {I.lectura('afinidad_gse_max')}",
                            f"El menos afín es {I('afinidad_gse_min')} ({I.lectura('afinidad_gse_min')})."))
    if I("comunas_50pct") is not None:
        C.append(Conclusion("Pacientes", DATO, f"La mitad de la venta con origen viene de {_n(I('comunas_50pct'), 'comuna', 'comunas')}: {I.lectura('comunas_50pct')}"))


def _modelo(I, C):
    e, cvd, conf = I("error_sede_nueva"), I("desvio_explicado_cv"), I("confianza_modelo")
    if e is None:
        return
    det = _frase(f"{I.texto('sedes_dentro_25')} de las sedes queda dentro de ±25% al predecirla como si fuera nueva.",
                 f"En zonas que el modelo no vio explica el {pct(cvd)} de la venta." if cvd is not None else "")
    if conf == "alta":
        C.append(Conclusion("Modelo", FORTALEZA, f"Modelo confiable: el error típico al predecir una sede nueva es {pct(e)}", det,
                            "Usar la venta P50 para priorizar y el P10 (conservador) para presupuestar."))
    elif conf == "media":
        C.append(Conclusion("Modelo", DATO, f"Modelo de confiabilidad media: el error típico al predecir una sede nueva es {pct(e)}", det,
                            "Usar el ranking para priorizar, decidir con el escenario P10 y validar en terreno los primeros sitios."))
    else:
        C.append(Conclusion("Modelo", ALERTA, f"Modelo de confiabilidad baja: el error típico al predecir una sede nueva es {pct(e)}", det,
                            "Usar el ranking solo como orden relativo. Antes de decidir, revisar los m² de las sedes, el origen de los pacientes y los meses atípicos."))
    sesgo = I("sesgo_sede_nueva")
    if sesgo is not None and sesgo > 0.10:
        C.append(Conclusion("Modelo", ALERTA, f"El modelo tiende a sobreestimar las aperturas ({con_signo(sesgo)} en la mediana)", "",
                            "Leer los sitios nuevos con el escenario P10 (conservador)."))
    elif sesgo is not None and sesgo < -0.10:
        C.append(Conclusion("Modelo", DATO, f"El modelo tiende a subestimar las aperturas ({con_signo(sesgo)} en la mediana)",
                            "Las cifras de los sitios nuevos son más bien conservadoras."))
    ep = I("error_sede_peor")
    if ep is not None and abs(ep) > 0.25:
        C.append(Conclusion("Modelo", DATO, f"{I('sede_peor_predicha')} se aleja del modelo ({I.lectura('sede_peor_predicha')})",
                            "Vende " + ("menos" if ep > 0 else "más") + " de lo que su ubicación, tamaño y competencia harían esperar.",
                            "Conversar con la clínica: un convenio, el estacionamiento o una especialidad estrella suelen explicar la diferencia."))
    ml = I("ventaja_huff_vs_ml")
    if ml is not None:
        if ml < -0.10:
            C.append(Conclusion("Modelo", ALERTA, f"Un modelo de machine learning explica más ({I.texto('ventaja_huff_vs_ml')} a favor del ML)",
                                I.lectura("ventaja_huff_vs_ml") + ".", "Al modelo le falta alguna variable: revisar con la clínica qué distingue a las sedes que vende más."))
        else:
            C.append(Conclusion("Modelo", FORTALEZA, "El modelo interpretable rinde igual o mejor que machine learning",
                                f"Diferencia: {I.texto('ventaja_huff_vs_ml')} ({I.lectura('ventaja_huff_vs_ml')}). Se prefiere el Huff porque explica el porqué y simula aperturas."))
    vm_ = {f: I(f"vida_media_{f}") for f in NOMBRE_FORMATO}
    if vm_.get("centro_medico") is not None:
        C.append(Conclusion("Modelo", DATO, f"La distancia pesa: el atractivo de un centro médico cae a la mitad cada {miles(vm_['centro_medico'], 0)} min de viaje",
                            ", ".join(f"{NOMBRE_FORMATO[f]}: {miles(v, 0)} min" for f, v in vm_.items() if v is not None)
                            + f". Con 5 minutos más, un centro médico pierde {I.texto('perdida_5min_centro_medico')} de su atractivo.",
                            "En los formatos chicos manda la cercanía: ubicarlos donde vive o trabaja el público, no solo en avenidas visibles."))
    fl = I("demanda_flotante")
    if fl is not None:
        if fl >= 0.25:
            C.append(Conclusion("Modelo", DATO, f"{pct(fl, 0)} de la demanda potencial viene de trabajadores", I.lectura("demanda_flotante") + ".",
                                "Centros médicos y tomas de muestras rinden más cerca de polos de oficinas y del metro."))
        elif fl < 0.10:
            C.append(Conclusion("Modelo", DATO, f"La demanda es sobre todo residencial (solo {pct(fl, 0)} viene de trabajadores)", "",
                                "Priorizar barrios con mucho público objetivo antes que zonas de oficinas."))
        else:
            C.append(Conclusion("Modelo", DATO, f"La demanda combina residentes y trabajadores ({pct(fl, 0)} viene de trabajadores)"))
    rel = {f: I(f"comp_relativa_{f}") for f in NOMBRE_FORMATO if I(f"comp_relativa_{f}") is not None}
    if rel:
        gana = [f for f, r in rel.items() if r < 1]
        pierde = [f for f, r in rel.items() if r >= 1]
        det = _frase(("Clínica Alemana atrae más en " + ", ".join(f"{NOMBRE_FORMATO[f]} ({miles(1 / rel[f], 1)} veces un competidor)" for f in gana) + ".") if gana else "",
                     ("La competencia atrae más en " + ", ".join(f"{NOMBRE_FORMATO[f]} ({miles(rel[f], 1)} veces una sede propia)" for f in pierde) + ".") if pierde else "",
                     "Comparación con un competidor de segmento premium a la misma distancia.")
        if not pierde:
            C.append(Conclusion("Modelo", FORTALEZA, "A igual distancia, Clínica Alemana atrae más que la competencia en todos sus formatos", det))
        elif not gana:
            C.append(Conclusion("Modelo", ALERTA, "A igual distancia, la competencia atrae más que Clínica Alemana en todos los formatos", det,
                                "La marca no compensa una peor ubicación: en zonas con mucha competencia, exigir mejor accesibilidad que el rival."))
        else:
            C.append(Conclusion("Modelo", DATO, "Frente a la competencia, la ventaja de Clínica Alemana depende del formato", det,
                                "En los formatos donde la competencia atrae más (" + ", ".join(NOMBRE_FORMATO[f] for f in pierde)
                                + "), la ubicación tiene que compensar: buscar sitios con menos competencia cercana."))
    g = I("efecto_tamano")
    if g is not None and g >= 0.3:
        C.append(Conclusion("Modelo", DATO, f"El tamaño importa: {I.lectura('efecto_tamano')}", "",
                            "Dimensionar cada sede nueva según el mercado de su isócrona (está en su ficha)."))


def _plan(I, C):
    n = I("n_sitios")
    if n is None:
        return
    if n == 0:
        C.append(Conclusion("Plan", ALERTA, "Ninguna ubicación supera el mínimo de venta",
                            "El mínimo es el percentil 25 de la venta de las sedes actuales de cada formato.",
                            "Bajar el umbral (PARAMETROS['expansion']['umbral_viabilidad_percentil']) o revisar los m² y el origen de los pacientes."))
        return
    neta, crec, can = I("venta_neta_plan"), I("crecimiento_plan"), I("canibalizacion_plan")
    C.append(Conclusion("Plan", OPORTUNIDAD, f"El plan de {n} ubicaciones suma {pesos(neta)} al mes en régimen"
                        + (f" ({pct(crec, 0)} de la venta actual de la red)" if crec is not None else ""),
                        _frase(f"Composición: {I.lectura('n_sitios')}.",
                               "Es venta NUEVA para la red: ya descuenta lo que las sedes nuevas le quitan a las actuales.",
                               f"Escenarios: de {pesos(I('plan_p10'))} (P10) a {pesos(I('plan_p90'))} (P90) al mes." if I("plan_p10") is not None else ""),
                        "Abrir en el orden del ranking: cada ubicación se eligió suponiendo abiertas las anteriores."))
    if can is not None:
        if can >= 0.35:
            C.append(Conclusion("Plan", ALERTA, f"Canibalización alta: {pct(can, 0)} de la venta de las sedes nuevas sale de las actuales",
                                I.lectura("canibalizacion_plan") + ".", "Priorizar las ubicaciones con menos canibalización o separarlas más de las sedes actuales."))
        elif can < 0.15:
            C.append(Conclusion("Plan", FORTALEZA, f"Canibalización baja: solo {pct(can, 0)} de la venta de las sedes nuevas sale de las actuales",
                                "Las sedes nuevas captan sobre todo demanda que hoy no llega a Clínica Alemana."))
        else:
            C.append(Conclusion("Plan", DATO, f"Canibalización moderada: {pct(can, 0)} de la venta de las sedes nuevas sale de las actuales", I.lectura("canibalizacion_plan") + "."))
    top5 = I("concentracion_top5")
    if top5 is not None and top5 >= 0.6:
        C.append(Conclusion("Plan", DATO, f"Las 5 mejores ubicaciones aportan el {pct(top5, 0)} del plan", f"La mejor: {I('mejor_sitio')} ({I.lectura('mejor_sitio')}).",
                            "Empezar por ellas y validar los resultados antes de abrir el resto."))
    elif I("mejor_sitio"):
        C.append(Conclusion("Plan", DATO, f"La ubicación con más venta nueva es {I('mejor_sitio')} ({I.lectura('mejor_sitio')})",
                            f"El valor está repartido: las 5 mejores aportan {pct(top5, 0)} del plan." if top5 is not None else ""))
    if I("comunas_plan"):
        C.append(Conclusion("Plan", DATO, f"Las comunas con más venta nueva: {I('comunas_plan')}", I.lectura("comunas_plan") + "."))
    ancho = I("ancho_escenarios")
    if ancho is not None:
        if ancho >= 2:
            C.append(Conclusion("Plan", ALERTA, f"Los escenarios de cada sitio son amplios (P90 ≈ {miles(ancho, 1)} veces el P10)",
                                "La incertidumbre viene sobre todo del atractivo propio de cada sitio, que el modelo no ve.",
                                "Decidir con el P10 y validar en terreno (visibilidad, estacionamiento, locales disponibles)."))
        else:
            C.append(Conclusion("Plan", DATO, f"Escenarios acotados: el P90 de un sitio es {miles(ancho, 1)} veces su P10",
                                "Incluyen la incertidumbre de los parámetros y el error propio de una sede nueva."))
    a1 = I("venta_anio1_plan")
    if a1 is not None:
        C.append(Conclusion("Plan", DATO, f"El primer año una sede nueva vende cerca del {I.lectura('venta_anio1_plan').split(' de ')[0]} de su régimen",
                            f"Si todo el plan abriera a la vez, el primer año sumaría {pesos(a1)}. La curva de maduración sale de las aperturas de los 5 años.",
                            "Presupuestar los primeros años con la rampa, no con la venta en régimen."))
    ca, cd = I("cobertura_antes"), I("cobertura_despues")
    if ca is not None and cd is not None and cd > ca + 0.005:
        C.append(Conclusion("Plan", OPORTUNIDAD, f"Con el plan, el segmento objetivo a ≤ 15 min de la red pasa de {pct(ca, 0)} a {pct(cd, 0)}",
                            f"{miles(I('cobertura_personas'))} personas del segmento objetivo quedan cerca de un centro médico o clínica."))
    rel = {f: I(f"relacion_formato_{f}") for f in NOMBRE_FORMATO}
    bajos = [f for f, v in rel.items() if v is not None and v < 0.5]
    if bajos:
        C.append(Conclusion("Plan", DATO, "Los sitios nuevos de " + " y ".join(NOMBRE_FORMATO[f] for f in bajos) + " venden menos que una sede actual típica",
                            " ".join(I.lectura(f"relacion_formato_{f}") for f in bajos) + ". Es esperable: las mejores zonas ya tienen sede.",
                            "Considerar formatos más livianos (menos m²) para esas ubicaciones."))
    if I("propuestos_viables") is not None:
        C.append(Conclusion("Plan", DATO, f"Sitios propuestos por la clínica: {I('propuestos_viables')} son viables", I.lectura("propuestos_viables") + "."))
    if I("macrozonas") is not None:
        C.append(Conclusion("Plan", DATO, f"{_n(I('macrozonas'), 'macrozona', 'macrozonas')} para una clínica de alta complejidad ({I.lectura('macrozonas')})",
                            "Cada macrozona es el área donde cualquier terreno logra al menos el 80% de la venta del mejor sitio: da margen para negociar."))


REGLAS = {"Ventas": _ventas, "Mercado": _mercado, "Entorno": _entorno, "Influencia": _influencia, "Pacientes": _pacientes, "Modelo": _modelo, "Plan": _plan}


# --------------------------------------------------------------------------------------------- API
def generar(metricas, temas=None):
    """Lista de Conclusion a partir de una lista de Metrica (de uno o varios temas)."""
    I = _Indicadores(metricas)
    C = []
    for t in temas or TEMAS:
        REGLAS[t](I, C)
    return C


def tabla(conclusiones):
    return pd.DataFrame([{"tema": TITULO_TEMA.get(c.tema, c.tema), "tipo": f"{ICONO[c.tipo]} {ETIQUETA[c.tipo]}", "conclusión": c.titular,
                          "detalle": c.detalle, "qué hacer": c.que_hacer} for c in conclusiones],
                        columns=["tema", "tipo", "conclusión", "detalle", "qué hacer"])


def para_pdf(conclusiones):
    """Párrafos para el informe PDF: '# Tema' y luego '✓ Titular. Detalle. Qué hacer: …'."""
    out, tema = [], None
    for c in conclusiones:
        if c.tema != tema:
            tema = c.tema
            out.append("# " + TITULO_TEMA.get(tema, tema))
        out.append(_frase(f"{SIMBOLO_PDF[c.tipo]} {c.titular}.", c.detalle, f"Qué hacer: {c.que_hacer}" if c.que_hacer else ""))
    return out


def html_conclusiones(conclusiones, titulo=None):
    """Tarjetas HTML (para mostrar en los notebooks)."""
    e = html.escape
    filas = [f"<h3 style='margin:8px 0 6px;color:#1F4E79'>{e(titulo)}</h3>"] if titulo else []
    tema = None
    for c in conclusiones:
        if c.tema != tema and not titulo:
            tema = c.tema
            filas.append(f"<h4 style='margin:12px 0 4px;color:#1F4E79'>{e(TITULO_TEMA.get(tema, tema))}</h4>")
        filas.append(f"<div style='border-left:5px solid {COLOR[c.tipo]};background:#fafafa;padding:6px 10px;margin:5px 0;font-family:Arial;font-size:13px'>"
                     f"<b>{ICONO[c.tipo]} {e(c.titular)}</b>"
                     + (f"<div style='color:#333;margin-top:2px'>{e(c.detalle)}</div>" if c.detalle else "")
                     + (f"<div style='color:#555;margin-top:2px'><i>Qué hacer:</i> {e(c.que_hacer)}</div>" if c.que_hacer else "") + "</div>")
    return "\n".join(filas)


def mostrar(conclusiones, titulo=None):
    from IPython.display import HTML, display
    display(HTML(html_conclusiones(conclusiones, titulo)))


def markdown(conclusiones):
    out, tema = [], None
    for c in conclusiones:
        if c.tema != tema:
            tema = c.tema
            out += ["", f"### {TITULO_TEMA.get(tema, tema)}", ""]
        out.append(f"- {ICONO[c.tipo]} **{c.titular}.** " + _frase(c.detalle, f"*Qué hacer:* {c.que_hacer}" if c.que_hacer else ""))
    return "\n".join(out).strip()
