# -*- coding: utf-8 -*-
"""Simulador de bases con la ESTRUCTURA EXACTA de las bases reales (mismos nombres de archivo y de columnas).

Sirve para probar todo el flujo de punta a punta antes de tener la data real y para comprobar que el modelo recupera
parámetros conocidos. Todo lo personal es ficticio (nombres "SIMULADO", RUT inventados).

Qué es real y qué es simulado:
  REAL       grafo vial de la RM (OSM), límites comunales, sedes de CAS y universo de competencia levantado
  SIMULADO   manzanas censales (sobre el tejido de calles real), personas, empresas, BBRR, POIs, Maestro de Calles
             (geometría real de OSM, numeración simulada), GTFS de 3 líneas de metro y toda la data del cliente.
La venta del cliente se genera con el mismo modelo de Huff del estudio + ruido (atractivo propio de cada sede y
sobre-dispersión por manzana), con parámetros guardados en verdad.json.
"""
import json
import os
import zipfile

import numpy as np
import pandas as pd
import geopandas as gpd
from scipy import sparse
from shapely.geometry import box

from .utilidades import Cronometro, norm_txt
from .esquemas import ESQUEMAS
from . import red as redmod, competencia as compmod, modelo, cliente, unidades as UN
from scipy.spatial import cKDTree
from .geocodificacion import separar_direccion, normalizar_calle

GSE = ["AB", "C1A", "C1B", "C2", "C3", "D", "E"]
AB_COMUNA = {"Vitacura": .58, "Lo Barnechea": .45, "Las Condes": .50, "Providencia": .42, "La Reina": .33, "Ñuñoa": .28,
             "Santiago": .10, "Peñalolén": .11, "Macul": .09, "Huechuraba": .14, "Colina": .10, "La Florida": .07,
             "San Miguel": .09, "Maipú": .05, "Recoleta": .03, "Independencia": .04, "Estación Central": .03,
             "Quilicura": .03, "Pudahuel": .03, "Puente Alto": .025, "Calera de Tango": .06, "Pirque": .08, "Buin": .03,
             "Talagante": .03, "Padre Hurtado": .04, "Lampa": .03, "San Bernardo": .025, "Cerrillos": .03, "La Cisterna": .04}
DENS_COMUNA = {"Santiago": 2.0, "Providencia": 1.8, "Ñuñoa": 1.6, "Independencia": 1.6, "Estación Central": 1.5, "San Miguel": 1.5,
               "Las Condes": 1.2, "La Cisterna": 1.3, "Recoleta": 1.3, "Macul": 1.2, "Vitacura": 0.8, "Lo Barnechea": 0.45,
               "La Reina": 0.85, "Colina": 0.35, "Lampa": 0.3, "Pirque": 0.15, "San José de Maipo": 0.08, "Tiltil": 0.1,
               "Alhué": 0.06, "Curacaví": 0.15, "María Pinto": 0.08, "San Pedro": 0.06, "Melipilla": 0.3, "Isla de Maipo": 0.2,
               "El Monte": 0.25, "Paine": 0.25, "Buin": 0.4, "Calera de Tango": 0.25, "Talagante": 0.4, "Peñaflor": 0.6,
               "Padre Hurtado": 0.5}
PROVINCIA = {"131": ("SANTIAGO", 131), "132": ("CORDILLERA", 132), "133": ("CHACABUCO", 133), "134": ("MAIPO", 134),
             "135": ("MELIPILLA", 135), "136": ("TALAGANTE", 136)}
# gasto mensual por hogar (CLP) por categoría y GSE: orden de magnitud EPF; salud es la que usa el modelo
GASTO_HOGAR = {"SAL": [520000, 300000, 200000, 130000, 85000, 55000, 35000], "ALI": [900000, 700000, 560000, 450000, 380000, 320000, 260000],
               "ALC": [90000, 60000, 45000, 35000, 28000, 22000, 15000], "VES": [250000, 160000, 110000, 75000, 50000, 35000, 22000],
               "SER": [180000, 120000, 90000, 60000, 45000, 30000, 20000], "VIV": [1100000, 700000, 480000, 330000, 240000, 170000, 120000],
               "TRA": [700000, 450000, 300000, 200000, 140000, 95000, 60000], "COM": [120000, 90000, 70000, 55000, 45000, 35000, 25000],
               "REC": [420000, 230000, 150000, 90000, 60000, 40000, 25000], "EDU": [650000, 380000, 220000, 120000, 70000, 40000, 20000],
               "RES": [450000, 250000, 160000, 100000, 65000, 40000, 25000], "BIE": [260000, 170000, 120000, 85000, 60000, 45000, 30000]}
INGRESO_HOGAR = [6500000, 3600000, 2400000, 1500000, 1000000, 700000, 420000]
PPH = [2.9, 3.0, 3.1, 3.2, 3.3, 3.4, 3.5]
POLOS = [(-70.598, -33.416, 1.0, "El Golf"), (-70.651, -33.440, 1.0, "Santiago Centro"), (-70.612, -33.425, 0.8, "Providencia"),
         (-70.578, -33.403, 0.6, "Nueva Las Condes"), (-70.606, -33.384, 0.5, "Ciudad Empresarial"), (-70.578, -33.392, 0.3, "Vitacura"),
         (-70.735, -33.360, 0.4, "Quilicura industrial"), (-70.757, -33.511, 0.25, "Maipú"), (-70.597, -33.519, 0.25, "La Florida"),
         (-70.690, -33.452, 0.2, "Estación Central")]
# superficie útil (m²) simulada de cada sede: entra al modelo como capacidad (atractivo ∝ (m²/m² típico del formato)^γ)
M2_SEDE = {"CAS-01": 95000, "CAS-03": 28000, "CAS-04": 3800, "CAS-05": 5200, "CAS-06": 4600, "CAS-09": 260, "CAS-10": 160,
           "CAS-11": 180, "CAS-12": 220, "CAS-13": 200, "CAS-14": 150}
VERDAD = {"gamma_capacidad": 0.8, "kappa": 2.0, "lambda": 0.30, "a": {"clinica": 2.4, "centro_medico": 1.0, "toma_muestras": 0.0},
          "beta": {"clinica": 0.055, "centro_medico": 0.11, "toma_muestras": 0.19},
          "a_comp": {"comp_clinica": 1.5, "comp_centro_medico": 0.3, "comp_laboratorio": -0.3},
          "pesos_gse": {"AB": 1.0, "C1A": 0.70, "C1B": 0.45, "C2": 0.20, "C3": 0.08, "D": 0.03, "E": 0.015},
          "sd_atractivo_sede": 0.10, "cv_sobredispersion_manzana": 0.25}
TICKET = {"clinica": 260000, "centro_medico": 52000, "toma_muestras": 24000}
LINEAS = {"clinica": {"Consulta": .22, "Laboratorio": .10, "Imagen": .14, "Hospitalización": .30, "Cirugía": .16, "Urgencia": .08},
          "centro_medico": {"Consulta": .50, "Laboratorio": .18, "Imagen": .20, "Kinesiología": .07, "Urgencia": .05},
          "toma_muestras": {"Laboratorio": 1.0}}
FACTOR_TICKET_LINEA = {"Consulta": 0.55, "Laboratorio": 0.45, "Imagen": 1.6, "Hospitalización": 7.0, "Cirugía": 6.0, "Urgencia": 1.4, "Kinesiología": 0.6}
ISAPRE_GSE = np.array([.93, .86, .72, .48, .27, .13, .06])
APERTURAS = {"CAS-04": "2022-04", "CAS-14": "2024-03"}
METRO = {"L1 simulada": [(-70.7248, -33.4447), (-70.6510, -33.4440), (-70.6015, -33.4183), (-70.5077, -33.4082)],
         "L2 simulada": [(-70.6447, -33.3804), (-70.6510, -33.4440), (-70.6610, -33.5360)],
         "L4 simulada": [(-70.6015, -33.4183), (-70.5770, -33.4490), (-70.5960, -33.5200), (-70.5755, -33.6094)]}


def _dv(cuerpos):
    out = []
    for x in np.asarray(cuerpos, dtype=np.int64):
        s, m = 0, 2
        for d in reversed(str(x)):
            s += int(d) * m; m = 2 if m == 7 else m + 1
        r = 11 - s % 11
        out.append("0" if r == 11 else "K" if r == 10 else str(r))
    return np.array(out)


def _con_dv(cuerpos):
    return np.char.add(np.asarray(cuerpos).astype(str), _dv(cuerpos))


def _formato_rut(norm, rng, con_dv=True):
    """RUT canónico -> como lo escribiría la clínica, con los formatos mezclados que se ven en la práctica:
    19.027.025-4 · 19027025-4 · 190270254 · 0190270254 (como el RUTID de Equifax) · ' 19027025 - 4 ' · 190270254.0
    (número leído como decimal por Excel), k minúscula y 0,3% con el dígito verificador mal digitado.
    con_dv=False: solo el cuerpo (19.027.025 · 19027025 · 019027025), para probar archivos sin dígito verificador."""
    s = pd.Series(norm).astype(str)
    malo = (rng.random(len(s)) < 0.003) & con_dv                             # 0,3% mal digitados (dígito verificador errado)
    s[malo] = [o[:-1] + str((int(o[-1]) + 1) % 10) if o[-1].isdigit() else o[:-1] + "1" for o in s[malo]]
    cuerpo, dv = s.str[:-1], s.str[-1]
    puntos = cuerpo.map(lambda c: f"{int(c):,}".replace(",", "."))
    u = rng.random(len(s))
    if not con_dv:
        return np.select([u < 0.35, u < 0.85], [puntos, cuerpo], cuerpo.str.zfill(9))
    decimal = np.where(dv.str.isdigit(), s + ".0", s)
    out = np.select([u < 0.25, u < 0.50, u < 0.70, u < 0.85, u < 0.95],
                    [puntos + "-" + dv, cuerpo + "-" + dv, s, s.str.zfill(10), " " + cuerpo + " - " + dv + " "], decimal)
    return np.where(rng.random(len(s)) < 0.3, pd.Series(out).str.replace("K", "k").values, out)


def _rut(n, rng):
    """RUT ficticios con dígito verificador, formato RUTID de Equifax (10 caracteres con ceros a la izquierda)."""
    nums = rng.choice(np.arange(3_000_000, 27_000_000), size=n, replace=False)
    out = []
    for x in nums:
        s, m = 0, 2
        for d in reversed(str(x)):
            s += int(d) * m; m = 2 if m == 7 else m + 1
        dv = 11 - s % 11
        out.append(f"{x}{'0' if dv == 11 else 'K' if dv == 10 else dv}".zfill(10))
    return np.array(out)


def _composicion_gse(ab, rng, n):
    mu = np.clip(5.0 - 9.0 * ab + rng.normal(0, 0.6, n), -0.8, 6.0)
    k = np.arange(7)
    p = np.exp(-(k[None, :] - mu[:, None]) ** 2 / (2 * 1.25 ** 2))
    return p / p.sum(1, keepdims=True)


def simular(cfg, ruta_comunas, semilla=2026, pob_objetivo=7_100_000, frac_per=1 / 25, n_emp=140_000, n_bbrr=200_000, n_pois=60_000):
    log = Cronometro()
    rng = np.random.default_rng(semilla)
    R = cfg["rutas"]
    sal = os.path.dirname(R["censo"]); os.makedirs(os.path.join(sal, "cliente"), exist_ok=True)
    crs = cfg["estudio"]["crs_metrico"]

    # ------------------------------------------------------------------ 1. grafo real y comunas
    G = redmod.cargar_grafo(cfg, None, log)
    # aristas con SOLO lo que se usa (tipo de vía, nombre y geometría): ox.graph_to_gdfs copiaría las ~20 columnas de OSM
    from shapely.geometry import LineString
    prim = lambda v: v[0] if isinstance(v, list) else v
    nx_, ny_ = dict(G.nodes(data="x")), dict(G.nodes(data="y"))
    hw, nom, geo, sentido = [], [], [], []
    for u, v, dd in G.edges(data=True):
        hw.append(prim(dd.get("highway", "")))
        nom.append(prim(dd.get("name")))
        sentido.append(prim(dd.get("oneway", False)))
        geo.append(dd.get("geometry") or LineString([(nx_[u], ny_[u]), (nx_[v], ny_[v])]))
    ed = gpd.GeoDataFrame({"highway": pd.Series(hw, dtype=object).astype(str).str.replace("_link", ""), "name": nom, "oneway": sentido},
                          geometry=geo, crs=G.graph.get("crs", "EPSG:4326"))
    del hw, nom, geo, sentido, nx_, ny_
    # la red compacta (matrices dispersas) se arma de inmediato y el grafo de OSMnx (~3,6 GB en la RM) se libera
    red = redmod.construir_red(G, cfg, None, log)
    del G
    import gc
    gc.collect()
    com = gpd.read_file(ruta_comunas).to_crs(crs)
    com["cut_comuna"] = com["cut_comuna"].astype(str).str.zfill(5)
    log(f"grafo: {len(ed):,} aristas · comunas: {len(com)}")

    # ------------------------------------------------------------------ 2. censo SD06 (manzanas sobre el tejido real)
    res = ed[ed["highway"].isin(["residential", "living_street", "tertiary", "secondary", "primary", "unclassified"])].to_crs(crs)
    mid = res.geometry.interpolate(0.5, normalized=True)
    c = 130.0
    cel = pd.DataFrame({"i": np.floor(mid.x / c).astype(np.int64), "j": np.floor(mid.y / c).astype(np.int64)}).drop_duplicates()
    mz = gpd.GeoDataFrame(geometry=[box(i * c + 8, j * c + 8, (i + 1) * c - 8, (j + 1) * c - 8) for i, j in zip(cel["i"], cel["j"])], crs=crs)
    mz = gpd.sjoin(mz, com[["comuna", "cut_comuna", "geometry"]], predicate="within").drop(columns="index_right")
    mz = mz[~mz.index.duplicated()].reset_index(drop=True)
    n = len(mz)
    ab = mz["comuna"].map(AB_COMUNA).fillna(0.02).values
    dens = mz["comuna"].map(DENS_COMUNA).fillna(1.0).values
    base = rng.gamma(2.2, 1 / 2.2, n) * dens
    # manzanas SIN población (para probar los filtros): parques en racimos, sitios eriazos y equipamiento sueltos
    cxy = np.c_[mz.geometry.centroid.x, mz.geometry.centroid.y]
    arbol = cKDTree(cxy)
    parque = np.zeros(n, bool)
    for c0, r0 in zip(rng.choice(n, 320, replace=False), rng.uniform(110, 380, 320)):
        parque[arbol.query_ball_point(cxy[c0], r0)] = True
    eriazo = (rng.random(n) < 0.012) & ~parque
    equip = (rng.random(n) < 0.010) & ~parque & ~eriazo
    base[parque | eriazo | equip] = 0.0
    pob = np.round(base / base.sum() * pob_objetivo).astype(int)
    P = _composicion_gse(ab, rng, n)
    pob_g = np.vstack([rng.multinomial(p_, pv) for p_, pv in zip(pob, P)])
    hog_g = np.round(pob_g / np.array(PPH)[None, :]).astype(int)
    cx = mz.geometry.centroid
    # códigos INE simulados: comuna(5) + distrito(2) + zona(3) + manzana(3); zona censal ≈ celdas de 1,2 km
    zx, zy = np.floor(cx.x / 1200).astype(int), np.floor(cx.y / 1200).astype(int)
    dx, dy = np.floor(cx.x / 4000).astype(int), np.floor(cx.y / 4000).astype(int)
    dist_id = pd.Series(list(zip(mz["cut_comuna"], dx, dy))).astype(str)
    dist_n = dist_id.groupby(mz["cut_comuna"].values).transform(lambda s: pd.factorize(s)[0] + 1).values
    zona_id = pd.Series(list(zip(mz["cut_comuna"], zx, zy))).astype(str)
    zona_n = zona_id.groupby(mz["cut_comuna"].values).transform(lambda s: pd.factorize(s)[0] + 1).values
    mz_n = pd.Series(zona_id.values).groupby(zona_id.values).cumcount().values + 1
    redcode = [f"{a}{b:02d}{z:03d}{m:03d}" for a, b, z, m in zip(mz["cut_comuna"], dist_n % 100, zona_n % 1000, mz_n % 1000)]
    S = {"ID_BLOCK": np.arange(1, n + 1), "COD_APD3": mz["cut_comuna"].values, "PRED": np.array(GSE)[pob_g.argmax(1)], "POB": pob}
    for k, g in enumerate(GSE):
        S[f"POB_{g}"] = pob_g[:, k]
    S["HOG"] = hog_g.sum(1)
    for k, g in enumerate(GSE):
        S[f"HOG_{g}"] = hog_g[:, k]
    viv = np.round(hog_g * 1.05).astype(int)
    S["VIV"] = viv.sum(1)
    for k, g in enumerate(GSE):
        S[f"VIV_{g}"] = viv[:, k]
    ing = hog_g * np.array(INGRESO_HOGAR)[None, :] * rng.lognormal(0, 0.08, (n, 1))
    S["ING"] = ing.sum(1).round()
    for k, g in enumerate(GSE):
        S[f"ING_{g}"] = ing[:, k].round()
    cats = cfg["censo"]["categorias_gasto"]
    gasto_cat = {}
    ruido = rng.lognormal(0, 0.10, (n, 1))
    for cat in cats:
        gasto_cat[cat] = hog_g * np.array(GASTO_HOGAR[cat])[None, :] * ruido
    S["GASTO"] = sum(v.sum(1) for v in gasto_cat.values()).round()
    for cat in cats:
        for k, g in enumerate(GSE):
            S[f"G_{cat}_{g}"] = gasto_cat[cat][:, k].round()
    for cat in cats:
        S[f"G_{cat}"] = gasto_cat[cat].sum(1).round()
    edades = rng.dirichlet([7, 10, 6, 9, 30, 20, 18], n)
    for k, e in enumerate(["POB_0_5", "POB_6_13", "POB_14_17", "POB_18_24", "POB_25_44", "POB_45_59", "POB_60_MAS"]):
        S[e] = np.round(pob * edades[:, k]).astype(int)
    S["H"] = rng.binomial(pob, 0.485); S["M"] = pob - S["H"]
    S = pd.DataFrame(S)
    S["REDCODE"] = redcode
    pdep = np.clip(0.1 + 0.45 * (dens - 0.6) + 0.3 * ab, 0.02, 0.97)
    S["DEPARTAMEN"] = rng.binomial(S["VIV"], pdep); S["CASAS"] = S["VIV"] - S["DEPARTAMEN"]
    S["TIPO_VIV"] = np.where(pdep > 0.6, "departamentos", np.where(pdep < 0.3, "casas", "mixto"))
    S["USO_SUELO"] = np.where(parque, "Area Verde", np.where(eriazo, "Sitio Eriazo", np.where(equip, "Equipamiento",
                              rng.choice(["Residencial", "Comercial", "Mixto"], n, p=[.82, .08, .10]))))
    S["PXQ"] = np.round(rng.lognormal(4, 1.2, n), 5)
    S["COMUNA"] = mz["comuna"].map(lambda s: norm_txt(s).upper()).values
    prov = [PROVINCIA.get(x[:3], ("SANTIAGO", 131)) for x in mz["cut_comuna"]]
    S["PROVINCIA"] = [p[0] for p in prov]; S["ID_PROV"] = [p[1] for p in prov]
    S["REGION"] = "METROPOLITANA DE SANTIAGO"; S["ID_REG"] = 13
    censo = gpd.GeoDataFrame(S, geometry=mz.geometry.values, crs=crs).to_crs("EPSG:4326")
    censo = censo[ESQUEMAS["censo"]]                       # mismo orden de columnas que la base real
    censo.to_file(R["censo"], driver="GPKG", layer="SD06_SOCIODEMOGRAPHIC_BLOCK_2026")
    log(f"censo: {n:,} manzanas · {pob.sum():,} habitantes · {len(censo.columns)} columnas · sin población: {int((pob == 0).sum()):,} "
        f"(parques {int(parque.sum()):,}, eriazos {int(eriazo.sum()):,}, equipamiento {int(equip.sum()):,})")
    # capa de áreas verdes: los parques + plazas chicas que tocan manzanas habitadas (no deben descartarlas)
    pq = gpd.GeoSeries(mz.geometry.values[parque], crs=crs).buffer(12).union_all()
    plazas = gpd.GeoSeries(gpd.points_from_xy(*cxy[rng.choice(n, 150, replace=False)].T), crs=crs).buffer(rng.uniform(25, 70, 150))
    av = gpd.GeoDataFrame({"tipo": ["parque"] * 1 + ["plaza"] * len(plazas)}, geometry=[pq] + list(plazas.values), crs=crs).to_crs(4326)
    av.to_file(R["areas_verdes"], driver="GPKG")
    log(f"áreas verdes: {len(av):,} polígonos")

    mzm = censo.to_crs(crs)
    bnd = mzm.geometry.bounds.values

    def puntos_en(idx):
        x = rng.uniform(bnd[idx, 0], bnd[idx, 2]); y = rng.uniform(bnd[idx, 1], bnd[idx, 3])
        ll = gpd.GeoSeries(gpd.points_from_xy(x, y), crs=crs).to_crs(4326)
        return ll.y.values, ll.x.values

    # ------------------------------------------------------------------ 3. personas (per), 72 columnas
    npm = rng.binomial(pob, frac_per)
    idx = np.repeat(np.arange(n), npm)
    m = len(idx)
    gse_p = np.concatenate([rng.choice(7, size=k, p=(pg / pg.sum() if pg.sum() else np.full(7, 1 / 7))) for pg, k in zip(pob_g, npm)])
    lat, lon = puntos_en(idx)
    edad = np.clip(rng.normal(41, 20, m), 0, 99).astype(int)
    rut = _rut(m, rng)
    renta = np.array(INGRESO_HOGAR)[gse_p] * rng.lognormal(0, 0.35, m)
    per = pd.DataFrame({
        "RUTID": rut, "NOMBRE": "PERSONA SIMULADA", "PATERNO": "SIMULADO", "MATERNO": "SIMULADO", "NOMBRES": "PERSONA",
        "FECHA_NACIMIENTO": (2026 - edad) * 10000 + 101, "EDAD": edad, "SEXO": rng.choice(["FEMENINO", "MASCULINO"], m, p=[.52, .48]),
        "FECHA_DEFUNCION": np.where(rng.random(m) < 0.008, "20250101", None), "DEFUNCION": None, "INTERDICTO": None,
        "EST_CIVIL": rng.choice(["SOLTERO", "CASADO", "DIVORCIADO", "VIUDO"], m, p=[.5, .38, .08, .04]), "FEC_MATRIMONIO": None,
        "TIPO_NACIONALIDAD": "CHILENO", "NACIONALIDAD": "CHILENA", "PROFESION_OFICIO": None,
        "ISE": np.round(10 - gse_p + rng.normal(0, 0.7, m), 1), "RENTA_EFX": np.round(renta / 2.5),
        "CANT_PERSONAS_HH": np.clip(rng.poisson(np.array(PPH)[gse_p]), 1, 9), "VEHI_CANTIDAD_HH": rng.poisson(np.array([2.1, 1.6, 1.2, .9, .6, .35, .15])[gse_p]),
        "VEHI_AVALUO_TOTAL_HH": None, "AVALUO_BBRR_TOTAL_HH": None, "CLEAN2_HH": None, "RENTA_TOTAL_HH": np.round(renta),
        "PREDICTOR1_MIN_HH": None, "PREDICTOR1_PROM_HH": None, "PREDICTOR1_MAX_HH": None, "ISE_DOMINATE_HH": None,
        "VEHICULOS": None, "CANT_VEHICULOS": rng.poisson(np.array([1.4, 1.1, .9, .6, .4, .2, .1])[gse_p]),
        "TIPOVIA_PART": "CALLE", "CALLE_PART": "SIMULADA", "NUMERO_PART": 0, "RESTO_DIRECCION_PART": None,
        "COMUNA_PART": censo["COMUNA"].values[idx], "CIUDAD_PART": "SANTIAGO", "REGION_PART": "METROPOLITANA",
        "GSE_PART": np.where(rng.random(m) < 0.03, None, np.array(GSE)[gse_p]), "DIRECC_VERIFICADA_PART": rng.choice(["S", "N"], m, p=[.8, .2]),
        "LONGITUD_PART": np.where(rng.random(m) < 0.02, np.nan, lon), "LATITUD_PART": lat, "FECHA_DIRECCION_PART": 20250601,
        "TIPO_DOMICILIO_PART": "PARTICULAR", "COD_ACTECO": None, "ACTIVIDAD_PRINCIPAL": None, "RUTID_CONYUGE": None,
        "RUTID_PADRE": None, "RUTID_MADRE": None, "BBRR": None, "CANT_BBRR": rng.poisson(np.array([1.8, 1.3, 1, .7, .5, .3, .15])[gse_p]),
        "EVERCLEAN_12M": None, "EVERCLEAN_24M": None, "EVERCLEAN_36M": None, "BOLCOM": None,
        "DICOM": rng.binomial(1, np.array([.04, .07, .1, .16, .24, .33, .4])[gse_p]), "ICOM": None,
        "HIJOS_0_2_ANOS": 0, "HIJOS_3_5_ANOS": 0, "HIJOS_6_13_ANOS": 0, "HIJOS_14_17_ANOS": 0, "HIJOS_18_24_ANOS": 0,
        "HIJOS_25_ANOS_O_MAS": 0, "CANT_HIJOS_TOTAL": rng.poisson(np.where(edad > 30, 1.5, 0.2)), "PARTICIP_SOCIEDADES": 0,
        "TRAMO_PROPIEDADES": None, "TRAMO_VEHICULO": None, "TRAMO_HIJOS": None, "TRAMO_FAMILIA": None, "TRAMO_EDAD": None,
        "TRAMO_RENTA": None, "TRAMO_RENTA_HH": None, "PROFESION_LIMPIA": None})
    per[ESQUEMAS["per"]].to_parquet(R["per"], index=False)
    log(f"per: {len(per):,} personas (1 de cada {1 / frac_per:.0f}) · {per.shape[1]} columnas")

    # ------------------------------------------------------------------ 4. empresas (txt con |), 31 columnas
    pol = np.array([(p[0], p[1], p[2]) for p in POLOS])
    en_polo = rng.random(n_emp) < 0.5
    k = rng.choice(len(POLOS), n_emp, p=pol[:, 2] / pol[:, 2].sum())
    elon = pol[k, 0] + rng.normal(0, 0.008, n_emp); elat = pol[k, 1] + rng.normal(0, 0.006, n_emp)
    ib = rng.choice(n, (~en_polo).sum(), p=pob / pob.sum()); la, lo = puntos_en(ib)
    elat[~en_polo] = la; elon[~en_polo] = lo
    tam = np.where(en_polo, rng.choice(["MICRO", "PEQUEÑA", "MEDIANA", "GRANDE"], n_emp, p=[.5, .3, .14, .06]),
                   rng.choice(["MICRO", "PEQUEÑA", "MEDIANA", "GRANDE"], n_emp, p=[.82, .155, .02, .005]))
    trab_real = np.select([tam == "MICRO", tam == "PEQUEÑA", tam == "MEDIANA", tam == "GRANDE"],
                          [rng.integers(1, 10, n_emp), rng.integers(10, 50, n_emp), rng.integers(50, 200, n_emp), rng.integers(200, 2500, n_emp)])
    rubros = ["COMERCIO", "SERVICIOS PROFESIONALES", "CONSTRUCCION", "SALUD", "EDUCACION", "TRANSPORTE", "INDUSTRIA", "FINANCIERO", "INMOBILIARIO", "ALIMENTACION"]
    rub = rng.choice(rubros, n_emp, p=[.26, .2, .08, .06, .04, .07, .06, .08, .07, .08])
    emp = pd.DataFrame({
        "RUTID": _con_dv(76_000_000 + np.arange(n_emp)), "RAZON_SOCIAL": [f"EMPRESA SIMULADA {i} SPA" for i in range(n_emp)],
        "ACTIVA": np.where(rng.random(n_emp) < 0.97, "ACTIVA", "INACTIVA"), "FECHA_INICIACION_ACTIVIDADES": None,
        "CODIGO_ACTIVIDAD": None, "ACTIVIDAD_PRINCIPAL": np.where(rub == "SALUD", "ACTIVIDADES DE ATENCION DE LA SALUD HUMANA", rub),
        "FECHA_CONSTITUCION": rng.integers(2005, 2026, n_emp) * 100 + rng.integers(1, 13, n_emp), "MARCA_PROPYME": np.isin(tam, ["MICRO", "PEQUEÑA"]).astype(int),
        "MONEDA_EXTRANJERA": None, "TAMANO_EMPRESAS": tam, "RUBRO": rub, "RUBRO_ESPECIFICO": None,
        "CANTIDAD_TRAB": np.where(rng.random(n_emp) < 0.4, trab_real, np.nan), "RANGO_TRABAJADORES": None, "TIPO_EMPRESA": "SPA",
        "FACTURACION_SUB_RANGO": None, "ULTIMO_DOCUMENTO": None, "FECHA_ULTIMO_DOCUMENTO": None, "FONO_AREA_COMER": None,
        "FONO_NUMERO_COMER": None, "TIPOVIA_COMER": None, "CALLE_COMER": None, "NUMERO_COMER": None, "RESTO_DIRECCION_COMER": None,
        "COMUNA_COMER": None, "CIUDAD_COMER": "SANTIAGO", "REGION_COMER": "METROPOLITANA", "LATITUD_COMER": np.round(elat, 6),
        "LONGITUD_COMER": np.round(elon, 6), "GSE_COMER": None, "COD_POSTAL_COMER": None})
    emp[ESQUEMAS["emp"]].to_csv(R["emp"], sep="|", index=False)
    log(f"emp: {len(emp):,} empresas · {emp.shape[1]} columnas")

    # ------------------------------------------------------------------ 5. BBRR (txt con |), 23 columnas
    ib = rng.choice(n, n_bbrr, p=pob / pob.sum()); la, lo = puntos_en(ib)
    dest = rng.choice(list("HCOSEILZW"), n_bbrr, p=[.76, .08, .05, .01, .02, .02, .02, .03, .01])
    gse_b = pob_g[ib].argmax(1)
    av = np.array([180, 120, 85, 60, 45, 32, 25])[gse_b] * 1e6 * rng.lognormal(0, 0.4, n_bbrr)
    bb = pd.DataFrame({"ROL": [f"{a}-{i:05d}-{rng.integers(1, 999):05d}" for i, a in enumerate(censo["COD_APD3"].values[ib])],
                       "MANZANA": rng.integers(1, 3000, n_bbrr), "PREDIO": rng.integers(1, 200, n_bbrr), "COD_COMUNA": censo["COD_APD3"].values[ib],
                       "COMUNA": censo["COMUNA"].values[ib], "DIRECCION": "DIRECCION SIMULADA", "AVALUO_FISCAL": av.round(),
                       "AVALUO_EXENTO_PROPIEDAD": (av * 0.5).round(), "CONTRIBUCION_SEMESTRAL": (av * 0.004).round(), "CODIGO_DESTINO": dest,
                       "GLOSA_DESTINO": pd.Series(dest).map({"H": "HABITACIONAL", "C": "COMERCIO", "O": "OFICINA", "S": "SALUD", "E": "EDUCACION Y CULTURA",
                                                             "I": "INDUSTRIA", "L": "BODEGA", "Z": "ESTACIONAMIENTO", "W": "SITIO ERIAZO"}).values,
                       "TIPO_PROPIEDAD": "NO AGRICOLA", "SUPERFICIE_TERRENO": np.round(rng.lognormal(5.3, 0.8, n_bbrr)), "RADIO": None,
                       "RUTID": None, "PATERNO": None, "MATERNO": None, "NOMBRES": None, "NOMBRE_RAZON_SOCIAL": None, "CIUDAD": "SANTIAGO",
                       "REGION": "METROPOLITANA", "LATITUD": np.round(la, 6), "LONGITUD": np.round(lo, 6)})
    bb[ESQUEMAS["bbrr"]].to_csv(R["bbrr"], sep="|", index=False)
    log(f"bbrr: {len(bb):,} propiedades · {bb.shape[1]} columnas")

    # ------------------------------------------------------------------ 6. GTFS de metro simulado (3 líneas sobre la red real)
    from scipy.sparse import csgraph
    M_pie = red.M["pie"]                          # caminata: ambos sentidos y tiempo ∝ largo -> ruta más corta en distancia

    def _camino(a, b):
        _, pred = csgraph.dijkstra(M_pie, directed=True, indices=int(a), return_predecessors=True)
        c = [int(b)]
        while c[-1] != a and pred[c[-1]] >= 0:
            c.append(int(pred[c[-1]]))
        return c[::-1]
    estaciones = []
    with zipfile.ZipFile(R["gtfs"], "w") as z:
        stops, trips, st, routes = [], [], [], []
        for li, (nom, pts) in enumerate(METRO.items()):
            pm_ = np.array(gpd.GeoSeries(gpd.points_from_xy([p[0] for p in pts], [p[1] for p in pts]), crs=4326).to_crs(crs).get_coordinates())
            nodos = redmod.nodo_cercano(red, pm_[:, 0], pm_[:, 1])[0]
            camino = []
            for a, b in zip(nodos[:-1], nodos[1:]):
                p = _camino(a, b)
                camino += p if not camino else p[1:]
            xym = np.c_[red.x[camino], red.y[camino]]
            xy = np.array(gpd.GeoSeries(gpd.points_from_xy(xym[:, 0], xym[:, 1]), crs=crs).to_crs(4326).get_coordinates())
            dacum = np.r_[0, np.cumsum(np.hypot(*np.diff(xym, axis=0).T))]
            marcas = np.arange(0, dacum[-1], 1150.0)
            sel = np.unique(np.searchsorted(dacum, marcas).clip(0, len(camino) - 1))
            ids = [f"{li + 1}_{k:02d}" for k in range(len(sel))]
            for sid, k in zip(ids, sel):
                stops.append({"stop_id": sid, "stop_name": f"Estación {sid} ({nom})", "stop_lat": xy[k, 1], "stop_lon": xy[k, 0]})
                estaciones.append((xy[k, 0], xy[k, 1]))
            routes.append({"route_id": f"R{li + 1}", "route_short_name": nom, "route_type": 1})
            tseg = np.diff(dacum[sel]) / (35 / 3.6) + 20
            for dirn, orden in ((0, list(range(len(sel)))), (1, list(range(len(sel)))[::-1])):
                for v in range(30):
                    tid = f"R{li + 1}_{dirn}_{v}"
                    trips.append({"route_id": f"R{li + 1}", "service_id": "LV", "trip_id": tid, "direction_id": dirn})
                    t = 7 * 3600 + v * 240
                    for q, kk in enumerate(orden):
                        hh = f"{t // 3600:02d}:{t % 3600 // 60:02d}:{t % 60:02d}"
                        st.append({"trip_id": tid, "arrival_time": hh, "departure_time": hh, "stop_id": ids[kk], "stop_sequence": q + 1})
                        if q < len(orden) - 1:
                            t += int(tseg[min(kk, orden[q + 1])])
        for nombre_t, df in (("stops", stops), ("routes", routes), ("trips", trips), ("stop_times", st)):
            z.writestr(f"{nombre_t}.txt", pd.DataFrame(df).to_csv(index=False))
        z.writestr("agency.txt", "agency_id,agency_name,agency_url,agency_timezone\nSIM,Metro simulado,https://example.org,America/Santiago\n")
        z.writestr("calendar.txt", "service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date\nLV,1,1,1,1,1,0,0,20260101,20261231\n")
    log(f"GTFS simulado: {len(METRO)} líneas · {len(estaciones)} estaciones")

    # ------------------------------------------------------------------ 7. POIs PI01 (28 columnas)
    arbol = [("Comercio", "Supermercados", "Supermercado", .08), ("Comercio", "Centros Comerciales", "Mall", .01),
             ("Comercio", "Casa Y Construccion", None, .05), ("Comercio", "Vestuario", None, .08), ("Alimentacion", "Comida Rapida", "Pizzeria", .10),
             ("Alimentacion", "Restaurantes", None, .10), ("Alimentacion", "Cafes", None, .05), ("Educacion", "Colegios", None, .06),
             ("Educacion", "Universidades", None, .01), ("Educacion", "Jardines Infantiles", None, .04), ("Servicios", "Bancos", None, .04),
             ("Servicios", "Oficinas", None, .05), ("Servicios", "Notarias", None, .01), ("Entretencion", "Gimnasios", None, .03),
             ("Transporte", "Paraderos", None, .08), ("Automotriz", "Servicentros", None, .03),
             ("Turismo", "Hoteles", None, .01), ("Gobierno", "Municipalidades", None, .01)]
    pr = np.array([a[3] for a in arbol]); pr = pr / pr.sum()
    kk = rng.choice(len(arbol), n_pois, p=pr)
    ip = rng.choice(n, n_pois, p=pob / pob.sum()); la, lo = puntos_en(ip)
    po = pd.DataFrame({"COD_CNTRY": "CL", "ID_POI": np.arange(1, n_pois + 1), "SOURCE": rng.choice(["WEB", None, "Overture"], n_pois),
                       "ID_SOURCE": None, "COD_APD3": censo["COD_APD3"].values[ip], "COD_CITY": None, "ZIP_COD": "7500000",
                       "CAT1_DES": [arbol[i][0] for i in kk], "CAT2_DES": [arbol[i][1] for i in kk], "CAT3_DES": [arbol[i][2] for i in kk],
                       "CAT_ENG": None, "BRAND": None, "TRADENAME": [f"{arbol[i][1]} simulado {j}" for j, i in enumerate(kk)], "ADDRESS": None,
                       "REFERENCE": None, "HOURS": None, "PHONE": None, "PHONE2": None, "WEB": None, "EMAIL": None, "OBS": None,
                       "LON_X": lo, "LAT_Y": la, "STATUS": "ACTIVO", "UPD_DATE": "2026-06-01", "CRE_DATE": "2020-01-01", "CHAIN": None})
    est = pd.DataFrame({"COD_CNTRY": "CL", "ID_POI": np.arange(n_pois + 1, n_pois + 1 + len(estaciones)), "SOURCE": "WEB", "COD_APD3": None,
                        "ZIP_COD": None, "CAT1_DES": "Transporte", "CAT2_DES": "Metro", "CAT3_DES": "Estacion de Metro",
                        "TRADENAME": "Estación de metro (simulada)", "LON_X": [e[0] for e in estaciones], "LAT_Y": [e[1] for e in estaciones],
                        "STATUS": "ACTIVO", "UPD_DATE": "2026-06-01", "CRE_DATE": "2020-01-01"})
    from .lectura import construir_area_estudio
    area = construir_area_estudio(censo, cfg)
    salud, verdad_pois = pois_salud_pi01(cfg, area, puntos_en, n, pob, n_pois + 1 + len(estaciones), rng)
    po = pd.concat([po, est, salud], ignore_index=True)[ESQUEMAS["pois"][:-1]]
    pg = gpd.GeoDataFrame(po, geometry=gpd.points_from_xy(po["LON_X"], po["LAT_Y"]), crs=4326)
    pg.to_file(R["pois"], driver="GPKG", layer="PI01_POI")
    verdad_pois.to_csv(os.path.join(sal, "verdad_pois_equifax.csv"), index=False, encoding="utf-8-sig")
    log(f"pois: {len(pg):,} · {pg.shape[1]} columnas · salud: {len(salud):,} "
        f"({(verdad_pois['verdad'] != 'nuevo').sum():,} duplicados o no humanos, {(verdad_pois['verdad'] == 'nuevo').sum():,} nuevos)")

    # ------------------------------------------------------------------ 8. Maestro de calles BC08 (geometría OSM, numeración simulada)
    st_ = ed[ed["name"].notna()].copy()
    st_["key"] = st_.geometry.map(lambda gg: tuple(sorted([tuple(np.round(gg.coords[0], 6)), tuple(np.round(gg.coords[-1], 6))])))
    st_ = st_.drop_duplicates("key").to_crs(crs).reset_index(drop=True)
    st_["NAM_RAW"] = st_["name"].astype(str)
    st_["TYP_STREET"] = np.where(st_["NAM_RAW"].str.lower().str.startswith("avenida"), "AV",
                                 np.where(st_["NAM_RAW"].str.lower().str.startswith("pasaje"), "PJE",
                                          np.where(st_["highway"].isin(["motorway", "trunk"]), "AUT", "CALLE")))
    st_["NAM_STREET"] = st_["NAM_RAW"].map(lambda s: normalizar_calle(s).upper())
    mids = st_.geometry.interpolate(0.5, normalized=True)
    cj = gpd.sjoin(gpd.GeoDataFrame(geometry=mids, crs=crs), com[["cut_comuna", "geometry"]], how="left", predicate="within")
    st_["COD_APD3"] = cj[~cj.index.duplicated()]["cut_comuna"].reindex(st_.index).fillna("13101").values
    # numeración: posición a lo largo del eje principal de cada calle en cada comuna (≈ 1 número por metro).
    # Vectorizado: el eje sale de la covarianza (momentos agrupados) de los extremos de los tramos de cada calle.
    p0 = np.array([gg.coords[0] for gg in st_.geometry]); p1 = np.array([gg.coords[-1] for gg in st_.geometry])
    grupo = pd.factorize(st_["NAM_STREET"] + "|" + st_["COD_APD3"])[0]
    ng = grupo.max() + 1
    cnt = np.bincount(grupo, minlength=ng) * 2.0
    mx = (np.bincount(grupo, p0[:, 0], ng) + np.bincount(grupo, p1[:, 0], ng)) / cnt
    my = (np.bincount(grupo, p0[:, 1], ng) + np.bincount(grupo, p1[:, 1], ng)) / cnt
    dx0, dy0, dx1, dy1 = p0[:, 0] - mx[grupo], p0[:, 1] - my[grupo], p1[:, 0] - mx[grupo], p1[:, 1] - my[grupo]
    sxx = np.bincount(grupo, dx0 ** 2 + dx1 ** 2, ng); syy = np.bincount(grupo, dy0 ** 2 + dy1 ** 2, ng); sxy = np.bincount(grupo, dx0 * dy0 + dx1 * dy1, ng)
    ang = 0.5 * np.arctan2(2 * sxy, sxx - syy)                      # dirección del eje principal (2x2, analítico)
    ex, ey = np.cos(ang), np.sin(ang)
    flip = (ex + ey) < 0; ex[flip] *= -1; ey[flip] *= -1
    a0 = dx0 * ex[grupo] + dy0 * ey[grupo]; a1 = dx1 * ex[grupo] + dy1 * ey[grupo]
    amin = pd.Series(np.minimum(a0, a1)).groupby(grupo).min().reindex(range(ng)).values
    off = -amin + 1
    # anclas: las calles con una sede de CAS se numeran para que la dirección real de la sede quede en su lugar
    sedes_m = pd.read_csv(R["maestro_sedes"])
    for _, s_ in sedes_m.iterrows():
        calle, num, _c = separar_direccion(str(s_["direccion"]))
        if not (calle and num):
            continue
        q = gpd.GeoSeries(gpd.points_from_xy([s_["lon"]], [s_["lat"]]), crs=4326).to_crs(crs).get_coordinates().values[0]
        cand = np.where(st_["NAM_STREET"].values == calle.upper())[0]
        if not len(cand):
            continue
        dist = np.minimum(np.hypot(*(p0[cand] - q).T), np.hypot(*(p1[cand] - q).T))
        if dist.min() < 400:
            gk = grupo[cand[np.argmin(dist)]]
            off[gk] = num - ((q[0] - mx[gk]) * ex[gk] + (q[1] - my[gk]) * ey[gk])
    ini = np.maximum(1, np.round(a0 + off[grupo])); fin = np.maximum(1, np.round(a1 + off[grupo]))
    lo_, hi_ = np.minimum(ini, fin), np.maximum(ini, fin)
    par = lambda v: (v // 2) * 2
    BC = pd.DataFrame({"COD_CNTRY": "CL", "ID_STREET": np.arange(1, len(st_) + 1), "ID_NAME": pd.factorize(st_["NAM_STREET"])[0] + 1,
                       "COD_APD3": st_["COD_APD3"].values, "COD_CITY": None, "COD_UNIQUE": None, "ID_BLOCK_L": None, "ID_BLOCK_R": None,
                       "ID_NBHD_L": None, "ID_NBHD_R": None, "COD_APD3_L": st_["COD_APD3"].values, "COD_APD3_R": st_["COD_APD3"].values,
                       "TYP_STREET": st_["TYP_STREET"].values, "NAM_STREET": st_["NAM_STREET"].values, "SYNONYM1": None, "SYNONYM2": None,
                       "NUM_BLOCK": None, "COD_STREET": None,
                       "START_LEFT": np.where(ini <= fin, par(lo_), par(hi_)), "END_LEFT": np.where(ini <= fin, par(hi_), par(lo_)),
                       "START_RIG": np.where(ini <= fin, par(lo_) + 1, par(hi_) + 1), "END_RIG": np.where(ini <= fin, par(hi_) + 1, par(lo_) + 1),
                       "START_LEF2": None, "END_LEF2": None, "START_RIG2": None, "END_RIG2": None,
                       "DIRECTION": np.where(st_["oneway"].astype(str).str.lower().isin(["true", "1", "yes"]), "FT", "B"), "LEVEL": 0,
                       "HIERARCHY": st_["highway"].map({"motorway": 1, "trunk": 1, "primary": 2, "secondary": 3, "tertiary": 4}).fillna(5).astype(int).values,
                       "SYMBOL": None, "TYPE_MAT": None, "LABEL": st_["NAM_RAW"].values})
    bc = gpd.GeoDataFrame(BC, geometry=st_.geometry.values, crs=crs).to_crs(4326)
    bc[ESQUEMAS["street"]].to_file(R["street"], driver="GPKG", layer="BC08_STREET")
    log(f"street: {len(bc):,} tramos · {bc.shape[1]} columnas")

    # ------------------------------------------------------------------ 9. "verdad": manzanas, red, sedes, competencia y Huff
    activa = emp["ACTIVA"].values == "ACTIVA"
    eg = gpd.GeoDataFrame({"trabajadores_est": trab_real.astype(float)[activa], "es_salud": (rub == "SALUD")[activa],
                           "RUTID": emp["RUTID"].values[activa], "RUBRO": rub[activa]},
                          geometry=gpd.points_from_xy(elon[activa], elat[activa]), crs=4326)
    pois_all = _pois_salud_simulados(cfg, area, rng)
    verdes = gpd.read_file(R["areas_verdes"])
    ut, _desc, _, emp_ut = UN.construir_unidades(censo, cfg, emp=eg, pois=pois_all, areas_verdes=verdes, cronometro=log)
    log(f"manzanas útiles: {len(ut):,}")
    sedes = sedes_modelo_desde_maestro(cfg, area)
    nodos_ut = redmod.preparar_unidades(red, ut)
    T = redmod.tiempos_a_puntos(red, ut, sedes[["x", "y"]].values, "auto_punta", cfg, nodos_ut=nodos_ut)
    # competencia verdadera: el levantamiento + los POIs de Equifax que de verdad son lugares nuevos (uno por lugar)
    nuevos_ok = set(verdad_pois.loc[verdad_pois["verdad"] == "nuevo", "ID_POI"])
    comp, _ = compmod.construir_competencia(cfg, area, pois=pois_all[pois_all["id"].isin(nuevos_ok)], unificar=False)
    pc = compmod.potencial_competencia(comp, ut, red, cfg, nodos_ut=nodos_ut, cronometro=log)
    log(f"tiempos: {T.shape[1]} sedes · potencial de competencia exacto por manzana ({pc.resumen['competidores']:,} competidores)")
    gpc = ut["gasto_salud_total"].sum() / max(ut["pob"].sum(), 1)
    Gm = ut[[f"gasto_salud_{g}" for g in GSE]].values
    d = modelo.DatosHuff(G=Gm, W=ut["trabajadores_est"].values * gpc, T=T, fmt=sedes["formato_modelo"].map({f: k for k, f in enumerate(modelo.FORMATOS)}).values,
                         pc=pc, A=sparse.identity(len(ut), format="csr"), S=np.zeros((len(ut), len(sedes))),
                         mask=np.ones((len(ut), len(sedes)), bool), sedes=list(sedes["sede"]), gse=GSE)
    th = np.r_[np.log(VERDAD["kappa"]), np.log(VERDAD["lambda"]), [VERDAD["a"][f] for f in modelo.FORMATOS],
               np.log([VERDAD["beta"][f] for f in modelo.FORMATOS]), [VERDAD["a_comp"][g] for g in modelo.GRUPOS_COMP],
               np.log([VERDAD["pesos_gse"][g] for g in GSE[1:]]), VERDAD["gamma_capacidad"]]
    d.z = capacidad_relativa(sedes.assign(m2=sedes["sede"].map(M2_SEDE)), "m2")
    # ruido realista: atractivo propio de cada sede (no observado) y sobre-dispersión por unidad
    efecto_sede = rng.normal(0, VERDAD["sd_atractivo_sede"], len(sedes))
    d.T = d.T - (efecto_sede / np.array([VERDAD["beta"][f] for f in sedes["formato_modelo"]]))[None, :]
    mu = modelo.predecir(th, d)
    d.T = np.where(np.isfinite(T), T, modelo.T_LEJOS)
    k_od = 1 / VERDAD["cv_sobredispersion_manzana"] ** 2
    mu = mu * rng.gamma(k_od, 1 / k_od, size=mu.shape)
    vm = dict(zip(sedes["sede"], mu.sum(0)))
    log("venta mensual madura simulada (MM CLP): " + ", ".join(f"{s}={v / 1e6:,.0f}" for s, v in vm.items()))

    # ------------------------------------------------------------------ 10. datos del cliente
    _datos_cliente(cfg, sedes, sedes_m, ut, mu, censo, per, emp_ut, rng, log)
    verdad = dict(VERDAD)
    verdad.update({"venta_mensual_madura": vm, "efecto_sede": dict(zip(sedes["sede"], efecto_sede)), "aperturas": APERTURAS,
                   "sedes_modelo": list(sedes["sede"]), "pob_total": int(pob.sum()), "unidades": int(len(ut)),
                   "manzanas_sin_poblacion": int((pob == 0).sum())})
    with open(cfg["simulacion"]["verdad"], "w", encoding="utf-8") as f:
        json.dump(verdad, f, ensure_ascii=False, indent=1, default=float)
    log("listo: bases simuladas en " + sal)
    return verdad


# --------------------------------------------------------------------------------------------- POIs DE SALUD DE EQUIFAX
# Cómo aparecen en PI01 los lugares de salud que también están en el levantamiento: con otro nombre parecido, otras
# coordenadas y a veces repetidos. Sirve para medir si la unificación encuentra los duplicados (verdad conocida).
CAT_PI01 = {"farmacia": ("Salud", "Farmacias", None), "dental": ("Salud", "Dentales", None), "medica": ("Salud", "Centros Medicos", None),
            "hospital": ("Salud", "Clinicas Y Hospitales", None), "laboratorio": ("Salud", "Laboratorios", "Toma de muestras"),
            "kine": ("Salud", "Kinesiologia", None), "optica": ("Salud", "Opticas", None), "eleam": ("Salud", "Residencias Adulto Mayor", None),
            "insumos": ("Salud", "Ortopedias", None), "ambulancia": ("Salud", "Ambulancias", None),
            "salud_otro": ("Salud", "Otros Servicios De Salud", None)}
P_EN_PI01 = {"farmacia": .85, "dental": .55, "medica": .65, "hospital": .90, "laboratorio": .70, "kine": .45, "optica": .60,
             "eleam": .40, "insumos": .40, "ambulancia": .30, "salud_otro": .30}
APELLIDOS = ["Rojas", "Muñoz", "Soto", "Contreras", "Silva", "Martínez", "Sepúlveda", "Morales", "Fuentes", "Valenzuela", "Araya",
             "Espinoza", "Castillo", "Tapia", "Reyes", "Gutiérrez", "Castro", "Pizarro", "Álvarez", "Vásquez", "Cortés", "Ramírez",
             "Núñez", "Carrasco", "Herrera", "Jara", "Vergara", "Figueroa", "Riquelme", "Bravo", "Saavedra", "Toledo", "Salinas",
             "Olivares", "Gallardo", "Garrido", "Cáceres", "Aguilera", "Orellana", "Navarro", "Zúñiga", "Paredes", "Lagos", "Acuña"]
LUGARES = ["Los Dominicos", "Plaza Ñuñoa", "Manquehue", "El Golf", "Tobalaba", "Plaza Italia", "Los Leones", "Pedro de Valdivia",
           "Irarrázaval", "Gran Avenida", "Pajaritos", "La Cisterna", "Bellavista", "Recoleta", "Macul", "Grecia", "Quilín",
           "Los Trapenses", "Chicureo", "La Dehesa", "San Damián", "Apoquindo", "Escuela Militar", "Vespucio", "Ossa", "Departamental"]
_GENERICO_LARGO = [("Centro Médico", ["C. Médico", "CM", "Ctro. Médico", "Centro Medico", "CENTRO MED."]),
                   ("Laboratorio", ["Lab.", "Laboratorio", "LAB"]), ("Clínica", ["Clinica", "Clín.", "CLINICA"]),
                   ("Doctor", ["Dr."]), ("Doctora", ["Dra."]), ("Toma de Muestras", ["TM", "Toma Muestras"]), ("Farmacias", ["Farmacia", "Fcia."])]


def _sin_tildes(t):
    import unicodedata
    return unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode()


def _variar_nombre(nombre, marca, rng):
    """Cómo escribiría PI01 el nombre de un lugar del levantamiento (devuelve también qué variación se aplicó)."""
    n = str(nombre)
    u = rng.random()
    if u < 0.16:
        tipo = "igual"
    elif u < 0.34:
        tipo = "abreviado"
        for largo, cortos in _GENERICO_LARGO:
            if largo.lower() in n.lower():
                i = n.lower().index(largo.lower())
                n = n[:i] + cortos[rng.integers(len(cortos))] + n[i + len(largo):]
    elif u < 0.46:
        tipo = "sin genérico"
        for largo, _ in _GENERICO_LARGO:
            if n.lower().startswith(largo.lower() + " ") and len(n) > len(largo) + 6:
                n = n[len(largo) + 1:]
                break
    elif u < 0.58 and isinstance(marca, str) and marca and marca.lower() not in n.lower():
        tipo = "marca + sucursal"
        n = f"{marca} {' '.join(n.split()[-2:])}"
    elif u < 0.70:
        tipo = "error de tipeo"
        palabras = n.split()
        largas = [i for i, w in enumerate(palabras) if len(w) >= 5]
        if largas:
            i = largas[rng.integers(len(largas))]
            w = palabras[i]
            k = int(rng.integers(1, len(w) - 2))
            palabras[i] = w[:k] + w[k + 1] + w[k] + w[k + 2:] if rng.random() < 0.5 else w[:k] + w[k + 1:]
            n = " ".join(palabras)
    elif u < 0.75:
        tipo = "razón social distinta"
        n = f"Inversiones Médicas {APELLIDOS[rng.integers(len(APELLIDOS))]} SpA"
    else:
        tipo = "sin tildes"
        n = _sin_tildes(n)
    if rng.random() < 0.45:
        n = _sin_tildes(n).upper()
    if tipo != "razón social distinta" and rng.random() < 0.10:
        n += [" SpA", " Ltda.", " S.A.", " LIMITADA"][rng.integers(4)]
    return n, tipo


def _variar_direccion(d, rng):
    if not isinstance(d, str) or not d.strip() or rng.random() < 0.20:
        return None
    principal = d.split(" / ")[0].split("(")[0].split(",")[0].strip()
    principal = principal.replace("Av. ", "AV " if rng.random() < 0.5 else "Avenida ").replace("N°", "").replace("  ", " ")
    return _sin_tildes(principal).upper() if rng.random() < 0.6 else principal


def _desplazar(lon, lat, metros, rng):
    ang = rng.uniform(0, 2 * np.pi, len(metros))
    return (lon + metros * np.cos(ang) / (111_320 * np.cos(np.radians(lat))), lat + metros * np.sin(ang) / 110_540)


def pois_salud_pi01(cfg, area, puntos_en, n_manzanas, pob, primer_id, rng):
    """POIs de salud de PI01 simulados + la verdad de cuáles son duplicados del levantamiento o entre sí."""
    from .competencia import leer_universo
    from .unificacion_pois import familias
    lev = leer_universo(cfg)
    lev = lev[lev.within(area.geometry.iloc[0])].reset_index(drop=True)
    fam = familias(lev["categoria"].astype(str) + " " + lev["formato_FRF"].astype(str), cfg["competencia"]["pois_equifax"]["familias"])
    esta = rng.random(len(lev)) < pd.Series(fam).map(P_EN_PI01).fillna(0.3).values
    filas = []
    for i in np.where(esta)[0]:
        r = lev.iloc[i]
        copias = 2 if rng.random() < 0.06 else 1                                   # Equifax repetido (dos fuentes)
        for c in range(copias):
            nombre, tipo = _variar_nombre(r["nombre"], r.get("marca"), rng)
            dist = min(float(rng.lognormal(np.log(30), 0.8)), 260.0) if rng.random() > 0.03 else float(rng.uniform(150, 280))
            filas.append({"nombre": nombre, "marca": str(r["marca"]).upper() if isinstance(r.get("marca"), str) and rng.random() < 0.4 else None,
                          "direccion": _variar_direccion(r.get("direccion"), rng), "familia": fam[i], "lon": r["lon"], "lat": r["lat"], "dist": dist,
                          "verdad": "duplicado del levantamiento" if c == 0 else "duplicado dentro de Equifax",
                          "id_universo_verdad": r["id_universo"], "variacion": tipo})
    dup = pd.DataFrame(filas)
    # lugares que solo están en Equifax: la mitad en cualquier parte, la otra mitad pegados a un lugar del levantamiento
    # (mismo edificio o galería, OTRO negocio): son los casos difíciles, que NO deben unirse
    n_nuevos = int(0.35 * len(dup))
    fams = rng.choice(["medica", "dental", "farmacia", "laboratorio", "kine", "optica", "hospital"], n_nuevos, p=[.32, .28, .12, .08, .1, .08, .02])
    plantillas = {"medica": ["Centro Médico {a}", "Consulta Dr. {a}", "Centro de Especialidades {l}", "Policlínico {a}"],
                  "dental": ["Clínica Dental {a}", "Dental {l}", "Centro Odontológico {a}"], "farmacia": ["Farmacia {a}", "Farmacia Popular {l}"],
                  "laboratorio": ["Laboratorio Clínico {a}"], "kine": ["Kinesiología {a}"], "optica": ["Óptica {a}"], "hospital": ["Clínica {a}"]}
    nombres = [plantillas[f][rng.integers(len(plantillas[f]))].format(a=APELLIDOS[rng.integers(len(APELLIDOS))], l=LUGARES[rng.integers(len(LUGARES))])
               for f in fams]
    cerca = rng.random(n_nuevos) < 0.5
    la, lo = puntos_en(rng.choice(n_manzanas, n_nuevos, p=pob / pob.sum()))
    k = rng.integers(0, len(lev), n_nuevos)
    nuevos = pd.DataFrame({"nombre": nombres, "marca": None, "direccion": None, "familia": fams,
                           "lon": np.where(cerca, lev["lon"].values[k], lo), "lat": np.where(cerca, lev["lat"].values[k], la),
                           "dist": np.where(cerca, rng.uniform(5, 60, n_nuevos), 0.0), "verdad": "nuevo", "id_universo_verdad": None,
                           "variacion": np.where(cerca, "nuevo junto a otro lugar", "nuevo")})
    vet = pd.DataFrame({"nombre": [f"Veterinaria {APELLIDOS[rng.integers(len(APELLIDOS))]}" for _ in range(300)], "marca": None, "direccion": None,
                        "familia": "veterinaria", "lon": 0.0, "lat": 0.0, "dist": 0.0, "verdad": "no es salud humana", "id_universo_verdad": None,
                        "variacion": "veterinaria"})
    vet["lat"], vet["lon"] = puntos_en(rng.choice(n_manzanas, 300, p=pob / pob.sum()))
    t = pd.concat([dup, nuevos, vet], ignore_index=True)
    t["lon"], t["lat"] = _desplazar(t["lon"].values.astype(float), t["lat"].values.astype(float), t["dist"].values.astype(float), rng)
    t["ID_POI"] = np.arange(primer_id, primer_id + len(t))
    # la copia repetida apunta al registro de Equifax que duplica (el anterior del mismo lugar)
    t["id_poi_original"] = np.where(t["verdad"] == "duplicado dentro de Equifax", t["ID_POI"] - 1, np.nan)
    cat = t["familia"].map(CAT_PI01)
    cat = cat.where(cat.notna(), pd.Series([("Salud", "Veterinarias", None)] * len(t)))
    po = pd.DataFrame({"COD_CNTRY": "CL", "ID_POI": t["ID_POI"].values, "SOURCE": rng.choice(["WEB Easy", "Overture", None], len(t)), "ID_SOURCE": None,
                       "COD_APD3": None, "COD_CITY": None, "ZIP_COD": None, "CAT1_DES": [c[0] for c in cat], "CAT2_DES": [c[1] for c in cat],
                       "CAT3_DES": [c[2] for c in cat], "CAT_ENG": None, "BRAND": t["marca"].values, "TRADENAME": t["nombre"].values,
                       "ADDRESS": t["direccion"].values, "REFERENCE": None, "HOURS": None, "PHONE": None, "PHONE2": None, "WEB": None,
                       "EMAIL": None, "OBS": None, "LON_X": t["lon"].values, "LAT_Y": t["lat"].values, "STATUS": "ACTIVO",
                       "UPD_DATE": pd.to_datetime(rng.integers(19400, 20600, len(t)), unit="D").strftime("%Y-%m-%d"),
                       "CRE_DATE": "2020-01-01", "CHAIN": np.where(rng.random(len(t)) < 0.5, t["marca"].values, None)})
    verdad = t[["ID_POI", "verdad", "id_universo_verdad", "id_poi_original", "variacion", "dist", "nombre"]].rename(
        columns={"dist": "desplazamiento_m", "nombre": "nombre_pi01"})
    return po, verdad


def capacidad_relativa(sedes, col="m2"):
    """z_j = log(capacidad_j / mediana de su formato). 0 = tamaño típico del formato (y para sedes sin dato)."""
    cap = pd.to_numeric(sedes[col], errors="coerce") if col in sedes else pd.Series(np.nan, index=sedes.index)
    med = cap.groupby(sedes["formato_modelo"]).transform("median")
    return np.nan_to_num(np.log(cap / med).values, nan=0.0)


def sedes_modelo_desde_maestro(cfg, area):
    """Sedes del maestro que entran al modelo (mismo filtro que el notebook 02), en CRS métrico."""
    s = pd.read_csv(cfg["rutas"]["maestro_sedes"])
    txt = (s["formato"].astype(str) + " " + s["estado"].astype(str) + " " + s["tipo_registro"].astype(str)).map(norm_txt)
    s = s[~txt.str.contains("|".join(norm_txt(x) for x in cfg["excluir_sedes"]))].copy()
    s["formato_modelo"] = s["formato"].map(lambda f: cliente.formato_modelo(f, cfg))
    s = s[s["formato_modelo"].notna()]
    g = gpd.GeoDataFrame(s, geometry=gpd.points_from_xy(s["lon"], s["lat"]), crs=4326)
    g = g[g.within(area.geometry.iloc[0])].to_crs(cfg["estudio"]["crs_metrico"])
    g["x"], g["y"] = g.geometry.x, g.geometry.y
    return g.rename(columns={"id": "sede"}).reset_index(drop=True)


def _pois_salud_simulados(cfg, area, rng):
    """POIs de salud de PI01 en el formato que entrega lectura.leer_pois (para armar la competencia de la verdad)."""
    from .lectura import renombrar
    p = gpd.read_file(cfg["rutas"]["pois"])
    p = renombrar(p, cfg["columnas"]["pois"], "pois")
    p["categoria_txt"] = (p["cat1"].fillna("") + " | " + p["cat2"].fillna("") + " | " + p["cat3"].fillna("")).map(norm_txt)
    return p[p.within(area.geometry.iloc[0])]


def _datos_cliente(cfg, sedes, sedes_m, ut, mu, censo, per, emp_ut, rng, log):
    """Ventas de 5 años, hoja de sedes, origen por zona censal, RUT seudonimizado, eventos y sitios propuestos."""
    R = cfg["rutas"]
    meses = pd.period_range("2021-11", "2026-10", freq="M")
    tasas = cfg["ventas"]["ipc_anual_aprox"]
    nivel, ipc = 1.0, []
    for p in meses:
        nivel *= (1 + tasas[p.year]) ** (1 / 12); ipc.append(nivel)
    ipc = np.array(ipc) / ipc[-1]
    estac = {1: .93, 2: .90, 3: 1.02, 4: 1.03, 5: 1.06, 6: 1.07, 7: 1.08, 8: 1.05, 9: .98, 10: 1.0, 11: .96, 12: .92}
    codigos = {s: f"S{100 + k}" for k, s in enumerate(sedes_m["id"])}
    gse_dem = (ut[[f"gasto_salud_{g}" for g in GSE]].values * np.array([VERDAD["pesos_gse"][g] for g in GSE])[None, :])
    gse_dem = gse_dem / np.maximum(gse_dem.sum(1, keepdims=True), 1e-9)
    filas = []
    vm = dict(zip(sedes["sede"], mu.sum(0)))
    for _, s in sedes_m.iterrows():
        sid = s["id"]
        fmt = cliente.formato_modelo(s["formato"], cfg) or "centro_medico"
        estacional = "estacional" in norm_txt(s["formato"]) or "estacional" in norm_txt(s["estado"])
        if sid in vm:
            base = vm[sid]
            j = list(sedes["sede"]).index(sid)
            mix_gse = (mu[:, j][:, None] * gse_dem).sum(0) / max(mu[:, j].sum(), 1)
        elif estacional or (sid.startswith("CAS") and "registro" not in norm_txt(s["formato"]) and "campus" not in norm_txt(s["formato"])):
            base = 350e6 if estacional else 0
            mix_gse = np.array([.5, .2, .15, .1, .05, 0, 0])
        else:
            continue
        if base <= 0:
            continue
        isapre = float(mix_gse @ ISAPRE_GSE)
        prev = {"Isapre": isapre * 0.92, "Fonasa": (1 - isapre) * 0.92, "Particular": 0.05, "Convenio empresa": 0.03}
        for t, p in enumerate(meses):
            f = base * estac[p.month] * (1.025 ** ((t - 59) / 12)) * rng.lognormal(0, 0.025)
            if estacional:
                f = base * (1.0 if ("Parva" in s["nombre"] and p.month in (6, 7, 8, 9)) or ("Maitencillo" in s["nombre"] and p.month in (1, 2)) else 0.0)
            if p <= pd.Period("2022-02", "M"):
                f *= 0.90                                                   # cola de pandemia (no informada)
            if sid in APERTURAS:
                a0 = pd.Period(APERTURAS[sid], "M")
                if p < a0:
                    continue
                mm = (p - a0).n + 0.5
                f *= 1 - (1 - 0.35) * np.exp(-mm / 10.0)                    # verdad de la rampa: r0 = 35%, τ = 10 meses
            if sid == "CAS-06" and pd.Period("2024-08", "M") <= p <= pd.Period("2024-10", "M"):
                f *= 0.35                                                   # remodelación
            if sid == "CAS-05" and p >= pd.Period("2023-07", "M"):
                f *= 1.0                                                    # convenio: nivel ya en la venta madura
            elif sid == "CAS-05":
                f /= 1.12                                                   # antes del convenio vendía 12% menos
            if f <= 0:
                continue
            for lin, sh in LINEAS[fmt].items():
                for pv, sp in prev.items():
                    monto = f * sh * sp * ipc[t] * rng.lognormal(0, 0.03)
                    tk = TICKET[fmt] * FACTOR_TICKET_LINEA[lin] * ipc[t]
                    filas.append({"id_sede": codigos[sid], "mes": str(p), "linea_prestacion": lin, "prevision": pv,
                                  "n_atenciones": max(1, int(round(monto / tk))), "monto_clp": int(round(monto))})
    v = pd.DataFrame(filas)
    v["n_pacientes"] = (v["n_atenciones"] / 1.35).round().clip(lower=1).astype(int)
    # problemas típicos de datos reales
    dup = v[(v["id_sede"] == codigos["CAS-09"]) & (v["mes"] == "2025-05")]
    falt = (v["id_sede"] == codigos["CAS-11"]) & (v["mes"] == "2022-09")
    pico = (v["id_sede"] == codigos["CAS-12"]) & (v["mes"] == "2023-03") & (v["prevision"] == "Isapre")
    v.loc[pico, "monto_clp"] *= 8
    nc = v.sample(25, random_state=1).assign(monto_clp=lambda x: -(x["monto_clp"] * 0.05).round().astype(int), n_atenciones=0, n_pacientes=0)
    v = pd.concat([v[~falt], dup, nc], ignore_index=True)
    v = v[["id_sede", "mes", "linea_prestacion", "prevision", "n_pacientes", "n_atenciones", "monto_clp"]]
    v.to_csv(R["ventas_cliente"], index=False, encoding="utf-8-sig")
    log(f"cliente · ventas: {len(v):,} filas, {v['mes'].min()} a {v['mes'].max()}, {v['id_sede'].nunique()} sedes")

    # hoja de sedes
    aperturas_hist = {"CAS-01": "1988-03-01", "CAS-02": "2009-08-01", "CAS-03": "2008-04-01", "CAS-05": "2016-05-01", "CAS-06": "2013-10-01",
                      "CAS-09": "2015-06-01", "CAS-10": "2018-09-01", "CAS-11": "2017-03-01", "CAS-12": "2019-11-01", "CAS-13": "2014-01-01"}
    sc = []
    for _, s in sedes_m[sedes_m["id"].isin(codigos)].iterrows():
        if s["id"].startswith(("REG", "VER")):
            continue
        fmt = cliente.formato_modelo(s["formato"], cfg) or "centro_medico"
        ap = APERTURAS.get(s["id"])
        sc.append({"id_sede": codigos[s["id"]], "nombre_sede": s["nombre"].replace("Clínica Alemana", "CAS"),
                   "formato": {"clinica": "Clínica", "centro_medico": "Centro médico", "toma_muestras": "Toma de muestras"}[fmt] + (" (estacional)" if "stacional" in str(s["estado"]) else ""),
                   "direccion": f"{str(s['direccion']).split('/')[0].strip()}, {s['comuna']}",
                   "fecha_apertura": pd.Timestamp(ap + "-01").strftime("%d-%m-%Y") if ap else pd.Timestamp(aperturas_hist.get(s["id"], "2012-01-01")).strftime("%d-%m-%Y"),
                   "fecha_cierre": None, "m2": M2_SEDE.get(s["id"], {"clinica": 60000, "centro_medico": 3500, "toma_muestras": 180}[fmt]),
                   "boxes": {"clinica": 180, "centro_medico": 40, "toma_muestras": 6}[fmt], "camas": 300 if fmt == "clinica" else 0,
                   "prestaciones": ", ".join(LINEAS[fmt].keys())})
    sc = pd.DataFrame(sc)
    sc["m2"] = sc["m2"].round()
    sc.to_csv(R["sedes_cliente"], index=False, encoding="utf-8-sig")

    # eventos informados
    ev = pd.DataFrame([
        {"id_sede": codigos["CAS-04"], "tipo": "Apertura", "desde": APERTURAS["CAS-04"], "hasta": APERTURAS["CAS-04"], "descripcion": "Inicio de operación"},
        {"id_sede": codigos["CAS-14"], "tipo": "Apertura", "desde": APERTURAS["CAS-14"], "hasta": APERTURAS["CAS-14"], "descripcion": "Inicio de operación"},
        {"id_sede": codigos["CAS-06"], "tipo": "Obras", "desde": "2024-08", "hasta": "2024-10", "descripcion": "Remodelación con cierre parcial"},
        {"id_sede": codigos["CAS-05"], "tipo": "Convenio", "desde": "2023-07", "hasta": "2023-07", "descripcion": "Nuevo convenio Fonasa MLE"}])
    ev.to_csv(R["eventos_cliente"], index=False, encoding="utf-8-sig")

    # ---------- (a) origen por ZONA CENSAL (formato alternativo): años 2024-2026, grupos con < 5 pacientes -> comuna
    pos_ut = pd.Series(np.arange(len(ut)), index=ut["ut"].values)
    mzc = pd.DataFrame({"ut": censo["ID_BLOCK"].astype(str).values, "zona": censo["REDCODE"].str[:10].values, "comuna": censo["COMUNA"].values})
    mzc = mzc[mzc["ut"].isin(pos_ut.index)].reset_index(drop=True)
    i_mz = pos_ut[mzc["ut"]].values
    filas = []
    anual = v[v["mes"] >= "2024-01"].assign(anio=lambda x: x["mes"].str[:4])
    inv = {c: s_ for s_, c in codigos.items()}
    for (cod, anio, lin), g in anual.groupby(["id_sede", "anio", "linea_prestacion"]):
        sid = inv[cod]
        if sid not in vm:
            continue
        j = list(sedes["sede"]).index(sid)
        aten = int(g["n_atenciones"].clip(lower=0).sum()); monto = float(g["monto_clp"].clip(lower=0).sum())
        p_mz = mu[i_mz, j] / mu[i_mz, j].sum()
        sin_dir = rng.binomial(aten, 0.03)
        t = pd.DataFrame({"zona": mzc["zona"].values, "comuna": mzc["comuna"].values, "n": rng.multinomial(aten - sin_dir, p_mz)})
        t = t[t["n"] > 0].groupby(["zona", "comuna"], as_index=False)["n"].sum()
        t["pac"] = rng.binomial(t["n"], 1 / 1.35).clip(1)
        chicos = t["pac"] < 5
        com = t[chicos].groupby("comuna", as_index=False)[["n", "pac"]].sum().rename(columns={"comuna": "zona"})
        com["zona"] = com["zona"].str.title()
        out = pd.concat([t[~chicos][["zona", "n", "pac"]], com, pd.DataFrame({"zona": ["SIN INFORMACION"], "n": [sin_dir], "pac": [max(1, int(sin_dir / 1.35))]})])
        out.loc[(out["pac"] < 5) & (out["zona"] != "SIN INFORMACION"), "zona"] = "SIN INFORMACION"
        out = out.groupby("zona", as_index=False)[["n", "pac"]].sum()
        out["monto"] = (monto * out["n"] / max(out["n"].sum(), 1) * rng.lognormal(0, 0.05, len(out))).round()
        filas.append(out.assign(id_sede=cod, anio=anio, linea_prestacion=lin))
    o = pd.concat(filas, ignore_index=True).rename(columns={"zona": "zona_domicilio", "pac": "n_pacientes", "n": "n_atenciones", "monto": "monto_clp"})
    o[["id_sede", "anio", "linea_prestacion", "zona_domicilio", "n_pacientes", "n_atenciones", "monto_clp"]].to_csv(R["origen_pacientes_por_zona"], index=False, encoding="utf-8-sig")
    log(f"cliente · origen por zona censal (alternativo): {len(o):,} filas")

    # ---------- (b) ATENCIONES CON RUT (formato principal): 24 meses, una fila por atención, RUT en claro como lo envía la clínica
    perg = gpd.GeoDataFrame(per[["RUTID", "GSE_PART"]], geometry=gpd.points_from_xy(per["LONGITUD_PART"], per["LATITUD_PART"]), crs=4326)
    perg = perg[np.isfinite(per["LONGITUD_PART"].values)]
    perg["ut"] = UN.IndiceManzanas(ut, ut["ut"].values, 60).asignar(perg)
    perg = perg[perg["ut"].notna()]
    perg["i"] = pos_ut[perg["ut"]].values
    perg = perg.sort_values("i")
    inicio = np.searchsorted(perg["i"].values, np.arange(len(ut)), side="left")
    cuantos = np.searchsorted(perg["i"].values, np.arange(len(ut)), side="right") - inicio
    ruts = pd.Series(perg["RUTID"].values).astype(str).str.lstrip("0").values
    gse_p = perg["GSE_PART"].values
    inicio_ventana = pd.Timestamp("2024-11-01"); dias = (pd.Timestamp("2026-10-31") - inicio_ventana).days
    partes = []
    for j, sid in enumerate(sedes["sede"]):
        fmt = sedes["formato_modelo"].iloc[j]
        n_pac = int(np.clip(vm[sid] / 1e6, 3000, 25000))
        p = mu[:, j] * (cuantos > 0)
        u_i = rng.choice(len(ut), n_pac, p=p / p.sum())
        k_p = inicio[u_i] + np.floor(rng.random(n_pac) * cuantos[u_i]).astype(int)
        visitas = np.minimum(rng.geometric(0.45, n_pac), 12)
        # 12% de los pacientes también se atiende en otra sede (elegida según el modelo en su manzana)
        otra = rng.random(n_pac) < 0.12
        pr = mu[u_i[otra]].copy(); pr[:, j] = 0
        pr = pr / np.maximum(pr.sum(1, keepdims=True), 1e-12)
        j2 = (pr.cumsum(1) < rng.random(len(pr))[:, None]).sum(1).clip(0, len(sedes) - 1)
        for kk, jj, nv in ((k_p, np.full(n_pac, j), visitas), (k_p[otra], j2, np.minimum(rng.geometric(0.6, otra.sum()), 6))):
            rep_k = np.repeat(kk, nv); rep_j = np.repeat(jj, nv)
            lineas = list(LINEAS[sedes["formato_modelo"].iloc[j]].keys())
            partes.append(pd.DataFrame({"rut_norm": ruts[rep_k], "gse": gse_p[rep_k], "j": rep_j,
                                        "fecha": inicio_ventana + pd.to_timedelta(rng.integers(0, dias, len(rep_k)), unit="D"),
                                        "linea_prestacion": rng.choice(lineas, len(rep_k))}))
    a = pd.concat(partes, ignore_index=True)
    a["formato"] = sedes["formato_modelo"].values[a["j"].values]
    a["linea_prestacion"] = np.where(a["formato"] == "toma_muestras", "Laboratorio", a["linea_prestacion"])
    a["monto_clp"] = (a["formato"].map(TICKET).values * a["linea_prestacion"].map(FACTOR_TICKET_LINEA).fillna(1).values
                      * rng.lognormal(-0.1, 0.45, len(a))).round()
    isap = pd.Series(a["gse"]).map(dict(zip(GSE, ISAPRE_GSE))).fillna(0.4).values
    a["prevision"] = np.where(rng.random(len(a)) < isap, "Isapre", np.where(rng.random(len(a)) < 0.9, "Fonasa", "Particular"))
    # 4% de los pacientes no está en la base de personas (extranjeros, menores sin registro…): RUT válido pero desconocido
    pac_u = pd.unique(a["rut_norm"])
    fuera = set(pac_u[rng.random(len(pac_u)) < 0.04])
    nuevos = dict(zip(sorted(fuera), _con_dv(rng.choice(np.arange(27_000_000, 29_000_000), len(fuera), replace=False))))
    a["rut_norm"] = a["rut_norm"].map(lambda r: nuevos.get(r, r))
    # convenios: atenciones pagadas por empresas (RUT de persona jurídica, está en emp)
    n_emp_at = int(0.03 * len(a))
    ruts_emp = pd.Series(emp_ut["RUTID"]).astype(str).values
    e = pd.DataFrame({"rut_norm": rng.choice(ruts_emp, n_emp_at), "gse": None, "j": rng.choice(len(sedes), n_emp_at, p=np.array([vm[s_] for s_ in sedes["sede"]]) / sum(vm.values())),
                      "fecha": inicio_ventana + pd.to_timedelta(rng.integers(0, dias, n_emp_at), unit="D"), "linea_prestacion": "Convenio empresa"})
    e["formato"] = sedes["formato_modelo"].values[e["j"].values]
    e["monto_clp"] = (e["formato"].map(TICKET).values * 3 * rng.lognormal(0, 0.6, n_emp_at)).round()
    e["prevision"] = "Convenio empresa"
    a = pd.concat([a, e], ignore_index=True).sample(frac=1, random_state=7)
    out = pd.DataFrame({"rut_paciente": _formato_rut(a["rut_norm"].values, rng), "id_sede": sedes["sede"].map(codigos).values[a["j"].values],
                        "fecha": a["fecha"].dt.strftime("%d-%m-%Y").values, "linea_prestacion": a["linea_prestacion"].values,
                        "prevision": a["prevision"].values, "monto_clp": a["monto_clp"].astype(int).values})
    out.to_csv(R["origen_pacientes"], index=False, encoding="utf-8-sig")
    log(f"cliente · atenciones con RUT: {len(out):,} filas · {a['rut_norm'].nunique():,} pacientes/empresas distintos")
    if R.get("origen_pacientes_sin_dv"):
        out.assign(rut_paciente=_formato_rut(a["rut_norm"].values, rng, con_dv=False)).to_csv(R["origen_pacientes_sin_dv"], index=False,
                                                                                              encoding="utf-8-sig")
        log("cliente · las mismas atenciones con el RUT SIN dígito verificador (escenario de prueba)")

    # sitios propuestos por la clínica (direcciones sobre el maestro de calles simulado)
    bc = gpd.read_file(R["street"])
    propuestas = [("APOQUINDO", "13114", "Centro médico"), ("IRARRAZAVAL", "13120", "Toma de muestras"), ("VICUNA MACKENNA", "13110", "Centro médico"),
                  ("PAJARITOS", "13119", "Centro médico"), ("CHICUREO", "13301", "Toma de muestras")]
    filas = []
    for k, (calle, cod, fmt) in enumerate(propuestas, start=1):
        t = bc[(bc["NAM_STREET"].str.contains(calle, regex=False)) & (bc["COD_APD3"] == cod)]
        if not len(t):
            t = bc[bc["NAM_STREET"].str.contains(calle, regex=False)]
        if not len(t):
            continue
        r = t.iloc[len(t) // 2]
        num = int((r["START_LEFT"] + r["END_LEFT"]) / 2) // 2 * 2
        nomcom = censo.loc[censo["COD_APD3"] == r["COD_APD3"], "COMUNA"].iloc[0].title() if (censo["COD_APD3"] == r["COD_APD3"]).any() else ""
        filas.append({"nombre": f"Propuesta {k}", "direccion": f"Av. {r['NAM_STREET'].title()} {num}, {nomcom}", "formato": fmt})
    pd.DataFrame(filas).to_csv(R["sitios_propuestos"], index=False, encoding="utf-8-sig")
    log(f"cliente · {len(filas)} sitios propuestos")


# --------------------------------------------------------------------------------------------- VARIANTES DE VENTAS
def _repartir_enteros(total, grupos, pesos):
    """Reparte el entero total[g] entre las filas del grupo g según `pesos`, con enteros que suman EXACTO el total."""
    w = pesos / np.bincount(grupos, weights=pesos)[grupos]
    x = total[grupos] * w
    base = np.floor(x).astype(np.int64)
    falta = (total - np.bincount(grupos, weights=base).round().astype(np.int64))
    orden = np.lexsort((-(x - base), grupos))                       # dentro de cada grupo, de mayor a menor fracción
    rango = np.arange(len(grupos)) - np.searchsorted(grupos[orden], grupos[orden])
    suma = np.zeros(len(grupos), np.int64)
    suma[orden] = (rango < falta[grupos[orden]]).astype(np.int64)
    return base + suma


def variantes_ventas(ruta_base, carpeta, semilla=7):
    """Variantes de la tabla de ventas simulada para comprobar que el estudio se adapta a datos distintos (las usa
    constructor/probar_escenarios.py). Todas representan la MISMA venta (salvo ×10, ÷20 y la historia corta), así que
    la venta madura de cada sede debe salir igual que con la tabla original. Devuelve {nombre: ruta}."""
    os.makedirs(carpeta, exist_ok=True)
    v = pd.read_csv(ruta_base, dtype={"monto_clp": "int64"})
    rng = np.random.default_rng(semilla)
    out = {}

    def escribir(df, nombre):
        ruta = os.path.join(carpeta, nombre)
        df.to_csv(ruta, index=False, encoding="utf-8-sig")
        out[nombre[:-4]] = ruta
    # 1. en miles de pesos, con la unidad en el nombre de la columna
    escribir(v.assign(monto_clp=(v["monto_clp"] / 1e3).round(3)).rename(columns={"monto_clp": "venta_miles"}), "ventas_en_miles.csv")
    # 2. en millones, con coma decimal chilena y SIN la unidad en el nombre: se reconoce por la magnitud y el ticket
    escribir(v.assign(monto_clp=(v["monto_clp"] / 1e6).map(lambda x: f"{x:.6f}".replace(".", ","))).rename(columns={"monto_clp": "monto"}),
             "ventas_en_millones.csv")
    # 3. unidad ambigua: sin atenciones y sin la unidad en el nombre (en pesos y en miles las cifras son posibles)
    escribir(v.drop(columns=["n_atenciones", "n_pacientes"]).rename(columns={"monto_clp": "monto"}), "ventas_unidad_ambigua.csv")
    # 4. una red 10 veces más grande y una 20 veces más chica (en pesos)
    for k, nombre in ((10.0, "ventas_x10.csv"), (1 / 20, "ventas_div20.csv")):
        escribir(v.assign(monto_clp=(v["monto_clp"] * k).round().astype("int64")), nombre)
    # 5. transaccional: cada sede × mes × línea × previsión se reparte en 3 a 30 filas con fecha diaria (los montos y las
    #    atenciones suman exacto lo original) y ~1% de las filas son idénticas a otra (dos atenciones del mismo valor).
    #    Parte de la tabla SIN los duplicados de error que trae la simulación: en una tabla transaccional un duplicado de
    #    carga no se puede distinguir de dos atenciones iguales (por eso allí no se eliminan).
    v = v.drop_duplicates()
    k = np.clip(v["n_atenciones"].values // 40, 3, 30)
    g = np.repeat(np.arange(len(v)), k)
    monto = _repartir_enteros(v["monto_clp"].values, g, rng.gamma(2.0, size=len(g)))
    aten = _repartir_enteros(v["n_atenciones"].values, g, rng.gamma(2.0, size=len(g)))
    per = pd.PeriodIndex(v["mes"].values[g], freq="M")
    dia = np.minimum(rng.integers(1, 29, len(g)), per.days_in_month)
    t = pd.DataFrame({"id_sede": v["id_sede"].values[g], "fecha_atencion": [f"{d:02d}-{p.month:02d}-{p.year}" for d, p in zip(dia, per)],
                      "linea_prestacion": v["linea_prestacion"].values[g], "prevision": v["prevision"].values[g],
                      "n_atenciones": aten, "monto_clp": monto})
    par = np.flatnonzero((t["monto_clp"].values % 2 == 0) & (t["n_atenciones"].values % 2 == 0) & (t["n_atenciones"].values >= 2))
    dup = rng.choice(par, size=min(len(par), len(t) // 100), replace=False)
    t.loc[dup, ["monto_clp", "n_atenciones"]] //= 2
    t = pd.concat([t, t.loc[dup]], ignore_index=True).sort_values(["id_sede", "fecha_atencion"], kind="stable")
    escribir(t, "ventas_transaccionales.csv")
    # 6. historia corta: solo los últimos 18 meses (con sus duplicados de error, como la tabla original)
    v = pd.read_csv(ruta_base, dtype={"monto_clp": "int64"})
    meses = sorted(v["mes"].unique())
    escribir(v[v["mes"].isin(meses[-18:])], "ventas_historia_corta.csv")
    return out



# --------------------------------------------------------------------------------------------- VARIANTES DE COORDENADAS
def _gms(v, hem_neg):
    """-33.4372 → 33°26'13.9200"S (grados, minutos y segundos con hemisferio)."""
    a = abs(v)
    g = int(a)
    m = int((a - g) * 60)
    sec = ((a - g) * 60 - m) * 60
    return f"{g}°{m}'{sec:.4f}\"{hem_neg if v < 0 else 'N'}"


def _escribir_coordenadas(lat, lon, rng, prop):
    """Coordenadas como TEXTO en formatos mezclados (como llegan de distintas fuentes). prop: proporciones de cada caso.
    Devuelve (lat_txt, lon_txt, caso) — caso dice qué se hizo en cada fila."""
    n = len(lat)
    lat, lon = np.asarray(lat, float), np.asarray(lon, float)
    caso = rng.choice(list(prop), size=n, p=np.array(list(prop.values())) / sum(prop.values())).astype(object)
    caso[~(np.isfinite(lat) & np.isfinite(lon))] = "vacia"            # sin coordenada: queda vacía
    la = pd.Series(lat).map("{:.6f}".format).to_numpy(object)
    lo = pd.Series(lon).map("{:.6f}".format).to_numpy(object)
    la[caso == "vacia"], lo[caso == "vacia"] = "", ""
    c = caso == "coma"
    la[c] = [x.replace(".", ",") for x in la[c]]; lo[c] = [x.replace(".", ",") for x in lo[c]]
    c = caso == "escalada"                     # sin punto decimal: × 1.000.000
    la[c] = np.round(lat[c] * 1e6).astype(np.int64).astype(str); lo[c] = np.round(lon[c] * 1e6).astype(np.int64).astype(str)
    c = caso == "miles"                        # escalada y con separador de miles de Excel: -33.437.200
    la[c] = [f"{int(round(x * 1e6)):,}".replace(",", ".") for x in lat[c]]; lo[c] = [f"{int(round(x * 1e6)):,}".replace(",", ".") for x in lon[c]]
    c = caso == "gms"
    la[c] = [_gms(x, "S") for x in lat[c]]; lo[c] = [_gms(x, "W") for x in lon[c]]
    c = caso == "sin_signo"
    la[c] = [x.lstrip("-") for x in la[c]]; lo[c] = [x.lstrip("-") for x in lo[c]]
    c = caso == "intercambiada"
    la[c], lo[c] = lo[c].copy(), la[c].copy()
    c = caso == "menos_tipografico"
    la[c] = [x.replace("-", "\u2212") for x in la[c]]; lo[c] = [x.replace("-", "\u2212").replace(".", ",") for x in lo[c]]
    return la, lo, caso


def variantes_coordenadas(cfg, carpeta, semilla=11):
    """Copias de las bases de puntos con las coordenadas escritas en formatos mezclados (coma decimal, sin punto decimal,
    separadores de miles, grados/minutos/segundos, sin signo, lat/lon intercambiadas, signo menos tipográfico). Todas
    representan los MISMOS puntos: leídas con `coordenadas.leer` deben dar lo mismo que las originales.
    Devuelve {clave de RUTAS: ruta de la variante}."""
    os.makedirs(carpeta, exist_ok=True)
    rng = np.random.default_rng(semilla)
    prop = {"punto": 0.40, "coma": 0.30, "escalada": 0.08, "miles": 0.05, "gms": 0.05, "sin_signo": 0.05, "intercambiada": 0.04,
            "menos_tipografico": 0.03}
    C, rutas, out = cfg["columnas"], cfg["rutas"], {}
    for base in ("emp", "bbrr"):                                       # .txt con separador "|"
        df = pd.read_csv(rutas[base], sep=cfg.get("separador_txt", "|"), dtype=str, keep_default_na=False)
        la, lo, _ = _escribir_coordenadas(pd.to_numeric(df[C[base]["lat"]]), pd.to_numeric(df[C[base]["lon"]]), rng, prop)
        df[C[base]["lat"]], df[C[base]["lon"]] = la, lo
        destino = os.path.join(carpeta, os.path.basename(rutas[base]))
        df.to_csv(destino, sep=cfg.get("separador_txt", "|"), index=False)
        out[base] = destino
    per = pd.read_parquet(rutas["per"])                                 # parquet con las coordenadas como texto
    la, lo, _ = _escribir_coordenadas(per[C["per"]["lat"]], per[C["per"]["lon"]], rng, prop)
    per[C["per"]["lat"]], per[C["per"]["lon"]] = la.astype(str), lo.astype(str)
    out["per"] = os.path.join(carpeta, os.path.basename(rutas["per"]))
    per.to_parquet(out["per"], index=False)
    for clave in ("maestro_sedes", "competencia"):                     # CSV del levantamiento
        df = pd.read_csv(rutas[clave], dtype=str, keep_default_na=False, encoding="utf-8-sig")
        ok = pd.to_numeric(df["lat"], errors="coerce").notna() & pd.to_numeric(df["lon"], errors="coerce").notna()
        la, lo, _ = _escribir_coordenadas(pd.to_numeric(df.loc[ok, "lat"]), pd.to_numeric(df.loc[ok, "lon"]), rng, prop)
        df.loc[ok, "lat"], df.loc[ok, "lon"] = la, lo
        out[clave] = os.path.join(carpeta, os.path.basename(rutas[clave]))
        df.to_csv(out[clave], index=False, encoding="utf-8-sig")
    return out
