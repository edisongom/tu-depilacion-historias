# -*- coding: utf-8 -*-
"""Red vial e isócronas con OSMnx.

Idea central: el tiempo de viaje se mide SOBRE LA RED DE CALLES (no en línea recta). Por eso las áreas de influencia
son ISÓCRONAS y no buffers: una isócrona de 10 minutos es el conjunto de lugares desde los que se llega a la sede en
10 minutos o menos por las calles reales, respetando sentidos de tránsito, autopistas, ríos y cerros.

Flujo:
  1. `cargar_grafo`: lee el GraphML de la región con OSMnx (`ox.load_graphml`), lo recorta al área de estudio y, si
     faltan, agrega velocidades y tiempos (`ox.routing.add_edge_speeds` / `add_edge_travel_times`).
  2. `construir_red`: arma matrices de tiempo para 4 modos:
        auto_valle  tiempo del grafo (velocidad de cada vía)
        auto_punta  tiempo del grafo ÷ factor de congestión por tipo de vía
        pie         4,8 km/h en ambos sentidos
        tp          transporte público: caminata + bus (aprox. por vías principales) + líneas GTFS (metro, buses)
  3. `tiempos_*`: Dijkstra (scipy) desde cada destino sobre el grafo invertido = tiempo DESDE cada esquina HACIA el destino.
  4. `isocronas_punto`: polígono de las calles alcanzadas (+ franja de 60 m).
  `isocrona_osmnx_referencia` hace lo mismo con networkx (`nx.ego_graph`), la receta clásica de OSMnx, para verificar.
"""
import glob
import io
import os
import zipfile

import numpy as np
import pandas as pd
import geopandas as gpd
import shapely
from scipy import sparse
from scipy.sparse import csgraph
from scipy.spatial import cKDTree

from .utilidades import Cronometro, n_nucleos, en_paralelo

RANGO_VIA = {"motorway": 6, "trunk": 5, "primary": 4, "secondary": 3, "tertiary": 2, "unclassified": 1, "residential": 1}
MODOS = ("auto_punta", "auto_valle", "pie", "tp")


class Red:
    """Contenedor de la red: coordenadas de nodos, aristas y matrices de tiempo por modo."""

    def resumen(self):
        return pd.DataFrame({"indicador": ["nodos", "aristas", "nodos en la componente principal (auto)", "km de red",
                                           "nodos totales red TP (capas)"],
                             "valor": [len(self.nodos), len(self.u), int(self.en_scc.sum()), round(self.largo.sum() / 1000 / 2, 0),
                                       self.M["tp"].shape[0] if "tp" in self.M else 0]})


def _primero(v):
    if isinstance(v, list):
        return str(v[0]) if v else ""
    return "" if v is None or (isinstance(v, float) and np.isnan(v)) else str(v)


def archivos_grafo(cfg):
    """Nombres de los GraphML elegidos en config_estudio.GRAFOS_VIALES (siempre lista)."""
    g = cfg["estudio"].get("grafos")
    if not g:
        return []
    return [g] if isinstance(g, str) else [str(x) for x in g]


def grafos_disponibles(carpeta):
    """Archivos .graphml (o .graphml.gz) que hay en la carpeta de grafos (y sus subcarpetas)."""
    if not carpeta or not os.path.isdir(carpeta):
        return []
    return sorted({os.path.basename(p) for p in glob.glob(os.path.join(carpeta, "**", "*.graphml*"), recursive=True)})


def buscar_grafos(cfg):
    """Ruta de cada GraphML de GRAFOS_VIALES, buscado por su NOMBRE EXACTO en la carpeta de grafos (acepta el nombre con o
    sin .graphml y la versión comprimida .graphml.gz). No se deduce nada del código de región."""
    import difflib
    carpeta = cfg["rutas"]["grafos"]
    disponibles = grafos_disponibles(carpeta)
    rutas = []
    for nombre in archivos_grafo(cfg):
        base = nombre if nombre.lower().endswith((".graphml", ".graphml.gz")) else nombre + ".graphml"
        cand = [base, base + ".gz"] if base.lower().endswith(".graphml") else [base]
        hallado = [p for c in cand for p in glob.glob(os.path.join(carpeta, "**", c), recursive=True)]
        if not hallado:
            parecidos = difflib.get_close_matches(base, disponibles, n=1, cutoff=0.7)
            raise FileNotFoundError(f"No está {base} en {carpeta}" + (f" (¿quisiste decir {parecidos[0]}?)" if parecidos else ""))
        rutas.append(sorted(hallado, key=len)[0])
    return rutas


def _leer_graphml(ruta, log):
    import osmnx as ox
    if ruta.endswith(".gz"):
        import gzip, shutil, tempfile
        tmp = os.path.join(tempfile.gettempdir(), os.path.basename(ruta)[:-3])
        if not os.path.exists(tmp):
            with gzip.open(ruta, "rb") as f, open(tmp, "wb") as g:
                shutil.copyfileobj(f, g)
        ruta = tmp
    log(f"cargando grafo {os.path.basename(ruta)} con osmnx.load_graphml …")
    G = ox.load_graphml(ruta)
    log(f"  {G.number_of_nodes():,} nodos · {G.number_of_edges():,} aristas")
    return G


def cargar_grafo(cfg, area=None, cronometro=None):
    """Carga el grafo de cada región del estudio con OSMnx, lo recorta al área de estudio, une las regiones (los nodos
    son ids de OSM: las calles que cruzan el límite regional se unen solas) y asegura velocidades y tiempos de viaje."""
    import osmnx as ox
    import networkx as nx
    log = cronometro or Cronometro()
    poly = area.to_crs("EPSG:4326").geometry.iloc[0] if area is not None else None
    partes = []
    for ruta in buscar_grafos(cfg):
        G = _leer_graphml(ruta, log)
        if poly is not None:                      # se recorta cada región antes de unir: la memoria no se suma
            try:
                G = ox.truncate.truncate_graph_polygon(G, poly, truncate_by_edge=True)
            except ValueError:                    # la región no toca el área de estudio
                log("  no toca el área de estudio: se omite")
                continue
            log(f"  recortado al área de estudio: {G.number_of_nodes():,} nodos · {G.number_of_edges():,} aristas")
        partes.append(G)
    if not partes:
        raise ValueError("Ningún grafo de GRAFOS_VIALES toca el área de estudio: revisa en config_estudio.py que sean los de las regiones del estudio")
    G = partes[0] if len(partes) == 1 else nx.compose_all(partes)
    if len(partes) > 1:
        log(f"regiones unidas: {G.number_of_nodes():,} nodos · {G.number_of_edges():,} aristas")
    del partes
    falta = any(("speed_kph" not in d or "travel_time" not in d) for _, _, d in list(G.edges(data=True))[:1000])
    if falta:
        V = cfg["red"]["velocidad_por_defecto_kph"]
        rutas = getattr(ox, "routing", None) or ox.speed              # osmnx 2.x: ox.routing · osmnx 1.x: ox.speed
        G = rutas.add_edge_speeds(G, hwy_speeds={k: v for k, v in V.items() if k != "default"}, fallback=V["default"])
        G = rutas.add_edge_travel_times(G)
        log("velocidades y tiempos agregados con osmnx.routing")
    return G


def _segmentos_aristas(geoms, lon, lat, u, v, crs):
    """Segmentos rectos que forman la geometría REAL de cada arista (las calles curvas del grafo simplificado de OSMnx).
    Devuelve (inicio, fin, arista) en CRS métrico, 100% vectorizado. Aristas sin geometría = recta entre sus nodos."""
    from pyproj import Transformer
    tiene = np.array([g is not None and not isinstance(g, float) for g in geoms])
    lineas = [g for g, t in zip(geoms, tiene) if t]
    ids = np.where(tiene)[0]
    if lineas:
        xy, k = shapely.get_coordinates(np.array(lineas, dtype=object), return_index=True)
        e = ids[k]
    else:
        xy, e = np.zeros((0, 2)), np.zeros(0, int)
    sin = np.where(~tiene)[0]
    xy = np.r_[xy, np.c_[lon[u[sin]], lat[u[sin]]], np.c_[lon[v[sin]], lat[v[sin]]]]
    e = np.r_[e, sin, sin]
    orden = np.argsort(e, kind="stable")                      # puntos de cada arista contiguos y en orden
    xy, e = xy[orden], e[orden]
    X, Y = Transformer.from_crs("EPSG:4326", crs, always_xy=True).transform(xy[:, 0], xy[:, 1])
    P = np.c_[X, Y]
    mismo = e[1:] == e[:-1]
    return P[:-1][mismo].astype(np.float32), P[1:][mismo].astype(np.float32), e[:-1][mismo].astype(np.int64)


def construir_red(G, cfg, gtfs=None, cronometro=None):
    """Arma la red para los 4 modos. `gtfs`: ruta a un GTFS (zip o carpeta) para transporte público (opcional)."""
    log = cronometro or Cronometro()
    R = cfg["red"]
    nodos = np.array(list(G.nodes))
    idx = {n: i for i, n in enumerate(nodos)}
    lon = np.array([G.nodes[n]["x"] for n in nodos], float)
    lat = np.array([G.nodes[n]["y"] for n in nodos], float)
    pts = gpd.GeoSeries(gpd.points_from_xy(lon, lat), crs="EPSG:4326").to_crs(cfg["estudio"]["crs_metrico"])
    u, v, L, T, H, NOM, GEO = [], [], [], [], [], [], []
    for a, b, d in G.edges(data=True):
        u.append(idx[a]); v.append(idx[b]); GEO.append(d.get("geometry"))
        largo = float(d.get("length", 0) or 0)
        tt = d.get("travel_time")
        try:
            tt = float(tt)
        except (TypeError, ValueError):
            tt = largo / (float(d.get("speed_kph", 30) or 30) / 3.6)
        L.append(largo); T.append(tt); H.append(_primero(d.get("highway")).replace("_link", "")); NOM.append(_primero(d.get("name")))
    red = Red()
    red.nodos, red.lon, red.lat = nodos, lon, lat
    red.x, red.y = pts.x.values, pts.y.values
    red.u, red.v = np.array(u), np.array(v)
    red.largo, red.highway, red.nombre = np.array(L), np.array(H), np.array(NOM)
    red.seg_a, red.seg_b, red.seg_e = _segmentos_aristas(GEO, lon, lat, red.u, red.v, cfg["estudio"]["crs_metrico"])
    n = len(nodos)
    red.n = n
    fac = np.array([R["factor_punta"].get(h, R["factor_punta"]["default"]) for h in red.highway])
    vcam = R["velocidad_caminata_kmh"] / 3.6
    red.t_arista = {"auto_valle": np.array(T), "auto_punta": np.array(T) / fac}
    red.Mf = {}
    for m in ("auto_valle", "auto_punta"):
        red.Mf[m] = sparse.csr_matrix((red.t_arista[m] + 1e-3, (red.u, red.v)), shape=(n, n))
    red.Mf["pie"] = sparse.csr_matrix((np.r_[red.largo, red.largo] / vcam + 1e-3, (np.r_[red.u, red.v], np.r_[red.v, red.u])), shape=(n, n))
    # componente principal fuertemente conexa (auto): los puntos se "pegan" a nodos de ella
    _, lab = csgraph.connected_components(red.Mf["auto_valle"], directed=True, connection="strong")
    red.en_scc = lab == np.bincount(lab).argmax()
    rango = np.zeros(n)
    rv = np.array([RANGO_VIA.get(h, 0) for h in red.highway])
    np.maximum.at(rango, red.u, rv); np.maximum.at(rango, red.v, rv)
    red.rango_via = rango
    red.id_scc = np.where(red.en_scc)[0]
    red.kd_scc = cKDTree(np.c_[red.x[red.id_scc], red.y[red.id_scc]])
    log(f"red base: {n:,} nodos · {len(red.u):,} aristas · componente principal {red.en_scc.mean():.1%}")
    red.Mf["tp"], red.tp_info = _red_tp(red, cfg, gtfs, log)
    # matrices "hacia": traspuestas (Dijkstra desde el destino entrega el tiempo de cada nodo HACIA el destino)
    red.M = {m: red.Mf[m].T.tocsr() for m in red.Mf}
    return red


# --------------------------------------------------------------------------------------------- TRANSPORTE PÚBLICO
def _red_tp(red, cfg, gtfs, log):
    """Red multicapa de transporte público.
       capa 0 (nodos 0..n-1)      caminata (toda la red, ambos sentidos)
       capa 1 (nodos n..2n-1)     bus aproximado sobre vías principales (si tp.bus_aproximado)
       capas GTFS                 un nodo por (patrón de recorrido, parada); tiempos programados
    Subir a un bus o línea cuesta la espera (½ intervalo); bajarse no cuesta."""
    P = cfg["tp"]; R = cfg["red"]
    n = red.n
    vcam = R["velocidad_caminata_kmh"] / 3.6
    filas, cols, val = [np.r_[red.u, red.v]], [np.r_[red.v, red.u]], [np.r_[red.largo, red.largo] / vcam]
    info = {"bus_aproximado": False, "lineas_gtfs": 0, "paradas_gtfs": 0}
    total = 2 * n
    if P.get("bus_aproximado"):
        es_bus = np.isin(red.highway, P["vias_bus"])
        vb = np.array([P["velocidad_bus_kmh"].get(h, 13) for h in red.highway[es_bus]]) / 3.6
        tb = np.maximum(red.largo[es_bus] / vb, red.t_arista["auto_punta"][es_bus])   # el bus no va más rápido que el auto en punta
        filas.append(red.u[es_bus] + n); cols.append(red.v[es_bus] + n); val.append(tb)
        nb = np.unique(np.r_[red.u[es_bus], red.v[es_bus]])
        filas += [nb, nb + n]; cols += [nb + n, nb]; val += [np.full(len(nb), P["espera_bus_min"] * 60), np.zeros(len(nb))]
        info["bus_aproximado"] = True
        info["km_red_bus"] = float(red.largo[es_bus].sum() / 1000)
    if gtfs:
        try:
            seg, sub, n_lin, n_par = _gtfs_a_aristas(gtfs, red, cfg, total)
            if len(seg):
                filas.append(seg[:, 0]); cols.append(seg[:, 1]); val.append(seg[:, 2])
                filas.append(sub[:, 0]); cols.append(sub[:, 1]); val.append(sub[:, 2])
                total = int(max(seg[:, :2].max(), sub[:, :2].max()) + 1)
                info["lineas_gtfs"], info["paradas_gtfs"] = n_lin, n_par
        except Exception as e:  # el GTFS es opcional: si falla se informa y se sigue con la aproximación
            log(f"GTFS no utilizable ({e}); se sigue sin él")
    f = np.concatenate(filas).astype(np.int64); c = np.concatenate(cols).astype(np.int64); w = np.concatenate(val) + 1e-3
    M = sparse.csr_matrix((w, (f, c)), shape=(total, total))
    log(f"red de transporte público: {total:,} nodos (caminata + bus{' + GTFS' if info['lineas_gtfs'] else ''}) · "
        f"{info['lineas_gtfs']} recorridos GTFS")
    return M, info


def _leer_gtfs(ruta):
    def abrir(nombre):
        if os.path.isdir(ruta):
            p = os.path.join(ruta, nombre)
            return pd.read_csv(p, dtype=str) if os.path.exists(p) else None
        with zipfile.ZipFile(ruta) as z:
            nombres = {os.path.basename(x): x for x in z.namelist()}
            return pd.read_csv(io.BytesIO(z.read(nombres[nombre])), dtype=str) if nombre in nombres else None
    return {k: abrir(f"{k}.txt") for k in ("stops", "routes", "trips", "stop_times")}


def _seg(hhmmss):
    h, m, s = (str(hhmmss).strip().split(":") + ["0", "0"])[:3]
    return int(h) * 3600 + int(m) * 60 + int(float(s))


def _gtfs_a_aristas(ruta, red, cfg, base):
    """Aristas de las líneas GTFS: tramos entre paradas consecutivas (tiempos programados de un viaje en punta),
    subidas (caminata a la parada + espera = ½ intervalo) y bajadas (caminata desde la parada)."""
    P = cfg["tp"]; vcam = cfg["red"]["velocidad_caminata_kmh"] / 3.6
    g = _leer_gtfs(ruta)
    st, trips, stops, routes = g["stop_times"], g["trips"], g["stops"], g["routes"]
    st = st.merge(trips[["trip_id", "route_id"] + (["direction_id"] if "direction_id" in trips else [])], on="trip_id")
    if "direction_id" not in st:
        st["direction_id"] = "0"
    st["t"] = st["departure_time"].fillna(st["arrival_time"]).map(_seg)
    st["stop_sequence"] = st["stop_sequence"].astype(int)
    st = st.sort_values(["trip_id", "stop_sequence"])
    ini = st.groupby("trip_id")["t"].min()
    a, b = (_seg(x) for x in P["ventana_punta_gtfs"])
    en_punta = ini[(ini >= a) & (ini <= b)]
    tipo = routes.set_index("route_id")["route_type"].astype(int) if "route_type" in routes else pd.Series(dtype=int)
    stops = stops.copy()
    sx = gpd.GeoSeries(gpd.points_from_xy(stops["stop_lon"].astype(float), stops["stop_lat"].astype(float)), crs="EPSG:4326").to_crs(cfg["estudio"]["crs_metrico"])
    d_snap, j = cKDTree(np.c_[red.x, red.y]).query(np.c_[sx.x, sx.y])
    snap = dict(zip(stops["stop_id"], zip(j, d_snap)))
    seg, sub = [], []
    nid = base
    n_lin = 0
    for (rid, did), d in st.groupby(["route_id", "direction_id"]):
        viajes = d["trip_id"].unique()
        en = [t for t in viajes if t in en_punta.index]
        rep = en[0] if en else viajes[0]
        # espera = mitad del intervalo en punta (viajes que parten en la ventana); sin viajes en punta, el valor por defecto
        espera_def = 60 * (P["espera_metro_min"] if int(tipo.get(rid, 3)) in (1, 2) else P["espera_bus_min"])
        espera = (b - a) / len(en) / 2 if en else espera_def
        espera = min(espera, 60 * P["max_espera_min"])
        r = d[d["trip_id"] == rep].sort_values("stop_sequence")
        ids = list(range(nid, nid + len(r))); nid += len(r)
        tt = r["t"].values
        for k in range(len(r) - 1):
            seg.append((ids[k], ids[k + 1], max(30.0, float(tt[k + 1] - tt[k]))))
        for k, sid in enumerate(r["stop_id"].values):
            jj, dd = snap[sid]
            acceso = dd / vcam
            sub.append((jj, ids[k], acceso + espera))      # subir: caminar a la parada + esperar
            sub.append((ids[k], jj, acceso))                 # bajar: caminar desde la parada
        n_lin += 1
    return np.array(seg, float), np.array(sub, float), n_lin, len(stops)


# --------------------------------------------------------------------------------------------- TIEMPOS
def nodo_cercano(red, x, y):
    """Nodo de la componente principal más cercano a coordenadas métricas: (índices, distancias en m)."""
    d, i = red.kd_scc.query(np.c_[np.atleast_1d(x), np.atleast_1d(y)])
    return red.id_scc[i], d


def _dijkstra_bloque(M, destinos, limite_s, cols, n, lote):
    """Trabajo de UN proceso: Dijkstra desde un bloque de destinos (en lotes para acotar la RAM)."""
    out = []
    for i in range(0, len(destinos), lote):
        D = csgraph.dijkstra(M, directed=True, indices=destinos[i:i + lote], limit=limite_s)
        out.append(((D[:, cols] if cols is not None else D[:, :n]) / 60).astype(np.float32))
    return np.vstack(out)


def tiempos_hacia(red, nodos_destino, modo, horizonte_min, cols=None, cfg=None, n_jobs=None):
    """Minutos desde cada nodo (o solo los nodos `cols`) HACIA cada destino: matriz (n_destinos × n_cols), inf = fuera
    del horizonte. Paralelo: los destinos se reparten entre los núcleos; destinos repetidos se calculan una sola vez."""
    nd = np.asarray(nodos_destino)
    ncol = len(cols) if cols is not None else red.n
    if not len(nd):
        return np.zeros((0, ncol), np.float32)
    u, inv = np.unique(nd, return_inverse=True)
    nj = n_jobs or n_nucleos(cfg)
    lote = (cfg or {}).get("computo", {}).get("lote_dijkstra", 24)
    partes = np.array_split(u, max(1, min(len(u), nj * 3)))      # ~3 tareas por núcleo para balancear la carga
    res = en_paralelo(_dijkstra_bloque, [(red.M[modo], p, 60 * horizonte_min, cols, red.n, lote) for p in partes if len(p)],
                      n_jobs=nj)
    return np.vstack(res)[inv]


def velocidad_acceso(cfg, modo):
    """Velocidad del tramo punto -> nodo más cercano (punto interior de la manzana a la calle; sede a la calle)."""
    return cfg["red"]["acceso_auto_kmh"] if modo.startswith("auto") else cfg["red"]["velocidad_caminata_kmh"]


def preparar_unidades(red, ut):
    """Nodo de red más cercano y distancia de acceso (m) de cada manzana, desde su punto interior (cx, cy).
    Se calcula una vez y se reutiliza en todas las matrices de tiempos."""
    return nodo_cercano(red, ut["cx"].values, ut["cy"].values)


def tiempos_a_puntos(red, ut, xy, modo, cfg, horizonte_min=None, nodos_ut=None):
    """Matriz (n_manzanas × n_puntos) de minutos desde cada manzana hasta cada punto (sede, competidor, candidato),
    incluyendo el tramo de acceso a la red en ambos extremos (a 15 km/h en auto, a pie en los otros modos).
    ∞ = fuera del horizonte de viaje. `nodos_ut` = resultado de `preparar_unidades` (evita recalcularlo)."""
    horizonte_min = horizonte_min or cfg["red"]["horizonte_min"]
    vel = velocidad_acceso(cfg, modo)
    xy = np.asarray(xy, float).reshape(-1, 2)
    nd, dd = nodo_cercano(red, xy[:, 0], xy[:, 1])
    nh, dh = nodos_ut if nodos_ut is not None else preparar_unidades(red, ut)
    T = tiempos_hacia(red, nd, modo, horizonte_min, cols=nh, cfg=cfg).T
    T += ((dh / 1000 / vel * 60)[:, None] + (dd / 1000 / vel * 60)[None, :]).astype(np.float32)
    T[T > horizonte_min] = np.inf
    return np.ascontiguousarray(T)


# --------------------------------------------------------------------------------------------- ISÓCRONAS
CELDAS_ISOCRONA = 400_000         # tope de celdas en el rectángulo de una isócrona (solo afecta a las muy extensas)
SEGMENTOS_EXACTO = 400            # hasta esta cantidad de segmentos, la isócrona se dibuja con el buffer exacto


def _poligono_tramos(a, b, buffer_m):
    """Polígono que cubre los tramos alcanzados con una franja de `buffer_m` metros (100% vectorizado).
    Los tramos se densifican, se marcan en una grilla de celdas, se unen las celdas (coverage_union) y se aplica el
    resto de la franja: equivale al buffer de las calles pero es varias veces más rápido.
    Celda = ⅔ de la franja (40 m con la franja de 60 m). En isócronas muy extensas (auto 30 min, TP 45 min) la celda
    crece hasta ~80 m para no pasar de CELDAS_ISOCRONA: misma área (±0,5%) y 3 veces más rápido; la diferencia de
    forma (IoU 0,90 contra celdas de 40 m) no se ve a la escala de esas isócronas (40 km de lado).
    Isócronas chicas (≤ SEGMENTOS_EXACTO segmentos, p. ej. 5 min a pie): buffer EXACTO de las calles (es barato ahí y
    es donde más se nota el detalle). Medido: la grilla queda a IoU 0,92–0,97 del exacto, con el área a ±1,5%."""
    if len(a) <= SEGMENTOS_EXACTO:
        lineas = shapely.multilinestrings(shapely.linestrings(np.stack([a, b], axis=1)))
        return shapely.buffer(lineas, buffer_m, quad_segs=2).simplify(2.0)
    lo = np.minimum(a.min(0), b.min(0))
    alto_ancho = np.maximum(a.max(0), b.max(0)) - lo
    c = min(max(5.0, buffer_m * 2 / 3, float(np.sqrt(np.prod(alto_ancho) / CELDAS_ISOCRONA))), 1.6 * buffer_m)
    L = np.hypot(*(b - a).T)
    k = np.maximum(1, np.ceil(L / (c / 2))).astype(np.int64)
    i = np.repeat(np.arange(len(k)), k + 1)
    inicio = np.r_[0, np.cumsum(k + 1)[:-1]]
    f = (np.arange(len(i)) - inicio[i]) / k[i]
    ij = np.floor((a[i] + (b[i] - a[i]) * f[:, None] - lo) / c).astype(np.int64)
    nx = int(ij[:, 0].max()) + 1
    iy, ix = np.divmod(np.unique(ij[:, 1] * nx + ij[:, 0]), nx)          # celdas distintas (clave 1D: rápido)
    cajas = shapely.box(lo[0] + ix * c, lo[1] + iy * c, lo[0] + (ix + 1) * c, lo[1] + (iy + 1) * c)
    return shapely.coverage_union_all(cajas).buffer(buffer_m - c / 2, quad_segs=1).simplify(c / 3)   # quad_segs=1: IoU 0,99 vs 2


def _poligonos_lote(seg_a, seg_b, indices, buffer_m):
    """Trabajo de UN proceso: polígonos de un lote de isócronas (cada una = índices de los segmentos alcanzados)."""
    return [_poligono_tramos(seg_a[ix].astype(float), seg_b[ix].astype(float), buffer_m) for ix in indices]


def _repartir(costos, n):
    """Reparte trabajos de costo conocido en n lotes parejos (el más caro primero, al lote más liviano)."""
    lotes, carga = [[] for _ in range(n)], np.zeros(n)
    for t in np.argsort(costos)[::-1]:
        j = int(np.argmin(carga))
        lotes[j].append(int(t))
        carga[j] += costos[t]
    return [l for l in lotes if l]


def isocronas_sitios(red, sitios, cfg, modos=None, cronometro=None, sentido="hacia", minutos=None, con_acceso=True):
    """Isócronas de varios sitios (columnas id, x, y en CRS métrico) para varios modos.
    sentido='hacia': lugares DESDE los que se llega al sitio en ≤ m minutos (área de influencia de una sede).
    sentido='desde': lugares a los que se llega desde el sitio (lo que muestra la receta clásica de OSMnx).
    Los Dijkstra (rápidos) se hacen aquí; los polígonos (lo caro) de TODOS los modos y cortes se reparten en un solo
    cálculo paralelo con lotes de costo parejo, para que ningún proceso quede esperando a la isócrona más grande."""
    log = cronometro or Cronometro()
    modos = modos or list(cfg["red"]["isocronas_min"].keys())
    trabajos = []                                          # (id, modo, minutos, índices de segmentos alcanzados)
    for modo in modos:
        mins = sorted(minutos or cfg["red"]["isocronas_min"][modo])
        nodos, d0 = nodo_cercano(red, sitios["x"].values, sitios["y"].values)
        acceso = d0 / 1000 / velocidad_acceso(cfg, modo) * 60 if con_acceso else np.zeros(len(d0))   # tramo sitio -> calle
        M = red.M[modo] if sentido == "hacia" else red.Mf[modo]
        for b in range(0, len(sitios), 32):                # de a 32 sitios: la matriz de tiempos queda acotada
            D = csgraph.dijkstra(M, directed=True, indices=nodos[b:b + 32], limit=60 * max(mins))[:, :red.n] / 60
            D += acceso[b:b + 32, None]
            for k in range(D.shape[0]):
                for m in mins:
                    ok = D[k] <= m
                    sel = np.flatnonzero((ok[red.u] & ok[red.v])[red.seg_e])      # segmentos de aristas alcanzadas
                    if len(sel):
                        trabajos.append((sitios["id"].iloc[b + k], modo, m, sel.astype(np.int32)))
            del D
    if not trabajos:
        return gpd.GeoDataFrame(columns=["id", "modo", "minutos", "geometry", "area_km2"], geometry="geometry", crs=cfg["estudio"]["crs_metrico"])
    lotes = _repartir(np.array([len(t[3]) for t in trabajos], float), min(len(trabajos), 2 * n_nucleos(cfg)))
    res = en_paralelo(_poligonos_lote, [(red.seg_a, red.seg_b, [trabajos[t][3] for t in l], cfg["red"]["buffer_isocrona_m"])
                                        for l in lotes], cfg)
    geom = {t: g for l, r in zip(lotes, res) for t, g in zip(l, r)}
    out = gpd.GeoDataFrame([{"id": trabajos[t][0], "modo": trabajos[t][1], "minutos": trabajos[t][2], "geometry": geom[t]}
                            for t in range(len(trabajos))], geometry="geometry", crs=cfg["estudio"]["crs_metrico"])
    out["area_km2"] = out.area / 1e6
    log(f"isócronas: {len(sitios)} sitios × {', '.join(modos)} · {len(trabajos)} polígonos en {len(lotes)} lotes")
    return out


def isocronas_punto(red, x, y, minutos, modo, cfg, sentido="hacia"):
    """Isócronas de un solo punto (atajo de isocronas_sitios)."""
    s = pd.DataFrame({"id": ["punto"], "x": [x], "y": [y]})
    return isocronas_sitios(red, s, cfg, [modo], cronometro=lambda m: None, sentido=sentido, minutos=minutos)


def isocrona_osmnx_referencia(G, lat, lon, minutos, peso="travel_time", vel_max_kmh=110):
    """Receta clásica de OSMnx/networkx: nodo más cercano (ox.distance.nearest_nodes) + subgrafo alcanzable
    (nx.ego_graph con distance=travel_time) + calles del subgrafo con franja de 60 m. Se usa para verificar.
    Para que sea rápida, primero se recorta el grafo a la distancia máxima posible en esos minutos."""
    import networkx as nx
    import osmnx as ox
    radio_grados = vel_max_kmh / 3.6 * 60 * minutos / 111_000 * 1.3
    cerca = [k for k, d in G.nodes(data=True) if abs(d["y"] - lat) <= radio_grados and abs(d["x"] - lon) <= radio_grados / np.cos(np.radians(lat))]
    Gl = G.subgraph(cerca).copy()
    nodo = ox.distance.nearest_nodes(Gl, lon, lat)
    sub = nx.ego_graph(Gl, nodo, radius=60 * minutos, distance=peso)
    aristas = ox.graph_to_gdfs(sub, nodes=False).to_crs(32719)
    return shapely.union_all(aristas.geometry.values).buffer(60, quad_segs=4)


def metricas_en_isocronas(iso, ut, cfg, columnas):
    """Suma de variables de las manzanas cuyo punto interior cae dentro de cada isócrona (población, objetivo, gasto…)."""
    pts = gpd.GeoDataFrame(ut[columnas].reset_index(drop=True), geometry=gpd.points_from_xy(ut["cx"], ut["cy"]), crs=cfg["estudio"]["crs_metrico"])
    j = gpd.sjoin(pts, iso[["geometry"]].reset_index().rename(columns={"index": "iso_i"}), predicate="within")
    s = j.groupby("iso_i")[columnas].sum()
    return iso.join(s).fillna({c: 0 for c in columnas})


def circuidad(red, ut, cfg, n=300, modo="auto_punta", semilla=1, nodos_ut=None):
    """Relación entre tiempo por red y distancia en línea recta (muestra de pares de manzanas con población). Didáctico:
    muestra por qué un buffer circular no representa bien el área de influencia."""
    rng = np.random.default_rng(semilla)
    con_pob = np.where(ut["pob"].values > 0)[0] if "pob" in ut else np.arange(len(ut))
    i = rng.choice(con_pob, size=min(n, len(con_pob)), replace=False)
    nh, dh = nodos_ut if nodos_ut is not None else preparar_unidades(red, ut)
    T = tiempos_hacia(red, nh[i[:60]], modo, 60, cols=nh[i], n_jobs=1)
    filas = []
    for a in range(T.shape[0]):
        d = np.hypot(ut["cx"].values[i] - ut["cx"].values[i[a]], ut["cy"].values[i] - ut["cy"].values[i[a]]) / 1000
        ok = np.isfinite(T[a]) & (d > 0.3)
        filas.append(pd.DataFrame({"km_linea_recta": d[ok], "minutos_red": T[a][ok]}))
    return pd.concat(filas, ignore_index=True)
