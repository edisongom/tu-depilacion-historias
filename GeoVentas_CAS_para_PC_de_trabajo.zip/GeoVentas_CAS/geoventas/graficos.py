# -*- coding: utf-8 -*-
"""Gráficos estáticos (matplotlib). Cada función devuelve la figura y, si se indica `ruta`, la guarda en PNG."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from .mapas import COLOR_FORMATO, NOMBRE_FORMATO

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": 0.25, "figure.dpi": 100})
AZUL, ROJO, GRIS = "#1F4E79", "#C00000", "#7F7F7F"


NOMBRES_SEDE = {}          # código de sede -> nombre real (lo fijan los notebooks); los gráficos muestran el nombre


def _nom(s):
    return NOMBRES_SEDE.get(s, s)


def _guardar(fig, ruta):
    if ruta:
        fig.savefig(ruta, dpi=150, bbox_inches="tight")
    return fig


def serie_red(panel, ruta=None):
    """Venta mensual total de la red: nominal vs real (pesos del último mes)."""
    t = panel.groupby("periodo")[["monto", "monto_real"]].sum()
    fig, ax = plt.subplots(figsize=(10, 3.6))
    x = pd.PeriodIndex(t.index, freq="M").to_timestamp()
    ax.plot(x, t["monto"] / 1e6, c=GRIS, lw=1.5, label="Pesos nominales (como vienen)")
    ax.plot(x, t["monto_real"] / 1e6, c=AZUL, lw=2, label="Pesos reales del último mes (sin inflación)")
    ax.set(title="Venta mensual total de la red", ylabel="MM CLP"); ax.legend()
    return _guardar(fig, ruta)


def series_sedes(panel, ruta=None, col="monto_real"):
    """Una mini-serie por sede, con los meses atípicos (rojo), quiebres (triángulo) y eventos informados (sombreado)."""
    sedes = list(panel["sede"].unique())
    nc = 3; nr = int(np.ceil(len(sedes) / nc))
    fig, axs = plt.subplots(nr, nc, figsize=(13, 2.3 * nr), sharex=True)
    axs = np.atleast_1d(axs).ravel()
    for ax, s in zip(axs, sedes):
        d = panel[panel["sede"] == s]
        x = pd.PeriodIndex(d["periodo"], freq="M").to_timestamp()
        ax.plot(x, d[col] / 1e6, c=AZUL, lw=1.3)
        if "desest" in d:
            ax.plot(x, d["desest"] / 1e6, c=AZUL, lw=0.8, ls=":", alpha=0.7)
        at = d["atipico"].values if "atipico" in d else np.zeros(len(d), bool)
        ax.scatter(x[at], d[col].values[at] / 1e6, c=ROJO, s=18, zorder=3)
        if "quiebre" in d:
            q = d["quiebre"].values
            ax.scatter(x[q], d[col].values[q] / 1e6, marker="v", c="#ED7D31", s=40, zorder=4)
        if "evento" in d:
            ev = d["evento"].astype(str).str.len().values > 0
            for xi in x[ev]:
                ax.axvspan(xi, xi + pd.Timedelta(days=30), color="#FFC000", alpha=0.25)
        ax.set_title(_nom(s), fontsize=9)
    for ax in axs[len(sedes):]:
        ax.axis("off")
    fig.suptitle("Venta mensual real por sede (MM CLP) · rojo = atípico · ▼ = quiebre de nivel · amarillo = evento informado", fontsize=10)
    fig.tight_layout()
    return _guardar(fig, ruta)


def estacionalidad(indice, ruta=None):
    indice = pd.Series(indice).sort_index()
    fig, ax = plt.subplots(figsize=(7, 3))
    meses = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]
    ax.bar(meses, (indice.values - 1) * 100, color=np.where(indice.values >= 1, AZUL, ROJO))
    ax.axhline(0, c="k", lw=0.8)
    ax.set(title="Estacionalidad común: % sobre / bajo el mes promedio", ylabel="%")
    return _guardar(fig, ruta)


def curva_maduracion(curva, ruta=None):
    fig, ax = plt.subplots(figsize=(7, 3.6))
    t = curva.get("tabla")
    if t is not None and len(t):
        for s, d in t.groupby("sede"):
            ax.plot(d["m"], d["indice"] * 100, "o", ms=3, alpha=0.6, label=f"{_nom(s)} (observado)")
        m = np.linspace(0, max(48, t["m"].max()), 200)
        ax.plot(m, 100 * (1 - (1 - curva["r0"]) * np.exp(-m / curva["tau"])), c="k", lw=2, label="curva estimada")
    ra = curva["rampa_anual"]
    for a, r in enumerate(ra):
        ax.hlines(100 * r, 12 * a, 12 * (a + 1), colors=ROJO, lw=3)
        ax.text(12 * a + 6, 100 * r + 2, f"año {a + 1}: {r:.0%}", ha="center", color=ROJO, fontsize=8)
    ax.set(title=f"Maduración de una sede nueva ({curva['fuente']})", xlabel="meses desde la apertura", ylabel="% de la venta en régimen", ylim=(0, 115))
    ax.legend(fontsize=7, loc="lower right")
    return _guardar(fig, ruta)


def barras_mix(mix, titulo, ruta=None):
    fig, ax = plt.subplots(figsize=(10, 0.35 * len(mix) + 1.2))
    izq = np.zeros(len(mix))
    for k, c in enumerate(mix.columns):
        ax.barh(mix.index.astype(str), mix[c] * 100, left=izq, label=str(c), color=plt.cm.tab20(k % 20))
        izq += mix[c].values * 100
    ax.set(title=titulo, xlabel="% de la venta"); ax.legend(fontsize=7, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.15))
    ax.invert_yaxis()
    return _guardar(fig, ruta)


def circuidad(df, ruta=None):
    """Tiempo por red vs distancia en línea recta: la dispersión muestra por qué un buffer circular engaña."""
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.scatter(df["km_linea_recta"], df["minutos_red"], s=4, alpha=0.25, c=AZUL)
    for km in (2, 5, 8):
        sel = df[(df["km_linea_recta"] - km).abs() < 0.25]["minutos_red"]
        if len(sel):
            ax.vlines(km, sel.quantile(0.05), sel.quantile(0.95), colors=ROJO, lw=3)
            ax.text(km + 0.15, sel.quantile(0.95), f"{km} km: {sel.quantile(0.05):.0f}–{sel.quantile(0.95):.0f} min", color=ROJO, fontsize=8)
    ax.set(title="Mismo radio, tiempos muy distintos: por eso se usan isócronas y no buffers",
           xlabel="distancia en línea recta (km)", ylabel="minutos por la red (auto, hora punta)")
    return _guardar(fig, ruta)


def ajuste_sedes(t, col_pred="venta_predicha", ruta=None, titulo="Venta observada vs predicha por sede"):
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(t["venta_observada"] / 1e6, t[col_pred] / 1e6, c=t["formato"].map(COLOR_FORMATO), s=40)
    for _, r in t.iterrows():
        ax.annotate(_nom(r["sede"]), (r["venta_observada"] / 1e6, r[col_pred] / 1e6), fontsize=7, xytext=(3, 3), textcoords="offset points")
    lo = min(t["venta_observada"].min(), t[col_pred].min()) / 1e6 * 0.8
    hi = max(t["venta_observada"].max(), t[col_pred].max()) / 1e6 * 1.2
    ax.plot([lo, hi], [lo, hi], "--", c=GRIS, lw=1)
    ax.set(xlabel="Venta observada (MM CLP/mes)", ylabel="Venta del modelo (MM CLP/mes)", title=titulo, xscale="log", yscale="log")
    return _guardar(fig, ruta)


def decaimiento(th, thetas, observado=None, ruta=None):
    fig, ax = plt.subplots(figsize=(8, 4))
    t = np.linspace(0, 45, 200)
    for f, nombre in enumerate(["clinica", "centro_medico", "toma_muestras"]):
        b = np.exp(th[5 + f])
        ax.plot(t, np.exp(-b * t), lw=2, c=COLOR_FORMATO[nombre], label=f"{NOMBRE_FORMATO[nombre]}: la mitad a los {np.log(2) / b:.0f} min")
        if thetas is not None and len(thetas):
            lo, hi = np.percentile(np.exp(thetas[:, 5 + f]), [10, 90])
            ax.fill_between(t, np.exp(-hi * t), np.exp(-lo * t), color=COLOR_FORMATO[nombre], alpha=0.15)
    if observado is not None and len(observado):
        for f, g in observado.groupby("formato"):
            ax.plot(g["t_medio"], g["indice"], "o", ms=4, c=COLOR_FORMATO.get(f, GRIS), alpha=0.6)
    ax.set(xlabel="minutos de viaje (auto, hora punta)", ylabel="atractivo relativo (1 = en la puerta)",
           title="¿Cuánto pesa la distancia? Caída del atractivo con el tiempo de viaje (banda = P10–P90)")
    ax.legend(fontsize=8)
    return _guardar(fig, ruta)


def validacion_sede_nueva(v, ruta=None):
    fig, ax = plt.subplots(figsize=(7, 0.35 * len(v) + 1.5))
    v = v.sort_values("error_pct")
    ax.barh(v["sede"].map(_nom), v["error_pct"] * 100, color=np.where(v["error_pct"].abs() <= 0.25, AZUL, ROJO))
    ax.axvline(0, c="k", lw=0.8); ax.axvspan(-25, 25, color=GRIS, alpha=0.1)
    ax.set(xlabel="error % al predecir la sede como si fuera nueva (sin usar sus datos)",
           title="Validación 'sede nueva' · franja gris = ±25%")
    return _guardar(fig, ruta)


def cv_scatter(y, p, titulo, ruta=None):
    fig, ax = plt.subplots(figsize=(5.5, 5))
    ax.scatter(y / 1e6, p / 1e6, s=8, alpha=0.5, c=AZUL)
    lim = max(np.nanmax(y), np.nanmax(p)) / 1e6 * 1.05
    ax.plot([0, lim], [0, lim], "--", c=GRIS)
    ax.set(xlabel="venta observada (MM CLP/mes)", ylabel="predicción fuera de muestra", title=titulo)
    return _guardar(fig, ruta)


def top_n(top, ruta=None):
    fig, ax = plt.subplots(figsize=(8, 0.34 * len(top) + 1.3))
    tt = top.iloc[::-1]
    ax.barh(tt["id_top"] + " · " + tt["comuna"].astype(str), tt["venta_neta"] / 1e6, color=tt["formato"].map(COLOR_FORMATO))
    if "venta_neta_p10_marginal" in tt:
        ax.errorbar(tt["venta_neta"] / 1e6, np.arange(len(tt)),
                    xerr=[(tt["venta_neta"] - tt["venta_neta_p10_marginal"]).clip(lower=0) / 1e6,
                          (tt["venta_neta_p90_marginal"] - tt["venta_neta"]).clip(lower=0) / 1e6], fmt="none", ecolor="k", lw=0.8, capsize=2)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=c, label=NOMBRE_FORMATO[k]) for k, c in COLOR_FORMATO.items() if (tt["formato"] == k).any()], loc="lower right")
    ax.set(xlabel="venta neta incremental en régimen (MM CLP/mes) · barra = P10–P90", title="Plan de expansión en orden de apertura")
    return _guardar(fig, ruta)


def entorno_curvas(det, ruta=None, nombres=None, col="pob_objetivo"):
    """Una mini-curva por sede: personas del segmento objetivo que llegan en 5, 10, 15… minutos, fuera de punta (línea
    punteada) y en hora punta (línea continua). La distancia vertical entre ambas es lo que quita la congestión."""
    sedes = list(dict.fromkeys(det["sede"]))
    n = len(sedes)
    if not n:
        return None
    nc = min(4, n)
    nf = int(np.ceil(n / nc))
    fig, axs = plt.subplots(nf, nc, figsize=(3.2 * nc, 2.4 * nf), sharex=True, squeeze=False)
    estilo = {"auto_valle": dict(ls="--", c=GRIS, label="Auto, fuera de punta"), "auto_punta": dict(ls="-", c=AZUL, label="Auto, hora punta"),
              "pie": dict(ls=":", c="#2e8b57", label="Caminando"), "tp": dict(ls="-.", c="#ED7D31", label="Transporte público")}
    for k, s in enumerate(sedes):
        ax = axs[k // nc][k % nc]
        d = det[det["sede"] == s]
        for modo, g in d.groupby("modo"):
            g = g.sort_values("minutos")
            ax.plot(g["minutos"], g[col] / 1000, marker="o", ms=3, **estilo.get(modo, {}))
        nom = (nombres or {}).get(s, d["nombre_visible"].iloc[0] if "nombre_visible" in d else s)
        nom = str(nom)
        ax.set_title(nom if len(nom) <= 40 else nom[:39] + "…", fontsize=8)
        ax.tick_params(labelsize=7)
    for k in range(n, nf * nc):
        axs[k // nc][k % nc].set_axis_off()
    axs[0][0].legend(fontsize=7, loc="upper left")
    fig.supxlabel("Minutos de viaje en auto"); fig.supylabel("Miles de personas del segmento objetivo")
    fig.suptitle("Público objetivo que llega a cada sede según los minutos de viaje, fuera de punta y en hora punta", fontsize=10)
    fig.tight_layout()
    return _guardar(fig, ruta)


def influencia_t80(res, sens, ruta=None, nombres=None):
    """Minutos que reúnen el 80% de la demanda modelada de cada sede: hora punta (barra), rango si la gente viaja más o
    menos de lo supuesto (línea) y fuera de punta (rombo)."""
    p = res[res["modo"] == "auto_punta"].sort_values("t80_min")
    v = res[res["modo"] == "auto_valle"].set_index("sede")["t80_min"] if "auto_valle" in set(res["modo"]) else None
    rango = sens.pivot_table(index="sede", columns="beta_x", values="t80_min")
    fig, ax = plt.subplots(figsize=(9, 0.42 * len(p) + 1.2))
    y = np.arange(len(p))
    nom = [(nombres or {}).get(s, n) for s, n in zip(p["sede"], p.get("nombre_visible", p["sede"]))]
    ax.barh(y, p["t80_min"], color=p["formato_modelo"].map(COLOR_FORMATO).fillna(AZUL), alpha=0.85, label="Hora punta")
    lo, hi = rango.min(axis=1).reindex(p["sede"]).to_numpy(), rango.max(axis=1).reindex(p["sede"]).to_numpy()
    ax.hlines(y, lo, hi, color="k", lw=1.2, label="Rango si se viaja más o menos de lo supuesto (β ± 25%)")
    if v is not None:
        ax.scatter(v.reindex(p["sede"]).to_numpy(), y, marker="D", s=22, color=GRIS, zorder=3, label="Fuera de punta")
    ax.set_yticks(y); ax.set_yticklabels(nom, fontsize=8)
    ax.set(xlabel="Minutos en auto que reúnen el 80% de la demanda de la sede", title="Alcance de cada sede (zona de influencia modelada, preliminar)")
    ax.legend(fontsize=7, loc="lower right")
    fig.tight_layout()
    return _guardar(fig, ruta)
