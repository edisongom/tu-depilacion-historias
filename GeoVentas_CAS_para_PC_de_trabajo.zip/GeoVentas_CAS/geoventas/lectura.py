# -*- coding: utf-8 -*-
"""Lectura de las bases Equifax (desde el bucket gs:// o local) con los nombres originales de columnas.

Las bases son grandes (personas 17 millones de filas, BBRR 9,5 millones), así que:
  * se leen SOLO las columnas que usa el estudio (nunca nombres ni direcciones de personas);
  * se leen por bloques y se filtran al área de estudio a medida que se leen (no se carga Chile completo en memoria);
  * los archivos de GCS se descargan una vez a una carpeta caché local y las siguientes lecturas son inmediatas.
"""
import os
import re

import numpy as np
import pandas as pd
import geopandas as gpd
import shapely

from .utilidades import norm_txt, norm_serie, Cronometro, codificacion
from . import rut, coordenadas


# --------------------------------------------------------------------------------------------- ARCHIVOS
def ruta_local(ruta, cfg):
    """Si la ruta es gs://, descarga el archivo (una sola vez) a la caché local y devuelve la ruta local."""
    ruta = str(ruta)
    if not ruta.startswith("gs://"):
        if not os.path.exists(ruta):
            raise FileNotFoundError(f"No existe el archivo: {ruta}")
        return ruta
    destino = os.path.join(cfg["carpetas"]["cache"], re.sub(r"[^A-Za-z0-9._-]", "_", ruta[5:]))
    if os.path.exists(destino) and os.path.getsize(destino) > 0:
        return destino
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    print(f"Descargando {ruta} a la caché local (solo la primera vez)…", flush=True)
    try:
        import fsspec
        with fsspec.open(ruta, "rb") as fi, open(destino + ".tmp", "wb") as fo:
            while True:
                b = fi.read(64 * 1024 * 1024)
                if not b:
                    break
                fo.write(b)
    except ImportError:
        from google.cloud import storage
        bucket, _, blob = ruta[5:].partition("/")
        storage.Client().bucket(bucket).blob(blob).download_to_filename(destino + ".tmp")
    os.replace(destino + ".tmp", destino)
    return destino


def columnas_reales(mapa, logicas=None):
    """Nombres reales de las columnas pedidas (excluye patrones con {gse} y listas)."""
    out = []
    for k, v in mapa.items():
        if logicas is not None and k not in logicas:
            continue
        if isinstance(v, str) and "{" not in v:
            out.append(v)
    return out


def renombrar(df, mapa, base):
    """Columnas reales -> nombres lógicos. Avisa cuáles faltan (no detiene el proceso)."""
    inv, faltan = {}, []
    for logico, real in mapa.items():
        if not isinstance(real, str) or "{" in real:
            continue
        if real in df.columns:
            inv[real] = logico
        else:
            faltan.append(f"{logico} ← '{real}'")
    if faltan:
        print(f"  [{base}] columnas no encontradas (se seguirá sin ellas): {', '.join(faltan)}")
    return df.rename(columns=inv)


def tabla_mapeo(cfg):
    """Tabla 'nombre lógico ← columna original' de todas las bases (para documentar el notebook)."""
    filas = []
    for base, mapa in cfg["columnas"].items():
        for k, v in mapa.items():
            filas.append({"base": base, "nombre_en_el_codigo": k, "columna_original": v if isinstance(v, str) else ", ".join(v)})
    return pd.DataFrame(filas)


# --------------------------------------------------------------------------------------------- ÁREA DE ESTUDIO
def leer_censo(cfg, cronometro=None):
    """Manzanas del censo (SD06) de las regiones del estudio, con todas sus columnas originales.
    Filtra por ID_REG (y por bbox si se configuró) al leer, para no cargar todo Chile."""
    log = cronometro or Cronometro()
    C = cfg["columnas"]["censo"]
    ruta = ruta_local(cfg["rutas"]["censo"], cfg)
    regs = cfg["estudio"]["id_regiones"]
    bbox = cfg["estudio"].get("bbox")
    kw = {"bbox": tuple(bbox)} if bbox else {}
    try:
        import pyogrio
        where = f"{C['id_region']} IN ({','.join(str(int(r)) for r in regs)})" if regs else None
        g = pyogrio.read_dataframe(ruta, where=where, **kw)
        if regs and len(g) == 0:        # ID_REG guardado como texto
            g = pyogrio.read_dataframe(ruta, where=f"{C['id_region']} IN ({','.join(repr(str(r)) for r in regs)})", **kw)
    except Exception as e:
        log(f"lectura filtrada no disponible ({e}); se lee completo y se filtra")
        g = gpd.read_file(ruta, **kw)
        if regs:
            g = g[pd.to_numeric(g[C["id_region"]], errors="coerce").isin(regs)]
    if g.crs is None:
        g = g.set_crs("EPSG:4326")
    g = g.to_crs("EPSG:4326")
    g = g[g.geometry.notna() & ~g.geometry.is_empty].reset_index(drop=True)
    log(f"censo: {len(g):,} manzanas · {pd.to_numeric(g[C['pob']], errors='coerce').sum():,.0f} habitantes")
    return g


def construir_area_estudio(censo, cfg, buffer_m=1500):
    """Polígono del área de estudio = manzanas del censo + 1,5 km (para no cortar gente justo en el borde)."""
    crs = cfg["estudio"]["crs_metrico"]
    m = censo.to_crs(crs)
    # unión rápida: celdas de 500 m que tocan manzanas, luego buffer
    c = m.geometry.representative_point()
    k = np.unique(np.c_[np.floor(c.x / 500), np.floor(c.y / 500)].astype(np.int64), axis=0)
    cajas = shapely.box(k[:, 0] * 500, k[:, 1] * 500, (k[:, 0] + 1) * 500, (k[:, 1] + 1) * 500)
    area = shapely.coverage_union_all(cajas).buffer(buffer_m)
    area = gpd.GeoDataFrame({"nombre": ["area_estudio"]}, geometry=[area], crs=crs).to_crs("EPSG:4326")
    return area


def _dentro(lon, lat, area_geom):
    """Máscara de los puntos (lon, lat ya leídos como float) que caen dentro del área de estudio."""
    lon = np.asarray(lon, float)
    lat = np.asarray(lat, float)
    ok = np.isfinite(lon) & np.isfinite(lat)
    x0, y0, x1, y1 = area_geom.bounds
    ok &= (lon >= x0) & (lon <= x1) & (lat >= y0) & (lat <= y1)
    if ok.any():
        shapely.prepare(area_geom)
        idx = np.where(ok)[0]
        ok[idx] = shapely.contains_xy(area_geom, lon[idx], lat[idx])
    return ok


# --------------------------------------------------------------------------------------------- BASES DE PUNTOS
def leer_puntos(nombre, cfg, area, logicas=None, filtros=None, cronometro=None, bloque=1_000_000):
    """Lee una base de puntos (per, emp, bbrr) por bloques, quedándose solo con las columnas del mapa de COLUMNAS
    y los registros dentro del área de estudio. Funciona con .parquet y con .txt/.csv (separador de config).
    Las coordenadas se leen con `coordenadas.leer` en cada bloque: coma o punto decimal, sin punto decimal, separadores de
    miles, grados/minutos/segundos, signo omitido o latitud y longitud intercambiadas (informe en .attrs['coordenadas'])."""
    log = cronometro or Cronometro()
    mapa = cfg["columnas"][nombre]
    cols = columnas_reales(mapa, logicas)
    lat_c, lon_c = mapa["lat"], mapa["lon"]
    area_geom = area.geometry.iloc[0]
    ruta = ruta_local(cfg["rutas"][nombre], cfg)
    partes, total, informes = [], 0, []
    lim = coordenadas.limites(cfg)

    def filtrar(df):
        la, lo, inf = coordenadas.leer(df[lat_c], df[lon_c], lim=lim)
        informes.append(inf)
        ok = _dentro(lo, la, area_geom)
        d = df.loc[ok].copy()
        d[lat_c], d[lon_c] = la[ok], lo[ok]
        return d
    if ruta.lower().endswith((".parquet", ".pq")):
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(ruta)
        disp = set(pf.schema_arrow.names)
        usar = [c for c in cols if c in disp]
        for lote in pf.iter_batches(batch_size=bloque, columns=usar):
            df = lote.to_pandas()
            total += len(df)
            partes.append(filtrar(df))
    else:
        sep = cfg.get("separador_txt", "|")
        cod = codificacion(ruta)
        with open(ruta, "r", encoding=cod, errors="replace") as f:
            cab = f.readline().rstrip("\n\r")
        if cab.count(sep) == 0:
            sep = max([",", ";", "|", "\t"], key=cab.count)
        disp = [c.strip().strip('"') for c in cab.split(sep)]
        usar = [c for c in cols if c in disp]
        for df in pd.read_csv(ruta, sep=sep, usecols=usar, chunksize=bloque, encoding=cod, dtype=str,
                              on_bad_lines="skip", encoding_errors="replace"):
            total += len(df)
            partes.append(filtrar(df))
    df = pd.concat(partes, ignore_index=True) if partes else pd.DataFrame(columns=usar)
    df = renombrar(df, {k: v for k, v in mapa.items() if (logicas is None or k in logicas)}, nombre)
    for c in ("lat", "lon"):
        df[c] = pd.to_numeric(df[c], errors="coerce").astype(float)
    g = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df["lon"], df["lat"]), crs="EPSG:4326")
    inf = coordenadas.sumar_informes(informes)
    g.attrs["coordenadas"] = coordenadas.REGISTRO[nombre] = inf
    log(f"{nombre}: {total:,} filas leídas · {len(g):,} dentro del área de estudio · " + coordenadas.texto_informe(inf))
    return g


def seudonimizar_base(ids, cfg, base, log=print):
    """RUTID de personas o empresas -> hash. Primero se lleva a la forma canónica (detectando UNA vez para la base si
    trae dígito verificador: Equifax lo trae), luego sha256(sal + RUT). Devuelve (hashes, informe)."""
    inf = rut.detectar_dv(ids)
    if inf["con_dv"] is None:                     # formato habitual de Equifax: con dígito verificador
        log(f"  {base}: {inf['explicacion']}; se asume que trae dígito verificador (formato Equifax)")
        inf["con_dv"] = True
    canon = rut.canonico(ids, con_dv=inf["con_dv"])
    inf["pct_vacios"] = round(100 * float((canon == "").mean()), 2) if len(canon) else 0.0
    inf["formatos"] = rut.formatos(ids).to_dict("list")
    log(f"  {base}: RUT {inf['explicacion']} · vacíos {inf['pct_vacios']:.2f}%")
    return rut.seudonimizar(canon.values, rut.sal_efectiva(cfg), cfg), inf


def _fallecidos(g, log):
    """Personas fallecidas: FECHA_DEFUNCION con una fecha real (no vacía, no 0, no 19000101) o DEFUNCION marcada (S, SI,
    1, X, FALLECIDO). Si saliera más de un 30% de fallecidos, la columna no significa lo que se cree: no se excluye a nadie."""
    muerto = pd.Series(False, index=g.index)
    if "fecha_defuncion" in g:
        crudo = g["fecha_defuncion"]
        f = crudo.astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
        f = f.where(crudo.notna() & ~f.isin(["", "nan", "None", "NaT", "<NA>", "0", "00000000"]), "")
        fecha = pd.Series(pd.NaT, index=g.index, dtype="datetime64[ns]")
        ocho = f.str.fullmatch(r"\d{8}")                                   # 20250101 (yyyymmdd, como FECHA_NACIMIENTO)
        if ocho.any():
            fecha[ocho] = pd.to_datetime(f[ocho], format="%Y%m%d", errors="coerce")
        otros = (f != "") & ~f.str.fullmatch(r"\d+")                       # 2025-01-01, 01/01/2025…
        if otros.any():
            fecha[otros] = pd.to_datetime(f[otros], format="mixed", dayfirst=True, errors="coerce")
        muerto |= fecha.between(pd.Timestamp("1901-01-01"), pd.Timestamp.today())
    if "defuncion" in g:
        d = norm_serie(g["defuncion"])
        muerto |= d.isin(["s", "si", "1", "x", "true", "fallecido", "fallecida"]).values
    pct = float(muerto.mean()) if len(muerto) else 0.0
    if pct > 0.30:
        log(f"  per: {pct:.0%} aparecería como fallecido: FECHA_DEFUNCION/DEFUNCION no significan lo esperado, no se excluye a nadie")
        return pd.Series(False, index=g.index)
    return muerto


def _sin_rut(cfg, base):
    """Columnas lógicas a leer: todas, menos el RUT si el estudio no cruzará RUT de pacientes (RUT_PACIENTES = "sin_rut")."""
    return [k for k in cfg["columnas"][base] if k != "id"] if cfg.get("rut_pacientes") == "sin_rut" else None


def leer_personas(cfg, area, cronometro=None):
    """Base de personas (per): edad, sexo, GSE, hogar, autos, BBRR, Dicom y renta en el área de estudio.
    El RUT se usa solo para crear su hash (para cruzar con los pacientes) y luego se descarta; sin RUT de pacientes
    ni siquiera se lee."""
    log = cronometro or Cronometro()
    P = cfg["per"]
    g = leer_puntos("per", cfg, area, logicas=_sin_rut(cfg, "per"), cronometro=log)
    if P.get("excluir_fallecidos") and ("fecha_defuncion" in g or "defuncion" in g):
        muertos = _fallecidos(g, log)
        log(f"  per: se excluyen {int(muertos.sum()):,} personas fallecidas")
        g = g.loc[~muertos.values].drop(columns=[c for c in ("fecha_defuncion", "defuncion") if c in g])
    g["edad"] = pd.to_numeric(g.get("edad"), errors="coerce")
    g = g[g["edad"].between(P["edad_min"], P["edad_max"]) | g["edad"].isna()]
    if "gse" in g:
        g["gse"] = g["gse"].astype(str).str.upper().str.strip().replace({"NAN": None, "NONE": None, "": None})
    for c in ("personas_hogar", "vehiculos", "bbrr", "hijos", "renta_hogar", "ise"):
        if c in g:
            g[c] = pd.to_numeric(g[c], errors="coerce")
    if "id" in g:                      # el RUT se transforma en hash y se descarta (nunca se guarda en claro)
        g["rut_hash"], inf = seudonimizar_base(g["id"], cfg, "per", log)
        g = g.drop(columns="id")
        g.attrs["rut"] = inf
    return g.reset_index(drop=True)


def clase_tamano(tam, claves):
    """Clase de tamaño de cada empresa (primera clave contenida en el texto normalizado), vectorizado. '' = sin clase."""
    clase = pd.Series("", index=tam.index)
    for k in claves:
        clase = clase.mask(clase.eq("") & tam.str.contains(k, regex=False), k)
    return clase


def trabajadores_por_tamano(trab, tam, cfg):
    """Trabajadores promedio por tamaño de empresa, estimados con las empresas de la MISMA base que sí traen CANTIDAD_TRAB.

    Por qué: los tramos de tamaño (SII/CORFO) son de ventas, no de empleo, y un valor fijo (p. ej. "grande" = 600) puede
    subestimar o sobrestimar mucho a los trabajadores. Lo que entra a la demanda flotante es la SUMA de trabajadores,
    así que se usa el PROMEDIO por tamaño (recortado en el p99 para que un dato erróneo no lo domine), no la mediana.
    Una clase con menos de `min_empresas_por_tamano` datos usa el valor fijo de `config_estudio.py`.
    Devuelve (Serie con el valor para cada empresa, tabla con lo que se usó).
    """
    E = cfg["emp"]
    fijo = {norm_txt(k): float(v) for k, v in E["trabajadores_por_tamano"].items()}
    sin_info = fijo.pop("sin informacion", 2.0)
    clase = clase_tamano(tam, [k for k in fijo if k])
    con_dato = trab.notna() & (trab > 0)
    filas = []
    for k, v_fijo in fijo.items():
        x = trab[con_dato & clase.eq(k)]
        usar_base = E.get("trabajadores_por_tamano_desde_base", True) and len(x) >= E.get("min_empresas_por_tamano", 30)
        v = float(x.clip(upper=x.quantile(0.99)).mean()) if usar_base else v_fijo
        filas.append({"tamano": k, "empresas": int(clase.eq(k).sum()), "con_CANTIDAD_TRAB": int(len(x)),
                      "valor_fijo_config": v_fijo, "promedio_en_base": round(float(x.mean()), 1) if len(x) else np.nan,
                      "valor_usado": round(v, 1), "fuente": "base (promedio recortado p99)" if usar_base else "valor fijo de config"})
    tabla = pd.DataFrame(filas)
    valores = clase.map(dict(zip(tabla["tamano"], tabla["valor_usado"]))).fillna(sin_info).astype(float)
    return valores, tabla


def leer_empresas(cfg, area, cronometro=None):
    """Empresas activas con trabajadores estimados (CANTIDAD_TRAB o, si falta, el promedio de su tamaño en la misma base)."""
    log = cronometro or Cronometro()
    E = cfg["emp"]
    g = leer_puntos("emp", cfg, area, logicas=_sin_rut(cfg, "emp"), cronometro=log)
    if E.get("solo_activas") and "activa" in g:
        act = norm_serie(g["activa"])
        ok = act.str.startswith("activ") | act.isin(["s", "si", "1", "true"]) | act.eq("")
        log(f"  emp: {int((~ok).sum()):,} empresas no activas excluidas")
        g = g.loc[ok.values]
    trab = pd.to_numeric(g.get("trabajadores"), errors="coerce")
    tam = norm_serie(g.get("tamano", pd.Series("", index=g.index)))
    por_tam, tabla = trabajadores_por_tamano(trab, tam, cfg)
    g["trabajadores_est"] = np.where(trab.notna() & (trab > 0), trab, por_tam.values).astype(float)
    g["fuente_trabajadores"] = np.where(trab.notna() & (trab > 0), "CANTIDAD_TRAB", "tamaño")
    g.attrs["trabajadores_por_tamano"] = tabla.to_dict("list")       # dict (no DataFrame): los attrs viajan con copias
    log("  emp: trabajadores por tamaño cuando falta CANTIDAD_TRAB: "
        + " · ".join(f"{r.tamano} {r.valor_usado:,.0f} ({'base' if r.fuente.startswith('base') else 'fijo'})" for r in tabla.itertuples()))
    txt = norm_serie(g.get("rubro", pd.Series("", index=g.index)).astype(str) + " " + g.get("actividad", pd.Series("", index=g.index)).astype(str))
    g["es_salud"] = txt.str.contains(E["regex_salud"], regex=True).values
    if "id" in g:                      # RUT de la empresa -> hash (para cruzar convenios / clientes empresa)
        g["rut_hash"], inf = seudonimizar_base(g["id"], cfg, "emp", log)
        g.attrs["rut"] = inf
    return g.drop(columns=[c for c in ("id",) if c in g]).reset_index(drop=True)


def leer_bbrr(cfg, area, cronometro=None):
    """Bienes raíces: solo destino, avalúo, superficie y coordenadas (sin propietarios)."""
    log = cronometro or Cronometro()
    g = leer_puntos("bbrr", cfg, area, logicas=["id", "destino", "glosa_destino", "avaluo", "sup_terreno", "tipo_propiedad",
                                                "comuna", "lat", "lon"], cronometro=log)
    dest = cfg["bbrr"]["destinos"]
    g["destino"] = g["destino"].astype(str).str.strip().str.upper().str[:1]
    g["grupo_destino"] = g["destino"].map(dest).fillna("otro")
    for c in ("avaluo", "sup_terreno"):
        if c in g:
            g[c] = pd.to_numeric(g[c], errors="coerce")
    return g.drop(columns=[c for c in ("id",) if c in g]).reset_index(drop=True)


def leer_gpkg_area(nombre, cfg, area, cronometro=None):
    """POIs (PI01) o calles (BC08) dentro del rectángulo del área de estudio (lectura con bbox, rápida)."""
    log = cronometro or Cronometro()
    ruta = ruta_local(cfg["rutas"][nombre], cfg)
    bbox = tuple(area.total_bounds)
    g = gpd.read_file(ruta, bbox=bbox)
    if g.crs is None:
        g = g.set_crs("EPSG:4326")
    g = g.to_crs("EPSG:4326")
    log(f"{nombre}: {len(g):,} registros en el rectángulo del área de estudio")
    return g


def _puntos_desde_columnas(nombre, cfg, area, log):
    """POIs cuya geometría viene vacía o fuera de lugar: se rearman desde las columnas de coordenadas (LON_X, LAT_Y),
    leídas con `coordenadas.leer` (coma o punto decimal, escala, signo, intercambio), y se filtran al área."""
    M = cfg["columnas"][nombre]
    ruta = ruta_local(cfg["rutas"][nombre], cfg)
    g = gpd.read_file(ruta, ignore_geometry=True)
    la, lo, inf = coordenadas.leer(g[M["lat"]], g[M["lon"]], cfg)
    ok = _dentro(lo, la, area.geometry.iloc[0])
    g = gpd.GeoDataFrame(g.loc[ok], geometry=gpd.points_from_xy(lo[ok], la[ok]), crs="EPSG:4326")
    g.attrs["coordenadas"] = coordenadas.REGISTRO[nombre] = inf
    log(f"{nombre}: geometría rearmada desde {M['lon']}/{M['lat']} · " + coordenadas.texto_informe(inf))
    return g


def leer_pois(cfg, area, cronometro=None):
    log = cronometro or Cronometro()
    g = leer_gpkg_area("pois", cfg, area, log)
    M = cfg["columnas"]["pois"]
    vacias = g.geometry.isna() | g.geometry.is_empty if len(g) else pd.Series(dtype=bool)
    if not len(g) or vacias.mean() > 0.5:          # geometría ausente: se usan las columnas de coordenadas
        g = _puntos_desde_columnas("pois", cfg, area, log)
    elif M.get("lat") in g and M.get("lon") in g:  # control: coordenadas de las columnas vs geometría
        la, lo, inf = coordenadas.leer(g[M["lat"]], g[M["lon"]], cfg)
        g.attrs["coordenadas"] = coordenadas.REGISTRO["pois"] = inf
    g = renombrar(g, cfg["columnas"]["pois"], "pois")
    if "estado" in g:
        est = norm_serie(g["estado"])
        g = g[~est.str.contains("cerrad|inactiv|baja", regex=True).values]
    partes = [g[c].astype(object).where(g[c].notna(), "").astype(str) if c in g else pd.Series("", index=g.index) for c in ("cat1", "cat2", "cat3")]
    g["categoria_txt"] = norm_serie(partes[0] + " | " + partes[1] + " | " + partes[2]).values       # CAT3 vacío no borra CAT1/CAT2
    return g.reset_index(drop=True)


def leer_calles(cfg, area, cronometro=None):
    g = leer_gpkg_area("street", cfg, area, cronometro)
    g = renombrar(g, cfg["columnas"]["street"], "street")
    return g[g.geometry.notna()].reset_index(drop=True)


# --------------------------------------------------------------------------------------------- CALIDAD
def reporte_calidad(nombre, df, claves=None, area_ok=None):
    """Una fila por base: registros, % de nulos en columnas clave, duplicados y geometrías vacías."""
    fila = {"base": nombre, "registros": len(df)}
    for c in (claves or []):
        if c in df.columns:
            fila[f"% nulos {c}"] = round(100 * float(df[c].isna().mean()), 2)
    if "id" in df.columns:
        fila["ids duplicados"] = int(df["id"].duplicated().sum())
    if "geometry" in df.columns:
        fila["geometrías vacías"] = int(df.geometry.isna().sum() + df.geometry.is_empty.sum())
    if area_ok is not None:
        fila["% dentro del área"] = round(100 * area_ok, 2)
    return fila


def diagnostico_gasto_censo(censo, cfg):
    """Gasto en salud por hogar implícito por GSE. Sirve para confirmar la UNIDAD del gasto del censo:
    si da ~100.000–600.000 CLP por hogar es mensual; si da 12 veces más, es anual."""
    C = cfg["columnas"]["censo"]; cat = cfg["censo"]["categoria_gasto_salud"]
    filas = []
    for g in cfg["gse"]:
        cg = C["gasto_cat_gse"].format(cat=cat, gse=g); ch = C["hog_gse"].format(gse=g); cp = C["pob_gse"].format(gse=g)
        gas = pd.to_numeric(censo.get(cg), errors="coerce").sum() if cg in censo else np.nan
        hog = pd.to_numeric(censo.get(ch), errors="coerce").sum() if ch in censo else np.nan
        pob = pd.to_numeric(censo.get(cp), errors="coerce").sum() if cp in censo else np.nan
        filas.append({"GSE": g, "población": pob, "hogares": hog, "gasto salud total": gas,
                      "gasto salud por hogar": gas / hog if hog else np.nan, "gasto salud por persona": gas / pob if pob else np.nan})
    return pd.DataFrame(filas)
