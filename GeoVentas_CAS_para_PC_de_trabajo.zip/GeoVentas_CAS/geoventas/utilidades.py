# -*- coding: utf-8 -*-
"""Utilidades comunes: normalización de texto, guardado y lectura de resultados intermedios entre notebooks,
mensajes de avance y formato de números en estilo chileno."""
import json
import os
import pickle
import re
import time
import unicodedata

import numpy as np
import pandas as pd
import geopandas as gpd


def norm_txt(s):
    """Texto en minúsculas, sin tildes ni signos, con espacios simples. Sirve para comparar nombres de comunas,
    calles, categorías o columnas que vienen escritas de distintas formas ("Ñuñoa" = "NUNOA" = "ñuñoa ")."""
    if s is None or (isinstance(s, float) and np.isnan(s)):
        return ""
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", s)).strip()


def norm_serie(serie):
    """norm_txt vectorizado para una Serie (más rápido con valores repetidos)."""
    serie = pd.Series(serie)
    u = pd.unique(serie.astype("object"))
    mapa = {v: norm_txt(v) for v in u}
    return serie.astype("object").map(mapa)


def codificacion(ruta, muestra=4_000_000):
    """Codificación de un csv/txt: "utf-8-sig" si los primeros MB son UTF-8 válido; si no, "cp1252" (latin-1 de Windows,
    habitual en exportaciones de bases chilenas). Sin esto, "MÉDICO" en latin-1 se leería como "M�DICO" y dejaría de
    calzar con las reglas de texto."""
    with open(ruta, "rb") as f:
        b = f.read(muestra)
    try:
        b.decode("utf-8")
    except UnicodeDecodeError as e:
        if e.start < len(b) - 4:                       # error real (no un carácter cortado justo al final de la muestra)
            return "cp1252"
    return "utf-8-sig"


def n_nucleos(cfg=None):
    """Núcleos a usar en paralelo según cfg['computo']['n_jobs'] (-1 = todos menos uno, mínimo 1)."""
    n = (cfg or {}).get("computo", {}).get("n_jobs", -1)
    tot = os.cpu_count() or 1
    return max(1, tot - 1 if n is None or n < 0 else min(int(n), tot))


_AVISOS_MEMORIA = set()
GB_POR_PROCESO = 1.2      # memoria típica de un proceso en paralelo (librerías + red + temporales); medido en la RM completa


def memoria_libre_gb():
    """Memoria que de verdad se puede pedir ahora (GB).
    * Windows: memoria "comprometible" disponible (RAM + archivo de paginación). Es lo que hace fallar una reserva
      ("bad allocation", "Unable to allocate"), aunque el Administrador de tareas muestre RAM libre.
    * Linux / Mac (Vertex AI): RAM disponible.
    Si no se puede medir, devuelve infinito (no limita)."""
    try:
        if os.name == "nt":
            import ctypes

            class _Estado(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            e = _Estado()
            e.dwLength = ctypes.sizeof(_Estado)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(e)):
                return e.ullAvailPageFile / 1e9
        try:
            import psutil
            return psutil.virtual_memory().available / 1e9
        except ImportError:
            return os.sysconf("SC_AVPHYS_PAGES") * os.sysconf("SC_PAGE_SIZE") / 1e9
    except Exception:
        return float("inf")


def procesos_que_caben(n, gb_por_tarea=None, cfg=None, reserva=0.8):
    """Cuántos procesos en paralelo caben en la memoria libre (≤ n, mínimo 1), dejando un 20% de margen."""
    gb = gb_por_tarea or (cfg or {}).get("computo", {}).get("gb_por_proceso", GB_POR_PROCESO)
    libre = memoria_libre_gb()
    return max(1, min(n, int(reserva * libre / max(gb, 0.05)))), libre


def liberar_procesos():
    """Cierra los procesos en paralelo que joblib deja vivos "por si acaso" después de cada cálculo.
    Cada uno retiene ~0,5–1 GB; si quedan vivos entre celdas, el notebook puede quedarse sin memoria en un paso
    que ni siquiera es paralelo. Volver a abrirlos cuesta 1–3 s, mucho menos que una caída."""
    try:
        from joblib.externals.loky import reusable_executor as _re
        ex = getattr(_re, "_executor", None)
        if ex is not None:
            ex.shutdown(wait=True, kill_workers=True)
            _re._executor = None
    except Exception:
        pass
    import gc
    gc.collect()


def _es_falta_de_memoria(err):
    """True si el error (o su causa en el proceso hijo) es por falta de memoria."""
    txt = f"{type(err).__name__} {err}".lower()
    claves = ("memoryerror", "unable to allocate", "bad allocation", "bad_alloc", "out of memory", "terminatedworkererror",
              "killed", "cannot allocate")
    return isinstance(err, MemoryError) or any(k in txt for k in claves)


def en_paralelo(funcion, tareas, cfg=None, n_jobs=None, backend="loky", gb_por_tarea=None, combinar=None):
    """Ejecuta funcion(*t) para cada tupla t de `tareas` en varios procesos (joblib) y devuelve la lista de resultados.
    Con `combinar(acumulado, resultado)` los resultados se combinan a medida que llegan (en cualquier orden) y se
    devuelve solo el acumulado: la memoria no crece con el número de tareas (p. ej. sumas parciales grandes).

    Robusto frente a la memoria:
    * Antes de partir, limita el número de procesos a los que caben en la memoria libre (`gb_por_tarea` GB cada uno;
      por defecto `cfg['computo']['gb_por_proceso']` o 1,2 GB). En un PC con poca memoria libre corre con menos
      procesos en vez de caerse.
    * Si igual falta memoria (otro programa la ocupó), reintenta con la mitad de procesos, hasta llegar a 1 (en serie).
    Si joblib no está disponible o hay un solo núcleo, corre en serie. Los arreglos numpy grandes se comparten por
    memoria (memmap), no se copian, y cada proceso usa 1 hilo (numpy/scipy no compiten por los núcleos)."""
    tareas = list(tareas)

    def reunir(resultados):
        if combinar is None:
            return list(resultados)
        acum = None
        for r in resultados:
            acum = r if acum is None else combinar(acum, r)
        return acum

    n = min(n_jobs or n_nucleos(cfg), len(tareas))
    if n <= 1:
        return reunir(funcion(*t) for t in tareas)
    try:
        from joblib import Parallel, delayed
    except ImportError:
        return reunir(funcion(*t) for t in tareas)
    modo_salida = "list" if combinar is None else "generator_unordered"
    n_mem, libre = procesos_que_caben(n, gb_por_tarea, cfg)
    if n_mem < n:
        if n_mem not in _AVISOS_MEMORIA:          # se avisa una vez por cada límite distinto (no en cada cálculo)
            _AVISOS_MEMORIA.add(n_mem)
            print(f"  (memoria libre {libre:,.1f} GB: se usan {n_mem} procesos en paralelo en vez de {n})")
        n = n_mem
    while True:
        if n <= 1:
            return reunir(funcion(*t) for t in tareas)
        try:
            try:
                from joblib import parallel_config
                with parallel_config(backend=backend, inner_max_num_threads=1):
                    return reunir(Parallel(n_jobs=n, max_nbytes="1M", return_as=modo_salida)(delayed(funcion)(*t) for t in tareas))
            except ImportError:
                return reunir(Parallel(n_jobs=n, backend=backend, max_nbytes="1M")(delayed(funcion)(*t) for t in tareas))
        except Exception as err:
            if not _es_falta_de_memoria(err):
                raise
            n = max(1, n // 2)
            print(f"  AVISO: faltó memoria ({type(err).__name__}); se reintenta con {n} proceso(s)")
        finally:
            if backend == "loky":
                liberar_procesos()          # los procesos no quedan vivos reteniendo memoria entre celdas


class Cronometro:
    """Imprime mensajes con el tiempo transcurrido: c = Cronometro(); c("listo")."""

    def __init__(self):
        self.t0 = time.time()

    def __call__(self, msg):
        print(f"[{time.time() - self.t0:7.1f} s] {msg}", flush=True)


def miles(v, dec=0):
    """Número con separador de miles chileno: 1234567.8 -> '1.234.568'."""
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return "–"
    txt = f"{v:,.{dec}f}"
    return txt.replace(",", "X").replace(".", ",").replace("X", ".")


def mm(v):
    """Pesos a millones: 1.234.567.890 -> '1.234,6 MM'. Con montos chicos se agregan decimales para no mostrar '0,0 MM'
    (540.000 -> '0,54 MM'; 54.000 -> '0,054 MM')."""
    if v is None or not np.isfinite(v):
        return "–"
    x = v / 1e6
    return miles(x, 1 if abs(x) >= 1 or x == 0 else 2 if abs(x) >= 0.1 else 3) + " MM"


def pct(v, dec=1):
    return (miles(100 * v, dec) + "%") if v is not None and np.isfinite(v) else "–"


# --------------------------------------------------------------------------------------------- INTERMEDIOS
def ruta_trabajo(cfg, nombre):
    return os.path.join(cfg["carpetas"]["trabajo"], nombre)


def guardar(obj, cfg, nombre):
    """Guarda un resultado intermedio en la carpeta de trabajo según su extensión:
    .parquet (DataFrame o GeoDataFrame), .gpkg, .csv, .json, .npy, .pkl. Devuelve la ruta."""
    ruta = ruta_trabajo(cfg, nombre)
    ext = nombre.rsplit(".", 1)[-1].lower()
    if ext == "parquet":
        obj.to_parquet(ruta, index=False)
    elif ext == "gpkg":
        if os.path.exists(ruta):
            os.remove(ruta)
        obj.to_file(ruta, driver="GPKG")
    elif ext == "csv":
        obj.to_csv(ruta, index=False, encoding="utf-8-sig")
    elif ext == "json":
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=1, default=_json_default)
    elif ext == "npy":
        np.save(ruta, obj)
    elif ext == "pkl":
        with open(ruta, "wb") as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
    else:
        raise ValueError(f"extensión no soportada: {nombre}")
    return ruta


def guardar_si_hay(obj, cfg, nombre):
    """Guarda un resultado OPCIONAL si tiene datos; si no (None o vacío), borra la versión anterior para que ningún
    notebook siguiente use por error un resultado de otra corrida (p. ej. flujos de un origen que ya no se entrega)."""
    if obj is None or (hasattr(obj, "__len__") and len(obj) == 0):
        ruta = ruta_trabajo(cfg, nombre)
        if os.path.exists(ruta):
            os.remove(ruta)
        return None
    return guardar(obj, cfg, nombre)


def cargar(cfg, nombre):
    """Lee un resultado intermedio guardado con `guardar`. Si no existe, dice qué notebook hay que correr antes."""
    ruta = ruta_trabajo(cfg, nombre)
    if not os.path.exists(ruta):
        from .insumos import PRODUCIDO_POR, TITULOS
        nb = PRODUCIDO_POR.get(nombre)
        raise FileNotFoundError(f"No existe '{nombre}' en {cfg['carpetas']['trabajo']}. "
                                + (f"Corre primero el notebook {nb} · {TITULOS[nb]}." if nb else
                                   "Corre primero el notebook que lo genera (ver la tabla de flujo en LEEME.md)."))
    ext = nombre.rsplit(".", 1)[-1].lower()
    if ext == "parquet":
        try:
            return gpd.read_parquet(ruta)
        except Exception:
            return pd.read_parquet(ruta)
    if ext == "gpkg":
        return gpd.read_file(ruta)
    if ext == "csv":
        return pd.read_csv(ruta, encoding="utf-8-sig", low_memory=False)
    if ext == "json":
        with open(ruta, encoding="utf-8") as f:
            return json.load(f)
    if ext == "npy":
        return np.load(ruta)
    if ext == "pkl":
        with open(ruta, "rb") as f:
            return pickle.load(f)
    raise ValueError(nombre)


def existe(cfg, nombre):
    return os.path.exists(ruta_trabajo(cfg, nombre))


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (pd.Timestamp, pd.Period)):
        return str(o)
    return str(o)


def carpeta_salida(cfg, sub=""):
    ruta = os.path.join(cfg["carpetas"]["salidas"], sub)
    os.makedirs(ruta, exist_ok=True)
    return ruta
