# -*- coding: utf-8 -*-
"""Indicadores clave del estudio, cada uno con su lectura en palabras simples.

Cinco temas, calculados con los resultados que ya guardaron los notebooks (no se recalcula nada pesado):
  Ventas      tamaño, crecimiento real (total y a red constante), volumen vs ticket, estacionalidad, volatilidad,
              concentración, mezcla, productividad por m², calidad de los datos
  Mercado     población y gasto en salud, cuota de la red, cobertura, brechas, competencia
  Pacientes   cruce del RUT, alcance (t80), venta local, retención, multisede, afinidad, comunas de origen
  Modelo      error "sede nueva", sesgo, validación cruzada, machine learning, distancia, demanda flotante,
              competencia, tamaño
  Plan        venta nueva, crecimiento, canibalización, escenarios, primer año, concentración, cobertura, sitios
              propuestos, macrozonas

Todo es RELATIVO a los datos (porcentajes, razones, minutos): sirve igual con una red que vende 20 veces más o 20
veces menos, con 3 o con 30 sedes. Lo que no se puede calcular con los datos entregados (p. ej. crecimiento con menos
de 24 meses) simplemente no aparece. Las conclusiones en palabras se arman en `geoventas/conclusiones.py`.
"""
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd

from .utilidades import miles, pct

MESES = ["", "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
NOMBRE_FORMATO = {"clinica": "clínica", "centro_medico": "centro médico", "toma_muestras": "toma de muestras"}
NOMBRE_GRUPO = {"comp_clinica": "clinica", "comp_centro_medico": "centro_medico", "comp_laboratorio": "toma_muestras"}
PLURAL_FORMATO = {"clinica": "clínicas", "centro_medico": "centros médicos", "toma_muestras": "tomas de muestras"}


def cantidad_formato(n, f):
    """'1 clínica', '9 centros médicos'."""
    return f"{miles(n)} {NOMBRE_FORMATO.get(f, f) if n == 1 else PLURAL_FORMATO.get(f, f)}"
TEMAS = ["Ventas", "Mercado", "Entorno", "Influencia", "Pacientes", "Modelo", "Plan"]


@dataclass
class Metrica:
    tema: str
    clave: str
    nombre: str
    valor: object
    formato: str = "decimal"      # pesos | pct | var | pp | min | entero | decimal | veces | texto
    lectura: str = ""

    @property
    def texto(self):
        return formatear(self.valor, self.formato)


# --------------------------------------------------------------------------------------------- FORMATO
def _finito(x):
    return x is not None and not isinstance(x, str) and np.isscalar(x) and np.isfinite(x)


def pesos(v):
    """Pesos en palabras: 17.778.000.000 → '$17.778 millones'; 54.500.000 → '$54,5 millones'; 540.000 → '$540 mil'."""
    if not _finito(v):
        return "–"
    s = "−" if v < 0 else ""
    a = abs(v)
    if a >= 1e6:
        return f"{s}${miles(a / 1e6, 0 if a >= 1e8 else 1)} millones"
    if a >= 1e3:
        return f"{s}${miles(a / 1e3, 0)} mil"
    return f"{s}${miles(a, 0)}"


def con_signo(v, dec=1):
    if not _finito(v):
        return "–"
    return ("+" if v >= 0 else "−") + pct(abs(v), dec)


def formatear(v, f):
    if f == "texto" or isinstance(v, str):
        return str(v)
    if not _finito(v):
        return "–"
    return {"pesos": lambda: pesos(v), "pct": lambda: pct(v), "var": lambda: con_signo(v),
            "pp": lambda: ("+" if v >= 0 else "−") + miles(abs(100 * v), 1) + " pp",
            "min": lambda: f"{miles(v, 0 if v >= 10 else 1)} min", "entero": lambda: miles(v),
            "veces": lambda: f"{miles(v, 1)} veces", "decimal": lambda: miles(v, 2)}.get(f, lambda: miles(v, 2))()


class _Lista(list):
    """Lista de métricas con un atajo para agregar."""

    def __init__(self, tema):
        super().__init__()
        self.tema = tema

    def __call__(self, clave, nombre, valor, formato="decimal", lectura=""):
        if valor is None or (not isinstance(valor, str) and np.isscalar(valor) and not np.isfinite(valor)):
            return
        if isinstance(valor, (np.floating, np.integer)):
            valor = valor.item()
        self.append(Metrica(self.tema, clave, nombre, valor, formato, lectura))


def _nombre(nombres, s):
    return nombres.get(s, s) if nombres else s


def nombres_sedes(sedes_estudio):
    if sedes_estudio is None or "sede" not in sedes_estudio:
        return {}
    col = "nombre_visible" if "nombre_visible" in sedes_estudio else "nombre"
    return dict(zip(sedes_estudio["sede"], sedes_estudio[col].fillna(sedes_estudio["sede"])))


def _titulo(t):
    return str(t).title().replace(" De ", " de ").replace(" Del ", " del ")


# --------------------------------------------------------------------------------------------- VENTAS
def ventas(panel, vm, crec=None, v=None, sedes_estudio=None):
    """Indicadores de la serie de ventas (notebook 02). panel: sede × mes; vm: venta madura; crec: crecimiento anual;
    v: ventas estandarizadas (para la mezcla de líneas y previsión); sedes_estudio: nombres y m²."""
    L = _Lista("Ventas")
    nom = nombres_sedes(sedes_estudio)
    p = panel[panel["periodo"].astype(str).str.len() == 7]
    per = sorted(p["periodo"].unique())
    n = len(per)
    if not n:
        return L
    L("n_meses", "Meses de historia de ventas", n, "entero", f"de {per[0]} a {per[-1]}")
    u12 = per[-12:]
    a12 = per[-24:-12] if n >= 24 else []
    vt = p[p["periodo"].isin(u12)]
    venta12 = float(vt["monto_real"].sum())
    L("venta_12m", "Venta de los últimos 12 meses (pesos de hoy)", venta12, "pesos", f"{u12[0]} a {u12[-1]} · {pesos(venta12 / len(u12))} al mes")
    modelo = vm[vm["en_modelo"] == True] if "en_modelo" in vm else vm
    red = float(modelo["venta_mensual_madura"].sum())
    L("venta_madura_red", "Venta mensual en régimen de las sedes del modelo", red, "pesos",
      f"{len(modelo)} sedes · es la venta que calibra el modelo (sin meses atípicos, llevada a régimen)")
    if a12:
        va = p[p["periodo"].isin(a12)]
        base = float(va["monto_real"].sum())
        if base > 0:
            L("var_real_12m", "Crecimiento real de la red (12 meses vs los 12 anteriores)", venta12 / base - 1, "var", "sin inflación")
            veinticuatro = p[p["periodo"].isin(a12 + u12)]
            meses_con_venta = veinticuatro[veinticuatro["monto_real"] > 0].groupby("sede")["periodo"].nunique()
            const = meses_con_venta[meses_con_venta == 24].index
            if len(const) and len(const) < vt["sede"].nunique():
                b, a = va.loc[va["sede"].isin(const), "monto_real"].sum(), vt.loc[vt["sede"].isin(const), "monto_real"].sum()
                if b > 0:
                    L("var_real_12m_red_constante", "Crecimiento real a red constante (solo sedes abiertas los 24 meses)", a / b - 1, "var",
                      f"{len(const)} de {vt['sede'].nunique()} sedes")
            at12, ata = vt["atenciones"].sum(), va["atenciones"].sum()
            if at12 > 0 and ata > 0:
                L("var_atenciones_12m", "Variación de las atenciones (12 meses)", at12 / ata - 1, "var")
                L("var_ticket_real_12m", "Variación del ticket real (venta por atención, sin inflación)", (venta12 / at12) / (base / ata) - 1, "var")
                L("ticket_real_12m", "Ticket promedio de los últimos 12 meses", venta12 / at12, "pesos", "venta ÷ atenciones")
            dif = vt.groupby("sede")["monto_real"].sum().sub(va.groupby("sede")["monto_real"].sum(), fill_value=0)
            if len(dif) and dif.max() > 0:
                L("sede_mas_crece", "Sede que más aporta al crecimiento", _nombre(nom, dif.idxmax()), "texto", f"+{pesos(dif.max())} en 12 meses")
            if len(dif) and dif.min() < 0:
                L("sede_mas_cae", "Sede que más resta", _nombre(nom, dif.idxmin()), "texto", f"{pesos(dif.min())} en 12 meses")
    if crec is not None and "cagr_3a" in crec and "sede" in crec:
        fila = crec[crec["sede"] == "TOTAL RED"]
        if len(fila) and pd.notna(fila["cagr_3a"].iloc[0]):
            L("cagr_3a", "Crecimiento real anual compuesto (últimos 3 años completos)", float(fila["cagr_3a"].iloc[0]), "var")
    if "estacional" in p and n >= 24:
        est = p.groupby("mes")["estacional"].median().reindex(range(1, 13))
        if est.notna().all():
            alto, bajo = int(est.idxmax()), int(est.idxmin())
            L("estacionalidad_amplitud", "Diferencia entre el mes más fuerte y el más débil del año", float(est.max() - est.min()), "pct",
              f"más fuerte: {MESES[alto]} ({con_signo(est.max() - 1, 0)} sobre un mes promedio) · más débil: {MESES[bajo]} ({con_signo(est.min() - 1, 0)})")
            L("mes_alto", "Mes más fuerte", MESES[alto], "texto", con_signo(est.max() - 1, 0))
            L("mes_bajo", "Mes más débil", MESES[bajo], "texto", con_signo(est.min() - 1, 0))
    if "cv_mensual" in modelo and modelo["cv_mensual"].notna().any():
        L("volatilidad_mensual", "Variación típica de un mes a otro en una sede (sin estacionalidad)", float(modelo["cv_mensual"].median()), "pct",
          "coeficiente de variación mediano: cuánto se mueve la venta de un mes normal")
    s = vt.groupby("sede")["monto_real"].sum()
    s = s[s > 0].sort_values(ascending=False)
    if len(s):
        sh = s / s.sum()
        L("sede_principal", "Sede que más vende", _nombre(nom, sh.index[0]), "texto", f"{pct(sh.iloc[0])} de la venta de 12 meses")
        L("participacion_sede_principal", "Participación de la sede que más vende", float(sh.iloc[0]), "pct")
        if len(sh) >= 3:
            L("participacion_top3", "Participación de las 3 sedes que más venden", float(sh.iloc[:3].sum()), "pct")
        L("sedes_efectivas", "Número efectivo de sedes (1 ÷ índice de concentración)", float(1 / (sh ** 2).sum()), "decimal",
          f"{len(sh)} sedes con venta; si todas vendieran lo mismo daría {len(sh)}")
    if v is not None and len(v):
        vv = v[v["periodo"].isin(u12)]
        for col, txt in (("linea", "línea de servicio"), ("prevision", "previsión")):
            if col in vv and vv[col].nunique() > 1:
                m = vv.groupby(col)["monto_real"].sum()
                m = (m / m.sum()).sort_values(ascending=False)
                L(f"{col}_principal", f"{txt[0].upper() + txt[1:]} principal", str(m.index[0]), "texto",
                  f"{pct(m.iloc[0])} de la venta · le sigue {m.index[1]} ({pct(m.iloc[1])})")
                L(f"participacion_{col}_principal", f"Participación de la {txt} principal", float(m.iloc[0]), "pct")
                L(f"{col}_segunda", f"Segunda {txt}", str(m.index[1]), "texto", pct(m.iloc[1]))
    if sedes_estudio is not None and "m2" in sedes_estudio and "formato_modelo" in modelo:
        x = modelo.merge(sedes_estudio[["sede", "m2"]], on="sede", how="left")
        x["m2"] = pd.to_numeric(x["m2"], errors="coerce")
        x = x[(x["m2"] > 0) & (x["venta_mensual_madura"] > 0)]
        x["por_m2"] = x["venta_mensual_madura"] / x["m2"]
        peor_ratio, detalle = 0.0, None
        for f, g in x.groupby("formato_modelo"):
            L(f"venta_m2_{f}", f"Venta mensual por m²: {NOMBRE_FORMATO.get(f, f)}", float(g["por_m2"].median()), "pesos", f"mediana de {len(g)} sede(s)")
            if len(g) >= 2:
                r = g["por_m2"].max() / g["por_m2"].min()
                if r > peor_ratio:
                    peor_ratio = r
                    detalle = (f, g.loc[g["por_m2"].idxmax(), "sede"], g.loc[g["por_m2"].idxmin(), "sede"])
        if detalle:
            f, mejor, peor = detalle
            L("brecha_productividad", "Diferencia de venta por m² dentro de un mismo formato", float(peor_ratio), "veces",
              f"{_nombre(nom, mejor)} vs {_nombre(nom, peor)} ({NOMBRE_FORMATO.get(f, f)})")
            L("productividad_mejor", "Sede más productiva por m²", _nombre(nom, mejor), "texto", NOMBRE_FORMATO.get(f, f))
            L("productividad_peor", "Sede menos productiva por m²", _nombre(nom, peor), "texto", NOMBRE_FORMATO.get(f, f))
    # calidad de los datos: solo sedes del modelo (las estacionales o excluidas tienen meses vacíos por diseño)
    en_mod = set(modelo["sede"]) if "sede" in modelo else set(p["sede"])
    pm = p[p["sede"].isin(en_mod)]
    abiertos = pm[~pm["antes_de_abrir"].astype(bool)] if "antes_de_abrir" in pm else pm
    if "atipico" in abiertos:
        k = int(abiertos["atipico"].sum())
        L("pct_meses_atipicos", "Meses atípicos (picos o caídas sin explicación)", k / max(len(abiertos), 1), "pct", f"{k} de {len(abiertos)} meses-sede")
    if "faltante" in abiertos:
        L("meses_faltantes", "Meses sin dato con la sede abierta", int(abiertos["faltante"].sum()), "entero")
    if "quiebre" in pm:
        q = pm[pm["quiebre"].astype(bool)]
        L("quiebres", "Cambios de nivel detectados (quiebres)", len(q), "entero",
          ", ".join(f"{_nombre(nom, r.sede)} ({r.periodo})" for r in q.itertuples()) if len(q) else "ninguno")
        if len(q):
            # ¿un cambio COMÚN a la red? (varias sedes con quiebre en el mismo mes ± 1): suele ser precios, un cambio de
            # registro o un shock externo, no algo propio de cada sede
            meses = pd.PeriodIndex(q["periodo"], freq="M")
            mejor, n_mejor, en_comun = None, 0, None
            for m0 in meses.unique():
                cerca = np.array([abs((m - m0).n) <= 1 for m in meses])
                k = q.loc[cerca, "sede"].nunique()
                if k > n_mejor:
                    mejor, n_mejor, en_comun = m0, k, cerca
            if n_mejor >= max(3, 0.4 * len(en_mod)):
                L("quiebre_comun", "Cambio de nivel común a la red", str(mejor), "texto", f"{n_mejor} de {len(en_mod)} sedes, en el mismo mes ± 1")
                L("quiebre_comun_sedes", "Sedes con el cambio de nivel común", n_mejor, "entero")
                propios = q[~en_comun]
                L("quiebres_propios", "Cambios de nivel propios de una sede (fuera del cambio común)", len(propios), "entero",
                  ", ".join(f"{_nombre(nom, r.sede)} ({r.periodo})" for r in propios.itertuples()) or "ninguno")
    if "en_maduracion" in modelo:
        mad = modelo[modelo["en_maduracion"] == True]
        L("sedes_en_maduracion", "Sedes que aún no llegan a régimen", len(mad), "entero", ", ".join(_nombre(nom, s) for s in mad["sede"]) or "ninguna")
    return L


# --------------------------------------------------------------------------------------------- MERCADO
def mercado(ut, vm, comp=None):
    """Tamaño del mercado, cuota de la red, cobertura y competencia (con los resultados de 03, 04 y 02)."""
    L = _Lista("Mercado")
    pob, obj = float(ut["pob"].sum()), float(ut.get("pob_objetivo", pd.Series(0.0)).sum())
    L("poblacion", "Habitantes del área de estudio", pob, "entero", f"{miles(len(ut))} manzanas útiles")
    if obj > 0:
        L("poblacion_objetivo", "Personas del segmento objetivo (AB, C1a y C1b)", obj, "entero", f"{pct(obj / pob)} de la población")
    g = float(ut["gasto_salud_total"].sum()) if "gasto_salud_total" in ut else np.nan
    go = float(ut["gasto_salud_objetivo"].sum()) if "gasto_salud_objetivo" in ut else np.nan
    if _finito(g) and g > 0:
        L("gasto_salud_mes", "Gasto mensual en salud de los hogares del área", g, "pesos",
          f"del segmento objetivo: {pesos(go)} ({pct(go / g)})" if _finito(go) else "")
    modelo = vm[vm["en_modelo"] == True] if "en_modelo" in vm else vm
    red = float(modelo["venta_mensual_madura"].sum())
    if _finito(g) and g > 0 and red > 0:
        L("cuota_gasto_salud", "Venta de la red como % del gasto en salud del área", red / g, "pct",
          "indicativo: la venta incluye pacientes de fuera del área y pagos de isapres y seguros, no solo gasto de bolsillo")
        if _finito(go) and go > 0:
            L("cuota_gasto_objetivo", "Venta de la red como % del gasto en salud del segmento objetivo", red / go, "pct")
    if "min_a_cm_o_clinica" in ut and obj > 0:
        t = ut["min_a_cm_o_clinica"].replace(np.inf, np.nan)
        L("cobertura_objetivo_15min", "Segmento objetivo a ≤ 15 min (auto, punta) de un centro médico o clínica de la red",
          float(ut.loc[t <= 15, "pob_objetivo"].sum() / obj), "pct")
    if "brecha" in ut and obj > 0:
        b = ut["brecha"].astype(bool)
        pb = float(ut.loc[b, "pob_objetivo"].sum())
        comunas = ut.loc[b].groupby("comuna")["pob_objetivo"].sum().sort_values(ascending=False).head(3).index
        L("brecha_poblacion_objetivo", "Segmento objetivo en zonas de brecha (mucha demanda a más de 15 min)", pb, "entero",
          f"{miles(int(b.sum()))} manzanas" + (f" · sobre todo en {', '.join(_titulo(c) for c in comunas)}" if len(comunas) else ""))
        L("brecha_pct", "Parte del segmento objetivo en zonas de brecha", pb / obj, "pct")
        if len(comunas):
            L("brecha_comunas", "Comunas con más brecha", ", ".join(_titulo(c) for c in comunas), "texto")
    if comp is not None and "en_modelo" in comp:
        c = comp[comp["en_modelo"].astype(bool)]
        cuenta = c["grupo"].map(NOMBRE_GRUPO).value_counts() if "grupo" in c else pd.Series(dtype=int)
        L("competidores", "Competidores en el modelo", len(c), "entero", ", ".join(cantidad_formato(v, f) for f, v in cuenta.items()))
        if obj > 0:
            L("competidores_por_10mil_objetivo", "Competidores por cada 10.000 personas del segmento objetivo", len(c) / obj * 1e4, "decimal")
    return L


# --------------------------------------------------------------------------------------------- ENTORNO DE LAS SEDES
def entorno(res, informe=None, ref=15, ref_traslape=5):
    """Entorno de las sedes de la red (notebook 04): congestión, alcance, competencia, traslape, tipos de entorno."""
    L = _Lista("Entorno")
    if res is None or not len(res):
        return L
    informe = informe or {}
    fuera = informe.get("fuera_del_area") or []
    L("sedes_entorno", "Sedes de la red analizadas (base de puntos del levantamiento)", len(res), "entero",
      f"{len(fuera)} fuera del área de estudio: {', '.join(fuera)}" if fuera else "todas las sedes oficiales del maestro en el área")
    por_region = informe.get("fuera_por_region") or {}
    L("sedes_fuera_area", "Sedes del maestro fuera del área de estudio (otras regiones)", len(fuera), "entero",
      ", ".join(f"{v} en {k}" for k, v in por_region.items()) if por_region else ", ".join(fuera))
    nom = res.set_index("sede")["nombre_visible"]
    po = res.set_index("sede").get(f"pob_objetivo_{ref}min")
    if po is not None and po.notna().any():
        L("alcance_objetivo_mediana", f"Segmento objetivo a {ref} min en hora punta (mediana de las sedes)", float(po.median()), "entero")
        L("sede_mayor_alcance", f"Sede con más segmento objetivo a {ref} min (punta)", nom[po.idxmax()], "texto", f"{miles(po.max())} personas")
        L("sede_menor_alcance", f"Sede con menos segmento objetivo a {ref} min (punta)", nom[po.idxmin()], "texto", f"{miles(po.min())} personas")
    if "perdida_punta_objetivo" in res and res["perdida_punta_objetivo"].notna().any():
        p = res.set_index("sede")["perdida_punta_objetivo"]
        L("perdida_punta_mediana", f"Segmento objetivo a {ref} min que se pierde en hora punta (mediana de las sedes)", float(p.median()), "pct",
          "frente a la misma zona fuera de punta")
        L("sede_mas_congestion", "Sede a la que más le quita la hora punta", nom[p.idxmax()], "texto", f"pierde {pct(p.max(), 0)} de su segmento a {ref} min")
        L("perdida_punta_maxima", "Pérdida máxima por congestión", float(p.max()), "pct")
    for c, k in (("minutos_meta_auto_punta", "minutos_meta_punta"), ("minutos_meta_auto_valle", "minutos_meta_valle")):
        if c in res and res[c].notna().any():
            L(k, f"Minutos para reunir la meta del segmento objetivo · {'hora punta' if 'punta' in c else 'fuera de punta'} (mediana)",
              float(res[c].median()), "min")
    ct = res.set_index("sede").get(f"comp_total_{ref}min")
    if ct is not None and ct.notna().any():
        L("competidores_entorno_mediana", f"Competidores a {ref} min (mediana de las sedes)", float(ct.median()), "entero")
        L("sede_mas_competencia", f"Sede con más competencia a {ref} min", nom[ct.idxmax()], "texto", f"{miles(ct.max())} competidores")
    if "traslape_red" in res:
        t = res.set_index("sede")["traslape_red"]
        L("traslape_mediano", f"Segmento objetivo a {ref_traslape} min compartido con otra sede de la red (mediana)", float(t.median()), "pct")
        L("sedes_traslape_alto", f"Sedes que comparten más de la mitad de su zona inmediata ({ref_traslape} min)", int((t > 0.5).sum()), "entero",
          ", ".join(nom[s] for s in t[t > 0.5].sort_values(ascending=False).index))
        L("traslape_maximo", "Traslape máximo con otras sedes de la red", float(t.max()), "pct")
        L("sede_mayor_traslape", "Sede con más traslape", nom[t.idxmax()], "texto",
          f"{pct(t.max(), 0)}, sobre todo con {res.set_index('sede').loc[t.idxmax(), 'traslape_principal_con']}")
    mt = res.set_index("sede").get(f"poi_metro_{ref}min")
    if mt is not None:
        L("sedes_con_metro", f"Sedes con estaciones de metro a {ref} min", int((mt > 0).sum()), "entero", f"de {len(res)}")
    if "tipo_entorno" in res:
        c = res["tipo_entorno"].value_counts()
        L("tipos_entorno", "Tipos de entorno de las sedes", " · ".join(f"{v} {k.lower()}" for k, v in c.items()), "texto")
    return L


# --------------------------------------------------------------------------------------------- ZONAS DE INFLUENCIA MODELADAS
def influencia(r, sedes=None):
    """Zonas de influencia preliminares (notebook 04b): alcance de la red y de cada sede, punta vs fuera de punta,
    territorio propio y sensibilidad a β."""
    L = _Lista("Influencia")
    res, red = r["resumen"], r["red"]
    modo = r["modo_ref"]
    p = res[res["modo"] == modo].set_index("sede")
    if not len(p):
        return L
    nom = p["nombre_visible"] if "nombre_visible" in p else pd.Series(p.index, index=p.index)
    L("sedes_influencia", "Sedes de la red en el análisis de zonas de influencia", len(p), "entero", "base de puntos del levantamiento")
    rt = red[red["modo"] == modo]
    t80 = rt["t80_min"].dropna()
    if len(t80):
        L("t80_red_punta", "Minutos que reúnen el 80% de la demanda de toda la red (auto, hora punta)", float(t80.iloc[0]), "min")
    zona = rt[rt["zona"].isin(["primaria", "secundaria"])]
    if len(zona):
        L("pob_objetivo_zona_red", "Segmento objetivo dentro de la zona de influencia de la red (80% de su demanda)", float(zona["pob_objetivo"].sum()), "entero",
          f"{miles(zona['pob'].sum())} habitantes en {miles(zona['area_km2'].sum(), 0)} km²")
    if "auto_valle" in set(red["modo"]) and modo != "auto_valle":
        rv = red[red["modo"] == "auto_valle"]
        L("t80_red_valle", "Minutos que reúnen el 80% de la demanda de toda la red (fuera de punta)", float(rv["t80_min"].dropna().iloc[0]), "min")
        a_p = zona["area_km2"].sum()
        a_v = rv[rv["zona"].isin(["primaria", "secundaria"])]["area_km2"].sum()
        if a_p > 0:
            L("crecimiento_zona_valle", "Cuánto crece la zona de influencia de la red fuera de punta", float(a_v / a_p - 1), "pct")
    if "formato_modelo" in p:
        for f, g in p.groupby("formato_modelo"):
            L(f"t80_inf_{f}", f"Minutos que reúnen el 80% de la demanda (mediana): {NOMBRE_FORMATO.get(f, f)}", float(g["t80_min"].median()), "min", f"{len(g)} sede(s)")
    L("sede_mayor_alcance_inf", "Sede con mayor alcance (t80)", nom[p["t80_min"].idxmax()], "texto", f"{miles(p['t80_min'].max(), 0)} min")
    L("sede_menor_alcance_inf", "Sede más local (t80)", nom[p["t80_min"].idxmin()], "texto", f"{miles(p['t80_min'].min(), 0)} min")
    if "demanda_en_territorio_propio" in p:
        pr = p["demanda_en_territorio_propio"]
        L("propia_mediana", "Demanda de cada sede que viene de su territorio propio (mediana)", float(pr.median()), "pct",
          "territorio = donde es la sede de su formato que más captaría; el resto lo comparte con sedes del mismo formato")
        L("propia_minima", "Demanda desde su territorio propio: la sede que más comparte", float(pr.min()), "pct")
        L("sede_menos_propia", "Sede que más comparte su demanda con otras sedes de su formato", nom[pr.idxmin()], "texto",
          f"solo {pct(pr.min(), 0)} viene de su territorio propio")
    s = r.get("sensibilidad")
    if s is not None and len(s):
        red_s = s[s["sede"] == "RED"]
        if len(red_s):
            L("t80_red_rango", "Rango del t80 de la red si la gente viaja más o menos de lo supuesto (β ± 25%)",
              f"{miles(red_s['t80_min'].min(), 1)} a {miles(red_s['t80_min'].max(), 1)} min", "texto")
        sed = s[s["sede"] != "RED"].pivot_table(index="sede", columns="beta_x", values="t80_min")
        L("t80_rango_mediano", "Cuánto se mueve el t80 de una sede con β ± 25% (mediana)", float((sed.max(1) - sed.min(1)).median()), "min")
    return L


# --------------------------------------------------------------------------------------------- PACIENTES
def pacientes(resumen_origen=None, ind=None, fid=None, afin=None, od=None, nombres=None):
    """Origen de los pacientes (notebook 05): cruce del RUT, alcance de cada formato, retención, multisede, afinidad."""
    L = _Lista("Pacientes")
    r = resumen_origen or {}
    tipo = r.get("tipo")
    if tipo:
        L("tipo_origen", "Origen de los pacientes", {"rut": "RUT de cada atención", "zona": "venta por zona", "coordenadas": "coordenadas del domicilio",
                                                     "sin_origen": "no se entregó"}.get(tipo, tipo), "texto",
          f"calibración por {r.get('nivel', '')}" if r.get("nivel") else "")
    L("cruce_rut", "Venta ubicada en el domicilio o la empresa del paciente (cruce del RUT)", r.get("cruce"), "pct")
    L("pacientes_unicos", "Pacientes distintos", r.get("pacientes"), "entero", f"{miles(r['atenciones'])} atenciones" if r.get("atenciones") else "")
    if r.get("pacientes") and r.get("atenciones"):
        L("atenciones_por_paciente", "Atenciones por paciente en el periodo", r["atenciones"] / r["pacientes"], "decimal")
    L("pct_multisede", "Pacientes que usan 2 o más sedes", r.get("pct_multisede"), "pct")
    L("venta_en_zona_preliminar", "Venta real que cae dentro de la zona de influencia preliminar (mediana de las sedes)", r.get("en_zona_preliminar"), "pct",
      "la zona preliminar reúne por construcción el 80% de la demanda modelada: 80% es el calce perfecto")
    if ind is not None and len(ind) and "t80_min" in ind:
        for f, g in ind.dropna(subset=["t80_min"]).groupby("formato_modelo"):
            L(f"t80_{f}", f"Minutos que reúnen el 80% de la venta: {NOMBRE_FORMATO.get(f, f)}", float(g["t80_min"].median()), "min",
              f"{len(g)} sede(s)" + (f", de {miles(g['t80_min'].min(), 0)} a {miles(g['t80_min'].max(), 0)} min" if len(g) > 1 else ""))
        bandas = [c for c in ("% venta 0-5 min", "% venta 5-10 min", "% venta 10-15 min") if c in ind]
        if bandas and "venta_mensual_madura" in ind:
            w = ind["venta_mensual_madura"].fillna(0)
            L("venta_15min", "Venta que viene de manzanas a ≤ 15 min de su sede", float((ind[bandas].sum(1) * w).sum() / max(w.sum(), 1e-300)), "pct")
        x = ind.dropna(subset=["t80_min"])
        if len(x) > 1:
            L("sede_mas_local", "Sede más local (menor t80)", _nombre(nombres, x.loc[x["t80_min"].idxmin(), "sede"]), "texto", f"{miles(x['t80_min'].min(), 0)} min")
            L("sede_mas_regional", "Sede que atrae de más lejos (mayor t80)", _nombre(nombres, x.loc[x["t80_min"].idxmax(), "sede"]), "texto", f"{miles(x['t80_min'].max(), 0)} min")
    if fid is not None and len(fid) and "pacientes" in fid:
        w = fid["pacientes"].clip(lower=0)
        for col, clave, nombre in (("retención anual promedio", "retencion_anual", "Pacientes que vuelven al año siguiente"),
                                   ("% una sola atención", "pct_una_atencion", "Pacientes con una sola atención")):
            if col in fid and fid[col].notna().any():
                L(clave, nombre, float((fid[col] * w).sum() / max(w[fid[col].notna()].sum(), 1)), "pct")
    if afin is not None and len(afin) and "dimensión" in afin:
        g = afin[afin["dimensión"] == "GSE"].groupby("categoría")["índice de afinidad"].median().dropna()
        if len(g) > 1:
            L("afinidad_gse_max", "GSE más afín a la red", str(g.idxmax()), "texto", f"índice {miles(g.max(), 0)} (100 = igual que su peso en la población)")
            L("afinidad_gse_min", "GSE menos afín a la red", str(g.idxmin()), "texto", f"índice {miles(g.min(), 0)}")
            L("afinidad_gse_max_indice", "Índice de afinidad del GSE más afín", float(g.max()), "decimal")
    if od is not None and len(od) and "% del total de la red" in od:
        s = (od.set_index("comuna") if "comuna" in od.columns else od)["% del total de la red"].sort_values(ascending=False)
        s = s / s.sum()
        k50 = int(np.searchsorted(s.cumsum().values, 0.5) + 1)
        L("comunas_50pct", "Comunas que reúnen la mitad de la venta", k50, "entero", ", ".join(_titulo(c) for c in s.index[:k50][:6]))
        L("comuna_principal", "Comuna que más aporta", _titulo(s.index[0]), "texto", f"{pct(s.iloc[0])} de la venta con origen")
    return L


# --------------------------------------------------------------------------------------------- MODELO
def nivel_confianza(error_sede_nueva, desvio_cv=None):
    """'alta' | 'media' | 'baja' según el error "sede nueva" y la validación cruzada espacial."""
    if not _finito(error_sede_nueva):
        return None
    cv_ok = lambda u: desvio_cv is None or not _finito(desvio_cv) or desvio_cv >= u
    if error_sede_nueva <= 0.15 and cv_ok(0.6):
        return "alta"
    if error_sede_nueva <= 0.25 and cv_ok(0.4):
        return "media"
    return "baja"


def modelo(mod, val, aj=None, nombres=None):
    """Confiabilidad y lectura de los parámetros del modelo (notebook 06)."""
    from .modelo import FORMATOS, pesos_gse
    L = _Lista("Modelo")
    th, d = mod["th"], mod.get("d")
    e = val["error_pct"].abs()
    L("error_sede_nueva", "Error típico al predecir una sede como si fuera nueva (validación \"sede nueva\")", float(e.median()), "pct",
      f"{pct((e <= 0.25).mean(), 0)} de las sedes dentro de ±25%")
    L("sedes_dentro_25", "Sedes predichas dentro de ±25% como si fueran nuevas", float((e <= 0.25).mean()), "pct")
    L("sesgo_sede_nueva", "Sesgo de esa predicción (mediana con signo)", float(val["error_pct"].median()), "var", "positivo = tiende a sobreestimar")
    if len(val):
        peor = val.loc[e.idxmax()]
        L("sede_peor_predicha", "Sede que el modelo explica peor", _nombre(nombres, peor["sede"]), "texto", f"{con_signo(peor['error_pct'], 0)} como sede nueva")
        L("error_sede_peor", "Error de la sede peor explicada", float(peor["error_pct"]), "var")
    L("sigma_sede", "Incertidumbre propia de una sede nueva (σ, escala log)", mod.get("sd_log_sede"), "pct",
      "atractivo no observado de cada sitio (estacionamiento, equipo, convenios); se suma a los escenarios P10/P90")
    met = mod.get("metricas") or {}
    L("desvio_explicado", "Ajuste manzana por manzana (desvío explicado, dentro de la muestra)", met.get("desvio_explicado_unidades"), "pct")
    cv = mod.get("cv") or {}
    L("desvio_explicado_cv", "Ajuste en zonas que el modelo no vio (validación cruzada espacial)", cv.get("desvio_explicado_cv"), "pct",
      f"{cv.get('bloques')} bloques de manzanas vecinas" if cv.get("bloques") else "")
    b = mod.get("benchmark") or {}
    if _finito(cv.get("desvio_explicado_cv")) and _finito(b.get("desvio_explicado_cv")):
        L("ventaja_huff_vs_ml", "Huff menos machine learning (misma validación espacial)", cv["desvio_explicado_cv"] - b["desvio_explicado_cv"], "pp",
          f"gradient boosting: {pct(b['desvio_explicado_cv'])}")
    if met.get("venta_observada_total"):
        L("error_total", "Venta total predicha vs observada", met["venta_predicha_total"] / met["venta_observada_total"] - 1, "var")
    if aj is not None and len(aj) and aj["venta_observada"].sum() > 0:
        L("wape_sedes", "Error medio por sede dentro de la muestra (WAPE)", float((aj["venta_predicha"] - aj["venta_observada"]).abs().sum() / aj["venta_observada"].sum()), "pct")
    for f, nombre in enumerate(FORMATOS):
        beta = float(np.exp(th[5 + f]))
        L(f"vida_media_{nombre}", f"Minutos en que el atractivo cae a la mitad: {NOMBRE_FORMATO[nombre]}", np.log(2) / beta, "min",
          f"5 minutos más de viaje restan {pct(1 - np.exp(-5 * beta), 0)} del atractivo")
        L(f"perdida_5min_{nombre}", f"Atractivo que se pierde con 5 minutos más de viaje: {NOMBRE_FORMATO[nombre]}", 1 - np.exp(-5 * beta), "pct")
    if d is not None:
        pg = np.r_[1.0, np.exp(th[11:-1])]
        lam = float(np.exp(th[1]))
        Dt = d.G @ pg + lam * d.W
        if Dt.sum() > 0:
            L("demanda_flotante", "Parte de la demanda potencial que viene de trabajadores (población flotante)", float(lam * d.W.sum() / Dt.sum()), "pct",
              f"peso de un trabajador frente a un residente λ = {miles(lam, 2)}")
        presentes = set(np.asarray(d.fmt).tolist())
        for k, f in enumerate(FORMATOS):
            if k in presentes:
                r = float(np.exp(th[8 + k] - th[2 + k]))
                L(f"comp_relativa_{f}", f"Atractivo de un competidor frente a una sede propia: {NOMBRE_FORMATO[f]}", r, "veces",
                  "menos de 1: a igual distancia, Clínica Alemana atrae más")
        g = pesos_gse(th, d)
        for k, etiqueta in (("C1A", "C1a"), ("C1B", "C1b"), ("C2", "C2")):
            if k in g:
                L(f"peso_{k.lower()}", f"Peso de afinidad del GSE {etiqueta} (AB = 1)", float(g[k]), "decimal",
                  f"de cada $100 que gasta en salud, un hogar {etiqueta} pesa como ${miles(100 * g[k], 0)} de un hogar AB")
        if not np.allclose(d.z, 0):
            L("efecto_tamano", "Efecto del tamaño de la sede (γ)", float(th[-1]), "decimal",
              f"una sede 20% más grande tiene {con_signo(1.2 ** th[-1] - 1, 0)} de atractivo")
    conf = nivel_confianza(float(e.median()) if len(e) else np.nan, cv.get("desvio_explicado_cv"))
    if conf:
        L("confianza_modelo", "Confiabilidad del modelo", conf, "texto", "alta: error ≤ 15% y ≥ 60% explicado fuera de muestra · media: ≤ 25% y ≥ 40%")
    return L


# --------------------------------------------------------------------------------------------- PLAN
def plan(top, vm, evals=None, macro=None, prop=None, cobertura=None):
    """Plan de expansión (notebook 07): venta nueva, canibalización, escenarios, cobertura y sitios."""
    L = _Lista("Plan")
    modelo = vm[vm["en_modelo"] == True] if "en_modelo" in vm else vm
    red = float(modelo["venta_mensual_madura"].sum())
    L("n_sitios", "Ubicaciones recomendadas", 0 if top is None else len(top), "entero",
      "" if top is None or not len(top) else ", ".join(cantidad_formato(v, k) for k, v in top["formato"].value_counts().items()))
    if evals:
        for f, e in evals.items():
            if e is not None and "viable" in e:
                L(f"viables_{f}", f"Manzanas candidatas viables: {NOMBRE_FORMATO.get(f, f)}", int(e["viable"].sum()), "entero", f"de {miles(len(e))} evaluadas")
    if top is None or not len(top):
        return L
    neta, bruta, can = float(top["venta_neta"].sum()), float(top["venta_bruta"].sum()), float(top["canibalizacion"].sum())
    L("venta_neta_plan", "Venta nueva para la red con todo el plan (régimen, al mes)", neta, "pesos", f"{pesos(12 * neta)} al año")
    if red > 0:
        L("crecimiento_plan", "Crecimiento de la red si se abre todo el plan", neta / red, "pct", f"sobre {pesos(red)} al mes de hoy")
    if bruta > 0:
        L("canibalizacion_plan", "Venta de las sedes nuevas que sale de las actuales (canibalización)", can / bruta, "pct",
          f"{pesos(can)} de {pesos(bruta)} brutos al mes")
    if {"venta_neta_p10_marginal", "venta_neta_p90_marginal"} <= set(top.columns):
        p10, p90 = float(top["venta_neta_p10_marginal"].sum()), float(top["venta_neta_p90_marginal"].sum())
        L("plan_p10", "Venta nueva del plan, escenario conservador (P10, al mes)", p10, "pesos", "suma de los P10 de cada sitio: indicativo")
        L("plan_p90", "Venta nueva del plan, escenario optimista (P90, al mes)", p90, "pesos")
        r = (top["venta_neta_p90_marginal"] / top["venta_neta_p10_marginal"].where(top["venta_neta_p10_marginal"] > 0)).median()
        L("ancho_escenarios", "Amplitud típica de los escenarios de un sitio (P90 ÷ P10)", float(r), "veces")
    if {"venta_anio_1", "venta_anual_regimen"} <= set(top.columns) and top["venta_anual_regimen"].sum() > 0:
        a1 = float(top["venta_anio_1"].sum())
        L("venta_anio1_plan", "Venta nueva del primer año (si todo el plan abriera a la vez)", a1, "pesos",
          f"{pct(a1 / top['venta_anual_regimen'].sum(), 0)} de lo que venderá en régimen")
    mejor = top.loc[top["venta_neta"].idxmax()]
    L("mejor_sitio", "Ubicación con más venta nueva", f"{mejor.get('id_top', '')}: {NOMBRE_FORMATO.get(mejor['formato'], mejor['formato'])} en {_titulo(mejor['comuna'])}",
      "texto", f"{pesos(mejor['venta_neta'])} al mes")
    if len(top) >= 6 and neta > 0:
        L("concentracion_top5", "Parte del plan que aportan las 5 mejores ubicaciones", float(top["venta_neta"].nlargest(5).sum() / neta), "pct")
    com = top.groupby("comuna")["venta_neta"].sum().sort_values(ascending=False)
    L("comunas_plan", "Comunas con más venta nueva", ", ".join(_titulo(c) for c in com.index[:3]), "texto", f"{len(com)} comunas en el plan")
    for f, g in top.groupby("formato"):
        actual = modelo.loc[modelo["formato_modelo"] == f, "venta_mensual_madura"] if "formato_modelo" in modelo else pd.Series(dtype=float)
        if len(actual) and actual.median() > 0:
            L(f"relacion_formato_{f}", f"Venta nueva típica de un sitio frente a una sede actual: {NOMBRE_FORMATO.get(f, f)}",
              float(g["venta_neta"].median() / actual.median()), "veces", f"{pesos(g['venta_neta'].median())} vs {pesos(actual.median())} al mes")
    if cobertura:
        antes, despues = cobertura.get("antes"), cobertura.get("despues")
        L("cobertura_antes", "Segmento objetivo a ≤ 15 min de un centro médico o clínica: hoy", antes, "pct")
        L("cobertura_despues", "Segmento objetivo a ≤ 15 min de un centro médico o clínica: con el plan", despues, "pct")
        L("cobertura_personas", "Personas del segmento objetivo que el plan deja a ≤ 15 min", cobertura.get("personas_nuevas"), "entero")
    if macro is not None and len(macro):
        L("macrozonas", "Macrozonas para una clínica", len(macro), "entero",
          f"la mejor, en {str(macro['comunas'].iloc[0]).split(', ')[0].title()}" if "comunas" in macro else "")
    if prop is not None and len(prop) and "viable" in prop:
        rec = prop[prop["formato"] == prop["formato_recomendado"]] if "formato_recomendado" in prop else prop
        nv = int(rec["viable"].astype(bool).sum())
        L("propuestos_viables", "Sitios propuestos por la clínica que son viables", f"{nv} de {rec['id_sitio'].nunique() if 'id_sitio' in rec else len(rec)}", "texto",
          (f"el mejor: {rec.loc[rec['venta_neta'].idxmax(), 'nombre']} ({pesos(rec['venta_neta'].max())} al mes)" if "nombre" in rec and len(rec) else ""))
        L("propuestos_viables_n", "Número de sitios propuestos viables", nv, "entero")
    return L


def cobertura_plan(ut, top, Tcand, minutos=15.0):
    """Segmento objetivo a ≤ `minutos` de un centro médico o clínica de la red, hoy y con las ubicaciones del plan."""
    if "min_a_cm_o_clinica" not in ut or not len(top) or "col_T" not in top:
        return None
    obj = ut["pob_objetivo"].values.astype(float)
    hoy = ut["min_a_cm_o_clinica"].replace(np.inf, np.nan).fillna(1e9).values
    cols = top.loc[top["formato"].isin(["clinica", "centro_medico"]), "col_T"].dropna().astype(int).values
    despues = hoy.copy()
    if len(cols):
        t = np.asarray(Tcand[:, cols], dtype=np.float32)
        t[~np.isfinite(t)] = 1e9
        despues = np.minimum(hoy, t.min(1))
    tot = max(obj.sum(), 1e-300)
    a, b = obj[hoy <= minutos].sum(), obj[despues <= minutos].sum()
    return {"minutos": minutos, "antes": float(a / tot), "despues": float(b / tot), "personas_nuevas": float(b - a)}


# --------------------------------------------------------------------------------------------- SALIDAS
# Indicadores de la portada del informe ejecutivo (con nombre corto); los que no existan en la corrida se omiten
KPI_INFORME = [("venta_12m", "Venta de los últimos 12 meses (pesos de hoy)"), ("var_real_12m", "Crecimiento real (12 meses)"),
               ("venta_madura_red", "Venta mensual en régimen de la red"), ("cuota_gasto_salud", "Venta de la red / gasto en salud del área"),
               ("poblacion_objetivo", "Personas del segmento objetivo"), ("cobertura_objetivo_15min", "Segmento objetivo a ≤ 15 min de la red"),
               ("competidores", "Competidores en el modelo"), ("cruce_rut", "Venta ubicada con el RUT del paciente"),
               ("perdida_punta_mediana", "Segmento que pierden las sedes en hora punta"),
               ("error_sede_nueva", "Error típico \"sede nueva\""), ("confianza_modelo", "Confiabilidad del modelo"),
               ("n_sitios", "Ubicaciones recomendadas"), ("venta_neta_plan", "Venta nueva del plan (régimen, al mes)"),
               ("crecimiento_plan", "Crecimiento de la red con el plan"), ("canibalizacion_plan", "Canibalización del plan"),
               ("cobertura_despues", "Segmento objetivo a ≤ 15 min con el plan")]


def kpis(lista):
    """{nombre corto: valor en texto} para la portada del informe (solo los indicadores que existen)."""
    m = {x.clave: x for x in lista}
    return {nombre: m[k].texto for k, nombre in KPI_INFORME if k in m}


def tabla(lista):
    """DataFrame para mostrar o exportar: tema, indicador, valor (texto), valor numérico y lectura."""
    filas = [{"tema": m.tema, "indicador": m.nombre, "valor": m.texto,
              "valor_numerico": m.valor if not isinstance(m.valor, str) else np.nan, "lectura": m.lectura, "clave": m.clave} for m in lista]
    return pd.DataFrame(filas, columns=["tema", "indicador", "valor", "valor_numerico", "lectura", "clave"])


def como_dict(lista):
    return {m.clave: asdict(m) for m in lista}


def desde_dict(d):
    return [Metrica(**v) for v in (d or {}).values()]
